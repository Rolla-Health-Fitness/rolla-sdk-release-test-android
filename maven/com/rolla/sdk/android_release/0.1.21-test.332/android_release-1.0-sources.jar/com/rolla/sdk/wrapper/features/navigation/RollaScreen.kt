package com.rolla.sdk.wrapper.features.navigation

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaConfiguration
import com.rolla.sdk.wrapper.config.RollaDisabledModule

/**
 * SDK screens a host app can open directly via [Rolla.openScreen].
 *
 * This is a deliberate whitelist, not a general router surface. Each value is
 * a self-contained top-level screen that is safe to enter from outside the
 * SDK's own navigation: it loads its own data, and — opened directly — it is
 * the root of the SDK UI, so its back affordance returns the user to the
 * host app (never to an SDK Home they did not visit). Mid-flow screens
 * (onboarding, consent, activity tracking) are intentionally not listed —
 * they carry flow state a direct entry would break.
 */
enum class RollaScreen(val rawValue: String) {
    /**
     * The activity history list — every recorded activity with month/day
     * filtering; activities open their detail page from here.
     */
    ACTIVITY_HISTORY("activityHistory"),

    /** The goals editor, where the user enables and adjusts their goals. */
    GOALS("goals"),

    /**
     * The SDK Home screen. Use it to bring the SDK back to its regular entry
     * point after a previous open made another screen the root — no engine
     * restart needed. Home keeps its usual affordances, such as the
     * back-to-host button.
     */
    HOME("home"),

    /**
     * The insights feed. Requires the insights module to be enabled: opening
     * it while [RollaDisabledModule.INSIGHTS] is in
     * [RollaConfiguration.disabledModules] resolves as
     * [RollaOpenScreenStatus.SCREEN_DISABLED].
     */
    INSIGHTS("insights"),

    /**
     * No navigation at all: show the SDK UI exactly as the user left it — the
     * last opened screen while the engine stays alive, or Home on a fresh
     * engine. Behaves like [Rolla.show] but reports a typed result; since
     * nothing navigates, it always resolves as
     * [RollaOpenScreenStatus.OPENED].
     */
    RESUME("resume"),
}
