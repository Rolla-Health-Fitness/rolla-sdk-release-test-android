package com.rolla.sdk.wrapper

import android.util.Log
import java.time.Instant
import java.time.OffsetDateTime
import java.util.Date

/**
 * The terminal outcome of a headless [Rolla.sync] call.
 *
 * A sync connects the user's primary data source and uploads anything new,
 * with no SDK UI. The outcome is always one of these.
 */
enum class RollaSyncOutcome(val rawValue: String) {
    /** The sync ran to completion. [RollaSyncResult.hasNewData] says whether anything new was uploaded. */
    SUCCESS("success"),

    /** Some data uploaded before an error stopped the rest. Reserved; not emitted today. */
    PARTIAL("partial"),

    /** Nothing was synced and that's expected — see [RollaSyncResult.skipReason]. Not an error. */
    SKIPPED("skipped"),

    /** The sync started but failed — see [RollaSyncResult.error]. */
    FAILURE("failure"),

    /** The SDK returned an outcome this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncOutcome =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/** Which data source a headless sync ran against. */
enum class RollaSyncSource(val rawValue: String) {
    /** The Rolla band (BLE). */
    BAND("band"),

    /** Apple HealthKit (not applicable on Android, present for parity). */
    APPLE_HEALTH("appleHealth"),

    /** Android Health Connect. */
    HEALTH_CONNECT("healthConnect"),

    /** Garmin (syncs server-side via OAuth). */
    GARMIN("garmin"),

    /** Oura (syncs server-side via OAuth). */
    OURA("oura"),

    /** The active source could not be determined. */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncSource =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Why a headless sync did nothing (only set when [RollaSyncResult.outcome] is
 * [RollaSyncOutcome.SKIPPED]).
 */
enum class RollaSyncSkipReason(val rawValue: String) {
    /** The user's primary source is the band, but no band is connected/known. */
    NO_BAND_CONNECTED("noBandConnected"),

    /** A sync was already in progress, so this call was a no-op. */
    ALREADY_IN_PROGRESS("alreadyInProgress"),

    /** The user's primary source syncs server-side (Garmin/Oura). */
    SERVER_SIDE_SOURCE("serverSideSource"),

    /**
     * The user's primary source needs a platform permission that has not been
     * granted (e.g. Health Connect read authorization). The host should request
     * the permission before retrying.
     */
    PERMISSIONS_REQUIRED("permissionsRequired"),

    /** The SDK is not initialized. */
    NOT_INITIALIZED("notInitialized"),

    /** The device is offline. */
    OFFLINE("offline"),

    /** The SDK returned a reason this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncSkipReason =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Result of [Rolla.sync].
 *
 * [hasNewData] is meaningful only for [RollaSyncOutcome.SUCCESS] /
 * [RollaSyncOutcome.PARTIAL]; [skipReason] is set only for
 * [RollaSyncOutcome.SKIPPED]; [error] only for [RollaSyncOutcome.FAILURE].
 */
data class RollaSyncResult(
    val outcome: RollaSyncOutcome,
    val hasNewData: Boolean,
    val source: RollaSyncSource,
    val lastSyncAt: Date? = null,
    val skipReason: RollaSyncSkipReason? = null,
    val error: String? = null
) {
    /** Whether the sync ran to completion (success or partial). */
    val didRun: Boolean
        get() = outcome == RollaSyncOutcome.SUCCESS || outcome == RollaSyncOutcome.PARTIAL

    companion object {
        private const val TAG = "RollaSync"

        /**
         * Build a result from the method-channel wire map
         * `{ "outcome": String, "hasNewData": Boolean, "source": String,
         *    "lastSyncAt": String?, "skipReason": String?, "error": String? }`.
         * Unknown enum strings map to their `UNKNOWN` case so older host
         * integrations keep working.
         */
        fun fromResponse(response: Any?): RollaSyncResult {
            val map = response as? Map<*, *>
                ?: return RollaSyncResult(
                    outcome = RollaSyncOutcome.UNKNOWN,
                    hasNewData = false,
                    source = RollaSyncSource.UNKNOWN
                )
            val outcome = RollaSyncOutcome.fromRawValue(map["outcome"] as? String)
            val hasNewData = map["hasNewData"] as? Boolean ?: false
            val source = RollaSyncSource.fromRawValue(map["source"] as? String)
            val skipReason = (map["skipReason"] as? String)?.let { RollaSyncSkipReason.fromRawValue(it) }
            val error = map["error"] as? String
            val lastSyncAt = (map["lastSyncAt"] as? String)?.let { parseIso8601(it) }
            return RollaSyncResult(
                outcome = outcome,
                hasNewData = hasNewData,
                source = source,
                lastSyncAt = lastSyncAt,
                skipReason = skipReason,
                error = error
            )
        }

        /**
         * Parse an ISO-8601 UTC timestamp; returns null on any parse failure.
         *
         * Uses java.time (available via core-library desugaring, already a
         * project prerequisite) so 0/3/6/9 fractional-second digits all parse to
         * the correct instant. A lenient SimpleDateFormat would silently misread
         * microsecond input (Dart's `toIso8601String()` emits 6 fractional
         * digits whenever the DateTime carries sub-millisecond precision), so it
         * is deliberately NOT used here.
         */
        private fun parseIso8601(raw: String): Date? {
            // Instant.parse handles the 'Z' (Zulu) form Dart emits; fall back to
            // OffsetDateTime for an explicit numeric offset (e.g. "+00:00").
            try {
                return Date.from(Instant.parse(raw))
            } catch (_: Exception) {
                // try offset form
            }
            try {
                return Date.from(OffsetDateTime.parse(raw).toInstant())
            } catch (_: Exception) {
                // unparseable
            }
            Log.w(TAG, "Could not parse lastSyncAt: $raw")
            return null
        }
    }
}
