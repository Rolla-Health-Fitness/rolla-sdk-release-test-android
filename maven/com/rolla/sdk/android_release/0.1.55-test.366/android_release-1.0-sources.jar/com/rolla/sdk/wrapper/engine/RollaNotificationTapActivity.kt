package com.rolla.sdk.wrapper.engine

import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import com.rolla.sdk.wrapper.features.notifications.RollaNotificationTarget

/**
 * Tap target of the SDK's own ongoing-workout notifications. An SDK-internal
 * component, public only because the manifest declares it by name — not host
 * API.
 *
 * It draws nothing and finishes at once, deciding the tap at tap time: while
 * the SDK UI is open it brings that UI to the front
 * ([RollaFlutterActivity.bringToFront]); otherwise it forwards the tap to the
 * host's launcher activity. Sending the tap straight to the launcher instead
 * would let a `singleTask` launcher take it by destroying every activity above
 * itself — the SDK activity included — while the cached engine keeps the SDK
 * page mounted.
 *
 * Task placement: a notification PendingIntent starts with no source activity,
 * so Android forces `FLAG_ACTIVITY_NEW_TASK` and places this activity by task
 * affinity. It keeps the default (package) affinity on purpose: in a host whose
 * activities use the default affinity it lands in the host's task, directly on
 * top of the SDK activity. In a host whose launcher declares
 * `android:taskAffinity=""` (every Flutter host) or a custom affinity, it lands
 * in its own transient task instead — which is why the re-front is started from
 * the SDK activity's own context rather than from here, and why the forward
 * path relies on the launcher intent's own `NEW_TASK` resolution to reach the
 * host's task.
 *
 * Android 12's notification-trampoline restriction covers services and
 * broadcast receivers only; an activity trampoline is permitted.
 *
 * Host contract: while the SDK UI is open the host receives no tap for these
 * notifications — the SDK UI is already on screen, so there is nothing to
 * route. With it closed, or the app not running, the host's launcher receives
 * the intent every Rolla notification tap delivers: its launch intent with
 * action [RollaNotificationTarget.TAP_ACTION] and the notification's `payload`
 * extra, so [com.rolla.sdk.wrapper.Rolla.notificationTarget] and cold-start
 * routing resolve it as usual.
 */
class RollaNotificationTapActivity : Activity() {

    companion object {
        /**
         * The tap PendingIntent for the SDK notification [notificationId],
         * carrying [payload] for the host's [RollaNotificationTarget] resolver.
         * The request code is offset from the notification id — see
         * [RollaNotificationTarget.TAP_REQUEST_CODE_BASE].
         */
        internal fun pendingIntent(context: Context, notificationId: Int, payload: String): PendingIntent {
            val intent = Intent(context, RollaNotificationTapActivity::class.java)
                .putExtra(RollaNotificationTarget.PAYLOAD_EXTRA, payload)
            return PendingIntent.getActivity(
                context,
                RollaNotificationTarget.TAP_REQUEST_CODE_BASE + notificationId,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // The API < 34 path runs overridePendingTransition in finish()
            // instead — either way the trampoline's own close never animates.
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        }
        // A recreated instance must never replay a tap.
        if (savedInstanceState == null && !RollaFlutterActivity.bringToFront()) {
            forwardToLauncher()
        }
        finish()
    }

    override fun finish() {
        super.finish()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }

    private fun forwardToLauncher() {
        // Keeps the flags the launch intent comes with: its NEW_TASK resolves
        // the host's task from wherever this activity was placed.
        val launcher = packageManager.getLaunchIntentForPackage(packageName) ?: return
        // Load-bearing: on ACTION_MAIN Android drops the tap intent (extras
        // included) whenever the task already exists — see TAP_ACTION.
        launcher.action = RollaNotificationTarget.TAP_ACTION
        intent.getStringExtra(RollaNotificationTarget.PAYLOAD_EXTRA)?.let {
            launcher.putExtra(RollaNotificationTarget.PAYLOAD_EXTRA, it)
        }
        startActivity(launcher)
    }
}
