package com.rolla.sdk.wrapper

data class RollaConfiguration(
    val token: String,
    val partnerId: String,
    val refreshToken: String? = null,
    val tokenExpiresIn: Int? = null,
    val userId: String? = null,
    val environment: String = "rnd",
    val disabledModules: Set<RollaDisabledModule> = emptySet(),
    val branding: RollaBranding? = null,
    val showSettingsButton: Boolean = true,
)
