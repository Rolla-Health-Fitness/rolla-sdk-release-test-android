package com.rolla.sdk.wrapper.features.navigation

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaConfiguration
import com.rolla.sdk.wrapper.config.RollaDisabledModule

/**
 * Outcome of a [Rolla.openScreen] request.
 *
 * Every outcome is one of these typed statuses — the call never throws and
 * never fails silently.
 */
enum class RollaOpenScreenStatus(val rawValue: String) {
    /**
     * The SDK UI is on the requested screen. The screen sits on top of the
     * SDK Home screen, so back returns to Home and the usual close
     * affordances apply from there.
     */
    OPENED("opened"),

    /**
     * The SDK session is not initialized. [Rolla.openScreen] configures the
     * SDK itself before navigating, so this indicates the configuration did
     * not produce a usable session (e.g. it was rejected).
     */
    NOT_INITIALIZED("notInitialized"),

    /**
     * The requested screen belongs to a module the host disabled via
     * [RollaConfiguration.disabledModules] (e.g. [RollaScreen.INSIGHTS] with
     * [RollaDisabledModule.INSIGHTS]). Nothing was opened.
     */
    SCREEN_DISABLED("screenDisabled"),

    /**
     * A mandatory startup step (onboarding, consent, permissions, or
     * data-source connection) is in front of the user. The SDK kept that
     * step in place instead of navigating; the request is not retried.
     */
    BLOCKED_BY_GATE("blockedByGate"),

    /**
     * The SDK UI could not be shown or did not become ready in time to
     * perform the navigation — the host activity was finishing, or the SDK's
     * home screen never mounted after initialization. Nothing was opened.
     */
    UI_UNAVAILABLE("uiUnavailable"),

    /**
     * A newer [Rolla.openScreen] request replaced this one while waiting for
     * the SDK UI to become ready. Only the latest request is honored.
     */
    SUPERSEDED("superseded"),

    /**
     * The navigation request could not be delivered or its response could
     * not be understood — an internal error or a build mismatch between this
     * wrapper and the SDK engine. Should not occur.
     */
    UNKNOWN_ERROR("unknownError");

    companion object {
        /** Map a wire string ([rawValue]) to a status; unknown values map to [UNKNOWN_ERROR]. */
        fun fromRawValue(raw: String?): RollaOpenScreenStatus =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN_ERROR

        /**
         * Build a status from the method-channel wire map `{ "status": String }`.
         * Anything unparseable maps to [UNKNOWN_ERROR].
         */
        fun fromResponse(response: Any?): RollaOpenScreenStatus =
            fromRawValue((response as? Map<*, *>)?.get("status") as? String)
    }
}
