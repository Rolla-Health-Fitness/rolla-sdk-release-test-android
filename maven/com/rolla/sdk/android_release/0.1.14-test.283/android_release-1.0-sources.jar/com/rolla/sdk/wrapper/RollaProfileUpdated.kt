package com.rolla.sdk.wrapper

/**
 * Payload of [RollaListener.onProfileUpdated].
 *
 * Carries ONLY the fields that changed, as a sparse map — nothing that didn't
 * change is re-sent. Hosts inspect [changedFields] for the keys they care
 * about. Values are plain JSON types; units live in the key names.
 *
 * Documented keys per source of the update:
 * - profile details edit: `birthdate` (ISO date string), `gender`, `heightCm`,
 *   `weightKg`, `units`, `username`, `country`, `cityId`, `language`,
 *   `timezone`, `maxHeartRate`
 * - weight log (add/edit): `weightKg`, `timestamp` (epoch)
 * - blood-pressure log (add/edit): `bloodPressureSystolic`,
 *   `bloodPressureDiastolic`, `timestamp` (epoch)
 *
 * New keys may be added over time; ignore keys you don't know.
 */
data class RollaProfileUpdated(
    val changedFields: Map<String, Any?>
) {
    companion object {
        /** Build from the method-channel wire map; a malformed payload never throws. */
        fun fromResponse(response: Any?): RollaProfileUpdated {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            val fields = (map["changedFields"] as? Map<*, *>)
                ?.entries
                ?.mapNotNull { (k, v) -> (k as? String)?.let { it to v } }
                ?.toMap() ?: emptyMap()
            return RollaProfileUpdated(changedFields = fields)
        }
    }
}
