package com.rolla.sdk.wrapper

interface RollaListener {
    fun onRollaClosed(rolla: Rolla, reason: RollaCloseReason) {}
    fun onRollaError(rolla: Rolla, error: RollaError) {}

    /**
     * Called when the SDK successfully refreshes tokens internally.
     *
     * Use this to sync your app's token storage with the SDK's refreshed tokens.
     *
     * @param rolla The Rolla instance that refreshed the token.
     * @param token The new access token.
     * @param refreshToken The new refresh token, if provided.
     * @param expiresIn Time in seconds until the new access token expires, if known.
     */
    fun onTokenRefreshed(rolla: Rolla, token: String, refreshToken: String?, expiresIn: Int?) {}

    /**
     * Called when the SDK's internal token refresh fails and the host app needs to provide new tokens.
     *
     * When this is called, obtain fresh tokens from your auth backend and push them
     * to the SDK via [Rolla.updateToken].
     *
     * @param rolla The Rolla instance that needs fresh tokens.
     */
    fun onTokenExpired(rolla: Rolla) {}

    /**
     * Called when a headless [Rolla.syncHealthData] reaches a terminal outcome.
     *
     * Delivers the same [RollaSyncResult] the `syncHealthData` callback receives,
     * giving a host one central place to observe sync results — for example, to
     * refresh its own UI. It fires only for a terminal outcome: transport
     * failures (e.g. the engine could not start) come back through the
     * `syncHealthData` callback as a failed Result and do not fire this method.
     *
     * @param rolla The Rolla instance that ran the sync.
     * @param result The terminal sync result.
     */
    fun onSyncCompleted(rolla: Rolla, result: RollaSyncResult) {}

    /**
     * Called when an activity completed inside the SDK UI reaches a lifecycle
     * phase: [RollaActivityPhase.FINISHED] (saved in-SDK — instant), then
     * [RollaActivityPhase.UPLOADED] (confirmed by the backend) or
     * [RollaActivityPhase.UPLOAD_FAILED] (the upload gave up permanently).
     *
     * [RollaCompletedActivity.source] distinguishes live-tracked activities
     * from manually logged ones. Key idempotency on `(activityId, phase)` —
     * `UPLOADED`/`UPLOAD_FAILED` can re-fire across retries. Distinct from
     * [onRollaClosed]: it fires whether or not the user then closes the SDK
     * UI, and `UPLOADED` can arrive after close (uploads finish in the
     * background while the engine is alive).
     *
     * @param rolla The Rolla instance delivering the event.
     * @param activity The activity payload, including its lifecycle phase.
     */
    fun onActivityCompleted(rolla: Rolla, activity: RollaCompletedActivity) {}

    /**
     * Called when a sync completes inside the SDK UI: the auto-sync on open,
     * the sync on return from background while the SDK is showing, and the
     * in-app manual refresh.
     *
     * Distinct from [onSyncCompleted], which fires only for host-initiated
     * headless [Rolla.syncHealthData] calls — the payload type is shared so a
     * host reads one result shape for both directions. On a successful band /
     * Apple Health / Health Connect UI sync, [RollaSyncResult.syncedData]
     * carries the same per-stream summary breakdown as the headless result
     * (samples are never included on UI syncs). It is null when there is
     * nothing attributable to report: failure events, Garmin/Oura content-only
     * refreshes, syncs that recorded no data, and syncs that overlapped
     * another sync (concurrent UI syncs or a concurrent headless sync) — never
     * wrong or double-reported data.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param result The terminal result of the UI sync.
     */
    fun onUiSyncCompleted(rolla: Rolla, result: RollaSyncResult) {}

    /**
     * Called when the user pairs a band inside the SDK UI — the band is
     * persisted locally and registered with the backend at this moment.
     * Auto-reconnects and login restores do not fire this.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param band The paired band (name, MAC, device type, RSSI).
     */
    fun onBandPaired(rolla: Rolla, band: RollaBandInfo) {}

    /**
     * Called when the user unpairs the band inside the SDK UI (confirmed by
     * the backend). A band unpaired remotely — from another device — is
     * reconciled silently and does not fire this.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param band The unpaired band (MAC plus last cached battery/firmware/serial).
     */
    fun onBandUnpaired(rolla: Rolla, band: RollaBandInfo) {}

    /**
     * Called when the SDK observes the user's primary data source change —
     * committed inside the SDK UI, or discovered on a profile/connections
     * refresh (changes made server-side or on another device surface on the
     * next refresh, not instantly).
     *
     * @param rolla The Rolla instance delivering the event.
     * @param change The previous and current primary source.
     */
    fun onPrimarySourceChanged(rolla: Rolla, change: RollaPrimarySourceChanged) {}

    /**
     * Called when the user saves goal changes inside the SDK UI (each toggle
     * backend-confirmed). One call per save, carrying both the toggled goals
     * and the resulting enabled set.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param change The toggled goals and the enabled set after the save.
     */
    fun onGoalsChanged(rolla: Rolla, change: RollaGoalsChanged) {}

    /**
     * Called when the user updates profile data inside the SDK UI — a profile
     * details edit, a weight log, or a blood-pressure log — with only the
     * changed fields. See [RollaProfileUpdated] for the key vocabulary.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param update The sparse map of changed fields.
     */
    fun onProfileUpdated(rolla: Rolla, update: RollaProfileUpdated) {}
}
