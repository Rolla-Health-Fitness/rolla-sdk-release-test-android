package com.rolla.sdk.wrapper

/**
 * Payload of [RollaListener.onBandPaired] and [RollaListener.onBandUnpaired].
 *
 * One shared shape for both events; which fields are populated depends on the
 * moment the event fires:
 * - **paired**: [name], [macAddress], [deviceType], [rssi] — firmware/battery
 *   are read from the band only seconds after pairing, so they are not part
 *   of the pairing payload.
 * - **unpaired**: [macAddress] plus the last cached [batteryPercent],
 *   [firmwareVersion], [serialNumber]; the band name is not cached locally,
 *   so it is absent.
 */
data class RollaBandInfo(
    /** The band's MAC address — the stable identifier. */
    val macAddress: String,
    /** Advertised band name (pairing only). */
    val name: String? = null,
    /** Signal strength at pairing time (pairing only). */
    val rssi: Int? = null,
    /** Device type reported by the BLE layer (pairing only). */
    val deviceType: String? = null,
    /** Last known battery percent (unpairing only, cached). */
    val batteryPercent: Int? = null,
    /** Last known firmware version (unpairing only, cached). */
    val firmwareVersion: String? = null,
    /** Last known serial number (unpairing only, cached). */
    val serialNumber: String? = null
) {
    companion object {
        /** Build from the method-channel wire map; a malformed payload never throws. */
        fun fromResponse(response: Any?): RollaBandInfo {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            return RollaBandInfo(
                macAddress = map["macAddress"] as? String ?: "",
                name = map["name"] as? String,
                rssi = (map["rssi"] as? Number)?.toInt(),
                deviceType = map["deviceType"] as? String,
                batteryPercent = (map["batteryPercent"] as? Number)?.toInt(),
                firmwareVersion = map["firmwareVersion"] as? String,
                serialNumber = map["serialNumber"] as? String
            )
        }
    }
}
