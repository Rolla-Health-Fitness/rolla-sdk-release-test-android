package com.rolla.sdk.wrapper

import android.util.Log
import java.time.Instant
import java.time.OffsetDateTime
import java.util.Date

/**
 * The lifecycle phase an in-SDK activity has reached when
 * [RollaListener.onActivityCompleted] fires.
 *
 * One activity emits up to three events, keyed by phase. Treat
 * `(activityId, phase)` as the idempotency key: [UPLOADED] and [UPLOAD_FAILED]
 * can re-fire across retries (e.g. the engine died after the server accepted
 * an upload but before the pending marker cleared).
 */
enum class RollaActivityPhase(val rawValue: String) {
    /**
     * Saved/finished locally inside the SDK. Instant signal — the backend has
     * NOT confirmed it yet, so anything the host does now may need reconciling
     * on [UPLOAD_FAILED].
     */
    FINISHED("finished"),

    /**
     * The backend confirmed the activity (the user's source of truth). May
     * arrive much later than [FINISHED] when the first upload attempt failed
     * and a later in-SDK sync retried it.
     */
    UPLOADED("uploaded"),

    /**
     * The upload gave up permanently — the activity is not in the backend and
     * will no longer be retried. Reconcile whatever was done on [FINISHED].
     */
    UPLOAD_FAILED("uploadFailed"),

    /** The SDK sent a phase this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaActivityPhase =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/** How a completed activity was produced inside the SDK. */
enum class RollaActivitySource(val rawValue: String) {
    /** Recorded live with the tracker (band or phone sensors). */
    ROLLA("rolla"),

    /** Entered manually by the user. */
    MANUAL("manual"),

    /** The source could not be determined (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaActivitySource =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Payload of [RollaListener.onActivityCompleted].
 *
 * Field vocabulary mirrors the Partner API activity summary.
 */
data class RollaCompletedActivity(
    val activityId: String,
    val phase: RollaActivityPhase,
    val source: RollaActivitySource,
    val catalogId: String? = null,
    /** Base activity type (e.g. `walk`, `run`, `cycling`, `cardio`). */
    val type: String? = null,
    /** `outdoor` or `indoor`. */
    val environment: String? = null,
    /** Catalog category (e.g. `cardio`). */
    val category: String? = null,
    val totalDurationS: Int? = null,
    val totalDistanceM: Double? = null,
    val totalCalories: Double? = null,
    val startTime: Date? = null,
    val endTime: Date? = null
) {
    companion object {
        private const val TAG = "RollaCompletedActivity"

        /**
         * Build from the method-channel wire map. Unknown enum strings map to
         * their `UNKNOWN` case so older host integrations keep working; a
         * malformed payload never throws.
         */
        fun fromResponse(response: Any?): RollaCompletedActivity {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            return RollaCompletedActivity(
                activityId = map["activityId"] as? String ?: "",
                phase = RollaActivityPhase.fromRawValue(map["phase"] as? String),
                source = RollaActivitySource.fromRawValue(map["source"] as? String),
                catalogId = map["catalogId"] as? String,
                type = map["type"] as? String,
                environment = map["environment"] as? String,
                category = map["category"] as? String,
                totalDurationS = (map["totalDurationS"] as? Number)?.toInt(),
                totalDistanceM = (map["totalDistanceM"] as? Number)?.toDouble(),
                totalCalories = (map["totalCalories"] as? Number)?.toDouble(),
                startTime = (map["startTime"] as? String)?.let { parseIso8601(it) },
                endTime = (map["endTime"] as? String)?.let { parseIso8601(it) }
            )
        }

        /**
         * Parse an ISO-8601 UTC timestamp; returns null on any parse failure.
         * Same java.time approach as [RollaSyncResult] (0/3/6/9 fractional
         * digits all parse to the correct instant).
         */
        private fun parseIso8601(raw: String): Date? {
            try {
                return Date.from(Instant.parse(raw))
            } catch (_: Exception) {
                // try offset form
            }
            try {
                return Date.from(OffsetDateTime.parse(raw).toInstant())
            } catch (_: Exception) {
                // unparseable
            }
            Log.w(TAG, "Could not parse timestamp: $raw")
            return null
        }
    }
}
