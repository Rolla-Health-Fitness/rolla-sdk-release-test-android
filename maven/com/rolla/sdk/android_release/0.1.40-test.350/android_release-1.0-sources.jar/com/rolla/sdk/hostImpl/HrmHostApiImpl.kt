package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import android.content.Context
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceConnectionState
import app.rolla.bluetoothSdk.device.DeviceType
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.extensions.executeOperation
import com.rolla.sdk.extensions.executeOperationSuspend
import com.rolla.sdk.extensions.toFlutterError
import com.rolla.sdk.generated.BluetoothCapabilities
import com.rolla.sdk.generated.BluetoothDevice
import com.rolla.sdk.generated.ConnectionState
import com.rolla.sdk.generated.DeviceType as PigeonDeviceType
import com.rolla.sdk.generated.HrmFlutterApi
import com.rolla.sdk.generated.HrmHostApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Native implementation of the Heart Rate Monitor (HRM) host API.
 *
 * Deliberately independent of [RollaBluetoothHostApiImpl] and the Rolla Band
 * path: it drives the same generic [BleManager] BLE machinery but pins every
 * operation to [DeviceType.HEART_RATE] (scan filtered to the Heart Rate Service
 * 0x180D, subscribe to the Heart Rate Measurement characteristic 0x2A37) and
 * routes results onto its own [HrmFlutterApi] channel.
 *
 * The [BleManager] scan / connection / heart-rate flows are shared singletons,
 * so this impl filters device and connection events down to heart-rate devices
 * (tracking their ids from the scan flow) before forwarding them, keeping the
 * HRM channel free of Rolla Band traffic.
 */
@SuppressLint("MissingPermission")
class HrmHostApiImpl(
    private val context: Context,
    private val bleManager: BleManager,
    private val hrmFlutterApi: HrmFlutterApi,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : HrmHostApi {

    companion object {
        private const val TAG = "HrmHostApiImpl"
    }

    /** Ids of devices discovered as heart-rate sensors, used to filter the
     *  shared connection-state and heart-rate flows down to HRM devices only.
     *  Concurrent because the two collectors below run on [Dispatchers.IO]
     *  while [connectHrmDevice] adds from whichever thread called it. */
    private val hrmDeviceIds: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Device-type filter in force before [startHrmScan] narrowed it to
     *  heart-rate devices, restored by [stopHrmScan]. The filter lives on the
     *  shared [BleManager], so leaving it narrowed would confine the band's own
     *  background rescans to heart-rate devices. */
    @Volatile
    private var previousAllowedDeviceTypes: Set<DeviceType>? = null

    init {
        // Discovered heart-rate devices → HRM device list. The Rolla Band also
        // advertises 0x180D but is NOT a generic HRM (its HR is proprietary and
        // connecting to it via the HRM path fails), and it has its own pairing
        // flow — so exclude it from the HRM picker.
        scope.launch {
            bleManager.getAllDevicesFlow().collect { devices ->
                val hrmDevices = devices.filter { it.hasDeviceType(DeviceType.HEART_RATE) && !isRollaBand(it) }
                hrmDevices.forEach { hrmDeviceIds.add(it.getMacAddress()) }
                val pigeonDevices = hrmDevices.map { convertToPigeonDevice(it) }
                withContext(Dispatchers.Main) {
                    hrmFlutterApi.onHrmDevicesFound(pigeonDevices) { }
                }
            }
        }

        // Connection-state changes, filtered to heart-rate devices.
        scope.launch {
            bleManager.connectionStateChanges.collect { event ->
                val uuid = event.first
                if (!hrmDeviceIds.contains(uuid)) return@collect
                val pigeonState = when (event.second) {
                    DeviceConnectionState.CONNECTED -> ConnectionState.CONNECTED
                    DeviceConnectionState.CONNECTING -> ConnectionState.CONNECTING
                    DeviceConnectionState.DISCONNECTED,
                    DeviceConnectionState.DISCONNECTING -> ConnectionState.DISCONNECTED
                }
                withContext(Dispatchers.Main) {
                    log(TAG, "HRM connection state $pigeonState for $uuid")
                    hrmFlutterApi.onHrmConnectionStateChanged(uuid, pigeonState) { }
                }
            }
        }

        // Heart-rate notifications (0x2A37), parsed natively into BPM.
        //
        // A strap taken off the body keeps notifying at its usual rate, repeating
        // its last value with contact flagged as lost. Those readings are reported
        // heart rates in name only — forwarding them freezes a number on screen for
        // as long as the strap stays powered on, and nothing downstream could tell
        // them apart from a live measurement.
        scope.launch {
            bleManager.getHeartRateFlow().collect { hr ->
                // The flow is shared by every connected device — including the
                // band, whose readings must not surface as this channel's. It
                // also replays its last value to a new collector, so an
                // unattributed reading is dropped rather than guessed at.
                val address = hr.deviceAddress ?: return@collect
                if (!hrmDeviceIds.contains(address)) return@collect
                if (hr.sensorContactDetected == false) return@collect
                withContext(Dispatchers.Main) {
                    hrmFlutterApi.onHrmHeartRateReceived(hr.heartRate.toLong()) { }
                }
            }
        }

        // Running speed & cadence notifications (0x2A53), for HRMs that also
        // expose the RSC service (Stage 2). The native flow reports speed in
        // km/h; convert to m/s for the Pigeon contract.
        scope.launch {
            bleManager.getRunningSpeedCadenceFlow().collect { rsc ->
                withContext(Dispatchers.Main) {
                    hrmFlutterApi.onHrmRunningSpeedCadenceReceived(
                        rsc.instantaneousSpeed.toDouble() / 3.6,
                        rsc.instantaneousCadence.toLong(),
                    ) { }
                }
            }
        }
    }

    override fun startHrmScan(scanDuration: Long, callback: (Result<Unit>) -> Unit) {
        executeOperationSuspend(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Scanning for HRM devices",
            operation = {
                if (previousAllowedDeviceTypes == null) {
                    previousAllowedDeviceTypes = bleManager.getAllowedDeviceTypes()
                }
                // Fresh scan / Refresh: drop stale HEART_RATE discoveries so a
                // powered-off monitor isn't re-listed from the 20s scan cache.
                // Connected monitors and Rolla Bands (which also advertise
                // 0x180D) stay put.
                bleManager.clearDisconnectedScannedDevices(
                    includeTypes = setOf(DeviceType.HEART_RATE),
                    excludeTypes = setOf(DeviceType.ROLLA_BAND)
                )
                bleManager.setScanDuration(scanDuration)
                bleManager.startScan(deviceTypes = setOf(DeviceType.HEART_RATE))
            },
            onSuccess = { }
        )
    }

    override fun stopHrmScan(callback: (Result<Unit>) -> Unit) {
        executeOperationSuspend(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Stopping HRM scan",
            operation = {
                val result = bleManager.stopScan()
                previousAllowedDeviceTypes?.let {
                    bleManager.setAllowedDeviceTypes(it)
                    previousAllowedDeviceTypes = null
                }
                result
            },
            onSuccess = { }
        )
    }

    override fun connectHrmDevice(uuid: String, callback: (Result<Boolean>) -> Unit) {
        hrmDeviceIds.add(uuid)
        executeOperation(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Connecting to HRM device: $uuid",
            // Request both HR and RSC. BleConnector keeps only types the device
            // advertised (best-effort) — so HR-only straps still connect, and RSC
            // (0x2A53) is subscribed when 0x1814 was in the scan ads. Matching
            // iOS, absence of RSC must not fail the connect.
            operation = {
                bleManager.connectToBleDevice(
                    uuid,
                    setOf(DeviceType.HEART_RATE, DeviceType.RUNNING_SPEED_AND_CADENCE),
                )
            },
            onSuccess = {
                log(TAG, "Connected to HRM device: $uuid")
                true
            },
            onError = { log(TAG, "Error connecting to HRM device: $uuid") }
        )
    }

    override fun disconnectHrmDevice(uuid: String, callback: (Result<Boolean>) -> Unit) {
        executeOperation(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Disconnecting from HRM device: $uuid",
            operation = { bleManager.disconnectFromDevice(uuid) },
            onSuccess = { true }
        )
    }

    override fun checkHrmConnectionState(uuid: String, callback: (Result<ConnectionState>) -> Unit) {
        bleManager.getConnectionState(uuid, onSuccess = { state ->
            callback(Result.success(convertToPigeonConnectionState(state)))
        }, onError = { error ->
            callback(Result.failure(toFlutterError(error)))
        })
    }

    /** The Rolla Band advertises 0x180D but must not appear in the HRM picker.
     *  Identify it by its device type or its "Rolla" advertised name. */
    private fun isRollaBand(device: BleDevice): Boolean {
        if (device.hasDeviceType(DeviceType.ROLLA_BAND)) return true
        return device.getName(context).lowercase().contains("rolla")
    }

    private fun convertToPigeonDevice(device: BleDevice): BluetoothDevice {
        return BluetoothDevice(
            name = device.getName(context),
            rssi = device.rssi.toLong(),
            uuid = device.getMacAddress(),
            capabilities = listOf(BluetoothCapabilities.HR),
            connectionState = if (device.isConnected()) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED,
            deviceType = PigeonDeviceType.OTHER
        )
    }

    private fun convertToPigeonConnectionState(state: DeviceConnectionState): ConnectionState {
        return when (state) {
            DeviceConnectionState.CONNECTED -> ConnectionState.CONNECTED
            DeviceConnectionState.CONNECTING -> ConnectionState.CONNECTING
            DeviceConnectionState.DISCONNECTED -> ConnectionState.DISCONNECTED
            DeviceConnectionState.DISCONNECTING -> ConnectionState.DISCONNECTED
        }
    }

    fun cleanup() {
        hrmDeviceIds.clear()
        scope.cancel()
    }
}
