package com.rolla.sdk.wrapper.features.sync

import com.rolla.sdk.wrapper.RollaListener

/**
 * Payload of [RollaListener.onPrimarySourceChanged].
 *
 * Reuses [RollaSyncSource] so hosts read one source vocabulary across the sync
 * APIs and this event. Fired when the SDK **observes** the user's primary data
 * source change — either committed inside the SDK UI or discovered on a
 * profile/connections refresh (a change made server-side or on another device
 * surfaces on the next refresh, not instantly).
 */
data class RollaPrimarySourceChanged(
    /** The primary source before the change. */
    val previousSource: RollaSyncSource,
    /** The primary source after the change. */
    val currentSource: RollaSyncSource
) {
    companion object {
        /**
         * Build from the method-channel wire map. Unknown enum strings map to
         * `UNKNOWN`.
         */
        fun fromResponse(response: Any?): RollaPrimarySourceChanged {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            return RollaPrimarySourceChanged(
                previousSource = RollaSyncSource.fromRawValue(map["previousSource"] as? String),
                currentSource = RollaSyncSource.fromRawValue(map["currentSource"] as? String)
            )
        }
    }
}
