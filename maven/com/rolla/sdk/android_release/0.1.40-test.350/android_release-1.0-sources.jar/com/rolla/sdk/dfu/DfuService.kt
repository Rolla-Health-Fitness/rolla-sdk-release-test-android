package com.rolla.sdk.dfu

import android.app.Activity
import android.content.Intent
import com.rolla.sdk.wrapper.engine.RollaEngineManager
import no.nordicsemi.android.dfu.DfuBaseService

class DfuService : DfuBaseService() {

    override fun getNotificationTarget(): Class<out Activity> {
        /*
         * Note: This is a library module, so we return a generic Activity class.
         * Host apps can extend this service and override this method to return
         * their own target activity if needed.
         */
        return Activity::class.java
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Nordic cancels the running DFU and stops this service on a Recents
        // swipe. The Add-to-App engine manager is told for the same reason:
        // if that swipe ended the host UI it tears the engine down so the next
        // launch does not resume a stale SDK session (no-op for Flutter-package
        // hosts).
        RollaEngineManager.notifyHostTaskRemoved(this)
    }
}
