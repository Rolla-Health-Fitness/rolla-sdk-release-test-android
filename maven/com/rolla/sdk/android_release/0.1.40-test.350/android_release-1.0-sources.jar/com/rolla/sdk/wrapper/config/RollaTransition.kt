package com.rolla.sdk.wrapper.config

import com.rolla.sdk.wrapper.Rolla

/**
 * How the SDK UI is animated on and off screen by [Rolla.show].
 *
 * The close animation always mirrors the opening one, whichever way the SDK
 * UI is closed (its own close button, [Rolla.dismiss], or system back).
 */
enum class RollaTransition {
    /** The platform's standard activity animation. */
    DEFAULT,

    /** A cross-fade between the host screen and the SDK UI. */
    FADE,
}
