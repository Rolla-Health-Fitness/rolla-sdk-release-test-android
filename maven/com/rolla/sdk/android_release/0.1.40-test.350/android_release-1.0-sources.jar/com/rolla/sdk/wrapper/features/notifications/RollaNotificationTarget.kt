package com.rolla.sdk.wrapper.features.notifications

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.features.navigation.RollaScreen
import org.json.JSONException
import org.json.JSONObject

/**
 * Where a tap on a Rolla SDK notification should lead, resolved from the
 * intent your launcher activity receives via [Rolla.notificationTarget].
 *
 * Every notification the SDK produces carries a payload naming its
 * destination; a `null` resolution means the tap did not come from a Rolla
 * notification.
 */
sealed class RollaNotificationTarget {

    /**
     * Take the user to the OS app-settings page — the notification asks them
     * to fix a permission (e.g. background location during a workout), so an
     * SDK screen would not help.
     */
    object AppSettings : RollaNotificationTarget()

    /** Open [screen] via [Rolla.openScreen]. */
    data class Screen(val screen: RollaScreen) : RollaNotificationTarget()

    companion object {
        /**
         * The intent extra carrying the Rolla payload. The key is
         * flutter_local_notifications' own `payload` extra, which the SDK's
         * native workout notifications mirror; the JSON marker inside the
         * payload — not the key — is what identifies Rolla.
         */
        internal const val PAYLOAD_EXTRA = "payload"

        /**
         * The action the native workout notifications set on their tap intent.
         * A launch intent left on `ACTION_MAIN`/`CATEGORY_LAUNCHER` matches the
         * task's root intent, so whenever the app's task already exists — always,
         * mid-workout — Android only brings the task to the foreground and drops
         * the intent, extras included, exactly like an app-icon tap. A different
         * action breaks that root-intent match, forcing real delivery to the
         * launcher activity (`onCreate` of a new instance, or `onNewIntent` when
         * it is `singleTop` on top). The value mirrors flutter_local_notifications
         * so every Rolla notification tap reaches the host with one uniform action.
         */
        internal const val TAP_ACTION = "SELECT_NOTIFICATION"

        /**
         * Base for the workout notifications' PendingIntent request codes
         * (base + notification id). The tap intents share their action,
         * component and category with flutter_local_notifications' own tap
         * PendingIntents, whose request code is the notification id — at an
         * equal request code the two would be one PendingIntent to the
         * platform, and FLAG_UPDATE_CURRENT would overwrite the extras of
         * whichever was created first. The offset keeps the SDK's request
         * codes out of any realistic notification-id space. Reads "ROL\0".
         */
        internal const val TAP_REQUEST_CODE_BASE = 0x524F4C00

        /**
         * The payload both native workout foreground notifications
         * (BleForegroundService, LocationService) attach to their tap intent:
         * `resume` shows the SDK UI exactly as the user left it — mid-workout,
         * the live tracking screen. Shared verbatim with the Dart
         * RollaNotificationPayload contract.
         */
        internal const val WORKOUT_TAP_PAYLOAD = """{"rolla":1,"type":"workoutInProgress","target":"resume"}"""

        // Wire contract shared verbatim with the Dart RollaNotificationPayload
        // and the iOS RollaNotificationTarget — keep all three in sync.
        private const val MARKER_KEY = "rolla"
        private const val TARGET_KEY = "target"
        private const val TARGET_APP_SETTINGS = "appSettings"

        internal fun parse(payload: String?): RollaNotificationTarget? {
            if (payload.isNullOrEmpty()) return null
            val json = try {
                JSONObject(payload)
            } catch (_: JSONException) {
                return null
            }
            // Any integer marker version >= 1 is a Rolla notification; an
            // unknown target from a newer contract still resolves — to Home.
            // Strictly an integer (org.json parses to Int or Long) — never a
            // coerced string/double/boolean, matching the Dart parser exactly.
            val version = when (val marker = json.opt(MARKER_KEY)) {
                is Int -> marker
                is Long -> if (marker > 0) 1 else 0
                else -> 0
            }
            if (version < 1) return null
            return when (val target = json.optString(TARGET_KEY)) {
                TARGET_APP_SETTINGS -> AppSettings
                else -> Screen(RollaScreen.entries.firstOrNull { it.rawValue == target } ?: RollaScreen.HOME)
            }
        }
    }
}
