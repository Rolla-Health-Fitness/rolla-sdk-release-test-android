package com.rolla.sdk.wrapper.config

import com.rolla.sdk.wrapper.Rolla

/**
 * Visual identity of the SDK UI. Every field is optional: a set field
 * overrides the SDK's built-in default individually — unset fields keep it.
 */
data class RollaBranding(
    /**
     * Display name of the host app, shown wherever SDK copy refers to the app
     * (consent and permission texts). null keeps the generic wording.
     */
    val hostAppName: String? = null,
    /**
     * Seeds the SDK's entire color scheme (buttons, navigation, inputs,
     * charts, share cards) in both light and dark themes. ARGB Int.
     */
    val primaryColor: Int? = null,
    /** Theme the SDK UI runs in: light, dark, or following the device (system). */
    val themeMode: RollaThemeMode? = null,
    /**
     * Path of a logo asset pre-bundled into the SDK by Rolla, shown in the
     * top app bar and on activity share cards.
     */
    val headerLogoAsset: String? = null,
    /** Privacy policy URL linked from the consent screen. */
    val privacyUrl: String? = null,
    /**
     * Whether the SDK UI uses generic "fitness device" wording (true) or
     * Rolla Band-specific naming, imagery, and copy (false). Unset keeps
     * the SDK default: generic wording.
     */
    val removeRollaBandReferences: Boolean? = null,
) {
    internal fun toMap(): Map<String, Any?> = buildMap {
        hostAppName?.let { put("hostAppName", it) }
        primaryColor?.let { put("primaryColor", it) }
        themeMode?.let { put("themeMode", it.rawValue) }
        headerLogoAsset?.let { put("headerLogoAsset", it) }
        privacyUrl?.let { put("privacyUrl", it) }
        removeRollaBandReferences?.let { put("removeRollaBandReferences", it) }
    }

    companion object {
        fun create(
            hostAppName: String? = null,
            primaryColor: Int? = null,
            themeMode: RollaThemeMode? = null,
            headerLogoAsset: String? = null,
            privacyUrl: String? = null,
            removeRollaBandReferences: Boolean? = null
        ): RollaBranding = RollaBranding(
            hostAppName = hostAppName,
            primaryColor = primaryColor,
            themeMode = themeMode,
            headerLogoAsset = headerLogoAsset,
            privacyUrl = privacyUrl,
            removeRollaBandReferences = removeRollaBandReferences
        )
    }
}
