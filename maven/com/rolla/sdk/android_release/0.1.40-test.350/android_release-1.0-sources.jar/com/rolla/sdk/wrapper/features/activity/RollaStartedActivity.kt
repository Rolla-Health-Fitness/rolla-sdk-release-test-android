package com.rolla.sdk.wrapper.features.activity

import android.util.Log
import com.rolla.sdk.wrapper.RollaListener
import com.rolla.sdk.wrapper.features.sync.RollaSyncResult
import java.time.Instant
import java.time.OffsetDateTime
import java.util.Date

/**
 * How the live session was running when [RollaListener.onActivityStarted]
 * fired.
 */
enum class RollaActivityStartOrigin(val rawValue: String) {
    /** A brand-new live-tracked session the user just started. */
    FRESH("fresh"),

    /**
     * A session restored after the app terminated mid-activity (crash or
     * kill). The started event fires again with this origin because the host
     * may have lost the original [FRESH] event along with the app; two
     * started events carrying the same `activityId` are the same activity.
     */
    CRASH_RECOVERY("crashRecovery"),

    /** The SDK sent an origin this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        /** Map a wire string ([rawValue]) to an origin; unknown values map to [UNKNOWN]. */
        fun fromRawValue(raw: String?): RollaActivityStartOrigin =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Payload of [RollaListener.onActivityStarted].
 *
 * Fires when a live tracking session begins running — a fresh start or a
 * crash-recovery resume ([origin] says which). Manual activities never fire it
 * (they are logged after the fact and enter the lifecycle at `finished`), and
 * pausing/resuming inside a session fires nothing. Every started activity
 * terminates in an activity-completed `FINISHED` or an activity-removed event;
 * the two can arrive in **different app sessions** when the app dies in
 * between. Two exceptions are cleaned up silently, without an event: a
 * session abandoned mid-tracking for over a day, and an interrupted session
 * neither resumed nor discarded before the user starts their next activity.
 */
data class RollaStartedActivity(
    val activityId: String,
    /** Base activity type (e.g. `walk`, `run`, `cycling`, `cardio`). */
    val type: String? = null,
    val startTime: Date? = null,
    val origin: RollaActivityStartOrigin = RollaActivityStartOrigin.UNKNOWN,
    val catalogId: String? = null
) {
    companion object {
        private const val TAG = "RollaActivity"

        /**
         * Build from the method-channel wire map. Unknown enum strings map to
         * their `UNKNOWN` case.
         */
        fun fromResponse(response: Any?): RollaStartedActivity {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            return RollaStartedActivity(
                activityId = map["activityId"] as? String ?: "",
                type = map["type"] as? String,
                startTime = (map["startTime"] as? String)?.let { parseIso8601(it) },
                origin = RollaActivityStartOrigin.fromRawValue(map["origin"] as? String),
                catalogId = map["catalogId"] as? String
            )
        }

        /**
         * Parse an ISO-8601 UTC timestamp; returns null on any parse failure.
         * (java.time handles 0/3/6/9 fractional-second digits — same rationale
         * as RollaSyncResult.parseIso8601.)
         */
        private fun parseIso8601(raw: String): Date? {
            try {
                return Date.from(Instant.parse(raw))
            } catch (_: Exception) {
                // try offset form
            }
            try {
                return Date.from(OffsetDateTime.parse(raw).toInstant())
            } catch (_: Exception) {
                // unparseable
            }
            Log.w(TAG, "Could not parse timestamp: $raw")
            return null
        }
    }
}
