package com.rolla.sdk.wrapper.features.activity

import com.rolla.sdk.wrapper.RollaListener

/**
 * Why an activity's record ceased to exist when
 * [RollaListener.onActivityRemoved] fired.
 */
enum class RollaActivityRemovalReason(val rawValue: String) {
    /**
     * The activity started but was never saved: the session was discarded
     * during crash recovery — the user chose Discard on the recovery prompt,
     * or the SDK silently discarded a session that recorded no data. Covers
     * what hosts commonly expect as "activity canceled".
     */
    CANCELED("canceled"),

    /**
     * A saved (possibly already uploaded) activity the user deleted from the
     * activity review screen. Fires only once the backend confirmed the
     * deletion (or the record was never uploaded, so only the local copy
     * existed).
     */
    DELETED("deleted"),

    /** The SDK sent a reason this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        /** Map a wire string ([rawValue]) to a reason; unknown values map to [UNKNOWN]. */
        fun fromRawValue(raw: String?): RollaActivityRemovalReason =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Payload of [RollaListener.onActivityRemoved].
 *
 * Fires when an activity's record is gone without a kept result — the method
 * names the effect (record removed), [reason] names the cause. Together with
 * the started/completed events this closes the lifecycle: every started
 * activity terminates in a `FINISHED` completion or a removal, except two
 * silent cleanups: sessions abandoned mid-tracking for over a day, and
 * interrupted sessions neither resumed nor discarded before the user starts
 * their next activity.
 */
data class RollaRemovedActivity(
    val activityId: String,
    val reason: RollaActivityRemovalReason = RollaActivityRemovalReason.UNKNOWN
) {
    companion object {
        /**
         * Build from the method-channel wire map. Unknown reason strings map to
         * [RollaActivityRemovalReason.UNKNOWN].
         */
        fun fromResponse(response: Any?): RollaRemovedActivity {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            return RollaRemovedActivity(
                activityId = map["activityId"] as? String ?: "",
                reason = RollaActivityRemovalReason.fromRawValue(map["reason"] as? String)
            )
        }
    }
}
