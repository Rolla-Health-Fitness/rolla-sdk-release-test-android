package com.rolla.sdk.wrapper.engine

import android.os.Build
import android.os.Bundle
import com.rolla.sdk.R
import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaTransition
import com.rolla.sdk.wrapper.features.session.RollaCloseReason
import io.flutter.embedding.android.FlutterFragmentActivity

class RollaFlutterActivity : FlutterFragmentActivity() {

    companion object {
        /** Intent extra carrying the [RollaTransition] name chosen at [Rolla.show]. */
        internal const val EXTRA_TRANSITION = "com.rolla.sdk.wrapper.EXTRA_TRANSITION"

        @Volatile
        internal var onDismiss: ((RollaCloseReason) -> Unit)? = null

        @Volatile
        private var pendingCloseReason: RollaCloseReason? = null

        @Volatile
        private var currentInstance: RollaFlutterActivity? = null

        /** True while an SDK Activity instance exists (created and not yet destroyed). */
        internal val isAlive: Boolean
            get() = currentInstance != null

        /**
         * True while an SDK Activity instance exists and is not finishing.
         * Stricter than [isAlive] on purpose: a dismiss runs `finish()`
         * synchronously, but the instance is only cleared in the later
         * `onDestroy` message — and reordering a finishing record to the
         * front would start a fresh instance with no dismiss wiring.
         */
        internal val canBringToFront: Boolean
            get() = currentInstance?.isFinishing == false

        internal fun setPendingCloseReason(reason: RollaCloseReason) {
            pendingCloseReason = reason
        }

        internal fun clearCallbacks() {
            onDismiss = null
            pendingCloseReason = null
        }

        internal fun finishCurrent() {
            currentInstance?.finish()
        }
    }

    private var didNotifyDismiss = false
    private var backPressedDuringSession = false
    private var isFadeTransition = false

    override fun getCachedEngineId(): String = RollaEngineManager.ENGINE_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentInstance = this
        didNotifyDismiss = false
        backPressedDuringSession = false
        isFadeTransition = intent?.getStringExtra(EXTRA_TRANSITION) == RollaTransition.FADE.name
        if (isFadeTransition && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // The API < 34 path runs overridePendingTransition in finish()
            // instead — every close funnels through that one override.
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        backPressedDuringSession = true
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Guarded so a late onDestroy from a replaced instance cannot
        // unregister a newer, live Activity.
        if (currentInstance == this) {
            currentInstance = null
        }
        notifyDismissOnce()
        // After super.onDestroy() the Flutter delegate has detached from the
        // engine, so a teardown deferred by a host task removal is safe now.
        RollaEngineManager.notifySdkActivityDestroyed()
    }

    override fun finish() {
        if (pendingCloseReason == null && backPressedDuringSession) {
            pendingCloseReason = RollaCloseReason.HostNavigationBack
        }
        super.finish()
        if (isFadeTransition && Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    private fun notifyDismissOnce() {
        if (didNotifyDismiss) return
        didNotifyDismiss = true

        val reason = pendingCloseReason ?: RollaCloseReason.HostModalDismiss
        pendingCloseReason = null

        onDismiss?.invoke(reason)
        onDismiss = null
    }
}
