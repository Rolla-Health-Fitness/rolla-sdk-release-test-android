package com.rolla.sdk.wrapper.config

/**
 * SDK modules that can be disabled.
 *
 * Pass values to [RollaConfiguration.disabledModules] 
 * to disable that module everywhere in the SDK UI.
 */
enum class RollaDisabledModule(val rawValue: String) {
    BLOOD_PRESSURE("bloodPressure"),
    INSIGHTS("insights"),
    LEADERBOARDS("leaderboards"),
    WEIGHT("weight"),
}
