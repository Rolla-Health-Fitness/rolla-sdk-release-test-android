package com.rolla.sdk.wrapper.features.session

sealed class RollaError(
    val code: String,
    override val message: String
) : Exception(message) {

    class EngineFailedToStart : RollaError(
        code = "ENGINE_FAILED",
        message = "The Flutter engine failed to start."
    )

    class InitializationFailed(details: String) : RollaError(
        code = "INIT_FAILED",
        message = "SDK initialization failed: $details"
    )

    class FlutterError(errorCode: String, errorMessage: String) : RollaError(
        code = "FLUTTER_ERROR",
        message = "Flutter error [$errorCode]: $errorMessage"
    )

    class AlreadyPresenting : RollaError(
        code = "ALREADY_PRESENTING",
        message = "Rolla is already presenting. Dismiss the current UI before presenting again."
    )

    class InvalidContext : RollaError(
        code = "INVALID_CONTEXT",
        message = "The presentation context is not available."
    )

    class Underlying(throwable: Throwable) : RollaError(
        code = "UNDERLYING_ERROR",
        message = throwable.message ?: throwable.toString()
    )

    class Unknown(details: String? = null) : RollaError(
        code = "UNKNOWN",
        message = details ?: "An unknown error occurred."
    )
}
