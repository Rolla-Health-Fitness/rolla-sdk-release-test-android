package com.rolla.sdk.wrapper.features.navigation

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaConfiguration

/**
 * Outcome of a [Rolla.openScreen] call. Every call resolves with exactly one
 * status.
 */
enum class RollaOpenScreenStatus(val rawValue: String) {
    /** The SDK UI is on the requested screen. */
    OPENED("opened"),

    /** The SDK session could not be initialized from the configuration. */
    NOT_INITIALIZED("notInitialized"),

    /**
     * The screen's module is disabled via
     * [RollaConfiguration.disabledModules]. Nothing was opened.
     */
    SCREEN_DISABLED("screenDisabled"),

    /**
     * A mandatory startup step (onboarding, consent, permissions, or
     * data-source connection) is in front of the user and stays there.
     */
    BLOCKED_BY_GATE("blockedByGate"),

    /**
     * The SDK UI could not be shown or did not become ready to navigate.
     * Nothing was opened.
     */
    UI_UNAVAILABLE("uiUnavailable"),

    /**
     * A newer [Rolla.openScreen] request replaced this one — only the latest
     * request is honored.
     */
    SUPERSEDED("superseded"),

    /** The request could not be delivered or its response could not be read. */
    UNKNOWN_ERROR("unknownError");

    companion object {
        /** Map a wire string ([rawValue]) to a status; unknown values map to [UNKNOWN_ERROR]. */
        fun fromRawValue(raw: String?): RollaOpenScreenStatus =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN_ERROR

        /**
         * Build a status from the method-channel wire map `{ "status": String }`.
         * Anything unparseable maps to [UNKNOWN_ERROR].
         */
        fun fromResponse(response: Any?): RollaOpenScreenStatus =
            fromRawValue((response as? Map<*, *>)?.get("status") as? String)
    }
}
