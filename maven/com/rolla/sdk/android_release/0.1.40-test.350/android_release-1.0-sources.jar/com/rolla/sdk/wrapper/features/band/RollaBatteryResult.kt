package com.rolla.sdk.wrapper.features.band

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.features.sync.RollaSyncSkipReason

/**
 * Why a band-battery read did or didn't yield a live value.
 *
 * Battery is a live BLE read from a **Rolla band**. A value is only present when
 * [AVAILABLE] — every other case is a typed "unavailable" reason the host can
 * branch on.
 */
enum class RollaBatteryStatus(val rawValue: String) {
    /** A fresh live battery level was read. [RollaBatteryResult.level] holds it. */
    AVAILABLE("available"),

    /** The user has no Rolla band paired. */
    NO_BAND_PAIRED("noBandPaired"),

    /**
     * A band is paired, but it could not be reached right now — powered off,
     * out of range, or the connect/read attempt ran out of time. The sync API
     * reports the same fact as [RollaSyncSkipReason.BAND_NOT_CONNECTED]
     * (identical raw value).
     */
    BAND_NOT_CONNECTED("bandNotConnected"),

    /**
     * The connected device is not a Rolla band. The current battery read never
     * returns this — it only connects to the user's own known band — so the case
     * exists for native/forward-compatibility.
     */
    NOT_ROLLA_DEVICE("notRollaDevice"),

    /**
     * Bluetooth is powered off or otherwise unavailable. (Missing Bluetooth
     * permission is reported separately as [BLUETOOTH_PERMISSION_REQUIRED].)
     */
    BLUETOOTH_UNAVAILABLE("bluetoothUnavailable"),

    /**
     * The Bluetooth runtime permission has not been granted. Shares its raw
     * value with [RollaSyncSkipReason.BLUETOOTH_PERMISSION_REQUIRED] so a host
     * can map "Bluetooth permission required" once across the battery and sync
     * APIs. The host should request the permission before retrying.
     */
    BLUETOOTH_PERMISSION_REQUIRED("bluetoothPermissionRequired"),

    /** An unexpected error occurred while reading. */
    UNKNOWN_ERROR("unknownError"),

    /** The SDK returned a status this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        /** Map a wire string ([rawValue]) to a status; unknown values map to [UNKNOWN]. */
        fun fromRawValue(raw: String?): RollaBatteryStatus =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Result of [Rolla.getBandBatteryLevel].
 *
 * [level] is non-null **only** when [status] is [RollaBatteryStatus.AVAILABLE].
 */
data class RollaBatteryResult(
    val status: RollaBatteryStatus,
    val level: Int? = null
) {
    /** Whether a live battery [level] is present. */
    val isAvailable: Boolean
        get() = status == RollaBatteryStatus.AVAILABLE && level != null

    companion object {
        /**
         * Build a result from the method-channel wire map
         * `{ "status": String, "level": Int? }`. Unknown statuses map to
         * [RollaBatteryStatus.UNKNOWN].
         */
        fun fromResponse(response: Any?): RollaBatteryResult {
            val map = response as? Map<*, *>
                ?: return RollaBatteryResult(RollaBatteryStatus.UNKNOWN, null)
            val status = RollaBatteryStatus.fromRawValue(map["status"] as? String)
            val level = (map["level"] as? Number)?.toInt()
            return RollaBatteryResult(
                status = status,
                level = if (status == RollaBatteryStatus.AVAILABLE) level else null
            )
        }
    }
}
