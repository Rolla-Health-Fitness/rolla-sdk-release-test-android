package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.characteristics.data.HrvData
import app.rolla.bluetoothSdk.commands.data.Hrv
import app.rolla.bluetoothSdk.commands.data.HrvRecord
import app.rolla.bluetoothSdk.commands.data.SyncTimestamp
import app.rolla.bluetoothSdk.utils.MAX_ANCHOR_SKEW_MS
import app.rolla.bluetoothSdk.utils.clampAnchor
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.recoverAnchor
import app.rolla.bluetoothSdk.utils.toBcdTimeOrNull
import app.rolla.bluetoothSdk.utils.toEpochMilliSecondsOrNull
import app.rolla.bluetoothSdk.utils.toIntLE
import app.rolla.bluetoothSdk.utils.toPositionedInt
import app.rolla.bluetoothSdk.utils.writeBcdTimeToArray
import java.util.Calendar
import java.util.TimeZone

class GetHrv : Command<HrvData> {

    // Mutated on the GATT callback thread via read(), snapshotted from coroutine threads
    // via snapshotEnd() — every access to this state is @Synchronized.
    private var hrvList: MutableList<Hrv> = mutableListOf()
    private var hrvTimestamp: SyncTimestamp = SyncTimestamp()
    private var nextPage = false
    private var maxDeliveredTimestamp = 0L

    companion object {
        const val TAG = "GetHrv"
        private const val NEXT_PAGE_FLAG = 0x02.toByte()
        private const val FIRST_PAGE_FLAG = 0x00.toByte()
        private const val TIMESTAMP_START_INDEX = 4
        private const val RECORD_SIZE = 15
        private const val DATA_NUMBER_OFFSET = 1
        private const val BCD_TIME_OFFSET = 3
        private const val HRV_OFFSET = 9
        private const val FATIGUE_DEGREE_OFFSET = 12
        private const val SBP_OFFSET = 13
        private const val DBP_OFFSET = 14
        private const val PAGE_SIZE = 50 * 16
        private const val END_OF_DATA_MARKER = 0xff.toByte()
    }

    @Synchronized
    fun setHrvTimestamp(lastBlockTimestamp: Long) {
        hrvTimestamp = SyncTimestamp(lastBlockTimestamp = recoverAnchor(lastBlockTimestamp))
        hrvList.clear()
        maxDeliveredTimestamp = 0L
    }

    @Synchronized
    fun setIsNextPage(nextPage: Boolean) {
        this.nextPage = nextPage
    }

    override fun getId(): Byte = 0x56.toByte()

    override fun errorId(): Byte = 0xD6.toByte()

    @Synchronized
    override fun bytesToWrite(): ByteArray {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        calendar.timeInMillis = hrvTimestamp.lastBlockTimestamp

        return createCommandBytes {
            this[1] = if (nextPage) NEXT_PAGE_FLAG else FIRST_PAGE_FLAG
            calendar.writeBcdTimeToArray(this, TIMESTAMP_START_INDEX)
        }
    }

    @Synchronized
    override fun read(data: ByteArray): HrvData {
        log(TAG, "HRV data ${data.contentToString()}")

        val recordCount = data.size / RECORD_SIZE
        if (recordCount == 0) {
            return createHrvData(isEndOfData = true, hasMoreData = false)
        }

        for (i in 0 until recordCount) {
            // A corrupted record (invalid BCD or impossible date) is skipped, not fatal —
            // aborting here would lose the rest of the page and stall the transfer.
            val hrvRecord = parseHrvRecord(data, i)
            if (hrvRecord == null) {
                log(TAG, "Skipping unparseable HRV record at offset ${i * RECORD_SIZE}")
                continue
            }
            processHrvRecord(hrvRecord)

            if (shouldReturnPage(hrvRecord.dataNumber)) {
                return createHrvData(isEndOfData = true, hasMoreData = hrvRecord.timeInMilliseconds > hrvTimestamp.lastBlockTimestamp)
            }
        }
        val endOfData = isEndOfData(data)
        return createHrvData(isEndOfData = endOfData, hasMoreData = !endOfData)
    }

    private fun parseHrvRecord(data: ByteArray, recordIndex: Int): HrvRecord? {
        val offset = recordIndex * RECORD_SIZE
        val dataNumber = data.toIntLE(DATA_NUMBER_OFFSET + offset, 2)
        val bcdTime = data.toBcdTimeOrNull(BCD_TIME_OFFSET + offset) ?: return null
        val hrv = data[HRV_OFFSET + offset].toPositionedInt(0)
        val fatigueDegree = data[FATIGUE_DEGREE_OFFSET + offset].toPositionedInt(0)
        val sbp = data[SBP_OFFSET + offset].toPositionedInt(0)
        val dbp = data[DBP_OFFSET + offset].toPositionedInt(0)
        val timeInMs = bcdTime.toEpochMilliSecondsOrNull() ?: return null

        return HrvRecord(dataNumber, bcdTime, hrv, fatigueDegree, sbp, dbp, timeInMs, offset)
    }

    private fun processHrvRecord(record: HrvRecord) {
        if (shouldAddHrv(record.hrv, record.timeInMilliseconds)) {
            hrvList.add(Hrv(record.timeInMilliseconds, record.hrv))
            maxDeliveredTimestamp = maxOf(maxDeliveredTimestamp, record.timeInMilliseconds)
        }
        logHrvRecord(record)
    }

    // A sample stamped beyond the skew allowance is dropped for now rather than delivered:
    // delivering it would either poison the anchor or, with a clamped anchor, be re-uploaded
    // on every sync; it is re-fetched once the wall clock passes it.
    private fun shouldAddHrv(hrv: Int, timestamp: Long): Boolean {
        return hrv > 0 &&
                timestamp > hrvTimestamp.lastBlockTimestamp &&
                timestamp <= System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS
    }

    private fun logHrvRecord(record: HrvRecord) {
        log(TAG, "Data Number: ${record.dataNumber}, Date: ${record.bcdTime.toDateString()}, " +
                "HRV: ${record.hrv}, Fatigue Degree: ${record.fatigueDegree}, " +
                "SBP: ${record.sbp}, DBP: ${record.dbp}")
    }

    private fun shouldReturnPage(dataNumber: Int): Boolean {
        return (dataNumber + 1) % PAGE_SIZE == 0
    }

    /**
     * Snapshot of the samples accumulated so far together with the matching sync anchor.
     * List and anchor are latched under the same lock, so a frame parsed after this
     * snapshot can never advance the anchor past samples missing from the list.
     */
    private fun createHrvData(isEndOfData: Boolean, hasMoreData: Boolean): HrvData {
        return HrvData(
            isEndOfData = isEndOfData,
            hasMoreData = hasMoreData,
            hrvList = ArrayList(hrvList),
            lastBlockTimestamp = currentAnchor()
        )
    }

    private fun isEndOfData(data: ByteArray): Boolean {
        return data.lastOrNull() == END_OF_DATA_MARKER
    }

    /** Ends the transfer with whatever was received so far (band error, silence, disconnect). */
    @Synchronized
    fun snapshotEnd(): HrvData {
        return createHrvData(isEndOfData = true, hasMoreData = false)
    }

    /**
     * Anchor for the next sync: the newest sample delivered this sync, falling back to the
     * previous anchor when nothing was delivered. Matching iOS, a truncated transfer
     * continues from the newest delivered sample — its undelivered remainder is re-fetched
     * by the next sync. The clamp is a backstop; delivery already filters future samples.
     */
    private fun currentAnchor(): Long {
        return clampAnchor(maxOf(hrvTimestamp.lastBlockTimestamp, maxDeliveredTimestamp))
    }
}
