package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.HeartRate

data class HeartRateData (
    var uuid: String = "",
    val isEndOfData: Boolean = false,
    val hasMoreData: Boolean = false,
    val heartRates: ArrayList<HeartRate> = arrayListOf(),
    // Sync anchors latched atomically with [heartRates]: a frame parsed after this
    // snapshot was taken can never advance a persisted anchor past samples that are
    // not in the list (that would permanently skip the gap between them).
    val lastBlockTimestamp: Long = 0L,
    val lastEntryTimestamp: Long = 0L,
)
