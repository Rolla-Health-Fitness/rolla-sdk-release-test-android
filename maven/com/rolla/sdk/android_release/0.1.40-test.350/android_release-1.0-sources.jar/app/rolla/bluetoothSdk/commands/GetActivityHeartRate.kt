package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.characteristics.data.HeartRateData
import app.rolla.bluetoothSdk.commands.data.ActiveHeartRateRecord
import app.rolla.bluetoothSdk.commands.data.HeartRate
import app.rolla.bluetoothSdk.commands.data.SyncTimestamp
import app.rolla.bluetoothSdk.utils.MAX_ANCHOR_SKEW_MS
import app.rolla.bluetoothSdk.utils.clampAnchor
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.recoverAnchor
import app.rolla.bluetoothSdk.utils.toBcdTimeOrNull
import app.rolla.bluetoothSdk.utils.toEpochMilliSecondsOrNull
import app.rolla.bluetoothSdk.utils.toIntLE
import app.rolla.bluetoothSdk.utils.toPositionedInt
import app.rolla.bluetoothSdk.utils.writeBcdTimeToArray
import java.util.Calendar
import java.util.TimeZone

class GetActivityHeartRate : Command<HeartRateData> {

    // Mutated on the GATT callback thread via read(), snapshotted from coroutine threads
    // via snapshotEnd() — every access to this state is @Synchronized.
    private var heartRateList: MutableList<HeartRate> = mutableListOf()
    private var activeHeartRateTimestamp: SyncTimestamp = SyncTimestamp()
    private var nextPage = false
    private var maxDeliveredBlockTimestamp = 0L
    private var maxDeliveredEntryTimestamp = 0L

    companion object {
        const val TAG = "GetActivityHeartRate"
        private const val NEXT_PAGE_FLAG = 0x02.toByte()
        private const val FIRST_PAGE_FLAG = 0x00.toByte()
        private const val TIMESTAMP_START_INDEX = 4
        private const val RECORD_SIZE = 24
        private const val DATA_NUMBER_OFFSET = 1
        private const val BCD_TIME_OFFSET = 3
        private const val HEART_RATES_PER_RECORD = 15
        private const val HEART_RATE_DATA_OFFSET = 9
        private const val MILLISECONDS_PER_MINUTE = 60 * 1000
        private const val PAGE_SIZE = 50 * 10
        private const val END_OF_DATA_MARKER = 0xff.toByte()
    }

    @Synchronized
    fun setHeartRateTimestamp(lastBlockTimestamp: Long, lastEntryTimestamp: Long) {
        activeHeartRateTimestamp = SyncTimestamp(
            lastBlockTimestamp = recoverAnchor(lastBlockTimestamp),
            lastEntryTimestamp = recoverAnchor(lastEntryTimestamp)
        )
        heartRateList.clear()
        maxDeliveredBlockTimestamp = 0L
        maxDeliveredEntryTimestamp = 0L
    }

    @Synchronized
    fun setHeartRateList(heartRateList: ArrayList<HeartRate>) {
        this.heartRateList = heartRateList
    }

    @Synchronized
    fun setIsNextPage(nextPage: Boolean) {
        this.nextPage = nextPage
    }

    override fun getId(): Byte  = 0x54.toByte()

    override fun errorId(): Byte = 0xD4.toByte()

    @Synchronized
    override fun bytesToWrite(): ByteArray {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        calendar.timeInMillis = activeHeartRateTimestamp.lastBlockTimestamp

        return createCommandBytes {
            this[1] = if (nextPage) NEXT_PAGE_FLAG else FIRST_PAGE_FLAG
            calendar.writeBcdTimeToArray(this, TIMESTAMP_START_INDEX)
        }
    }

    @Synchronized
    override fun read(data: ByteArray): HeartRateData {
        log(TAG, "Activity heart rate data ${data.contentToString()}")

        val recordCount = data.size / RECORD_SIZE
        if (recordCount == 0) {
            return createHeartRateData(isEndOfData = true, hasMoreData = false)
        }

        for (i in 0 until recordCount) {
            // A corrupted record (invalid BCD or impossible date) is skipped, not fatal —
            // aborting here would lose the rest of the page and stall the transfer.
            val heartRateRecord = parseHeartRateRecord(data, i)
            if (heartRateRecord == null) {
                log(TAG, "Skipping unparseable activity heart rate record at offset ${i * RECORD_SIZE}")
                continue
            }
            processHeartRateRecord(data, heartRateRecord)

            if (shouldReturnPage(heartRateRecord.dataNumber)) {
                return createHeartRateData(isEndOfData = true, hasMoreData = heartRateRecord.timeInMilliseconds > activeHeartRateTimestamp.lastBlockTimestamp)
            }
        }
        val endOfData = isEndOfData(data)
        return createHeartRateData(isEndOfData = endOfData, hasMoreData = !endOfData)
    }

    private fun parseHeartRateRecord(data: ByteArray, recordIndex: Int): ActiveHeartRateRecord? {
        val offset = recordIndex * RECORD_SIZE
        val dataNumber = data.toIntLE(DATA_NUMBER_OFFSET + offset, 2)
        val bcdTime = data.toBcdTimeOrNull(BCD_TIME_OFFSET + offset) ?: return null
        val timeInSeconds = bcdTime.toEpochMilliSecondsOrNull() ?: return null

        return ActiveHeartRateRecord(dataNumber, bcdTime, timeInSeconds, offset)
    }

    private fun processHeartRateRecord(data: ByteArray, record: ActiveHeartRateRecord) {
        val heartRateArray = processMinuteHeartRates(data, record)
        logHeartRateRecord(record, heartRateArray)
    }

    private fun processMinuteHeartRates(data: ByteArray, record: ActiveHeartRateRecord): String {
        return buildString {
            for (j in (HEART_RATES_PER_RECORD - 1) downTo 0) {
                val heartRate = data[HEART_RATE_DATA_OFFSET + j + record.offset].toPositionedInt(0)
                insert(0, "$heartRate ")

                val timestamp = record.timeInMilliseconds + (j * MILLISECONDS_PER_MINUTE)
                if (shouldAddHeartRate(heartRate, timestamp)) {
                    addHeartRateEntry(record, heartRate, timestamp)
                }
            }
        }
    }

    // 0xFF (255) is the firmware "end of activity / no data" sentinel — never a real BPM (QA-207).
    // A sample stamped beyond the skew allowance is dropped for now rather than delivered:
    // delivering it would either poison the anchor or, with a clamped anchor, be re-uploaded
    // on every sync; it is re-fetched once the wall clock passes it.
    private fun shouldAddHeartRate(heartRate: Int, timestamp: Long): Boolean {
        return heartRate > 0 &&
                heartRate != 255 &&
                timestamp > activeHeartRateTimestamp.lastEntryTimestamp &&
                timestamp <= System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS
    }

    private fun addHeartRateEntry(record: ActiveHeartRateRecord, heartRate: Int, timestamp: Long) {
        heartRateList.add(HeartRate(timestamp, heartRate))
        maxDeliveredBlockTimestamp = maxOf(maxDeliveredBlockTimestamp, record.timeInMilliseconds)
        maxDeliveredEntryTimestamp = maxOf(maxDeliveredEntryTimestamp, timestamp)
    }

    private fun logHeartRateRecord(record: ActiveHeartRateRecord, heartRateArray: String) {
        log(TAG, "Data Number: ${record.dataNumber}, Date: ${record.bcdTime.toDateString()}, " +
                "Heart Rate Array: $heartRateArray")
    }

    private fun shouldReturnPage(dataNumber: Int): Boolean {
        return (dataNumber + 1) % PAGE_SIZE == 0
    }

    /**
     * Snapshot of the samples accumulated so far together with the matching sync anchors.
     * List and anchors are latched under the same lock, so a frame parsed after this
     * snapshot can never advance an anchor past samples missing from the list.
     */
    private fun createHeartRateData(isEndOfData: Boolean, hasMoreData: Boolean): HeartRateData {
        return HeartRateData(
            isEndOfData = isEndOfData,
            hasMoreData = hasMoreData,
            heartRates = ArrayList(heartRateList),
            lastBlockTimestamp = currentBlockAnchor(),
            lastEntryTimestamp = currentEntryAnchor()
        )
    }

    private fun isEndOfData(data: ByteArray): Boolean {
        return data.lastOrNull() == END_OF_DATA_MARKER
    }

    /** Ends the transfer with whatever was received so far (band error, silence, disconnect). */
    @Synchronized
    fun snapshotEnd(): HeartRateData {
        return createHeartRateData(isEndOfData = true, hasMoreData = false)
    }

    /**
     * Anchors for the next sync: the newest record/sample delivered this sync, falling back
     * to the previous anchors when nothing was delivered. Matching iOS, a truncated transfer
     * continues from the newest delivered sample — its undelivered remainder is re-fetched
     * by the next sync. The clamp is a backstop; delivery already filters future samples.
     */
    private fun currentBlockAnchor(): Long {
        return clampAnchor(maxOf(activeHeartRateTimestamp.lastBlockTimestamp, maxDeliveredBlockTimestamp))
    }

    private fun currentEntryAnchor(): Long {
        return clampAnchor(maxOf(activeHeartRateTimestamp.lastEntryTimestamp, maxDeliveredEntryTimestamp))
    }
}
