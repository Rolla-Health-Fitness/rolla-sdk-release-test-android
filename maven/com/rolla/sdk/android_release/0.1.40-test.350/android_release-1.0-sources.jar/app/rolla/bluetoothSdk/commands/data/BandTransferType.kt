package app.rolla.bluetoothSdk.commands.data

/**
 * The multi-packet history transfers a band sync runs. Used to track per-device,
 * per-transfer liveness (last frame seen, watchdog state) so one metric's stalled
 * transfer can never block or be masked by another's.
 */
enum class BandTransferType {
    HEART_RATE,
    STEPS,
    SLEEP,
    HRV,
    MOTION,
}
