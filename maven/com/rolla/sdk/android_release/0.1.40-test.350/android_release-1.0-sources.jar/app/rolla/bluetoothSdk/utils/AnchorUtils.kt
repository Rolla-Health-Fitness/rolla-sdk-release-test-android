package app.rolla.bluetoothSdk.utils

// Band clock skew tolerance: samples stamped further in the future than this are
// dropped for now (they are re-fetched once the wall clock passes them), so a
// persisted anchor can never end up ahead of the data the band actually has.
const val MAX_ANCHOR_SKEW_MS = 5 * 60 * 1000L

/**
 * A persisted anchor far ahead of the wall clock (from a corrupt record parsed by an
 * older SDK) would make every fetch return empty until real time catches up — pulling
 * it back to now re-opens the window immediately. Anchors within the skew allowance
 * are honored: they come from legitimate small band-clock skew, and lowering them
 * would make the band re-deliver the overlap on every sync.
 */
fun recoverAnchor(anchor: Long): Long {
    return if (anchor > System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS) System.currentTimeMillis() else anchor
}

/** Backstop clamp for outgoing anchors; delivery already filters future-stamped samples. */
fun clampAnchor(anchor: Long): Long {
    return minOf(anchor, System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS)
}
