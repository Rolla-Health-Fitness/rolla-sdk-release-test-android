package app.rolla.bluetoothSdk.commands.data

/**
 * The persisted fetch-from anchors a history command was started with. Anchors for the
 * NEXT sync are derived from the samples actually delivered (each command's maxDelivered
 * tracking), never by mutating these values mid-transfer — an anchor advanced from parse
 * state could pass samples that were filtered or lost and permanently skip them.
 */
data class SyncTimestamp(
    val lastBlockTimestamp: Long = 0L,
    val lastEntryTimestamp: Long = 0L,
)
