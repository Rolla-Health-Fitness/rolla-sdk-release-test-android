package app.rolla.bluetoothSdk.result.error

class OperationTimedOut(operationName: String) : Error (
    code = ErrorCodes.OPERATION_TIMED_OUT,
    message = "$operationName timed out waiting for the device"
)
