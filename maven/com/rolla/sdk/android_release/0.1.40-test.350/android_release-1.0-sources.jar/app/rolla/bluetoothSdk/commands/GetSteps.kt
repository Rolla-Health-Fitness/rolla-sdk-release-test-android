package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.characteristics.data.StepsData
import app.rolla.bluetoothSdk.commands.data.StepRecord
import app.rolla.bluetoothSdk.commands.data.Steps
import app.rolla.bluetoothSdk.commands.data.SyncTimestamp
import app.rolla.bluetoothSdk.utils.MAX_ANCHOR_SKEW_MS
import app.rolla.bluetoothSdk.utils.clampAnchor
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.recoverAnchor
import app.rolla.bluetoothSdk.utils.toBcdTimeOrNull
import app.rolla.bluetoothSdk.utils.toEpochMilliSecondsOrNull
import app.rolla.bluetoothSdk.utils.toIntLE
import app.rolla.bluetoothSdk.utils.toPositionedInt
import app.rolla.bluetoothSdk.utils.writeBcdTimeToArray
import java.util.Calendar
import java.util.TimeZone

class GetSteps : Command<StepsData> {

    // Mutated on the GATT callback thread via read(), snapshotted from coroutine threads
    // via snapshotEnd() — every access to this state is @Synchronized.
    private var stepList: MutableList<Steps> = mutableListOf()
    private var stepTimestamp: SyncTimestamp = SyncTimestamp()
    private var nextPage = false
    private var maxDeliveredBlockTimestamp = 0L
    private var maxDeliveredEntryTimestamp = 0L

    companion object {
        const val TAG = "GetSteps"
        private const val NEXT_PAGE_FLAG = 0x02.toByte()
        private const val FIRST_PAGE_FLAG = 0x00.toByte()
        private const val TIMESTAMP_START_INDEX = 4
        private const val RECORD_SIZE = 25
        private const val DATA_NUMBER_OFFSET = 1
        private const val BCD_TIME_OFFSET = 3
        private const val TOTAL_STEPS_OFFSET = 9
        private const val CALORIES_OFFSET = 11
        private const val DISTANCE_OFFSET = 13
        private const val STEPS_DATA_OFFSET = 15
        private const val STEPS_PER_RECORD = 10
        private const val MILLISECONDS_PER_MINUTE = 60 * 1000
        private const val CALORIES_DIVISOR = 100f
        private const val DISTANCE_DIVISOR = 100f
        private const val PAGE_SIZE = 50 * 9
        private const val END_OF_DATA_MARKER = 0xff.toByte()
    }

    @Synchronized
    fun setStepTimestamp(lastBlockTimestamp: Long, lastEntryTimestamp: Long) {
        stepTimestamp = SyncTimestamp(
            lastBlockTimestamp = recoverAnchor(lastBlockTimestamp),
            lastEntryTimestamp = recoverAnchor(lastEntryTimestamp)
        )
        stepList.clear()
        maxDeliveredBlockTimestamp = 0L
        maxDeliveredEntryTimestamp = 0L
    }

    @Synchronized
    fun setIsNextPage(nextPage: Boolean) {
        this.nextPage = nextPage
    }

    override fun getId(): Byte = 0x52.toByte()

    override fun errorId(): Byte = 0xD2.toByte()

    @Synchronized
    override fun bytesToWrite(): ByteArray {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        calendar.timeInMillis = stepTimestamp.lastBlockTimestamp

        return createCommandBytes {
            this[1] = if (nextPage) NEXT_PAGE_FLAG else FIRST_PAGE_FLAG
            calendar.writeBcdTimeToArray(this, TIMESTAMP_START_INDEX)
        }
    }

    @Synchronized
    override fun read(data: ByteArray): StepsData {
        log(TAG, "Step count detailed data ${data.contentToString()}")

        val recordCount = data.size / RECORD_SIZE
        if (recordCount == 0) {
            return createStepsData(isEndOfData = true, hasMoreData = false)
        }

        for (i in 0 until recordCount) {
            // A corrupted record (invalid BCD or impossible date) is skipped, not fatal —
            // aborting here would lose the rest of the page and stall the transfer.
            val stepRecord = parseStepRecord(data, i)
            if (stepRecord == null) {
                log(TAG, "Skipping unparseable step record at offset ${i * RECORD_SIZE}")
                continue
            }
            processStepRecord(data, stepRecord)

            if (shouldReturnPage(stepRecord.dataNumber)) {
                return createStepsData(isEndOfData = true, hasMoreData = stepRecord.timeInMilliseconds > stepTimestamp.lastBlockTimestamp)
            }
        }
        val endOfData = isEndOfData(data)
        return createStepsData(isEndOfData = endOfData, hasMoreData = !endOfData)
    }

    private fun parseStepRecord(data: ByteArray, recordIndex: Int): StepRecord? {
        val offset = recordIndex * RECORD_SIZE
        val dataNumber = data.toIntLE(DATA_NUMBER_OFFSET + offset, 2)
        val bcdTime = data.toBcdTimeOrNull(BCD_TIME_OFFSET + offset) ?: return null
        val totalSteps = data.toIntLE(TOTAL_STEPS_OFFSET + offset, 2)
        val calories = data.toIntLE(CALORIES_OFFSET + offset, 2)
        val distance = data.toIntLE(DISTANCE_OFFSET + offset, 2)
        val timeInMs = bcdTime.toEpochMilliSecondsOrNull() ?: return null

        return StepRecord(dataNumber, bcdTime, totalSteps, calories, distance, timeInMs, offset)
    }

    private fun processStepRecord(data: ByteArray, record: StepRecord) {
        val stepsArray = processMinuteSteps(data, record)
        logStepRecord(record, stepsArray)
    }

    private fun processMinuteSteps(data: ByteArray, record: StepRecord): String {
        return buildString {
            for (j in (STEPS_PER_RECORD - 1) downTo 0) {
                val steps = data[STEPS_DATA_OFFSET + j + record.offset].toPositionedInt(0)
                insert(0, "$steps ")

                val timestamp = record.timeInMilliseconds + (j * MILLISECONDS_PER_MINUTE)
                if (shouldAddStep(steps, timestamp)) {
                    addStepEntry(record, steps, timestamp)
                }
            }
        }
    }

    // A sample stamped beyond the skew allowance is dropped for now rather than delivered:
    // delivering it would either poison the anchor or, with a clamped anchor, be re-uploaded
    // on every sync; it is re-fetched once the wall clock passes it.
    private fun shouldAddStep(steps: Int, timestamp: Long): Boolean {
        return steps > 0 &&
                timestamp > stepTimestamp.lastEntryTimestamp &&
                timestamp <= System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS
    }

    private fun addStepEntry(record: StepRecord, steps: Int, timestamp: Long) {
        val caloriesPerStep = if (record.totalSteps > 0) {
            record.calories * (steps.toDouble() / record.totalSteps)
        } else 0.0

        stepList.add(Steps(timestamp, steps, caloriesPerStep / CALORIES_DIVISOR))
        maxDeliveredBlockTimestamp = maxOf(maxDeliveredBlockTimestamp, record.timeInMilliseconds)
        maxDeliveredEntryTimestamp = maxOf(maxDeliveredEntryTimestamp, timestamp)
    }

    private fun logStepRecord(record: StepRecord, stepsArray: String) {
        log(TAG, "Data Number: ${record.dataNumber}, Date: ${record.bcdTime.toDateString()}, " +
                "Step: ${record.totalSteps}, Calories: ${record.calories / CALORIES_DIVISOR}, " +
                "Distance: ${record.distance / DISTANCE_DIVISOR}km, Steps array: $stepsArray")
    }

    private fun shouldReturnPage(dataNumber: Int): Boolean {
        return (dataNumber + 1) % PAGE_SIZE == 0
    }

    /**
     * Snapshot of the samples accumulated so far together with the matching sync anchors.
     * List and anchors are latched under the same lock, so a frame parsed after this
     * snapshot can never advance an anchor past samples missing from the list.
     */
    private fun createStepsData(isEndOfData: Boolean, hasMoreData: Boolean): StepsData {
        return StepsData(
            isEndOfData = isEndOfData,
            hasMoreData = hasMoreData,
            steps = ArrayList(stepList),
            lastBlockTimestamp = currentBlockAnchor(),
            lastEntryTimestamp = currentEntryAnchor(),
        )
    }

    private fun isEndOfData(data: ByteArray): Boolean {
        return data.lastOrNull() == END_OF_DATA_MARKER
    }

    /** Ends the transfer with whatever was received so far (band error, silence, disconnect). */
    @Synchronized
    fun snapshotEnd(): StepsData {
        return createStepsData(isEndOfData = true, hasMoreData = false)
    }

    /**
     * Anchors for the next sync: the newest record/sample delivered this sync, falling back
     * to the previous anchors when nothing was delivered. Matching iOS, a truncated transfer
     * continues from the newest delivered sample — its undelivered remainder is re-fetched
     * by the next sync. The clamp is a backstop; delivery already filters future samples.
     */
    private fun currentBlockAnchor(): Long {
        return clampAnchor(maxOf(stepTimestamp.lastBlockTimestamp, maxDeliveredBlockTimestamp))
    }

    private fun currentEntryAnchor(): Long {
        return clampAnchor(maxOf(stepTimestamp.lastEntryTimestamp, maxDeliveredEntryTimestamp))
    }
}
