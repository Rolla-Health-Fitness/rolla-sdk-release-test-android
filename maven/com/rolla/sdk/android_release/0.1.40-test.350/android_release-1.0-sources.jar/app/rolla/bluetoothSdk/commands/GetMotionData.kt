package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.characteristics.data.MotionData
import app.rolla.bluetoothSdk.commands.data.Motion
import app.rolla.bluetoothSdk.commands.data.MotionRecord
import app.rolla.bluetoothSdk.utils.MAX_ANCHOR_SKEW_MS
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.toBcdTimeOrNull
import app.rolla.bluetoothSdk.utils.toEpochMilliSecondsOrNull
import app.rolla.bluetoothSdk.utils.toIntLE
import app.rolla.bluetoothSdk.utils.toPositionedInt

class GetMotionData : Command<MotionData> {

    // Mutated on the GATT callback thread via read(), snapshotted from coroutine threads
    // via snapshotEnd() — every access to this state is @Synchronized.
    private var motionList: MutableList<Motion> = mutableListOf()
    private var fromTimestamp: Long = 0
    private var nextPage = false
    private var secondLevelFirmware = false

    companion object {
        const val TAG = "GetMotionData"
        private const val NEXT_PAGE_FLAG = 0x02.toByte()
        private const val FIRST_PAGE_FLAG = 0x00.toByte()
        private const val RECORD_SIZE_LEGACY = 14
        private const val RECORD_SIZE_SECOND_LEVEL = 15
        private const val PAGE_SIZE_LEGACY = 50 * 17
        private const val PAGE_SIZE_SECOND_LEVEL = 50 * 16
        private const val DATA_NUMBER_OFFSET = 1
        private const val BCD_TIME_OFFSET = 3
        private const val HEART_RATE_OFFSET = 9
        private const val SPM_OFFSET = 10
        private const val EXERCISE_IDENTIFIER_OFFSET = 14
        private const val END_OF_DATA_MARKER = 0xff.toByte()
    }

    @Synchronized
    fun setFromTimestamp(timestamp: Long) {
        this.fromTimestamp = timestamp
        motionList.clear()
    }

    @Synchronized
    fun setIsNextPage(nextPage: Boolean) {
        this.nextPage = nextPage
    }

    @Synchronized
    fun setSecondLevelFirmware(enabled: Boolean) {
        secondLevelFirmware = enabled
    }

    private fun configuredRecordSize(): Int =
        if (secondLevelFirmware) RECORD_SIZE_SECOND_LEVEL else RECORD_SIZE_LEGACY

    private fun pageSize(recordSize: Int): Int =
        if (recordSize == RECORD_SIZE_SECOND_LEVEL) PAGE_SIZE_SECOND_LEVEL else PAGE_SIZE_LEGACY

    override fun getId(): Byte = 0x77.toByte()

    override fun errorId(): Byte = 0xF7.toByte()

    @Synchronized
    override fun bytesToWrite(): ByteArray {
        return createCommandBytes {
            this[1] = if (nextPage) NEXT_PAGE_FLAG else FIRST_PAGE_FLAG
        }
    }

    @Synchronized
    override fun read(data: ByteArray): MotionData {
        log(TAG, "Motion data ${data.contentToString()}")

        val rs = resolveRecordSize(data)
        val recordCount = data.size / rs
        if (recordCount == 0) {
            return createMotionData(isEndOfData = true, hasMoreData = false)
        }

        for (i in 0 until recordCount) {
            // A corrupted record (invalid BCD or impossible date) is skipped, not fatal —
            // aborting here would lose the rest of the page and stall the transfer.
            val motionRecord = parseMotionRecord(data, i, rs)
            if (motionRecord == null) {
                log(TAG, "Skipping unparseable motion record at offset ${i * rs}")
                continue
            }
            processMotionRecord(motionRecord)

            if (shouldReturnPage(motionRecord.dataNumber, rs)) {
                return createMotionData(isEndOfData = true, hasMoreData = motionRecord.timeInMilliseconds > fromTimestamp)
            }
        }
        val endOfData = isEndOfData(data)
        return createMotionData(isEndOfData = endOfData, hasMoreData = !endOfData)
    }

    private fun parseMotionRecord(data: ByteArray, recordIndex: Int, rs: Int): MotionRecord? {
        val offset = recordIndex * rs
        val dataNumber = data.toIntLE(DATA_NUMBER_OFFSET + offset, 2)
        val bcdTime = data.toBcdTimeOrNull(BCD_TIME_OFFSET + offset) ?: return null
        val heartRate = data[HEART_RATE_OFFSET + offset].toPositionedInt(0)
        val spm = data.toIntLE(SPM_OFFSET + offset, 4)

        val exerciseIdentifier = if (rs == RECORD_SIZE_SECOND_LEVEL) {
            data[EXERCISE_IDENTIFIER_OFFSET + offset].toInt() and 0xFF
        } else {
            null
        }

        val timeInMs = bcdTime.toEpochMilliSecondsOrNull() ?: return null

        return MotionRecord(dataNumber, bcdTime, heartRate, spm, timeInMs, offset, exerciseIdentifier)
    }

    private fun processMotionRecord(record: MotionRecord) {
        if (shouldAddMotion(record.timeInMilliseconds, record.heartRate)) {
            motionList.add(
                Motion(
                    record.timeInMilliseconds,
                    record.heartRate,
                    record.spm,
                    record.exerciseIdentifier
                )
            )
        }
        logMotionRecord(record)
    }

    // 0xFF (255) is the firmware "end of activity / no data" sentinel — drop the record
    // rather than persist a contaminated HR sample (QA-207). A record stamped beyond the
    // clock-skew allowance is fabricated (corrupt frame) — it must not enter the workout
    // reconstruction as a real sample.
    private fun shouldAddMotion(timestamp: Long, heartRate: Int): Boolean {
        return timestamp > fromTimestamp &&
                timestamp <= System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS &&
                heartRate != 255
    }

    private fun logMotionRecord(record: MotionRecord) {
        log(TAG, "Data Number: ${record.dataNumber}, Date: ${record.bcdTime.toDateString()}, " +
                "HR: ${record.heartRate}, SPM: ${record.spm}, id=${record.exerciseIdentifier}")
    }

    private fun shouldReturnPage(dataNumber: Int, recordSize: Int): Boolean {
        return (dataNumber + 1) % pageSize(recordSize) == 0
    }

    private fun createMotionData(isEndOfData: Boolean, hasMoreData: Boolean): MotionData {
        return MotionData(
            isEndOfData = isEndOfData,
            hasMoreData = hasMoreData,
            motionList = ArrayList(motionList)
        )
    }

    private fun isEndOfData(data: ByteArray): Boolean {
        return data.lastOrNull() == END_OF_DATA_MARKER
    }

    /** Ends the transfer with whatever was received so far (band error, silence, disconnect). */
    @Synchronized
    fun snapshotEnd(): MotionData {
        return createMotionData(isEndOfData = true, hasMoreData = false)
    }

    private fun resolveRecordSize(data: ByteArray): Int {
        val preferred = configuredRecordSize()
        val alternate = if (preferred == RECORD_SIZE_SECOND_LEVEL) {
            RECORD_SIZE_LEGACY
        } else {
            RECORD_SIZE_SECOND_LEVEL
        }

        val preferredScore = scoreRecordSizeCandidate(data, preferred)
        val alternateScore = scoreRecordSizeCandidate(data, alternate)

        if (alternateScore > preferredScore) {
            log(TAG, "Switching motion record size from $preferred to $alternate based on payload shape")
            return alternate
        }

        return preferred
    }

    private fun scoreRecordSizeCandidate(data: ByteArray, recordSize: Int): Int {
        if (recordSize <= 0 || data.isEmpty()) return Int.MIN_VALUE

        val payloadSize = if (isEndOfData(data)) data.size - 1 else data.size
        if (payloadSize < recordSize) return Int.MIN_VALUE

        val records = payloadSize / recordSize
        if (records == 0) return Int.MIN_VALUE

        var commandHeaderMatches = 0
        for (i in 0 until records) {
            val offset = i * recordSize
            if (data[offset] == getId()) {
                commandHeaderMatches++
            }
        }

        val fullFitBonus = if (payloadSize % recordSize == 0) 5 else 0
        val commandHeaderScore = commandHeaderMatches * 10
        val preferredBias = if (recordSize == configuredRecordSize()) 1 else 0
        return commandHeaderScore + fullFitBonus + preferredBias
    }
}
