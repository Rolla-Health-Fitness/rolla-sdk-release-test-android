package app.rolla.bluetoothSdk.connect

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import android.os.Build
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.executeWithBluetoothConnect
import app.rolla.bluetoothSdk.utils.getFullUUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import javax.inject.Singleton
import kotlinx.coroutines.*

@Singleton
class OperationQueue(private val context: Context) {
    companion object {
        private const val TAG = "OperationQueue"
        private const val OPERATION_TIMEOUT_MS = 10_000L
    }

    private val operationQueues = ConcurrentHashMap<String, LinkedBlockingQueue<BleOperation>>()
    private val activeOperations = ConcurrentHashMap<String, BleOperation>() // Changed from Boolean to BleOperation
    private val operationTimeouts = ConcurrentHashMap<String, Job>()

    fun queueOperation(operation: BleOperation) {
        log(TAG, "queueOperation() called for ${operation.deviceAddress} - ${operation.name}")
        val queue = operationQueues.computeIfAbsent(operation.deviceAddress) {
            LinkedBlockingQueue() 
        }
        queue.offer(operation)
        processNextOperation(operation.deviceAddress)
    }

    @SuppressLint("MissingPermission")
    private fun processNextOperation(deviceAddress: String) {
        context.executeWithBluetoothConnect(
            operation = {
                // Synchronize the entire check-and-start sequence
                synchronized(activeOperations) {
                    // Don't start new operation if one is already active
                    if (activeOperations.containsKey(deviceAddress)) {
                        activeOperations[deviceAddress]?.let { activeOperation ->
                            log(TAG, "Operation ${activeOperation.name} already active for $deviceAddress, returning")
                        }
                        return@executeWithBluetoothConnect
                    }

                    val queue = operationQueues[deviceAddress] ?: return@executeWithBluetoothConnect
                    val operation = queue.poll() ?: return@executeWithBluetoothConnect

                    log(TAG, "Start operation ${operation.name} for $deviceAddress")
                    activeOperations[deviceAddress] = operation

                    // Start timeout for this operation
                    startOperationTimeout(deviceAddress, operation)

                    // Execute the operation
                    executeOperationInternal(deviceAddress, operation)
                }
            },
            onPermissionDenied = {
                log(TAG, "Missing BLUETOOTH_CONNECT permission for operation queue")
                cleanup()
            }
        )
    }

    private fun startOperationTimeout(deviceAddress: String, operation: BleOperation) {
        // Cancel any existing timeout
        operationTimeouts.remove(deviceAddress)?.cancel()

        // Start new timeout (10 seconds)
        operationTimeouts[deviceAddress] = CoroutineScope(Dispatchers.IO).launch {
            delay(OPERATION_TIMEOUT_MS)
            // Expire ONLY the operation this timeout was started for. A cancelled timeout
            // can still reach this line (its delay may elapse just as the operation
            // completes), and one that outlives its operation must never complete
            // whichever operation happens to be active by then: that shifts every later
            // GATT callback onto the wrong operation, until one is left waiting for a
            // callback that has already been consumed and head-blocks the queue.
            completeOperation(deviceAddress, operation, false, -1)
        }
    }

    @SuppressLint("MissingPermission")
    fun executeOperationInternal(deviceAddress: String, operation: BleOperation) {
        when (operation) {
            is BleOperation.ReadCharacteristic -> {
                log(TAG, "Executing ReadCharacteristic for ${operation.characteristic.uuid.getFullUUID()}")
                val success = operation.gatt.readCharacteristic(operation.characteristic)
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress} - ${operation.characteristic.uuid.getFullUUID()}")
                    operationComplete(deviceAddress, false, BluetoothGatt.GATT_FAILURE)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress - ${operation.characteristic.uuid.getFullUUID()}")
                }
            }
            is BleOperation.WriteCharacteristic -> {
                log(TAG, "Executing WriteCharacteristic for ${operation.characteristic.uuid.getFullUUID()}")
                val success = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeCharacteristic(
                        operation.characteristic,
                        operation.data,
                        BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    ) == android.bluetooth.BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    operation.characteristic.value = operation.data
                    @Suppress("DEPRECATION")
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeCharacteristic(operation.characteristic)
                }
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress} - ${operation.characteristic.uuid.getFullUUID()}")
                    operationComplete(deviceAddress, false, null)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress - ${operation.characteristic.uuid.getFullUUID()}")
                }
            }
            is BleOperation.WriteDescriptor -> {
                log(TAG, "Executing WriteDescriptor for ${operation.descriptor.uuid}, value size: ${operation.value.size}")
                val success = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeDescriptor(
                        operation.descriptor,
                        operation.value
                    ) == android.bluetooth.BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    operation.descriptor.value = operation.value
                    @Suppress("DEPRECATION")
                    @SuppressLint("MissingPermission")
                    operation.gatt.writeDescriptor(operation.descriptor)
                }
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress} - ${operation.descriptor.uuid.getFullUUID()}")
                    operationComplete(deviceAddress, false, null)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress - ${operation.descriptor.uuid.getFullUUID()}")
                }
            }
            is BleOperation.ReadRssi -> {
                val success = operation.gatt.readRemoteRssi()
                if (!success) {
                    log(TAG, "${operation::class.simpleName} failed immediately for $deviceAddress}")
                    operationComplete(deviceAddress, false, null)
                } else {
                    log(TAG, "Operation ${operation.name} executed successfully for $deviceAddress")
                }
            }
        }
    }

    fun operationComplete(deviceAddress: String, success: Boolean, status: Int?) {
        completeOperation(deviceAddress, expected = null, success = success, status = status)
    }

    /**
     * Completes the operation currently active for [deviceAddress]. When [expected] is
     * given, the completion is dropped unless that exact operation is still the active
     * one — used by the timeout so a late or already-cancelled timeout cannot complete
     * an operation it was never started for.
     */
    private fun completeOperation(deviceAddress: String, expected: BleOperation?, success: Boolean, status: Int?) {
        // Synchronize the completion and next operation start
        synchronized(activeOperations) {
            if (expected != null && activeOperations[deviceAddress] !== expected) {
                log(TAG, "Timeout for ${expected.name} on $deviceAddress ignored - operation is no longer active")
                return
            }
            if (expected != null) {
                log(TAG, "Operation ${expected.name} timed out for $deviceAddress")
            }
            log(TAG, "operationComplete() called for $deviceAddress - success: $success, status: $status")
            // Cancel timeout
            operationTimeouts.remove(deviceAddress)?.cancel()
            // Get and remove the active operation
            val activeOperation = activeOperations.remove(deviceAddress)
            if (activeOperation != null) {
                log(TAG, "Completing operation: ${activeOperation.name}")
                activeOperation.onComplete(success, status)
            } else {
                log(TAG, "No active operation found for $deviceAddress")
            }
        }

        // Process next operation outside the synchronized block to avoid deadlock
        processNextOperation(deviceAddress)
    }

    fun clearQueue(deviceAddress: String) {
        val activeOperation: BleOperation?
        val queuedOperations: Collection<BleOperation>
        synchronized(activeOperations) {
            // Drop the pending timeout together with the operation it guards. A timeout
            // left running here outlives the teardown and fires into the NEXT connection
            // for the same device, completing an unrelated operation up to 10s later —
            // which is why a re-pair right after an unpair starved while one a minute
            // later worked.
            operationTimeouts.remove(deviceAddress)?.cancel()
            activeOperation = activeOperations.remove(deviceAddress)
            queuedOperations = operationQueues.remove(deviceAddress) ?: emptyList()
        }

        activeOperation?.onComplete(false, null)
        queuedOperations.forEach { operation ->
            operation.onComplete(false, null)
        }
    }

    fun cleanup() {
        val activeOperationsSnapshot: List<BleOperation>
        val queuedOperations: List<BleOperation>
        synchronized(activeOperations) {
            operationTimeouts.values.forEach { timeout -> timeout.cancel() }
            operationTimeouts.clear()

            activeOperationsSnapshot = activeOperations.values.toList()
            activeOperations.clear()

            queuedOperations = operationQueues.values.flatten()
            operationQueues.clear()
        }

        activeOperationsSnapshot.forEach { operation ->
            operation.onComplete(false, null)
        }
        queuedOperations.forEach { operation ->
            operation.onComplete(false, null)
        }
    }
}
