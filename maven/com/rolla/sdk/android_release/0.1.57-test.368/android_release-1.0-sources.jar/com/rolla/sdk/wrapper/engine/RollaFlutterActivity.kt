package com.rolla.sdk.wrapper.engine

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import com.rolla.sdk.R
import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaTransition
import com.rolla.sdk.wrapper.features.session.RollaCloseReason
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache

class RollaFlutterActivity : FlutterFragmentActivity() {

    companion object {
        /** Intent extra carrying the [RollaTransition] name chosen at [Rolla.show]. */
        internal const val EXTRA_TRANSITION = "com.rolla.sdk.wrapper.EXTRA_TRANSITION"

        @Volatile
        internal var onDismiss: ((RollaCloseReason) -> Unit)? = null

        @Volatile
        private var pendingCloseReason: RollaCloseReason? = null

        @Volatile
        private var currentInstance: RollaFlutterActivity? = null

        /** True while an SDK Activity instance exists (created and not yet destroyed). */
        internal val isAlive: Boolean
            get() = currentInstance != null

        /**
         * Brings the live SDK Activity back to the front of its task. Started from the
         * instance's own context so the target task is always the one it lives in —
         * a caller sitting in another task (a notification trampoline placed there by
         * affinity) would otherwise start a second instance beside it.
         *
         * False when no instance exists or the one that does is finishing — stricter
         * than [isAlive] on purpose: a dismiss runs `finish()` synchronously, but the
         * instance is only cleared in the later `onDestroy` message, and reordering a
         * finishing record to the front would start a fresh instance with no dismiss
         * wiring.
         */
        internal fun bringToFront(): Boolean {
            val instance = currentInstance ?: return false
            if (instance.isFinishing || instance.isDestroyed) return false
            instance.startActivity(
                Intent(instance, RollaFlutterActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            )
            return true
        }

        internal fun setPendingCloseReason(reason: RollaCloseReason) {
            pendingCloseReason = reason
        }

        internal fun clearCallbacks() {
            onDismiss = null
            pendingCloseReason = null
        }

        internal fun finishCurrent() {
            currentInstance?.finish()
        }
    }

    private var didNotifyDismiss = false
    private var backPressedDuringSession = false
    private var isFadeTransition = false

    /**
     * False when the system restores this instance after the process died: the
     * engine that backed it is gone, so there is nothing to show and the instance
     * only exists to finish. Decided once, in [onCreate], before anything attaches.
     */
    private var engineCached = true

    /**
     * The engine the Flutter fragment is handed while [engineCached] is false — a
     * bare one with no plugins and no Dart isolate, created only if the fragment
     * attaches before the finish lands, and destroyed with this instance.
     */
    private var throwawayEngine: FlutterEngine? = null

    // Null while the engine is gone: the delegate throws on a cache miss, which is
    // exactly the crash a restored instance must avoid.
    override fun getCachedEngineId(): String? = if (engineCached) RollaEngineManager.ENGINE_ID else null

    override fun provideFlutterEngine(context: Context): FlutterEngine? {
        if (engineCached) return null
        return FlutterEngine(context.applicationContext, null, false).also { throwawayEngine = it }
    }

    // Neither the activity control surface nor the plugins belong on the throwaway engine.
    override fun shouldAttachEngineToActivity(): Boolean = engineCached

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        if (engineCached) super.configureFlutterEngine(flutterEngine)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        engineCached = FlutterEngineCache.getInstance().contains(RollaEngineManager.ENGINE_ID)
        if (!engineCached) {
            // Restored by the system after the process died with the SDK UI in the
            // task — a relaunch from Recents, or a notification trampoline placed
            // above this record. Attaching the saved fragment to the missing cache
            // entry throws, so the saved state is dropped and the instance finishes
            // before it ever starts: it never shows, never counts as the SDK
            // activity, and the host hears nothing about it.
            super.onCreate(null)
            finish()
            return
        }
        super.onCreate(savedInstanceState)
        currentInstance = this
        didNotifyDismiss = false
        backPressedDuringSession = false
        isFadeTransition = intent?.getStringExtra(EXTRA_TRANSITION) == RollaTransition.FADE.name
        if (isFadeTransition && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // The API < 34 path runs overridePendingTransition in finish()
            // instead — every close funnels through that one override.
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        backPressedDuringSession = true
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!engineCached) {
            // The fragment has detached: the bare engine it was handed is ours to
            // destroy, and nothing below applies to an instance that never presented.
            throwawayEngine?.destroy()
            throwawayEngine = null
            return
        }
        // Guarded so a late onDestroy from a replaced instance cannot
        // unregister a newer, live Activity.
        if (currentInstance == this) {
            currentInstance = null
        }
        notifyDismissOnce()
        // After super.onDestroy() the Flutter delegate has detached from the
        // engine, so a teardown deferred by a host task removal is safe now.
        RollaEngineManager.notifySdkActivityDestroyed()
    }

    override fun finish() {
        if (pendingCloseReason == null && backPressedDuringSession) {
            pendingCloseReason = RollaCloseReason.HostNavigationBack
        }
        super.finish()
        if (isFadeTransition && Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    private fun notifyDismissOnce() {
        if (didNotifyDismiss) return
        didNotifyDismiss = true

        val reason = pendingCloseReason ?: RollaCloseReason.HostModalDismiss
        pendingCloseReason = null

        onDismiss?.invoke(reason)
        onDismiss = null
    }
}
