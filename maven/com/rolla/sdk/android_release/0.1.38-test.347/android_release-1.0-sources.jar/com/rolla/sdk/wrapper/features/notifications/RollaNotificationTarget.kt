package com.rolla.sdk.wrapper.features.notifications

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.features.navigation.RollaScreen
import org.json.JSONException
import org.json.JSONObject

/**
 * Where a tap on a Rolla SDK notification should lead, resolved from the
 * intent your launcher activity receives via [Rolla.notificationTarget].
 *
 * Every notification the SDK produces carries a payload naming its
 * destination; a `null` resolution means the tap did not come from a Rolla
 * notification.
 */
sealed class RollaNotificationTarget {

    /**
     * Take the user to the OS app-settings page — the notification asks them
     * to fix a permission (e.g. background location during a workout), so an
     * SDK screen would not help.
     */
    object AppSettings : RollaNotificationTarget()

    /** Open [screen] via [Rolla.openScreen]. */
    data class Screen(val screen: RollaScreen) : RollaNotificationTarget()

    companion object {
        /**
         * The intent extra carrying the Rolla payload. The key is
         * flutter_local_notifications' own `payload` extra, which the SDK's
         * native workout notifications mirror; the JSON marker inside the
         * payload — not the key — is what identifies Rolla.
         */
        internal const val PAYLOAD_EXTRA = "payload"

        /**
         * The payload both native workout foreground notifications
         * (BleForegroundService, LocationService) attach to their tap intent:
         * `resume` shows the SDK UI exactly as the user left it — mid-workout,
         * the live tracking screen. Shared verbatim with the Dart
         * RollaNotificationPayload contract.
         */
        internal const val WORKOUT_TAP_PAYLOAD = """{"rolla":1,"type":"workoutInProgress","target":"resume"}"""

        // Wire contract shared verbatim with the Dart RollaNotificationPayload
        // and the iOS RollaNotificationTarget — keep all three in sync.
        private const val MARKER_KEY = "rolla"
        private const val TARGET_KEY = "target"
        private const val TARGET_APP_SETTINGS = "appSettings"

        internal fun parse(payload: String?): RollaNotificationTarget? {
            if (payload.isNullOrEmpty()) return null
            val json = try {
                JSONObject(payload)
            } catch (_: JSONException) {
                return null
            }
            // Any integer marker version >= 1 is a Rolla notification; an
            // unknown target from a newer contract still resolves — to Home.
            // Strictly an integer (org.json parses to Int or Long) — never a
            // coerced string/double/boolean, matching the Dart parser exactly.
            val version = when (val marker = json.opt(MARKER_KEY)) {
                is Int -> marker
                is Long -> if (marker > 0) 1 else 0
                else -> 0
            }
            if (version < 1) return null
            return when (val target = json.optString(TARGET_KEY)) {
                TARGET_APP_SETTINGS -> AppSettings
                else -> Screen(RollaScreen.entries.firstOrNull { it.rawValue == target } ?: RollaScreen.HOME)
            }
        }
    }
}
