package com.rolla.sdk.ble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.rolla.sdk.wrapper.engine.RollaEngineManager
import com.rolla.sdk.wrapper.features.notifications.RollaNotificationTarget

/**
 * Foreground service used to keep the app process alive during BLE-only workouts
 * (e.g. cardio), so the OS is less likely to stop BLE connectivity/processing.
 *
 * Note: this service does not manage the BLE connection itself; it provides the
 * required foreground classification + ongoing notification.
 */
class BleForegroundService : Service() {

    companion object {
        private const val NOTIFICATION_ID = 2001
        private const val CHANNEL_ID = "ble_workout"

        private const val ACTION_START = "com.rolla.sdk.ACTION_START_BLE_WORKOUT"
        private const val ACTION_STOP = "com.rolla.sdk.ACTION_STOP_BLE_WORKOUT"

        fun start(context: Context) {
            val intent = Intent(context, BleForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, BleForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_START, null -> {
                showNotification()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Workout (Bluetooth)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Bluetooth workout running in the background"
                enableLights(false)
                enableVibration(false)
                setBypassDnd(false)
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun showNotification() {
        val notification = createNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotification(): Notification {
        // Find the launcher activity dynamically to make the SDK app-agnostic
        val launcherIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = if (launcherIntent != null) {
            // Marks the notification as Rolla's and names its tap destination
            // for the Rolla.notificationTarget resolver.
            launcherIntent.putExtra(RollaNotificationTarget.PAYLOAD_EXTRA, RollaNotificationTarget.WORKOUT_TAP_PAYLOAD)
            PendingIntent.getActivity(
                this,
                // The notification id as request code keeps this PendingIntent
                // distinct from any bare launcher PendingIntent the host app
                // creates — FLAG_UPDATE_CURRENT would otherwise overwrite the
                // extras of whichever was created first.
                NOTIFICATION_ID,
                launcherIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } else {
            null
        }

        // Get the app's icon dynamically
        val appIcon = try {
            val appInfo = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            appInfo.icon
        } catch (e: PackageManager.NameNotFoundException) {
            android.R.drawable.ic_dialog_info // Fallback to system icon
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Workout in progress")
            .setContentText("Keeping Bluetooth connection active…")
            .setSmallIcon(appIcon)
            .apply {
                if (pendingIntent != null) {
                    setContentIntent(pendingIntent)
                }
            }
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setShowWhen(false)
            .build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // The user swiped a host task away while this service kept the process
        // alive. The Add-to-App engine manager decides whether that ended the
        // host UI and, if so, stops this service and tears the engine down so
        // the next launch does not resume a stale SDK session (no-op for
        // Flutter-package hosts).
        RollaEngineManager.notifyHostTaskRemoved(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
