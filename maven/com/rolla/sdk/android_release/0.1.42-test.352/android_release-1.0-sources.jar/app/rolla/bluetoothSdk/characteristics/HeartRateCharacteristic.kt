package app.rolla.bluetoothSdk.characteristics

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.characteristics.data.HeartRateMeasurementData
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.isBitSet
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.toUShortLE
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class HeartRateCharacteristic @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext
) : Characteristic {

    companion object {
        const val TAG = "HeartRateCharacteristic"

        // Heart Rate Flags bit positions. Of the two sensor contact bits, the
        // higher one says whether the sensor reports contact at all and the
        // lower one whether it has contact right now.
        private const val FLAG_HR_VALUE_FORMAT = 0
        private const val FLAG_SENSOR_CONTACT_DETECTED = 1
        private const val FLAG_SENSOR_CONTACT_SUPPORTED = 2
        private const val FLAG_ENERGY_EXPENDED_PRESENT = 3
        private const val FLAG_RR_INTERVAL_PRESENT = 4

        // RR-Interval conversion constants
        private const val RR_INTERVAL_RESOLUTION = 1000
        private const val RR_INTERVAL_DIVISOR = 1024
    }

    override val uuid: String = "2A37".getFullUUID()
    override val scope = CoroutineScope(bleScopeContext)

    private val _dataFlow = MutableSharedFlow<HeartRateMeasurementData>(replay = 1)
    val dataFlow: SharedFlow<HeartRateMeasurementData> = _dataFlow.asSharedFlow()

    override fun onRead(byteArray: ByteArray, device: BleDevice) {
        processHeartRateData(byteArray, device)
    }

    override fun onNotify(byteArray: ByteArray, device: BleDevice) {
        processHeartRateData(byteArray, device)
    }

    private fun processHeartRateData(byteArray: ByteArray, device: BleDevice) {
        if (byteArray.isEmpty()) {
            throw IllegalArgumentException("Heart rate data is empty")
        }

        val heartRateData = parseHeartRate(byteArray, device.getMacAddress())
        log(
            TAG,
            "HR: ${heartRateData.heartRate} BPM, Contact: ${heartRateData.sensorContactDetected}, " +
                    "Energy: ${heartRateData.energyExpended} kJ, RR: ${heartRateData.rrIntervals?.size ?: 0} intervals"
        )

        scope.launch {
            _dataFlow.emit(heartRateData)
        }
    }

    /**
     * Parse heart rate measurement data according to Bluetooth Heart Rate Service specification.
     *
     * @param data Raw bytes from heart rate characteristic
     * @param deviceAddress MAC address of the device the bytes came from
     * @return Complete heart rate measurement data
     */
    private fun parseHeartRate(data: ByteArray, deviceAddress: String): HeartRateMeasurementData {
        if (data.isEmpty()) {
            throw IllegalArgumentException("Heart rate data cannot be empty")
        }

        val flags = data[0].toUByte().toInt()
        val is16BitFormat = flags.isBitSet(FLAG_HR_VALUE_FORMAT)
        val hasSensorContact = flags.isBitSet(FLAG_SENSOR_CONTACT_SUPPORTED)
        val sensorContactDetected = if (hasSensorContact) flags.isBitSet(FLAG_SENSOR_CONTACT_DETECTED) else null
        val hasEnergyExpended = flags.isBitSet(FLAG_ENERGY_EXPENDED_PRESENT)
        val hasRrInterval = flags.isBitSet(FLAG_RR_INTERVAL_PRESENT)

        var offset = 1

        // Heart Rate Value (8-bit or 16-bit)
        val heartRate = if (is16BitFormat) {
            if (data.size < offset + 2) {
                throw IllegalArgumentException("Insufficient data for 16-bit heart rate")
            }
            val value = data.toUShortLE(offset).toInt()
            offset += 2
            value
        } else {
            if (data.size < offset + 1) {
                throw IllegalArgumentException("Insufficient data for 8-bit heart rate")
            }
            val value = data[offset].toUByte().toInt()
            offset += 1
            value
        }

        // Energy Expended (optional, 16-bit)
        var energyExpended: Int? = null
        if (hasEnergyExpended) {
            if (data.size < offset + 2) {
                throw IllegalArgumentException("Insufficient data for energy expended")
            }
            energyExpended = data.toUShortLE(offset).toInt()
            offset += 2
        }

        // RR-Intervals (optional, multiple 16-bit values)
        var rrIntervals: List<Int>? = null
        if (hasRrInterval && offset < data.size) {
            val intervals = mutableListOf<Int>()
            while (offset + 1 < data.size) {
                val rrValue = data.toUShortLE(offset).toInt()
                intervals.add((rrValue * RR_INTERVAL_RESOLUTION) / RR_INTERVAL_DIVISOR)
                offset += 2
            }
            rrIntervals = intervals.takeIf { it.isNotEmpty() }
        }

        return HeartRateMeasurementData(
            heartRate = heartRate,
            deviceAddress = deviceAddress,
            sensorContactDetected = sensorContactDetected,
            energyExpended = energyExpended,
            rrIntervals = rrIntervals
        )
    }
}