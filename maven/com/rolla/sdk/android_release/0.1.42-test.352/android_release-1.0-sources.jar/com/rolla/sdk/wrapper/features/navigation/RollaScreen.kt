package com.rolla.sdk.wrapper.features.navigation

import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaConfiguration
import com.rolla.sdk.wrapper.config.RollaDisabledModule

/** SDK screens a host app can open directly via [Rolla.openScreen]. */
enum class RollaScreen(val rawValue: String) {
    /**
     * The activity history — every recorded activity, with month and day
     * filtering.
     */
    ACTIVITY_HISTORY("activityHistory"),

    /** The goals editor. */
    GOALS("goals"),

    /**
     * The SDK Home screen. Returns the SDK to its regular entry point after
     * another screen was opened as the root — no engine restart needed.
     */
    HOME("home"),

    /**
     * The insights feed. Requires the insights module to be enabled; with
     * [RollaDisabledModule.INSIGHTS] in [RollaConfiguration.disabledModules]
     * the open resolves as [RollaOpenScreenStatus.SCREEN_DISABLED].
     */
    INSIGHTS("insights"),

    /**
     * The Nutrition tab: today's calorie budget, what has been logged against
     * it, and hydration. Requires the nutrition module to be enabled; with
     * [RollaDisabledModule.NUTRITION] in [RollaConfiguration.disabledModules]
     * the open resolves as [RollaOpenScreenStatus.SCREEN_DISABLED].
     */
    NUTRITION("nutrition"),

    /**
     * The SDK UI exactly as the user left it — the last opened screen, or
     * Home on a fresh engine. Performs no navigation and always resolves as
     * [RollaOpenScreenStatus.OPENED].
     */
    RESUME("resume"),
}
