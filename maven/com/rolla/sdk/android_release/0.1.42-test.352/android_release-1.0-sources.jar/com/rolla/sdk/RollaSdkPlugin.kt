package com.rolla.sdk

import android.content.Intent
import android.util.Log
import androidx.annotation.NonNull
import com.rolla.sdk.generated.GroupInstallationHostApi
import com.rolla.sdk.hostImpl.GroupInstallationHandler
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodChannel

/**
 * RollaSdkPlugin - Zero-config Flutter plugin for Rolla SDK
 *
 * Automatically initializes all native components when attached to Flutter engine.
 * NO Hilt configuration required in host app!
 *
 * The plugin uses RollaAndroidSdk.init() which internally manages Hilt/Dagger DI
 * without requiring the host app to configure @HiltAndroidApp or @AndroidEntryPoint.
 *
 * Partner apps just need:
 * ```yaml
 * dependencies:
 *   rolla_sdk: ^0.1.0
 * ```
 */
class RollaSdkPlugin : FlutterPlugin {

    companion object {
        private const val TAG = "RollaSdkPlugin"
    }

    private var bridge: RollaBluetoothBridge? = null
    private var appLauncherChannel: MethodChannel? = null

    override fun onAttachedToEngine(@NonNull flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        // Registered before the SDK bridge on purpose: the installation marker must stay
        // readable even when bridge initialization fails, so group-session cleanup can run.
        GroupInstallationHostApi.setUp(
            flutterPluginBinding.binaryMessenger,
            GroupInstallationHandler(flutterPluginBinding.applicationContext),
        )
        try {
            // Initialize SDK with application context (internally handles Hilt/Dagger)
            val sdk = RollaAndroidSdk.init(flutterPluginBinding.applicationContext)

            // Create the bridge which registers all Pigeon handlers
            bridge = sdk.createBridge(
                context = flutterPluginBinding.applicationContext,
                binaryMessenger = flutterPluginBinding.binaryMessenger
            )

            HealthConnectWorkoutDetailsBridge.register(
                context = flutterPluginBinding.applicationContext,
                messenger = flutterPluginBinding.binaryMessenger,
            )

            appLauncherChannel = MethodChannel(
                flutterPluginBinding.binaryMessenger,
                "rolla_sdk/app_launcher",
            ).apply {
                setMethodCallHandler { call, result ->
                    if (call.method == "launchApp") {
                        val packageName = call.argument<String>("packageName")
                        if (packageName == null) {
                            result.error("INVALID_ARGUMENT", "packageName is required", null)
                            return@setMethodCallHandler
                        }
                        val context = flutterPluginBinding.applicationContext
                        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                        if (intent != null) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    } else {
                        result.notImplemented()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize RollaSdk", e)
        }
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        GroupInstallationHostApi.setUp(binding.binaryMessenger, null)
        bridge?.cleanUp()
        bridge = null
        appLauncherChannel?.setMethodCallHandler(null)
        appLauncherChannel = null
    }
}
