package com.rolla.sdk.hostImpl

import android.content.Context
import android.util.AtomicFile
import com.rolla.sdk.generated.FlutterError
import com.rolla.sdk.generated.GroupInstallationHostApi
import java.io.File
import java.util.UUID

/**
 * Per-install marker for group sessions.
 *
 * Lives in [Context.getNoBackupFilesDir], so it is created once per installation, never
 * restored from a backup onto another device, and gone after an uninstall. Combined with the
 * keychain-backed installation id it lets the SDK tell a reinstall from an app update, which
 * secure storage alone cannot do.
 */
class GroupInstallationHandler(private val context: Context) : GroupInstallationHostApi {

    override fun installationMarker(): String {
        try {
            val marker = File(context.noBackupFilesDir, MARKER_FILE)
            return synchronized(LOCK) {
                if (marker.exists()) {
                    marker.readText()
                } else {
                    val id = UUID.randomUUID().toString()
                    val atomic = AtomicFile(marker)
                    val stream = atomic.startWrite()
                    try {
                        stream.write(id.toByteArray())
                        atomic.finishWrite(stream)
                    } catch (error: Exception) {
                        atomic.failWrite(stream)
                        throw error
                    }
                    id
                }
            }
        } catch (_: Exception) {
            throw FlutterError("STORAGE_UNAVAILABLE", "Installation storage unavailable", null)
        }
    }

    private companion object {
        const val MARKER_FILE = "rolla_group_installation"

        /** Process-wide: two engines must never race to create the marker. */
        val LOCK = Any()
    }
}
