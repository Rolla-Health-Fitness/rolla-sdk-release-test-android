package com.rolla.sdk.wrapper.config

data class RollaConfiguration(
    val token: String,
    val partnerId: String,
    val refreshToken: String? = null,
    val tokenExpiresIn: Int? = null,
    val userId: String? = null,
    val environment: String = "rnd",
    val disabledModules: Set<RollaDisabledModule> = emptySet(),
    val disabledDataSources: Set<RollaDataSource> = emptySet(),
    /**
     * SDK UI language. When set, it is authoritative for the Flutter engine's
     * lifetime and replaces persisted picks and the user's backend profile
     * language. null keeps the profile-driven behavior.
     */
    val language: RollaLanguage? = null,
    val branding: RollaBranding? = null,
    val showOptionsButton: Boolean = true,
    val showGoalsSection: Boolean = false,
    /**
     * Custom URL scheme the Rolla backend redirects to at the end of a
     * cloud-source OAuth flow (Garmin/Oura). Must match the `app_scheme`
     * configured for your partner on the Rolla backend, and the same scheme
     * must be registered on flutter_web_auth_2's CallbackActivity in the host
     * app manifest. When set, those connects run in an in-app auth session
     * that returns to the app automatically. null (default) opens them in the
     * external browser.
     */
    val oauthCallbackScheme: String? = null,
)
