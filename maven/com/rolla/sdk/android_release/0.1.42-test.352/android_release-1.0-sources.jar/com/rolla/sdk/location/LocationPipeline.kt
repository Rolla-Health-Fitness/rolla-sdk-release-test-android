package com.rolla.sdk.location

import android.location.Location
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.generated.BandActivityType
import kotlin.math.*

/**
 * GPS processing pipeline — direct port of iOS DefaultLocationDataProcessor
 * from the location-improvements branch.
 *
 * Pipeline flow:
 *   Raw GPS → timestamp validation → GPS gap detection → accuracy/coordinate validation →
 *   calibration → [over-speed lockout] → post-calibration warm-up → Gate A (speed) →
 *   Gate B (lateral deviation) → Gate C (course spike) → consecutive rejection handling →
 *   stationary detection → minimum emit distance → EMA smoothing → emit
 */
class LocationPipeline(
    private val activityType: BandActivityType,
    private val config: LocationActivityConfig,
    private val trackingStartTimeMs: Long,
    private val logger: LocationDebugCapture = LocationDebugCapture
) {
    companion object {
        private const val TAG = "LocationPipeline"

        // Consecutive plausible, moving fixes needed to leave the over-speed
        // lockout. One fix is scatter; four in a row at walking pace and
        // consistent with each other is a person on foot again.
        private const val LOCKOUT_EXIT_CONSECUTIVE_FIXES = 4

        // Relapse hysteresis: a lockout re-entered shortly after an exit, with
        // vehicle-speed Doppler seen in between, is stop-and-go traffic that
        // crept at walking pace — not a walk. A car rarely holds ≤ maxSpeedMps
        // for 12 s straight; a walker does it trivially. The Doppler condition
        // spares a walker whose exit landed on a GPS shadow and snapped back:
        // that re-lockout shows no vehicle Doppler and keeps the short exit.
        private const val LOCKOUT_EXIT_CONSECUTIVE_FIXES_AFTER_RELAPSE = 12
        private const val LOCKOUT_RELAPSE_WINDOW_MS = 60_000L

        // The fix that ends the lockout becomes the anchor, so it must be at
        // least as precise as any other re-anchor path requires.
        private const val LOCKOUT_EXIT_MAX_ACCURACY_M = 20.0
    }

    // Caps the otherwise-unbounded post-calibration warm-up so the recorded
    // first point can't hang for tens of seconds indoors waiting for a
    // high-accuracy fix. Sourced from config so it's tunable per activity.
    private val warmUpTimeoutMs: Long = config.calibrationConfig.warmUpTimeoutMs

    private val calibrationManager = GPSCalibrationManager(config.calibrationConfig)
    private val courseValidator = CourseValidator()
    private val stationaryDetector = StationaryDetector(
        enterSpeedThreshold = config.stationarySpeedEntry,
        requiredSlowReadings = config.stationaryConsecutiveRequired,
        exitSpeedThreshold = config.stationarySpeedExit,
        exitDisplacementThreshold = config.stationaryDisplacementExit
    )

    private var lastAcceptedLocation: Location? = null
    private var lastEmittedLocation: Location? = null
    private var secondLastEmittedLocation: Location? = null
    private var isPostCalibrationWarmUp = false
    // Wall-clock (fix time) when warm-up began; null when not warming up.
    private var warmUpStartTimeMs: Long? = null
    private var lastAcceptedTimestampMs: Long = 0L
    private var lastValidGpsWallTimeMs: Long? = null
    private var consecutiveGateRejections = 0

    private var smoothedLat: Double? = null
    private var smoothedLon: Double? = null

    // Sustained over-speed lockout. `maxConsecutiveRejections` implausible
    // fixes in a row mean the anchor — not the fixes — is stale (the user got
    // into a vehicle, or the receiver teleported for good). Instead of nulling
    // the anchor and re-seeding on whatever arrives next (which re-anchors onto
    // the vehicle and leaks points whenever it slows), the pipeline holds here
    // until a run of fixes that are plausible relative to the first fix of the
    // run and actually moving shows the user is on foot again.
    private var isOverSpeedLockout = false
    private var lockoutRunStartFix: Location? = null
    private var lockoutPlausibleMovingFixes = 0
    private var lockoutExitRequiredFixes = LOCKOUT_EXIT_CONSECUTIVE_FIXES
    private var lastLockoutExitTimeMs: Long? = null
    // Relapse hysteresis evidence: any fix with vehicle-speed Doppler since the
    // last lockout exit. Cleared at exit.
    private var vehicleDopplerSinceLockoutExit = false

    // Where the user plausibly was before continuity was lost, dated by when
    // they were LAST seen there — not by the anchor's own timestamp, which for
    // a stop can be far older and would dilute the bridge speed by the stop's
    // duration. The first emit afterwards is judged against it: reachable at
    // activity speed → same segment (a GPS shadow, a tunnel); not reachable →
    // the user was carried there and the route must start a new segment.
    private data class ContinuityReference(val latitude: Double, val longitude: Double, val lastSeenTimeMs: Long)
    private var continuityReference: ContinuityReference? = null

    // Debug-capture bookkeeping — all per-session. Populated regardless of
    // whether the capture is enabled, so values are always ready to emit.
    private val sessionStartWallMs: Long = System.currentTimeMillis()
    private var sessionInputCount: Int = 0
    private var sessionEmitCount: Int = 0
    private var sessionWarmupReanchors: Int = 0
    private var sessionWarmupTimeoutEmits: Int = 0
    private var sessionOverSpeedLockouts: Int = 0
    private var sessionOverSpeedLockoutExits: Int = 0
    private var sessionSegmentStarts: Int = 0
    private val sessionGateRejections: MutableMap<String, Int> =
        linkedMapOf("A" to 0, "B" to 0, "C" to 0, "warmup" to 0)
    private val sessionSuppressCounts: MutableMap<String, Int> = linkedMapOf()
    private var lastInputFixMs: Long? = null
    private var lastEmitMs: Long? = null
    private var lastStationaryState: Boolean = false

    init {
        // Land the config-snapshot event before any fix can arrive so log
        // readers can reconstruct which tunings were active this run.
        emitConfigSnapshot()
    }

    /**
     * Process a raw location through the full pipeline.
     * Returns a smoothed, filtered location (with its segment-continuity
     * verdict) or null if rejected at any gate.
     */
    fun processLocation(location: Location): ProcessedLocation? {
        sessionInputCount += 1
        logger.logInput(location)

        val fixMs = location.time
        val dtSec = lastInputFixMs?.let { (fixMs - it) / 1000.0 }
        val dtSinceLastEmit = lastEmitMs?.let { (fixMs - it) / 1000.0 }
        logger.logTimer(
            fixTsMs = fixMs,
            dtSec = dtSec,
            dtSinceLastEmit = dtSinceLastEmit,
            dtSincePendingArm = null,
            dtSinceLastStationary = null
        )
        lastInputFixMs = fixMs

        val timestampMs = location.time

        val nowMs = System.currentTimeMillis()
        if (timestampMs > nowMs + 60_000) {
            log(TAG, "[PIPELINE] Rejected: timestamp >60s in future")
            return suppress(location, "timestamp_future")
        }

        if (timestampMs < trackingStartTimeMs) {
            log(TAG, "[PIPELINE] Rejected: before tracking start")
            return suppress(location, "timestamp_before_start")
        }

        if (lastAcceptedTimestampMs > 0 && timestampMs <= lastAcceptedTimestampMs) {
            log(TAG, "[PIPELINE] Rejected: timestamp regression or duplicate")
            return suppress(location, "timestamp_regression")
        }

        if (lastAcceptedLocation != null) {
            val lastWall = lastValidGpsWallTimeMs
            if (lastWall != null && (nowMs - lastWall) > (config.gapResetThresholdSeconds * 1000).toLong()) {
                val gapSec = (nowMs - lastWall) / 1000
                log(TAG, "[PIPELINE] GPS gap of ${gapSec}s detected — resetting pipeline")
                logger.logState(
                    transition = "gap-reset",
                    details = mapOf("gapSec" to gapSec.toDouble())
                )
                triggerGapReset()
            }
        }

        if (!isValidLocation(location)) {
            return null
        }

        lastValidGpsWallTimeMs = nowMs

        val calibrationResult = calibrationManager.processLocation(location)
        when (calibrationResult) {
            is GPSCalibrationManager.Result.Calibrating -> return suppress(location, "calibrating")

            is GPSCalibrationManager.Result.Calibrated -> {
                if (lastAcceptedLocation == null) {
                    setLastAccepted(calibrationResult.location, "calibration-complete")
                    isPostCalibrationWarmUp = true
                    warmUpStartTimeMs = calibrationResult.location.time // arm warm-up timeout
                    lastAcceptedTimestampMs = calibrationResult.location.time
                    lastValidGpsWallTimeMs = nowMs
                    log(TAG, "[PIPELINE] Calibration complete — initial anchor, warm-up active")
                    logger.logState(
                        transition = "calibration-complete",
                        details = mapOf(
                            "lat" to calibrationResult.location.latitude,
                            "lon" to calibrationResult.location.longitude,
                            "acc" to if (calibrationResult.location.hasAccuracy())
                                calibrationResult.location.accuracy.toDouble() else null
                        )
                    )
                    return suppress(location, "calibration_bootstrap")
                }
                return applyPipeline(calibrationResult.location)
            }

            is GPSCalibrationManager.Result.Failed -> {
                if (lastAcceptedLocation == null) {
                    setLastAccepted(location, "calibration-failed-bootstrap")
                    isPostCalibrationWarmUp = true
                    warmUpStartTimeMs = location.time // arm warm-up timeout
                    lastAcceptedTimestampMs = location.time
                    lastValidGpsWallTimeMs = nowMs
                    log(TAG, "[PIPELINE] Calibration failed — bootstrapping from raw fix, warm-up active")
                    logger.logState(
                        transition = "calibration-failed-bootstrap",
                        details = mapOf("reason" to calibrationResult.reason)
                    )
                    return suppress(location, "calibration_bootstrap")
                }
                return applyPipeline(location)
            }
        }
    }

    fun reset() {
        calibrationManager.reset()
        courseValidator.reset()
        stationaryDetector.reset()
        setLastAccepted(null, "pipeline-reset")
        setLastEmittedPair(null, null, "pipeline-reset")
        setSmoothed(null, null, "pipeline-reset")
        lastAcceptedTimestampMs = 0L
        lastValidGpsWallTimeMs = null
        setConsecutiveRejections(0, "reset")
        isPostCalibrationWarmUp = false
        warmUpStartTimeMs = null
        lastStationaryState = false
        clearLockoutState()
        // A new session has no previous segment to be continuous with.
        continuityReference = null
    }

    /**
     * Emit the per-session summary line. Callers must invoke this before
     * the underlying log file is closed, so the summary lands as the last
     * line of the JSONL for easy post-hoc triage.
     */
    fun finalizeSession() {
        val durationSec = (System.currentTimeMillis() - sessionStartWallMs) / 1000.0
        logger.logPipelineSummary(
            mapOf(
                "durationSec" to durationSec,
                "inputCount" to sessionInputCount,
                "emitCount" to sessionEmitCount,
                "suppressCountByReason" to sessionSuppressCounts.toMap(),
                "gateRejectionCounts" to sessionGateRejections.toMap(),
                "warmupReanchors" to sessionWarmupReanchors,
                "warmupTimeoutEmits" to sessionWarmupTimeoutEmits,
                "overSpeedLockouts" to sessionOverSpeedLockouts,
                "overSpeedLockoutExits" to sessionOverSpeedLockoutExits,
                "segmentStarts" to sessionSegmentStarts,
                // Counters for mechanisms not yet ported to Android. Kept
                // in the payload so iOS and Android pipeline-summary lines
                // have the same keys and `jq` scripts work unchanged.
                "warmupTeleportRejections" to 0,
                "pendingArms" to 0,
                "pendingConfirms" to mapOf("speed" to 0, "distance" to 0, "timeout" to 0)
            )
        )
    }

    private fun triggerGapReset() {
        // The outage itself may hide a vehicle ride: remember where the user
        // last plausibly was so the first emit afterwards can be judged.
        rememberContinuityReference()
        setLastAccepted(null, "gap-reset")
        setLastEmittedPair(null, null, "gap-reset")
        lastValidGpsWallTimeMs = null
        setConsecutiveRejections(0, "reset")
        isPostCalibrationWarmUp = false
        warmUpStartTimeMs = null
        stationaryDetector.reset()
        courseValidator.reset()
        setSmoothed(null, null, "gap-reset")
        if (config.resetCalibrationOnGap) {
            calibrationManager.reset()
        }
        lastStationaryState = false
        clearLockoutState()
    }

    // Full clear, including the relapse memory: used when the pipeline itself
    // restarts (session reset, gap reset), not on a lockout exit.
    private fun clearLockoutState() {
        isOverSpeedLockout = false
        lockoutRunStartFix = null
        lockoutPlausibleMovingFixes = 0
        lockoutExitRequiredFixes = LOCKOUT_EXIT_CONSECUTIVE_FIXES
        lastLockoutExitTimeMs = null
        vehicleDopplerSinceLockoutExit = false
    }

    // Only the FIRST loss of continuity sets the reference: a later loss
    // before any emit must not move it forward, or the check would judge
    // only the tail of the discontinuity. `lastAcceptedTimestampMs` is bumped
    // by every fix consistent with the anchor and never by a gate rejection,
    // so it is exactly "last seen near the anchor".
    private fun rememberContinuityReference() {
        if (continuityReference != null) return
        val anchor = lastAcceptedLocation ?: return
        continuityReference = ContinuityReference(
            latitude = anchor.latitude,
            longitude = anchor.longitude,
            lastSeenTimeMs = maxOf(anchor.time, lastAcceptedTimestampMs)
        )
    }

    /** Returns whether the lockout was entered by this call. */
    private fun checkOverSpeedLockout(location: Location): Boolean {
        if (consecutiveGateRejections < config.maxConsecutiveRejections) return false
        enterOverSpeedLockout(consecutiveGateRejections, location)
        return true
    }

    /**
     * Abandons the stale anchor after a run of implausible fixes.
     * `lastAcceptedLocation` is deliberately kept non-null — processLocation's
     * calibrated branch re-seeds (and re-arms warm-up) whenever it is null,
     * which would bypass the lockout and re-anchor onto the vehicle. Scatter
     * cannot become the new anchor either: exiting needs a consistent run of
     * moving fixes, not a single one. The triggering fix does not open the
     * first run: it is the tail of the rejected burst, and seeding with it only
     * moves the point at which a long GPS-shadow burst exits onto the shadow.
     */
    private fun enterOverSpeedLockout(rejections: Int, location: Location) {
        sessionOverSpeedLockouts += 1
        rememberContinuityReference()
        isOverSpeedLockout = true
        lockoutRunStartFix = null
        lockoutPlausibleMovingFixes = 0
        val sinceExitMs = lastLockoutExitTimeMs?.let { location.time - it }
        val relapse = vehicleDopplerSinceLockoutExit && sinceExitMs != null && sinceExitMs <= LOCKOUT_RELAPSE_WINDOW_MS
        lockoutExitRequiredFixes =
            if (relapse) LOCKOUT_EXIT_CONSECUTIVE_FIXES_AFTER_RELAPSE else LOCKOUT_EXIT_CONSECUTIVE_FIXES
        setLastEmittedPair(null, null, "lockout")
        setSmoothed(null, null, "lockout")
        setConsecutiveRejections(0, "lockout")
        // Warm-up is a property of the abandoned anchor; the exit fix
        // re-anchors on its own terms.
        isPostCalibrationWarmUp = false
        warmUpStartTimeMs = null
        stationaryDetector.reset()
        courseValidator.reset()
        lastStationaryState = false
        log(TAG, "[PIPELINE] $rejections consecutive rejections — anchor is stale, entering over-speed lockout " +
                "(exit needs $lockoutExitRequiredFixes fixes)")
        logger.logState(
            transition = "over-speed-lockout",
            details = mapOf(
                "rejections" to rejections,
                "exitRequiredFixes" to lockoutExitRequiredFixes,
                "relapse" to relapse,
                "sinceLastExitSec" to sinceExitMs?.let { it / 1000.0 }
            )
        )
    }

    /**
     * Lockout fixes are judged against the FIRST fix of the current run, not
     * the anchor — the anchor is what we no longer trust — and not the previous
     * fix either: 1 Hz position jitter makes consecutive-fix implied speed
     * swing between 0 and 5 m/s during a steady walk, which would keep
     * resetting the run, whereas over the run's whole span the jitter averages
     * out while a vehicle still reads as tens of m/s. A fix that fails restarts
     * the run at itself. "Moving" is decided by Doppler alone: position-implied
     * speed between indoor scatter fixes is routinely 1–3 m/s, which would read
     * as a plausible walk and re-anchor the pipeline onto scatter, while outdoor
     * GPS fixes — the only ones worth recording — carry Doppler. Requiring
     * motion also keeps a vehicle waiting at a light from re-acquiring the
     * anchor; a genuinely stationary user has nothing to record until they walk
     * anyway. A plausible fix WITHOUT Doppler is neutral — it neither extends
     * nor restarts the run: it says nothing about motion, and the fused
     * provider interleaves such (network) fixes among GNSS fixes in urban
     * canyons, so restarting on each would only delay a legitimate exit. The
     * fix that ends the run must also be precise enough to anchor on; a coarse
     * one keeps the run alive and waits for a better fix.
     */
    private fun handleOverSpeedLockout(location: Location): Nothing? {
        val runStart = lockoutRunStartFix
        if (runStart == null) {
            lastAcceptedTimestampMs = location.time
            lockoutRunStartFix = location
            return suppress(location, "lockout_await")
        }
        val dtMs = location.time - runStart.time
        if (dtMs <= 0) {
            // Unreachable for raw fixes (the regression guard rejects them first);
            // a fix with an older timestamp must neither extend the run nor wind
            // lastAcceptedTimestampMs back.
            lockoutPlausibleMovingFixes = 0
            log(TAG, "[PIPELINE] Rejected: non-positive dt in lockout")
            return suppress(location, "lockout_dt_non_positive")
        }
        lastAcceptedTimestampMs = location.time
        val impliedSpeed =
            distanceMeters(runStart.latitude, runStart.longitude, location.latitude, location.longitude) / (dtMs / 1000.0)
        val hasDoppler = location.hasSpeed() && location.speed >= 0
        val doppler = location.speed.toDouble()
        val plausible = impliedSpeed <= config.maxSpeedMps && (!hasDoppler || doppler <= config.maxSpeedMps)
        val moving = hasDoppler && doppler >= config.stationarySpeedExit
        val qualifies = plausible && moving
        val neutral = plausible && !hasDoppler
        if (qualifies) {
            lockoutPlausibleMovingFixes += 1
        } else if (!neutral) {
            lockoutPlausibleMovingFixes = 0
            lockoutRunStartFix = location
        }
        val reason = when {
            qualifies -> "lockout_plausible"
            !plausible -> "lockout_implausible"
            hasDoppler -> "lockout_not_moving"
            else -> "lockout_no_doppler"
        }
        logger.logGate(
            gate = "lockout",
            passed = qualifies,
            reason = reason,
            inputs = mapOf(
                "impliedSpeedMps" to impliedSpeed,
                "spd" to if (hasDoppler) doppler else null,
                "limitMps" to config.maxSpeedMps,
                "minMovingMps" to config.stationarySpeedExit,
                "acc" to if (location.hasAccuracy()) location.accuracy.toDouble() else null,
                "consecutive" to lockoutPlausibleMovingFixes,
                "needed" to lockoutExitRequiredFixes
            ),
            fixTsMs = location.time
        )
        val preciseEnough = location.hasAccuracy() && location.accuracy.toDouble() <= LOCKOUT_EXIT_MAX_ACCURACY_M
        if (lockoutPlausibleMovingFixes >= lockoutExitRequiredFixes && preciseEnough) {
            return exitOverSpeedLockout(location)
        }
        log(TAG, "[PIPELINE] Over-speed lockout — implied ${String.format("%.1f", impliedSpeed)}m/s, " +
                "$lockoutPlausibleMovingFixes/$lockoutExitRequiredFixes plausible moving fixes")
        return suppress(location, "lockout_suppressed")
    }

    // The re-anchor fix itself is not emitted: the next fix passes the gates
    // against it and is the one that carries the continuity verdict. The
    // rejection counter is already 0 (nothing counts during the lockout).
    private fun exitOverSpeedLockout(location: Location): Nothing? {
        sessionOverSpeedLockoutExits += 1
        isOverSpeedLockout = false
        lockoutRunStartFix = null
        lockoutPlausibleMovingFixes = 0
        lastLockoutExitTimeMs = location.time
        vehicleDopplerSinceLockoutExit = false
        setLastAccepted(location, "lockout-exit")
        lastAcceptedTimestampMs = location.time
        stationaryDetector.reset()
        courseValidator.reset()
        log(TAG, "[PIPELINE] Over-speed lockout ended — re-anchored at ${location.latitude}, ${location.longitude}")
        logger.logState(
            transition = "over-speed-lockout-exit",
            details = mapOf(
                "lat" to location.latitude,
                "lon" to location.longitude,
                "acc" to if (location.hasAccuracy()) location.accuracy.toDouble() else null,
                "spd" to if (location.hasSpeed()) location.speed.toDouble() else null
            )
        )
        return suppress(location, "lockout_exit_reanchor")
    }

    /**
     * First emit after continuity was lost: does this point join the previous
     * segment or start a new one? A GPS-shadow burst or a tunnel leaves the
     * user where a walker could have got to, so the gap is bridged as before;
     * a vehicle ride does not, so the gap stays open. Consumes the reference.
     * A gap that cannot be timed (dt ≤ 0) cannot be vouched for either and
     * stays open.
     */
    private fun resolveSegmentContinuity(location: Location): Boolean {
        val reference = continuityReference ?: return false
        continuityReference = null
        val dtSec = (location.time - reference.lastSeenTimeMs) / 1000.0
        val distance = distanceMeters(reference.latitude, reference.longitude, location.latitude, location.longitude)
        val bridgeSpeed: Double? = if (dtSec > 0) distance / dtSec else null
        val startsSegment = bridgeSpeed?.let { it > config.maxSpeedMps } ?: true
        if (startsSegment) sessionSegmentStarts += 1
        val speedText = bridgeSpeed?.let { String.format("%.1f", it) + "m/s" } ?: "untimed"
        log(TAG, "[PIPELINE] Continuity: ${String.format("%.0f", distance)}m in ${String.format("%.0f", dtSec)}s = " +
                "$speedText → ${if (startsSegment) "new segment" else "continued"}")
        logger.logState(
            transition = if (startsSegment) "segment-start" else "segment-continued",
            details = mapOf(
                "bridgeDistM" to distance,
                "bridgeDtSec" to dtSec,
                "bridgeSpeedMps" to bridgeSpeed,
                "limitMps" to config.maxSpeedMps
            )
        )
        return startsSegment
    }

    private fun applyPipeline(location: Location): ProcessedLocation? {
        val last = lastAcceptedLocation ?: return null

        // Vehicle evidence for the relapse hysteresis; cleared at lockout exit.
        if (location.hasSpeed() && location.speed > config.maxSpeedMps) {
            vehicleDopplerSinceLockoutExit = true
        }

        // Anchor abandoned: nothing below is meaningful until a consistent
        // run of moving fixes re-acquires one.
        if (isOverSpeedLockout) {
            return handleOverSpeedLockout(location)
        }

        if (isPostCalibrationWarmUp) {
            // Warm-up reuses the activity's recorded-track accuracy floor
            // (config.maxAccuracy) instead of a stricter hardcoded 15 m, so
            // indoor first-fixes aren't held to a precision the recorded track
            // never requires.
            if (location.hasAccuracy() && location.accuracy.toDouble() <= config.maxAccuracy) {
                setLastAccepted(location, "warmup-reanchor")
                lastAcceptedTimestampMs = location.time
                isPostCalibrationWarmUp = false
                warmUpStartTimeMs = null
                sessionWarmupReanchors += 1
                log(TAG, "[PIPELINE] Warm-up re-anchor: replaced centroid with ${String.format("%.1f", location.accuracy)}m-accuracy fix")
                logger.logState(
                    transition = "warm-up-reanchor",
                    details = mapOf("acc" to location.accuracy.toDouble())
                )
                logger.logGate(
                    gate = "warmup",
                    passed = true,
                    reason = "pass",
                    inputs = mapOf("acc" to location.accuracy.toDouble()),
                    fixTsMs = location.time
                )
                return suppress(location, "warmup_reanchor")
            } else {
                // Cap the unbounded warm-up wait. Once we've been warming up
                // longer than the timeout, accept the best-so-far fix as the
                // new anchor and fall through to the normal pipeline so the
                // recorded first point can't hang indoors. The fix already
                // passed isValidLocation (<= maxAccuracy), and re-anchoring
                // lastAccepted to it keeps Gate A's implied-speed baseline honest.
                val start = warmUpStartTimeMs ?: location.time
                val warmAgeMs = location.time - start
                if (warmAgeMs > warmUpTimeoutMs) {
                    isPostCalibrationWarmUp = false
                    warmUpStartTimeMs = null
                    sessionWarmupTimeoutEmits += 1
                    setLastAccepted(location, "warmup-timeout")
                    lastAcceptedTimestampMs = location.time
                    log(TAG, "[PIPELINE] Warm-up timed out — accepting ${String.format("%.1f", location.accuracy)}m fix as anchor")
                    logger.logState(
                        transition = "warm-up-timeout",
                        details = mapOf("acc" to if (location.hasAccuracy()) location.accuracy.toDouble() else null)
                    )
                    // fall through to Gate A below
                } else {
                    logger.logGate(
                        gate = "warmup",
                        passed = false,
                        reason = "warmup_awaiting_accuracy",
                        inputs = mapOf(
                            "acc" to if (location.hasAccuracy()) location.accuracy.toDouble() else null
                        ),
                        fixTsMs = location.time
                    )
                    return suppress(location, "warmup_awaiting_accuracy")
                }
            }
        }

        val dtMs = location.time - last.time
        if (dtMs <= 0) {
            log(TAG, "[PIPELINE] Rejected: non-positive dt in pipeline")
            return suppress(location, "dt_non_positive")
        }

        val dtSeconds = dtMs / 1000.0
        val distance = distanceMeters(last.latitude, last.longitude, location.latitude, location.longitude)
        val impliedSpeed = distance / dtSeconds

        // Gate A: Speed validation
        val gateAInputs = mapOf(
            "impliedSpeedMps" to impliedSpeed,
            "maxSpeedMps" to config.maxSpeedMps,
            "distanceM" to distance,
            "dtSec" to dtSeconds
        )
        if (impliedSpeed > config.maxSpeedMps) {
            bumpGateRejection("A")
            logger.logGate(
                gate = "A",
                passed = false,
                reason = "gate_a_speed",
                inputs = gateAInputs,
                fixTsMs = location.time
            )
            log(TAG, "[GATE A] Rejected: implied ${String.format("%.1f", impliedSpeed)}m/s " +
                    "> max ${String.format("%.1f", config.maxSpeedMps)}m/s " +
                    "[rejection #$consecutiveGateRejections]")
            checkOverSpeedLockout(location)
            return suppress(location, "gate_a_speed")
        }
        logger.logGate(
            gate = "A",
            passed = true,
            reason = "pass",
            inputs = gateAInputs,
            fixTsMs = location.time
        )

        // Gate B: Lateral deviation
        val prevEmit = lastEmittedLocation
        val prev2Emit = secondLastEmittedLocation
        if (prevEmit != null && prev2Emit != null) {
            val emitDtMs = location.time - prevEmit.time
            val emitDtSeconds = emitDtMs / 1000.0
            if (emitDtSeconds > 0 && emitDtSeconds < 5.0) {
                val lateralDev = perpendicularDistance(
                    pointLat = location.latitude, pointLon = location.longitude,
                    lineStartLat = prev2Emit.latitude, lineStartLon = prev2Emit.longitude,
                    lineEndLat = prevEmit.latitude, lineEndLon = prevEmit.longitude
                )
                val lateralThreshold = maxOf(5.0, location.accuracy * 0.7)
                val gateBInputs = mapOf(
                    "lateralDevM" to lateralDev,
                    "thresholdM" to lateralThreshold,
                    "emitDtSec" to emitDtSeconds,
                    "acc" to location.accuracy.toDouble()
                )
                if (lateralDev > lateralThreshold) {
                    bumpGateRejection("B")
                    logger.logGate(
                        gate = "B",
                        passed = false,
                        reason = "gate_b_lateral",
                        inputs = gateBInputs,
                        fixTsMs = location.time
                    )
                    log(TAG, "[GATE B] Rejected: lateral deviation ${String.format("%.1f", lateralDev)}m " +
                            "> threshold ${String.format("%.1f", lateralThreshold)}m " +
                            "[rejection #$consecutiveGateRejections]")
                    checkOverSpeedLockout(location)
                    return suppress(location, "gate_b_lateral")
                }
                logger.logGate(
                    gate = "B",
                    passed = true,
                    reason = "pass",
                    inputs = gateBInputs,
                    fixTsMs = location.time
                )
            }
        }

        // Gate C: Course spike detection
        if (!courseValidator.validate(location)) {
            bumpGateRejection("C")
            logger.logGate(
                gate = "C",
                passed = false,
                reason = "gate_c_course",
                inputs = mapOf(
                    "course" to if (location.hasBearing()) location.bearing.toDouble() else null,
                    "spd" to if (location.hasSpeed()) location.speed.toDouble() else null
                ),
                fixTsMs = location.time
            )
            log(TAG, "[GATE C] Rejected: course spike [rejection #$consecutiveGateRejections]")
            checkOverSpeedLockout(location)
            return suppress(location, "gate_c_course")
        }
        logger.logGate(
            gate = "C",
            passed = true,
            reason = "pass",
            inputs = mapOf(
                "course" to if (location.hasBearing()) location.bearing.toDouble() else null,
                "spd" to if (location.hasSpeed()) location.speed.toDouble() else null
            ),
            fixTsMs = location.time
        )

        setConsecutiveRejections(0, "reset")

        // Stationary detection
        val hasDoppler = location.hasSpeed() && location.speed >= 0
        stationaryDetector.addPosition(location.latitude, location.longitude, location.time)

        val wasStationary = stationaryDetector.isStationary
        val update = if (hasDoppler) {
            stationaryDetector.update(location.speed.toDouble())
        } else {
            stationaryDetector.checkDisplacementStationary()
        }
        val isStationary = update.isStationary

        logger.logStationaryDetail(
            speed = if (hasDoppler) location.speed.toDouble() else Double.NaN,
            displacement = update.displacement,
            consecutiveSlowReadings = stationaryDetector.consecutiveSlowReadings,
            isStationary = isStationary,
            isPendingStationary = stationaryDetector.isPendingStationary,
            ruleFired = update.ruleFired,
            fixTsMs = location.time
        )

        if (wasStationary != isStationary) {
            val transition = if (isStationary) "stationary-entered" else "stationary-exited"
            logger.logState(
                transition = transition,
                details = mapOf("ruleFired" to update.ruleFired)
            )
            lastStationaryState = isStationary
        }

        if (wasStationary && !isStationary) {
            courseValidator.reset()
            log(TAG, "[PIPELINE] Stationary ended — CourseValidator reset")
        }

        if (isStationary || stationaryDetector.isPendingStationary) {
            setLastAccepted(location, if (isStationary) "stationary-confirmed" else "stationary-pending")
            lastAcceptedTimestampMs = location.time
            val speedStr = if (hasDoppler) String.format("%.2f", location.speed) else "n/a"
            val state = if (isStationary) "confirmed" else "pending"
            log(TAG, "[PIPELINE] Stationary ($state) — suppressed (doppler: ${speedStr}m/s)")
            return suppress(
                location,
                if (isStationary) "stationary_confirmed" else "stationary_pending"
            )
        }

        // Minimum emit distance (accuracy-adaptive)
        val minimumEmitDistance = maxOf(config.minEmitDistanceFloor, minOf(location.accuracy * 0.5, 8.0))
        val distanceFromLastEmit = lastEmittedLocation?.let {
            distanceMeters(it.latitude, it.longitude, location.latitude, location.longitude)
        } ?: Double.MAX_VALUE

        setLastAccepted(location, "post-gate-accept")
        lastAcceptedTimestampMs = location.time

        val emitInputs = mapOf(
            "distanceFromLastEmitM" to (if (distanceFromLastEmit.isFinite()) distanceFromLastEmit else null),
            "minimumEmitDistanceM" to minimumEmitDistance,
            "acc" to location.accuracy.toDouble()
        )
        if (distanceFromLastEmit < minimumEmitDistance) {
            logger.logGate(
                gate = "emit-threshold",
                passed = false,
                reason = "sub_threshold",
                inputs = emitInputs,
                fixTsMs = location.time
            )
            log(TAG, "[PIPELINE] Sub-threshold: ${String.format("%.2f", distanceFromLastEmit)}m " +
                    "< min ${String.format("%.2f", minimumEmitDistance)}m " +
                    "(acc=${String.format("%.1f", location.accuracy)}m)")
            return suppress(location, "sub_threshold")
        }
        logger.logGate(
            gate = "emit-threshold",
            passed = true,
            reason = "pass",
            inputs = emitInputs,
            fixTsMs = location.time
        )

        val startsSegment = resolveSegmentContinuity(location)

        // EMA smoothing (adaptive alpha based on accuracy)
        val alpha = minOf(config.emaAlphaCap, maxOf(0.2, 5.0 / maxOf(location.accuracy.toDouble(), 1.0)))

        val emitLat: Double
        val emitLon: Double
        val sLat = smoothedLat
        val sLon = smoothedLon
        if (sLat != null && sLon != null) {
            emitLat = alpha * location.latitude + (1.0 - alpha) * sLat
            emitLon = alpha * location.longitude + (1.0 - alpha) * sLon
        } else {
            emitLat = location.latitude
            emitLon = location.longitude
        }
        setSmoothed(emitLat, emitLon, "emit")

        val emitted = Location(location.provider ?: "fused").apply {
            latitude = emitLat
            longitude = emitLon
            altitude = location.altitude
            accuracy = location.accuracy
            time = location.time
            elapsedRealtimeNanos = location.elapsedRealtimeNanos
            if (location.hasSpeed()) speed = location.speed
            if (location.hasBearing()) bearing = location.bearing
        }

        setLastEmittedPair(emitted, lastEmittedLocation, "emit")

        log(TAG, "[PIPELINE] Emitted | ${String.format("%.1f", distanceFromLastEmit)}m, " +
                "alpha=${String.format("%.2f", alpha)}, " +
                "acc=${String.format("%.1f", location.accuracy)}m" +
                if (startsSegment) " [new segment]" else "")
        sessionEmitCount += 1
        lastEmitMs = location.time
        logger.logEmit(emitted)

        return ProcessedLocation(emitted, startsSegment)
    }

    private fun isValidLocation(location: Location): Boolean {
        if (!location.hasAccuracy()) {
            log(TAG, "[PIPELINE] Rejected: no accuracy")
            suppress(location, "validation_no_accuracy")
            return false
        }
        val acc = location.accuracy.toDouble()
        if (!acc.isFinite() || acc <= 0) {
            log(TAG, "[PIPELINE] Rejected: accuracy $acc <= 0 or non-finite")
            suppress(location, "validation_accuracy_invalid")
            return false
        }
        if (acc > config.maxAccuracy) {
            log(TAG, "[PIPELINE] Rejected: accuracy ${String.format("%.1f", acc)}m > max ${String.format("%.1f", config.maxAccuracy)}m")
            suppress(location, "validation_accuracy")
            return false
        }
        val lat = location.latitude
        val lon = location.longitude
        if (!lat.isFinite() || !lon.isFinite() || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
            log(TAG, "[PIPELINE] Rejected: coordinate out of valid range")
            suppress(location, "validation_coordinate")
            return false
        }
        if (abs(lat) < 0.001 && abs(lon) < 0.001) {
            log(TAG, "[PIPELINE] Rejected: Null Island (0,0) — GPS chip error state")
            suppress(location, "validation_null_island")
            return false
        }
        return true
    }

    /**
     * Perpendicular distance from a point to the line defined by two previous emissions.
     * Used for Gate B (lateral deviation check).
     * Port of iOS perpendicularDistance() — uses flat-Earth approximation at mid-latitude.
     */
    private fun perpendicularDistance(
        pointLat: Double, pointLon: Double,
        lineStartLat: Double, lineStartLon: Double,
        lineEndLat: Double, lineEndLon: Double
    ): Double {
        val midLat = (lineStartLat + lineEndLat) / 2.0
        val cosLat = cos(Math.toRadians(midLat))
        val metersPerDegreeLat = 111_320.0
        val metersPerDegreeLon = 111_320.0 * cosLat

        val bx = (lineEndLon - lineStartLon) * metersPerDegreeLon
        val by = (lineEndLat - lineStartLat) * metersPerDegreeLat
        val cx = (pointLon - lineStartLon) * metersPerDegreeLon
        val cy = (pointLat - lineStartLat) * metersPerDegreeLat

        val lenSq = bx * bx + by * by
        if (lenSq <= 0.01) {
            return sqrt(cx * cx + cy * cy)
        }

        val t = (cx * bx + cy * by) / lenSq
        val projX = t * bx
        val projY = t * by
        val dx = cx - projX
        val dy = cy - projY

        return sqrt(dx * dx + dy * dy)
    }

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, results)
        return results[0].toDouble()
    }

    // --------------------------------------------------------------
    // Typed anchor setters — route every anchor mutation through here
    // so a single `anchor-change` event is emitted per mutation.
    // --------------------------------------------------------------

    private fun setLastAccepted(new: Location?, reason: String) {
        val old = lastAcceptedLocation
        lastAcceptedLocation = new
        logger.logAnchorChange(
            variable = "lastAccepted",
            reason = reason,
            old = locationAnchorMap(old),
            new = locationAnchorMap(new)
        )
    }

    private fun setLastEmittedPair(
        newLast: Location?,
        newSecondLast: Location?,
        reason: String
    ) {
        val oldLast = lastEmittedLocation
        val oldSecondLast = secondLastEmittedLocation
        lastEmittedLocation = newLast
        secondLastEmittedLocation = newSecondLast
        logger.logAnchorChange(
            variable = "lastEmitted",
            reason = reason,
            old = locationAnchorMap(oldLast),
            new = locationAnchorMap(newLast)
        )
        logger.logAnchorChange(
            variable = "secondLastEmitted",
            reason = reason,
            old = locationAnchorMap(oldSecondLast),
            new = locationAnchorMap(newSecondLast)
        )
    }

    private fun setSmoothed(lat: Double?, lon: Double?, reason: String) {
        val oldLat = smoothedLat
        val oldLon = smoothedLon
        smoothedLat = lat
        smoothedLon = lon
        val oldMap = if (oldLat != null && oldLon != null) {
            mapOf("lat" to oldLat, "lon" to oldLon)
        } else null
        val newMap = if (lat != null && lon != null) {
            mapOf("lat" to lat, "lon" to lon)
        } else null
        logger.logAnchorChange(
            variable = "smoothed",
            reason = reason,
            old = oldMap,
            new = newMap
        )
    }

    private fun setConsecutiveRejections(new: Int, gate: String) {
        val old = consecutiveGateRejections
        if (old == new) return
        consecutiveGateRejections = new
        logger.logRejectionCounter(old = old, new = new, gate = gate)
    }

    private fun bumpGateRejection(gate: String) {
        sessionGateRejections[gate] = (sessionGateRejections[gate] ?: 0) + 1
        setConsecutiveRejections(consecutiveGateRejections + 1, gate)
    }

    // --------------------------------------------------------------
    // Suppress helper — single path for every `return null` that isn't
    // gate-based, so session counts and the JSONL stay in lock-step.
    // Returns `Nothing?` so it can be the `return` expression of any
    // nullable-returning caller.
    // --------------------------------------------------------------

    private fun suppress(location: Location, reason: String): Nothing? {
        sessionSuppressCounts[reason] = (sessionSuppressCounts[reason] ?: 0) + 1
        logger.logSuppress(location, reason)
        return null
    }

    private fun locationAnchorMap(loc: Location?): Map<String, Any?>? {
        if (loc == null) return null
        return mapOf(
            "lat" to loc.latitude,
            "lon" to loc.longitude,
            "acc" to if (loc.hasAccuracy()) loc.accuracy.toDouble() else null,
            "tsMs" to loc.time
        )
    }

    private fun emitConfigSnapshot() {
        logger.logConfigSnapshot(
            mapOf(
                "activity" to activityType.name,
                "maxAccuracy" to config.maxAccuracy,
                "maxSpeedMps" to config.maxSpeedMps,
                "gapResetThresholdSeconds" to config.gapResetThresholdSeconds,
                "maxConsecutiveRejections" to config.maxConsecutiveRejections,
                "resetCalibrationOnGap" to config.resetCalibrationOnGap,
                "minEmitDistanceFloor" to config.minEmitDistanceFloor,
                "emaAlphaCap" to config.emaAlphaCap,
                "stationarySpeedEntry" to config.stationarySpeedEntry,
                "stationaryConsecutiveRequired" to config.stationaryConsecutiveRequired,
                "stationarySpeedExit" to config.stationarySpeedExit,
                "stationaryDisplacementExit" to config.stationaryDisplacementExit,
                "calibrationDurationMs" to config.calibrationConfig.calibrationDurationMs,
                "minPointsForCalibration" to config.calibrationConfig.minPointsForCalibration,
                "maxCalibrationAccuracy" to config.calibrationConfig.maxCalibrationAccuracy,
                "trackingStartTimeMs" to trackingStartTimeMs,
                "lockoutExitConsecutiveFixes" to LOCKOUT_EXIT_CONSECUTIVE_FIXES,
                "lockoutExitConsecutiveFixesAfterRelapse" to LOCKOUT_EXIT_CONSECUTIVE_FIXES_AFTER_RELAPSE,
                "lockoutRelapseWindowSec" to LOCKOUT_RELAPSE_WINDOW_MS / 1000.0,
                "lockoutExitMaxAccuracyM" to LOCKOUT_EXIT_MAX_ACCURACY_M
            )
        )
    }
}
