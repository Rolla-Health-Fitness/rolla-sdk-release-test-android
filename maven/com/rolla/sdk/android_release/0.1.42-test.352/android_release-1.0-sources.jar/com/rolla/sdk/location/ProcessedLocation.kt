package com.rolla.sdk.location

import android.location.Location

/**
 * A pipeline emit plus the route-continuity verdict that goes with it.
 *
 * [isSegmentStart] is true on the first emit after track continuity was lost
 * (e.g. a dropped vehicle segment): this point starts a new route segment and
 * must not be joined to the previous emit. Mirrors `LocationData.isSegmentStart`
 * on iOS — Android's [Location] has no spare typed field for it, hence the wrapper.
 */
data class ProcessedLocation(
    val location: Location,
    val isSegmentStart: Boolean
)
