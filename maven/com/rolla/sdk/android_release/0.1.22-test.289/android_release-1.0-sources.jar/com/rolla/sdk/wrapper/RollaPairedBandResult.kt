package com.rolla.sdk.wrapper

/**
 * Whether the user's account currently has a Rolla band paired.
 *
 * This answers a **pairing-state query with zero Bluetooth** — no scan, no
 * connect, no BLE permission; it works with Bluetooth off. It says nothing
 * about the live link (see [RollaListener.onBandConnected] /
 * [RollaListener.onBandDisconnected] for that).
 */
enum class RollaPairedBandStatus(val rawValue: String) {
    /** A band is paired for this account — [RollaPairedBandResult.band] describes it. */
    PAIRED("paired"),

    /** The user's profile confirms no band is paired. */
    NOT_PAIRED("notPaired"),

    /**
     * The pairing state could not be determined — the profile was unreachable
     * (offline/timeout) and no local record exists (e.g. a fresh login while
     * offline). Reported instead of guessing.
     */
    UNKNOWN("unknown");

    companion object {
        /** Map a wire string ([rawValue]) to a status; unknown values map to [UNKNOWN]. */
        fun fromRawValue(raw: String?): RollaPairedBandStatus =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Result of [Rolla.getPairedBandInfo].
 *
 * [band] is non-null **only** when [status] is [RollaPairedBandStatus.PAIRED].
 */
data class RollaPairedBandResult(
    /** Whether a band is paired, or why that couldn't be determined. */
    val status: RollaPairedBandStatus,
    /**
     * The paired band. The MAC address is authoritative; every other field is
     * a best-effort cached value from the last time the SDK talked to the band
     * (and may be null).
     */
    val band: RollaBandInfo? = null
) {
    /** Whether a paired [band] is present. */
    val isPaired: Boolean
        get() = status == RollaPairedBandStatus.PAIRED && band != null

    companion object {
        /**
         * Build a result from the method-channel wire map
         * `{ "status": String, "band": Map? }`. Unknown statuses map to
         * [RollaPairedBandStatus.UNKNOWN] so older host integrations keep working.
         */
        fun fromResponse(response: Any?): RollaPairedBandResult {
            val map = response as? Map<*, *>
                ?: return RollaPairedBandResult(RollaPairedBandStatus.UNKNOWN, null)
            val status = RollaPairedBandStatus.fromRawValue(map["status"] as? String)
            val band = (map["band"] as? Map<*, *>)?.let { RollaBandInfo.fromResponse(it) }
            return RollaPairedBandResult(
                status = status,
                band = if (status == RollaPairedBandStatus.PAIRED) band else null
            )
        }
    }
}
