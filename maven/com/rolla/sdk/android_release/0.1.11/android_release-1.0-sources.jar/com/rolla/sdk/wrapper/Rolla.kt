package com.rolla.sdk.wrapper

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import java.lang.ref.WeakReference

class Rolla(val configuration: RollaConfiguration) {

    companion object {
        private const val TAG = "Rolla"

        fun destroyEngine() {
            RollaEngineManager.getInstance().destroy()
        }
    }

    var listener: RollaListener?
        get() = listenerRef?.get()
        set(value) {
            listenerRef = value?.let { WeakReference(it) }
        }

    private var listenerRef: WeakReference<RollaListener>? = null

    val isPresenting: Boolean
        get() = engineManager.isPresenting

    private val engineManager: RollaEngineManager
        get() = RollaEngineManager.getInstance()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingCloseReason: RollaCloseReason? = null

    fun show(activity: Activity) {
        mainHandler.post {
            if (engineManager.isPresenting) {
                listener?.onRollaError(this, RollaError.AlreadyPresenting())
                return@post
            }

            if (activity.isFinishing || activity.isDestroyed) {
                listener?.onRollaError(this, RollaError.InvalidContext())
                return@post
            }

            engineManager.setPresenting(true)
            prepareAndShow(activity)
        }
    }

    fun show(fragment: Fragment) {
        val activity = fragment.activity
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            mainHandler.post {
                listener?.onRollaError(this, RollaError.InvalidContext())
            }
            return
        }
        show(activity)
    }

    /**
     * Clear all persisted session data (tokens, auth metadata) from secure storage.
     *
     * Call this when your app logs out the user and you want the SDK to forget
     * all credentials for that user. This does **not** dismiss the SDK UI or
     * destroy the Flutter engine — it only purges stored tokens.
     *
     * The engine must be initialized (i.e. [show] must have been called at
     * least once) for the method channel to be available.
     */
    fun clearSession(callback: ((Result<Unit>) -> Unit)? = null) {
        mainHandler.post {
            engineManager.clearSession { result ->
                mainHandler.post {
                    callback?.invoke(result)
                }
            }
        }
    }

    fun dismiss() {
        mainHandler.post {
            if (!engineManager.isPresenting) return@post

            if (pendingCloseReason == null) {
                pendingCloseReason = RollaCloseReason.Programmatic
            }

            RollaFlutterActivity.setPendingCloseReason(
                pendingCloseReason ?: RollaCloseReason.Programmatic
            )
            RollaFlutterActivity.finishCurrent()
        }
    }

    private fun prepareAndShow(activity: Activity) {
        try {
            engineManager.initialize(activity)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize engine", e)
            cleanup()
            listener?.onRollaError(this, RollaError.EngineFailedToStart())
            return
        }

        setupCallbacks()

        engineManager.configure(
            config = configuration,
            showBackButton = true
        ) { result ->
            mainHandler.post {
                result.onSuccess {
                    if (activity.isFinishing || activity.isDestroyed) {
                        cleanup()
                        listener?.onRollaError(this, RollaError.InvalidContext())
                        return@post
                    }
                    launchActivity(activity)
                }.onFailure { error ->
                    cleanup()
                    val rollaError = when (error) {
                        is RollaError -> error
                        else -> RollaError.InitializationFailed(error.message ?: "Unknown error")
                    }
                    listener?.onRollaError(this, rollaError)
                }
            }
        }
    }

    private fun launchActivity(activity: Activity) {
        if (RollaFlutterActivity.onDismiss != null) {
            Log.w(TAG, "Warning: overwriting existing onDismiss callback - this should not happen")
        }

        RollaFlutterActivity.onDismiss = { reason ->
            mainHandler.post {
                val finalReason = pendingCloseReason ?: reason
                cleanup()
                listener?.onRollaClosed(this, finalReason)
            }
        }

        val intent = Intent(activity, RollaFlutterActivity::class.java)
        activity.startActivity(intent)

        Log.d(TAG, "RollaFlutterActivity launched")
    }

    private fun setupCallbacks() {
        if (engineManager.onClose != null || engineManager.onError != null) {
            Log.w(TAG, "Warning: overwriting existing engine callbacks - this should not happen")
        }

        engineManager.onClose = { reason ->
            pendingCloseReason = RollaCloseReason.FlutterRequested(reason)
            RollaFlutterActivity.finishCurrent()
        }

        engineManager.onError = { code, message ->
            mainHandler.post {
                listener?.onRollaError(this, RollaError.FlutterError(code, message))
            }
        }
    }

    private fun cleanup() {
        pendingCloseReason = null
        engineManager.setPresenting(false)
        engineManager.onClose = null
        engineManager.onError = null
        RollaFlutterActivity.clearCallbacks()
    }
}
