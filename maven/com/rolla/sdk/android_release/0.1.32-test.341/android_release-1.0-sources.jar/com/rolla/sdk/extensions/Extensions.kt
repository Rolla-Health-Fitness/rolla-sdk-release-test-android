package com.rolla.sdk.extensions

import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.OperationAlreadyInProgress
import app.rolla.bluetoothSdk.result.error.OperationTimedOut
import app.rolla.bluetoothSdk.result.error.UnknownError
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.generated.FlutterError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Upper bound for a single band data-transfer operation. Generous on purpose: it exists
// so a response that never arrives cannot leave the per-device callback registered
// forever (which would fail every later call for that device with
// OperationAlreadyInProgress until the process dies), not to police slow transfers.
private const val COMMAND_OPERATION_TIMEOUT_MS = 5 * 60 * 1000L

fun toFlutterError(err: Error? = null, exception: Exception? = null): FlutterError {
    val error = err ?: UnknownError(exception)
    return FlutterError(error.code, error.message, error.exception?.message)
}

fun <T> executeOperation(
    scope: CoroutineScope,
    callback: (Result<T>) -> Unit,
    tag: String? = null,
    operationName: String? = null,
    operation: () -> MethodResult,
    onSuccess: (MethodResult) -> T,
    onError: (Exception) -> Unit = {}
) {
    executeAsync(scope, callback, operation = {
        operationName?.let { name ->
            tag?.let { t -> log(t, name) }
        }

        val result = operation()

        if (result.successful) {
            Result.success(onSuccess(result))
        } else {
            Result.failure(toFlutterError(result.error))
        }
    }, onError = onError)
}

private fun <T> executeAsync(
    scope: CoroutineScope,
    callback: (Result<T>) -> Unit,
    operation: suspend () -> Result<T>?,
    onError: (Exception) -> Unit = {}
) {
    scope.launch {
        try {
            val result = operation()
            withContext(Dispatchers.Main) {
                if (result != null) {
                    callback(result)
                }
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                callback(Result.failure(toFlutterError(exception = e)))
                onError(e)
            }
        }
    }
}

fun <T> executeCommandOperation(
    scope: CoroutineScope,
    uuid: String,
    callbacks: MutableMap<String, (Result<T>) -> Unit>,
    callback: (Result<T>) -> Unit,
    tag: String,
    operationName: String,
    timeoutMs: Long = COMMAND_OPERATION_TIMEOUT_MS,
    operation: () -> MethodResult
) {
    if (callbacks.containsKey(uuid)) {
        callback.invoke(Result.failure(toFlutterError(OperationAlreadyInProgress(operationName))))
        return
    }
    callbacks[uuid] = callback

    scope.launch {
        delay(timeoutMs)
        withContext(Dispatchers.Main) {
            // Identity check on the main dispatcher — the same context every resolution
            // path uses — so an operation that already resolved (and a newer one that
            // reused this device's slot) is never failed by a stale timer.
            if (callbacks[uuid] === callback) {
                callbacks.remove(uuid)
                log(tag, "$operationName timed out after ${timeoutMs}ms — releasing the device slot")
                callback(Result.failure(toFlutterError(OperationTimedOut(operationName))))
            }
        }
    }

    executeAsync(scope, callback, operation = {
        log(tag, operationName)
        val result = operation()

        if (result.successful) {
            null // Wait for flow data
        } else {
            // Removed on the main dispatcher like every other resolution path, so the
            // timeout timer's identity check can never race this and double-resolve.
            withContext(Dispatchers.Main) { callbacks.remove(uuid) }
            Result.failure(toFlutterError(result.error))
        }
    }, onError = { callbacks.remove(uuid) })
}

fun <T, R> collectFlowWithCallback(
    scope: CoroutineScope,
    flow: SharedFlow<T>,
    callbacks: MutableMap<String, (Result<R>) -> Unit>,
    tag: String,
    dataName: String,
    getUuid: (T) -> String,
    getError: (T) -> Error?,
    getSuccessValue: (T) -> R,
    onNoCallback: ((T) -> Unit)? = null,
    onSuccess: ((T) -> Unit)? = null
) {
    scope.launch {
        flow.collect { data ->
            withContext(Dispatchers.Main) {
                log(tag, "$dataName: $data")
                val uuid = getUuid(data)
                val callback = callbacks[uuid]
                if (callback != null) {
                    val error = getError(data)
                    if (error != null) {
                        callback(Result.failure(toFlutterError(error)))
                    } else {
                        callback(Result.success(getSuccessValue(data)))
                        onSuccess?.invoke(data)
                    }
                    callbacks.remove(uuid)
                } else {
                    log(tag, "No callback found for $dataName $data")
                    onNoCallback?.invoke(data)
                }
            }
        }
    }
}

fun <T, R> collectNextPageFlowWithCallback(
    scope: CoroutineScope,
    flow: SharedFlow<T>,
    callbacks: MutableMap<String, (Result<R>) -> Unit>,
    tag: String,
    dataName: String,
    getUuid: (T) -> String,
    isDataEnd: (T) -> Boolean,
    getSuccessValue: (T) -> R,
    onNoCallback: ((T) -> Unit)? = null,
) {
    scope.launch {
        flow.collect { data ->
            withContext(Dispatchers.Main) {
                log(tag, "$dataName: $data")
                val uuid = getUuid(data)
                val callback = callbacks[uuid]
                if (callback != null) {
                    val isEnd = isDataEnd(data)
                    if (isEnd) {
                        callback(Result.success(getSuccessValue(data)))
                        callbacks.remove(uuid)
                    }
                } else {
                    log(tag, "No callback found for $dataName $data")
                    onNoCallback?.invoke(data)
                }
            }
        }
    }
}

fun <T> executeOperationSuspend(
    scope: CoroutineScope,
    callback: (Result<T>) -> Unit,
    tag: String,
    operationName: String,
    operation: suspend () -> MethodResult,
    onSuccess: (MethodResult) -> T
) {
    executeAsync(scope, callback, operation = {
        log(tag, operationName)
        val result = operation()

        if (result.successful) {
            Result.success(onSuccess(result))
        } else {
            Result.failure(toFlutterError(result.error))
        }
    })
}
