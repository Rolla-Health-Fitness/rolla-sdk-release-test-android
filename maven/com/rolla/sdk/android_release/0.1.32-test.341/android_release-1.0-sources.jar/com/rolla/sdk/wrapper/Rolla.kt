package com.rolla.sdk.wrapper

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import com.rolla.sdk.R
import com.rolla.sdk.wrapper.config.RollaConfiguration
import com.rolla.sdk.wrapper.config.RollaTransition
import com.rolla.sdk.wrapper.engine.RollaEngineManager
import com.rolla.sdk.wrapper.engine.RollaFlutterActivity
import com.rolla.sdk.wrapper.features.band.RollaBatteryResult
import com.rolla.sdk.wrapper.features.band.RollaPairedBandResult
import com.rolla.sdk.wrapper.features.navigation.RollaOpenScreenStatus
import com.rolla.sdk.wrapper.features.navigation.RollaScreen
import com.rolla.sdk.wrapper.features.session.RollaCloseReason
import com.rolla.sdk.wrapper.features.session.RollaError
import com.rolla.sdk.wrapper.features.sync.RollaSyncOutcome
import com.rolla.sdk.wrapper.features.sync.RollaSyncResult
import com.rolla.sdk.wrapper.features.sync.RollaSyncedHealthData

class Rolla(val configuration: RollaConfiguration) {

    companion object {
        private const val TAG = "Rolla"

        fun destroyEngine() {
            RollaEngineManager.getInstance().destroy()
        }
    }

    var listener: RollaListener? = null

    val isPresenting: Boolean
        get() = engineManager.isPresenting

    private val engineManager: RollaEngineManager
        get() = RollaEngineManager.getInstance()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingCloseReason: RollaCloseReason? = null

    @JvmOverloads
    fun show(activity: Activity, transition: RollaTransition = RollaTransition.DEFAULT) {
        mainHandler.post {
            if (engineManager.isPresenting) {
                listener?.onRollaError(this, RollaError.AlreadyPresenting())
                return@post
            }

            if (activity.isFinishing || activity.isDestroyed) {
                listener?.onRollaError(this, RollaError.InvalidContext())
                return@post
            }

            engineManager.setPresenting(true)
            prepareAndShow(activity, transition)
        }
    }

    @JvmOverloads
    fun show(fragment: Fragment, transition: RollaTransition = RollaTransition.DEFAULT) {
        val activity = fragment.activity
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            mainHandler.post {
                listener?.onRollaError(this, RollaError.InvalidContext())
            }
            return
        }
        show(activity, transition)
    }

    /**
     * Open a specific SDK screen ([RollaScreen]), presenting the SDK UI
     * first when needed — an already-presented UI navigates in place.
     *
     * The opened screen is the root of the SDK UI: the back button returns
     * the user to your app. Every outcome is a typed [RollaOpenScreenStatus],
     * delivered on the main thread; presentation failures are also reported
     * to [RollaListener.onRollaError].
     *
     * Call [warmUpEngine] before the first [openScreen]. A warm engine
     * settles everything off screen and shows nothing unless the screen
     * opened, whereas a cold engine must present first and lands on Home
     * while it starts up. On a cold start, then, a status like
     * [RollaOpenScreenStatus.SCREEN_DISABLED] arrives with the SDK already
     * open on Home; it describes what the user ended up seeing, not a no-op.
     *
     * @param activity The activity to present the SDK UI from.
     * @param screen The SDK screen to open.
     * @param transition The presentation animation, same as [show]. Ignored
     *   when already on screen.
     * @param callback Delivers the [RollaOpenScreenStatus].
     */
    fun openScreen(
        activity: Activity,
        screen: RollaScreen,
        transition: RollaTransition = RollaTransition.DEFAULT,
        callback: (RollaOpenScreenStatus) -> Unit,
    ) {
        mainHandler.post {
            if (engineManager.isPresenting) {
                // Already on screen — route the navigation request as-is; the
                // Dart side resolves the status.
                engineManager.openScreen(screen) { status ->
                    mainHandler.post { callback(status) }
                }
                return@post
            }

            if (activity.isFinishing || activity.isDestroyed) {
                listener?.onRollaError(this, RollaError.InvalidContext())
                callback(RollaOpenScreenStatus.UI_UNAVAILABLE)
                return@post
            }

            engineManager.setPresenting(true)

            if (engineManager.isReady) {
                openScreenOnWarmEngine(activity, screen, transition, callback)
                return@post
            }

            // Cold engine: present first. Start-up is long enough that the
            // SDK's loader has to cover it anyway, and the queued navigation
            // settles underneath that same loader — navigate-first would
            // only delay the reveal.
            prepareAndShow(activity, transition) { result ->
                result.onSuccess {
                    // Dispatched only after the "initialize" channel
                    // invocation (same sequencing as syncHealthData); the
                    // Dart side queues the request until its home widget
                    // settles, so right after configure is safe.
                    engineManager.openScreen(screen) { status ->
                        mainHandler.post { callback(status) }
                    }
                }.onFailure { error ->
                    val status = when (error) {
                        is RollaError.InvalidContext -> RollaOpenScreenStatus.UI_UNAVAILABLE
                        else -> RollaOpenScreenStatus.UNKNOWN_ERROR
                    }
                    callback(status)
                }
            }
        }
    }

    /**
     * Warm-engine open: navigate first, present only on
     * [RollaOpenScreenStatus.OPENED].
     *
     * With a running engine the target screen settles offscreen before the
     * reveal, so the host-side [transition] uncovers the finished screen.
     * Presenting first and navigating after would visibly replay the SDK's
     * internal navigation transition on reveal — Flutter tickers don't
     * advance while the UI is hidden — and would flash the SDK open even
     * when the request resolves to a failure such as
     * [RollaOpenScreenStatus.SCREEN_DISABLED]. Only a cold engine start
     * presents first: there the loader covers the navigation settling.
     *
     * The caller must have reserved the presentation slot
     * ([RollaEngineManager.setPresenting]). A path that never presents
     * releases only that slot — the presentation callbacks are wired once the
     * open is known to succeed, so a rejected open leaves whichever instance
     * owns them untouched.
     */
    private fun openScreenOnWarmEngine(
        activity: Activity,
        screen: RollaScreen,
        transition: RollaTransition,
        callback: (RollaOpenScreenStatus) -> Unit,
    ) {
        engineManager.ensureConfigured(activity.applicationContext, configuration) { configureResult ->
            mainHandler.post {
                configureResult.onSuccess {
                    engineManager.openScreen(screen) { status ->
                        mainHandler.post {
                            if (status != RollaOpenScreenStatus.OPENED) {
                                // Nothing will be revealed — the SDK stays
                                // hidden and the status speaks for itself.
                                engineManager.setPresenting(false)
                                callback(status)
                                return@post
                            }
                            if (activity.isFinishing || activity.isDestroyed) {
                                engineManager.setPresenting(false)
                                listener?.onRollaError(this, RollaError.InvalidContext())
                                callback(RollaOpenScreenStatus.UI_UNAVAILABLE)
                                return@post
                            }
                            setupCallbacks()
                            launchActivity(activity, transition)
                            callback(RollaOpenScreenStatus.OPENED)
                        }
                    }
                }.onFailure { error ->
                    engineManager.setPresenting(false)
                    val rollaError = (error as? RollaError)
                        ?: RollaError.InitializationFailed(error.message ?: "Unknown error")
                    listener?.onRollaError(this, rollaError)
                    callback(RollaOpenScreenStatus.UNKNOWN_ERROR)
                }
            }
        }
    }

    /**
     * Clear all persisted session data (tokens, auth metadata) from secure storage.
     *
     * Call this when your app logs out the user and you want the SDK to forget
     * all credentials for that user. This does **not** dismiss the SDK UI or
     * destroy the Flutter engine — it only purges stored tokens.
     *
     * The engine must be initialized (i.e. [show] must have been called at
     * least once) for the method channel to be available.
     */
    fun clearSession(callback: ((Result<Unit>) -> Unit)? = null) {
        mainHandler.post {
            engineManager.clearSession { result ->
                mainHandler.post {
                    callback?.invoke(result)
                }
            }
        }
    }

    /**
     * Push fresh tokens to the SDK.
     *
     * Call this after receiving an [RollaListener.onTokenExpired] callback,
     * once your app has obtained new tokens from its own auth backend.
     *
     * @param token The new access token.
     * @param refreshToken An optional new refresh token.
     * @param expiresIn Optional time in seconds until the new token expires.
     * @param callback Called when the SDK has accepted or rejected the token update.
     */
    fun updateToken(
        token: String,
        refreshToken: String? = null,
        expiresIn: Int? = null,
        callback: ((Result<Unit>) -> Unit)? = null
    ) {
        mainHandler.post {
            engineManager.updateToken(
                token = token,
                refreshToken = refreshToken,
                expiresIn = expiresIn
            ) { result ->
                mainHandler.post {
                    callback?.invoke(result)
                }
            }
        }
    }

    /**
     * Start and configure the Flutter engine ahead of time, WITHOUT presenting
     * any UI.
     *
     * This is an optional performance optimization. [show], [openScreen],
     * [getBandBatteryLevel], [getPairedBandInfo], and [syncHealthData] all
     * start the engine themselves on first use, so none of them require a
     * prior warm-up — calling this simply moves that one-time start-up cost
     * off the first call. A common pattern is to warm up right after login
     * so the first [show] presents instantly.
     *
     * A later [show] reuses the running engine and presents immediately. Safe to
     * call repeatedly: a repeat call for the same user is a no-op that preserves
     * the existing session.
     *
     * The warmed engine holds memory for the lifetime of the session; release it
     * with [destroyEngine] once you no longer need the SDK.
     *
     * @param context Any context (application context is used internally).
     * @param callback Called when the engine is configured and ready, or with
     *   an error if start-up failed.
     */
    fun warmUpEngine(context: Context, callback: ((Result<Unit>) -> Unit)? = null) {
        val appContext = context.applicationContext
        mainHandler.post {
            // Warm-up runs headless, so it must not wire up the onClose/onError
            // callbacks. Another Rolla instance may be presenting right now, and
            // those callbacks belong to it; show() wires them when this instance
            // presents. The host-EVENT callbacks are different: they are
            // engine-scoped, not presentation-scoped, so a headless warm-up DOES
            // wire them — events must flow without the SDK UI ever opening.
            wireHostEventCallbacks()
            engineManager.ensureConfigured(appContext, configuration) { result ->
                mainHandler.post { callback?.invoke(result) }
            }
        }
    }

    /**
     * Read the connected Rolla band's current battery level.
     *
     * This is a **live BLE read from a Rolla band** — the user must have a Rolla
     * band paired and reachable for a value to come back.
     *
     * Works on its own: the engine starts automatically on first use (no UI is
     * shown) — a prior [warmUpEngine] or [show] only removes the one-time
     * start-up latency.
     *
     * The result is always a typed [RollaBatteryResult]. Cases where no live
     * value is available (no band paired, band not reachable, not a Rolla
     * band, Bluetooth off or missing permission) resolve as success with a
     * non-AVAILABLE status, never as a thrown error and never as a stale value
     * reported as live. A failed Result is reserved for transport problems,
     * such as the engine failing to start.
     *
     * @param context Any context (application context is used internally).
     * @param callback Delivers the battery result on the main thread.
     */
    fun getBandBatteryLevel(context: Context, callback: (Result<RollaBatteryResult>) -> Unit) {
        val appContext = context.applicationContext
        mainHandler.post {
            // Headless read: don't wire presentation callbacks (see warmUpEngine).
            // Host-event callbacks ARE wired — they're engine-scoped.
            wireHostEventCallbacks()
            engineManager.ensureConfigured(appContext, configuration) { configureResult ->
                configureResult.onSuccess {
                    engineManager.getBandBatteryLevel { batteryResult ->
                        mainHandler.post { callback(batteryResult) }
                    }
                }.onFailure { error ->
                    val rollaError = (error as? RollaError)
                        ?: RollaError.InitializationFailed(error.message ?: "Unknown error")
                    mainHandler.post { callback(Result.failure(rollaError)) }
                }
            }
        }
    }

    /**
     * Answer "does this account currently have a Rolla band paired?" — with
     * **zero Bluetooth**: no scan, no connect, no BLE permission; works with
     * Bluetooth off.
     *
     * Works on its own: the engine starts automatically on first use (no UI is
     * shown) — a prior [warmUpEngine] or [show] only removes the one-time
     * start-up latency.
     *
     * The result is always a typed [RollaPairedBandResult]: BAND_PAIRED with the
     * band's MAC address (always present) plus the last cached
     * battery/firmware/serial — each may be null if the SDK hasn't read the band
     * recently (for a live battery value use [getBandBatteryLevel]),
     * NO_BAND_PAIRED when the user's profile confirms no band, or UNKNOWN when
     * the state could not be determined (offline with no local record) — never
     * a guess. A failed Result is reserved for transport problems, such as the
     * engine failing to start.
     *
     * The lookup is network-first on purpose — the profile is the
     * authoritative pairing record, so a band unpaired remotely from another
     * device (which fires no event by design) is reported correctly; a local
     * record only answers when the network can't.
     *
     * This is a pairing-state query, not a link-state one: live connect/
     * disconnect transitions are reported by [RollaListener.onBandConnected] /
     * [RollaListener.onBandDisconnected] instead.
     *
     * @param context Any context (application context is used internally).
     * @param callback Delivers the paired-band result on the main thread.
     */
    fun getPairedBandInfo(context: Context, callback: (Result<RollaPairedBandResult>) -> Unit) {
        val appContext = context.applicationContext
        mainHandler.post {
            // Headless query: don't wire presentation callbacks (see warmUpEngine).
            // Host-event callbacks ARE wired — they're engine-scoped.
            wireHostEventCallbacks()
            engineManager.ensureConfigured(appContext, configuration) { configureResult ->
                configureResult.onSuccess {
                    engineManager.getPairedBandInfo { pairedResult ->
                        mainHandler.post { callback(pairedResult) }
                    }
                }.onFailure { error ->
                    val rollaError = (error as? RollaError)
                        ?: RollaError.InitializationFailed(error.message ?: "Unknown error")
                    mainHandler.post { callback(Result.failure(rollaError)) }
                }
            }
        }
    }

    /**
     * Run a full sync of the user's primary health data source and upload
     * anything new, WITHOUT showing any UI.
     *
     * Works on its own: the engine starts automatically on first use — a prior
     * [warmUpEngine] or [show] only removes the one-time start-up latency.
     *
     * The result is always a typed [RollaSyncResult]. A sync that does nothing
     * for an expected reason — no band paired, the band not reachable, a sync
     * already running, a server-side source, or offline — resolves as success
     * with a [RollaSyncOutcome.SKIPPED] outcome, never as a thrown error. A
     * failed Result is reserved for transport problems, such as the engine
     * failing to start.
     *
     * The same result is also delivered to
     * [RollaListener.onSyncHealthDataCompleted] once a sync reaches a terminal
     * outcome.
     *
     * On success, [RollaSyncResult.syncedData] describes what was uploaded. A
     * per-stream summary is always included; pass `includeSamples = true` to
     * also receive the raw sample arrays ([RollaSyncedHealthData.samples]).
     * Samples are heavier — a band sync can be thousands of points — so they
     * default to off.
     *
     * @param context Any context (application context is used internally).
     * @param includeSamples When `true`, also return the raw per-stream samples.
     *   Defaults to `false` (summaries only).
     * @param callback Delivers the sync result on the main thread.
     */
    fun syncHealthData(
        context: Context,
        includeSamples: Boolean = false,
        callback: (Result<RollaSyncResult>) -> Unit
    ) {
        val appContext = context.applicationContext
        mainHandler.post {
            // Headless sync: don't wire presentation callbacks (see warmUpEngine).
            // Host-event callbacks ARE wired — they're engine-scoped.
            wireHostEventCallbacks()
            engineManager.ensureConfigured(appContext, configuration) { configureResult ->
                configureResult.onSuccess {
                    engineManager.syncHealthData(includeSamples) { syncResult ->
                        mainHandler.post {
                            syncResult.onSuccess { result ->
                                listener?.onSyncHealthDataCompleted(this, result)
                            }
                            callback(syncResult)
                        }
                    }
                }.onFailure { error ->
                    val rollaError = (error as? RollaError)
                        ?: RollaError.InitializationFailed(error.message ?: "Unknown error")
                    mainHandler.post { callback(Result.failure(rollaError)) }
                }
            }
        }
    }

    fun dismiss() {
        mainHandler.post {
            if (!engineManager.isPresenting) return@post

            if (pendingCloseReason == null) {
                pendingCloseReason = RollaCloseReason.Programmatic
            }

            RollaFlutterActivity.setPendingCloseReason(
                pendingCloseReason ?: RollaCloseReason.Programmatic
            )
            RollaFlutterActivity.finishCurrent()
        }
    }

    /**
     * Shared presentation flow: start the engine, wire callbacks, configure,
     * and launch the SDK activity. Failures are always reported to the
     * listener, matching [show]; [onResult] additionally tells a caller that
     * needs to act after presentation (like [openScreen]) whether the launch
     * happened. Runs — and reports — on the main thread.
     */
    private fun prepareAndShow(
        activity: Activity,
        transition: RollaTransition,
        onResult: ((Result<Unit>) -> Unit)? = null
    ) {
        try {
            engineManager.initialize(activity)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize engine", e)
            cleanup()
            listener?.onRollaError(this, RollaError.EngineFailedToStart())
            onResult?.invoke(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        setupCallbacks()

        // Back button forced on: for a native add-to-app host it is the user's
        // only built-in way out of the SDK Activity and back to the host app.
        engineManager.configure(
            config = configuration,
            showBackButton = true
        ) { result ->
            mainHandler.post {
                result.onSuccess {
                    if (activity.isFinishing || activity.isDestroyed) {
                        cleanup()
                        listener?.onRollaError(this, RollaError.InvalidContext())
                        onResult?.invoke(Result.failure(RollaError.InvalidContext()))
                        return@post
                    }
                    launchActivity(activity, transition)
                    onResult?.invoke(Result.success(Unit))
                }.onFailure { error ->
                    cleanup()
                    val rollaError = when (error) {
                        is RollaError -> error
                        else -> RollaError.InitializationFailed(error.message ?: "Unknown error")
                    }
                    listener?.onRollaError(this, rollaError)
                    onResult?.invoke(Result.failure(rollaError))
                }
            }
        }
    }

    private fun launchActivity(activity: Activity, transition: RollaTransition) {
        if (RollaFlutterActivity.onDismiss != null) {
            Log.w(TAG, "Warning: overwriting existing onDismiss callback - this should not happen")
        }

        RollaFlutterActivity.onDismiss = { reason ->
            mainHandler.post {
                val finalReason = pendingCloseReason ?: reason
                cleanup()
                listener?.onRollaClosed(this, finalReason)
            }
        }

        // The transition rides along as an extra because the activity is
        // launched by class name — there is no constructor to pass it through.
        // The activity uses it to mirror the animation on close.
        val intent = Intent(activity, RollaFlutterActivity::class.java)
        intent.putExtra(RollaFlutterActivity.EXTRA_TRANSITION, transition.name)
        if (transition == RollaTransition.FADE) {
            val options = ActivityOptions.makeCustomAnimation(activity, R.anim.rolla_fade_in, R.anim.rolla_fade_out)
            activity.startActivity(intent, options.toBundle())
        } else {
            activity.startActivity(intent)
        }

        Log.d(TAG, "RollaFlutterActivity launched")
    }

    /**
     * Wire the host-event closures to THIS instance's listener for the
     * engine's lifetime. Unlike the presentation callbacks (wired in
     * [setupCallbacks], cleared in [cleanup] on dismiss), events keep flowing
     * after the SDK UI closes — a late `uploaded` activity phase must still
     * reach the host, and a host that only ever runs headless calls still gets
     * events. Cleared only by [destroyEngine] or when another Rolla instance
     * wires itself (last writer wins, matching the presentation-callback
     * semantics). This instance is captured deliberately so delivery survives
     * the host dropping its reference; the engine manager is a singleton and
     * holds no reference back, so this is a cycle-free lifetime extension
     * until destroy/rewire.
     */
    private fun wireHostEventCallbacks() {
        engineManager.onActivityCompleted = { activity ->
            mainHandler.post { listener?.onActivityCompleted(this, activity) }
        }

        engineManager.onActivityStarted = { activity ->
            mainHandler.post { listener?.onActivityStarted(this, activity) }
        }

        engineManager.onActivityRemoved = { activity ->
            mainHandler.post { listener?.onActivityRemoved(this, activity) }
        }

        engineManager.onUiSyncCompleted = { result ->
            mainHandler.post { listener?.onUiSyncCompleted(this, result) }
        }

        engineManager.onBandPaired = { band ->
            mainHandler.post { listener?.onBandPaired(this, band) }
        }

        engineManager.onBandUnpaired = { band ->
            mainHandler.post { listener?.onBandUnpaired(this, band) }
        }

        engineManager.onBandConnected = { band ->
            mainHandler.post { listener?.onBandConnected(this, band) }
        }

        engineManager.onBandDisconnected = { band ->
            mainHandler.post { listener?.onBandDisconnected(this, band) }
        }

        engineManager.onPrimarySourceChanged = { change ->
            mainHandler.post { listener?.onPrimarySourceChanged(this, change) }
        }

        engineManager.onGoalsChanged = { change ->
            mainHandler.post { listener?.onGoalsChanged(this, change) }
        }

        engineManager.onProfileUpdated = { update ->
            mainHandler.post { listener?.onProfileUpdated(this, update) }
        }
    }

    private fun setupCallbacks() {
        if (engineManager.onClose != null || engineManager.onError != null) {
            Log.w(TAG, "Warning: overwriting existing engine callbacks - this should not happen")
        }

        wireHostEventCallbacks()

        engineManager.onClose = { reason ->
            pendingCloseReason = RollaCloseReason.FlutterRequested(reason)
            RollaFlutterActivity.finishCurrent()
        }

        engineManager.onError = { code, message ->
            mainHandler.post {
                listener?.onRollaError(this, RollaError.FlutterError(code, message))
            }
        }

        engineManager.onTokenRefreshed = { token, refreshToken, expiresIn ->
            mainHandler.post {
                listener?.onTokenRefreshed(this, token, refreshToken, expiresIn)
            }
        }

        engineManager.onTokenExpired = {
            mainHandler.post {
                listener?.onTokenExpired(this)
            }
        }
    }

    private fun cleanup() {
        pendingCloseReason = null
        engineManager.setPresenting(false)
        engineManager.onClose = null
        engineManager.onError = null
        engineManager.onTokenRefreshed = null
        engineManager.onTokenExpired = null
        RollaFlutterActivity.clearCallbacks()
    }
}
