package app.rolla.bluetoothSdk.characteristics.impl

import android.annotation.SuppressLint
import android.content.Context
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic.Companion.TAG
import java.io.File
import app.rolla.bluetoothSdk.characteristics.data.ActivityControlData
import app.rolla.bluetoothSdk.characteristics.data.BatteryLevelData
import app.rolla.bluetoothSdk.characteristics.data.FactoryResetData
import app.rolla.bluetoothSdk.characteristics.data.FirmwareStateData
import app.rolla.bluetoothSdk.characteristics.data.HeartRateData
import app.rolla.bluetoothSdk.characteristics.data.HrvData
import app.rolla.bluetoothSdk.characteristics.data.MotionData
import app.rolla.bluetoothSdk.characteristics.data.SleepData
import app.rolla.bluetoothSdk.characteristics.data.StepsData
import app.rolla.bluetoothSdk.characteristics.data.StopData
import app.rolla.bluetoothSdk.characteristics.data.TotalHeartRateData
import app.rolla.bluetoothSdk.characteristics.data.UserData
import app.rolla.bluetoothSdk.commands.ActivityCallbackAndSetDeviceName
import app.rolla.bluetoothSdk.commands.ActivityControl
import app.rolla.bluetoothSdk.commands.BatteryLevel
import app.rolla.bluetoothSdk.commands.ChargingStatus
import app.rolla.bluetoothSdk.commands.Command
import app.rolla.bluetoothSdk.commands.FactoryReset
import app.rolla.bluetoothSdk.commands.GetActivityHeartRate
import app.rolla.bluetoothSdk.commands.GetAutomaticDetection
import app.rolla.bluetoothSdk.commands.GetCurrentTime
import app.rolla.bluetoothSdk.commands.GetHrv
import app.rolla.bluetoothSdk.commands.GetMotionData
import app.rolla.bluetoothSdk.commands.MotionSecondLevelFirmware
import app.rolla.bluetoothSdk.commands.GetPassiveHeartRate
import app.rolla.bluetoothSdk.commands.GetSleep
import app.rolla.bluetoothSdk.commands.GetSteps
import app.rolla.bluetoothSdk.commands.GetUserData
import app.rolla.bluetoothSdk.commands.GetWristBandParams
import app.rolla.bluetoothSdk.commands.Handshake
import app.rolla.bluetoothSdk.commands.HeartRatePackages
import app.rolla.bluetoothSdk.commands.OtaUpdate
import app.rolla.bluetoothSdk.commands.SetAutomaticDetection
import app.rolla.bluetoothSdk.commands.SetCurrentTime
import app.rolla.bluetoothSdk.commands.SetMotionSavingInterval
import app.rolla.bluetoothSdk.commands.SetUserData
import app.rolla.bluetoothSdk.commands.SetWristBandParams
import app.rolla.bluetoothSdk.commands.data.ActivityMode
import app.rolla.bluetoothSdk.commands.data.ActivityStatus
import app.rolla.bluetoothSdk.commands.data.AutomaticMode
import app.rolla.bluetoothSdk.commands.data.ChargingState
import app.rolla.bluetoothSdk.commands.data.FirmwareState
import app.rolla.bluetoothSdk.commands.data.HeartRate
import app.rolla.bluetoothSdk.commands.data.UserInfo
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.FactoryResetError
import app.rolla.bluetoothSdk.result.error.GetBatteryLevelError
import app.rolla.bluetoothSdk.result.error.GetUserDataError
import app.rolla.bluetoothSdk.result.error.SetUserDataError
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.toHex
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import no.nordicsemi.android.dfu.DfuBaseService
import no.nordicsemi.android.dfu.DfuProgressListener
import no.nordicsemi.android.dfu.DfuServiceController
import no.nordicsemi.android.dfu.DfuServiceInitiator
import no.nordicsemi.android.dfu.DfuServiceListenerHelper
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class RollaBandImpl(
    @param:ApplicationContext private val context: Context,
    @BleScopeContext bleScopeContext: CoroutineContext,
) {

    val scope = CoroutineScope(bleScopeContext)
    @Volatile
    private var rawCaptureMode = false

    private val _rawNotificationFlow = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    val rawNotificationFlow: SharedFlow<ByteArray> = _rawNotificationFlow.asSharedFlow()

    fun enableRawCaptureMode() {
        rawCaptureMode = true
    }

    fun disableRawCaptureMode() {
        rawCaptureMode = false
    }

    val handshake = Handshake()
    val getCurrentTime = GetCurrentTime()
    val setCurrentTime = SetCurrentTime()
    val getAutomaticDetectionHeartRate = GetAutomaticDetection(AutomaticMode.HEART_RATE)
    val getAutomaticDetectionHrv = GetAutomaticDetection(AutomaticMode.HRV)
    val setAutomaticDetectionHeartRate = SetAutomaticDetection(AutomaticMode.HEART_RATE)
    val setAutomaticDetectionHrv = SetAutomaticDetection(AutomaticMode.HRV)
    val getWristBandParams = GetWristBandParams()
    val setWristbandParamsInActivity = SetWristBandParams(true)
    val setWristbandParamsOutsideActivity = SetWristBandParams(false)
    val batteryLevel = BatteryLevel()
    val chargingStatus = ChargingStatus()
    val getUserData = GetUserData()
    val setUserData = SetUserData()
    val activityControl = ActivityControl()
    val activityCallbackAndSetDeviceName = ActivityCallbackAndSetDeviceName()
    val heartRatePackages = HeartRatePackages()
    val otaUpdate = OtaUpdate()
    val factoryReset = FactoryReset()
    val getSteps = GetSteps()
    val getHrv = GetHrv()
    val getPassiveHeartRate = GetPassiveHeartRate()
    val getActivityHeartRate = GetActivityHeartRate()
    val getSleep = GetSleep()
    val setMotionSavingInterval = SetMotionSavingInterval()
    val getMotionData = GetMotionData()

    private val _batteryLevelDataFlow = MutableSharedFlow<BatteryLevelData>(replay = 1)
    val batteryLevelDataFlow: SharedFlow<BatteryLevelData> = _batteryLevelDataFlow.asSharedFlow()

    private val _factoryResetFlow = MutableSharedFlow<FactoryResetData>(replay = 1)
    val factoryResetFlow: SharedFlow<FactoryResetData> = _factoryResetFlow.asSharedFlow()

    private val _userDataResponseFlow = MutableSharedFlow<UserData>(replay = 1)
    val userDataFlow: SharedFlow<UserData> = _userDataResponseFlow.asSharedFlow()

    private val _setUserDataResponseFlow = MutableSharedFlow<UserData>(replay = 1)
    val setUserDataFlow: SharedFlow<UserData> = _setUserDataResponseFlow.asSharedFlow()

    private val _startActivityFlow = MutableSharedFlow<ActivityControlData>(replay = 1)
    val startActivityFlow: SharedFlow<ActivityControlData> = _startActivityFlow.asSharedFlow()

    private val _stopActivityFlow = MutableSharedFlow<ActivityControlData>(replay = 1)
    val stopActivityFlow: SharedFlow<ActivityControlData> = _stopActivityFlow.asSharedFlow()

    private val _heartRatePackagesFlow = MutableSharedFlow<StopData>(replay = 1)
    val heartRatePackagesFlow: SharedFlow<StopData> = _heartRatePackagesFlow.asSharedFlow()

    private val _firmwareUpdateFlow = MutableSharedFlow<FirmwareStateData>(replay = 1)
    val firmwareUpdateFlow: SharedFlow<FirmwareStateData> = _firmwareUpdateFlow.asSharedFlow()

    private val _firmwareUpdateStartedFlow = MutableSharedFlow<FirmwareStateData>(replay = 1)
    val firmwareUpdateStartedFlow: SharedFlow<FirmwareStateData> = _firmwareUpdateStartedFlow.asSharedFlow()

    private val _firmwareUpdateProgressFlow = MutableSharedFlow<Int>(replay = 1)
    val firmwareUpdateProgressFlow: SharedFlow<Int> = _firmwareUpdateProgressFlow.asSharedFlow()

    private val _firmwareUpdateCompletedFlow = MutableSharedFlow<FirmwareStateData>(replay = 1)
    val firmwareUpdateCompletedFlow: SharedFlow<FirmwareStateData> = _firmwareUpdateCompletedFlow.asSharedFlow()

    private val _firmwareUpdateErrorFlow = MutableSharedFlow<String>(replay = 1)
    val firmwareUpdateErrorFlow: SharedFlow<String> = _firmwareUpdateErrorFlow.asSharedFlow()

    private val _stepsFlow = MutableSharedFlow<StepsData>(replay = 1)
    val stepsFlow: SharedFlow<StepsData> = _stepsFlow.asSharedFlow()

    private val _hrvFlow = MutableSharedFlow<HrvData>(replay = 1)
    val hrvFlow: SharedFlow<HrvData> = _hrvFlow.asSharedFlow()
    private val _passiveHeartRateFlow = MutableSharedFlow<HeartRateData>(replay = 1)
    val passiveHeartRateFlow: SharedFlow<HeartRateData> = _passiveHeartRateFlow.asSharedFlow()
    private val _activityHeartRateFlow = MutableSharedFlow<HeartRateData>(replay = 1)
    val activityHeartRateFlow: SharedFlow<HeartRateData> = _activityHeartRateFlow.asSharedFlow()

    private val _totalHeartRateFlow = MutableSharedFlow<TotalHeartRateData>(replay = 1)
    val totalHeartRateFlow: SharedFlow<TotalHeartRateData> = _totalHeartRateFlow.asSharedFlow()

    private val _sleepFlow = MutableSharedFlow<SleepData>(replay = 1)
    val sleepFlow: SharedFlow<SleepData> = _sleepFlow.asSharedFlow()

    private val _motionDataFlow = MutableSharedFlow<MotionData>(replay = 1)
    val motionDataFlow: SharedFlow<MotionData> = _motionDataFlow.asSharedFlow()

    private val _chargingStateFlow = MutableSharedFlow<ChargingState>(replay = 1)
    val chargingStateFlow: SharedFlow<ChargingState> = _chargingStateFlow.asSharedFlow()

    private var activityStatus = ActivityStatus.FINISHED
    private var activityMode = ActivityMode.STOP
    private var stopped = false
    // When true, the Dart layer has a crash-recovery dialog pending. All native
    // auto-stop triggers are suppressed until the user makes a choice.
    @Volatile var activityRestorePending = false
    private var stateData = FirmwareStateData("", "", FirmwareState.IDLE)
    private var dfuServiceController: DfuServiceController? = null
    private var dfuServiceClass: Class<out DfuBaseService>? = null
    private var otaUrl = ""
    private var dfuProgressListener: DfuProgressListener? = null

    fun processData(byteArray: ByteArray, device: BleDevice?) {
        if (byteArray.isEmpty()) return
        // A single malformed frame must not crash the GATT callback thread or abort
        // processing of the notifications that follow it.
        try {
            processDataInternal(byteArray, device)
        } catch (e: Exception) {
            log(TAG, "Dropped unprocessable frame 0x${byteArray[0].toHex()}: ${e.message}")
        }
    }

    private fun processDataInternal(byteArray: ByteArray, device: BleDevice?) {
        when (byteArray[0]) {
            handshake.getId() -> handshake.read(byteArray)
            handshake.errorId() -> {
                log(TAG, "Handshake error")
            }
            getCurrentTime.getId() -> getCurrentTime.read(byteArray)
            getCurrentTime.errorId() -> {
                log(TAG, "Get current time error")
            }
            setCurrentTime.getId() -> setCurrentTime.read(byteArray)
            setCurrentTime.errorId() -> {
                log(TAG, "Set current time error")
            }
            getAutomaticDetectionHeartRate.getId() -> getAutomaticDetectionHeartRate.read(byteArray)
            getAutomaticDetectionHeartRate.errorId() -> {
                log(TAG, "Get automatic detection error")
            }
            setAutomaticDetectionHeartRate.getId() -> setAutomaticDetectionHeartRate.read(byteArray)
            setAutomaticDetectionHeartRate.errorId() -> {
                log(TAG, "Set automatic detection heart rate error")
            }
            setAutomaticDetectionHrv.getId() -> setAutomaticDetectionHrv.read(byteArray)
            setAutomaticDetectionHrv.errorId() -> {
                log(TAG, "Set automatic detection hrv error")
            }
            getWristBandParams.getId() -> getWristBandParams.read(byteArray)
            getWristBandParams.errorId() -> {
                log(TAG, "Get wrist band params error")
            }
            setWristbandParamsOutsideActivity.getId() -> setWristbandParamsOutsideActivity.read(byteArray)
            setWristbandParamsOutsideActivity.errorId() -> {
                log(TAG, "Set wrist band params outside activity error")
            }
            batteryLevel.getId() -> {
                val batteryLevel = batteryLevel.read(byteArray)
                scope.launch {
                    _batteryLevelDataFlow.emit(BatteryLevelData(device!!.getMacAddress(), batteryLevel))
                }
            }
            batteryLevel.errorId() -> {
                log(TAG, "Get battery level error")
                scope.launch {
                    _batteryLevelDataFlow.emit(BatteryLevelData(device!!.getMacAddress(), -1, GetBatteryLevelError()))
                }
            }
            factoryReset.getId() -> {
                factoryReset.read(byteArray)
                scope.launch {
                    _factoryResetFlow.emit(FactoryResetData(device!!.getMacAddress(), true))
                }
            }
            factoryReset.errorId() -> {
                log(TAG, "Factory reset error")
                scope.launch {
                    _factoryResetFlow.emit(FactoryResetData(device!!.getMacAddress(), false, FactoryResetError()))
                }
            }
            chargingStatus.getId() -> {
                val chargingState = chargingStatus.read(byteArray)
                scope.launch {
                    _chargingStateFlow.emit(chargingState)
                }
            }
            getUserData.getId() -> {
                val userInfo = getUserData.read(byteArray)
                scope.launch {
                    _userDataResponseFlow.emit(UserData(device!!.getMacAddress(), userInfo))
                }
            }
            getUserData.errorId() -> {
                log(TAG, "Get user data error")
                scope.launch {
                    _userDataResponseFlow.emit(UserData(device!!.getMacAddress(), UserInfo(0, 0, 0, 0f, 0, ""),
                        GetUserDataError()
                    ))
                }
            }
            setUserData.getId() -> {
                setUserData.read(byteArray)
                scope.launch {
                    _setUserDataResponseFlow.emit(UserData(device!!.getMacAddress(), UserInfo(0, 0, 0, 0f, 0, "")))
                }
            }
            setUserData.errorId() -> {
                log(TAG, "Set user data error")
                scope.launch {
                    _setUserDataResponseFlow.emit(UserData(device!!.getMacAddress(), UserInfo(0, 0, 0, 0f, 0, ""),
                        SetUserDataError()))
                }
            }
            activityControl.getId() -> {
                val activityControlInfo = activityControl.read(byteArray)
                if (!activityControlInfo.success) {
                    if (activityStatus == ActivityStatus.STARTING) {
                        scope.launch {
                            _startActivityFlow.emit(ActivityControlData(device!!.getMacAddress(), false, activityStatus, activityControlInfo.error))
                        }
                        activityStatus = ActivityStatus.STARTED
                    }
                    if (activityStatus == ActivityStatus.FINISHING) {
                        scope.launch {
                            _stopActivityFlow.emit(ActivityControlData(device!!.getMacAddress(), false, activityStatus, activityControlInfo.error))
                        }
                        activityStatus = ActivityStatus.FINISHED
                    }
                    log(TAG, "Activity control error")
                }
            }
            activityCallbackAndSetDeviceName.getId() -> {
                val activityInfo = activityCallbackAndSetDeviceName.read(byteArray)
                if (activityInfo.activityMode == ActivityMode.START) {
                    activityStatus = ActivityStatus.STARTED
                    activityMode = ActivityMode.START
                    scope.launch {
                        _startActivityFlow.emit(ActivityControlData(device!!.getMacAddress(), true, activityStatus))
                    }
                } else if (activityInfo.activityMode == ActivityMode.STOP) {
                    // Distinguish a host-commanded stop (we are FINISHING because
                    // stopBandActivity/forceStopBandActivity called setFinishingStatus)
                    // from a spontaneous band-initiated end (band sent 0x16 06 00
                    // while the SDK still believed the activity was STARTED). Only
                    // the spontaneous case needs the Flutter auto-finalize callback;
                    // the commanded case is resolved by the pending stopActivity
                    // callback. NOTE: this discriminator is advisory only — the
                    // authoritative gate is that a commanded stop has a pending
                    // stopActivityCallbacks entry and therefore never reaches
                    // onNoCallback. endedByBand is a belt-and-suspenders guard.
                    // Idempotent on purpose: a SPONTANEOUS end is only the transition
                    // out of a genuinely-active (STARTED) session. A host-commanded
                    // stop is FINISHING here; and a DUPLICATE 0x16 06 00 echo (which
                    // JStyle firmware can emit) sees the already-demoted FINISHED
                    // state below and yields false, so it can never manufacture a
                    // second spurious spontaneous-end emission.
                    val wasSpontaneous = activityStatus == ActivityStatus.STARTED
                    activityStatus = ActivityStatus.FINISHED
                    activityMode = ActivityMode.STOP
                    scope.launch {
                        _stopActivityFlow.emit(
                            ActivityControlData(
                                device!!.getMacAddress(),
                                true,
                                activityStatus,
                                endedByBand = wasSpontaneous
                            )
                        )
                    }
                }
            }
            heartRatePackages.getId() -> {
                heartRatePackages.read(byteArray)
                if (activityStatus != ActivityStatus.FINISHING) {
                    activityStatus = ActivityStatus.STARTED
                }
                // Auto-stop is suppressed when a crash-recovery dialog is pending so the
                // band keeps running until the user chooses resume / save / discard.
                val shouldAutoStop = activityMode == ActivityMode.STOP && activityStatus == ActivityStatus.STARTED && !stopped && !activityRestorePending
                if (shouldAutoStop) {
                    scope.launch {
                        _heartRatePackagesFlow.emit(StopData(device!!.getMacAddress()))
                    }
                    stopped = true
                }
            }
            getSteps.getId() -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                }
                val stepsData = getSteps.read(byteArray)
                stepsData.uuid = device!!.getMacAddress()
                log(TAG, "Steps data: $stepsData")
                scope.launch {
                    if (stepsData.isEndOfData) {
                        _stepsFlow.emit(stepsData)
                    }
                }
            }
            getHrv.getId() -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                }
                val hrvData = getHrv.read(byteArray)
                hrvData.uuid = device!!.getMacAddress()
                log(TAG, "HRV data: $hrvData")
                scope.launch {
                    if (hrvData.isEndOfData) {
                        _hrvFlow.emit(hrvData)
                    }
                }
            }
            getPassiveHeartRate.getId() -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                }
                markHeartRateFrame(device)
                val heartRateData = getPassiveHeartRate.read(byteArray)
                heartRateData.uuid = device!!.getMacAddress()
                log(TAG, "Heart rate data: $heartRateData")
                scope.launch {
                    if (heartRateData.isEndOfData) {
                        _passiveHeartRateFlow.emit(heartRateData)
                    }
                }
            }
            getPassiveHeartRate.errorId() -> {
                markHeartRateFrame(device)
                log(TAG, "Passive heart rate error frame — ending passive phase with data received so far")
                device?.getMacAddress()?.let { forcePassiveHeartRateEnd(it) }
            }
            getActivityHeartRate.getId() -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                }
                markHeartRateFrame(device)
                val heartRateData = getActivityHeartRate.read(byteArray)
                heartRateData.uuid = device!!.getMacAddress()
                log(TAG, "Activity heart rate data: $heartRateData")
                scope.launch {
                    if (heartRateData.isEndOfData) {
                        _activityHeartRateFlow.emit(heartRateData)
                    }
                }
            }
            getActivityHeartRate.errorId() -> {
                markHeartRateFrame(device)
                log(TAG, "Activity heart rate error frame — ending heart rate sync with data received so far")
                device?.getMacAddress()?.let { forceActivityHeartRateEnd(it) }
            }
            getSleep.getId() -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                }
                val sleepData = getSleep.read(byteArray)
                sleepData.uuid = device!!.getMacAddress()
                log(TAG, "Sleep data: $sleepData")
                scope.launch {
                    if (sleepData.isEndOfData) {
                        _sleepFlow.emit(sleepData)
                    }
                }
            }
            getMotionData.getId() -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                } else {
                    val motionData = getMotionData.read(byteArray)
                    motionData.uuid = device!!.getMacAddress()
                    log(TAG, "Motion data: $motionData")
                    scope.launch {
                        if (motionData.isEndOfData) {
                            _motionDataFlow.emit(motionData)
                        }
                    }
                }
            }

            setMotionSavingInterval.getId() -> setMotionSavingInterval.read(byteArray)
            else -> {
                if (rawCaptureMode) {
                    _rawNotificationFlow.tryEmit(byteArray)
                }
                log(TAG, "Not handled ${byteArray[0]}")
            }
        }
    }

    fun canStartActivity(): Boolean {
        return activityStatus == ActivityStatus.FINISHED
    }

    fun setStartingStatus() {
        activityStatus = ActivityStatus.STARTING
    }

    fun isActivityStarted(): Boolean {
        return activityStatus == ActivityStatus.STARTED
    }

    fun setFinishingStatus() {
        activityStatus = ActivityStatus.FINISHING
    }

    fun setFirmwareVersion(version: String) {
        getUserData.setFirmwareVersion(version)
        setUserData.setFirmwareVersion(version)
        getMotionData.setSecondLevelFirmware(MotionSecondLevelFirmware.isSupported(version))
    }

    fun isOtaStarted(): Boolean {
        return stateData.state != FirmwareState.IDLE
    }

    fun setFirmwareStateStarted(uuid: String) {
        stateData.state = FirmwareState.STARTED
        stateData.uuid = uuid
        scope.launch {
            _firmwareUpdateFlow.emit(stateData)
        }
    }

    @SuppressLint("MissingPermission")
    fun startInternalUpdate(bleDevice: BleDevice) {
        if (stateData.state == FirmwareState.STARTED) {
            stateData.state = FirmwareState.INTERNAL_STARTED
            stateData.dfuUuid = bleDevice.getMacAddress()
            scope.launch {
                _firmwareUpdateFlow.emit(stateData)
            }
            startUpdate(bleDevice.getMacAddress(), bleDevice.getName(context))
        }
    }

    fun setDfuServiceClass(serviceClass: Class<out DfuBaseService>) {
        this.dfuServiceClass = serviceClass
    }

    fun setOtaUrl(url: String) {
        this.otaUrl = url
    }

    fun startUpdate(macAddress: String, deviceName: String) {
        val serviceClass = dfuServiceClass ?: throw IllegalStateException("DfuService class not set")

        val starter = DfuServiceInitiator(macAddress)
            .setDeviceName(deviceName)
            .setKeepBond(true)
            .disableResume()
            .setDisableNotification(true) // Disabling notification
            .setPacketsReceiptNotificationsEnabled(false) // Disabling notification
            .setForeground(false) // Disabling notification
            .setRestoreBond(true)
            .setRebootTime(60000)
            .setNumberOfRetries(2)
        // If you want to have experimental button less DFU feature (DFU from SDK 12.x only!) supported call additionally:
        starter.setUnsafeExperimentalButtonlessServiceInSecureDfuEnabled(true)
        // but be aware of this: https://devzone.nordicsemi.com/question/100609/sdk-12-bootloader-erased-after-programming/
        // and other issues related to this experimental service.

        // For DFU bootloaders from SDK 15 and 16 it may be required to add a delay before sending each
        // data packet. This delay gives the DFU target more time to prepare flash memory, causing less
        // packets being dropped and more reliable transfer. Detection of packets being lost would cause
        // automatic switch to PRN = 1, making the DFU very slow (but reliable).
        starter.setPrepareDataObjectDelay(300L)

        // Init packet is required by Bootloader/DFU from SDK 7.0+ if HEX or BIN file is given above.
        // In case of a ZIP file, the init packet (a DAT file) must be included inside the ZIP file.
        //val uri = Uri.parse("file:///android_asset/J2251_V015_1_20230324.zip")
        //context.contentResolver.openInputStream(uri)
        //val uri = Uri.parse("file:///android_asset/J2251_V015_1_20230324")
        //Uri.parse("file://android_asset/J2251_V015_1_20230324.zip")
        //starter.setZip(null, "storage/emulated/0/Download/J2251_V034_1_20231010.zip")
        ///data/user/0/app.rolla.one/cache/RollaOne/RollaBand/J2251_V034_1_20231010.zip
        starter.setZip(null, otaUrl)

        dfuProgressListener?.let {
            DfuServiceListenerHelper.unregisterProgressListener(context, it)
            log(TAG, "[FIRMWARE] Unregistered previous DFU listener")
        }

        dfuProgressListener = object : DfuProgressListener {
            override fun onDeviceConnecting(deviceAddress: String) {
                log(TAG, "onDeviceConnecting $deviceAddress")
            }

            override fun onDeviceConnected(deviceAddress: String) {
                log(TAG, "onDeviceConnected $deviceAddress")
            }

            override fun onDfuProcessStarting(deviceAddress: String) {
                log(TAG, "onDfuProcessStarting $deviceAddress")
            }

            override fun onDfuProcessStarted(deviceAddress: String) {
                stateData.state = FirmwareState.ON_STARTED
                scope.launch {
                    _firmwareUpdateFlow.emit(stateData)
                }
                scope.launch {
                    _firmwareUpdateStartedFlow.emit(stateData)
                }
                log(TAG, "onDfuProcessStarted $deviceAddress")
            }

            override fun onEnablingDfuMode(deviceAddress: String) {
                log(TAG, "onEnablingDfuMode $deviceAddress")
            }

            override fun onProgressChanged(
                deviceAddress: String,
                percent: Int,
                speed: Float,
                avgSpeed: Float,
                currentPart: Int,
                partsTotal: Int
            ) {
                log(TAG, "onProgressChanged $deviceAddress $percent $speed $avgSpeed $currentPart $partsTotal")
                scope.launch {
                    _firmwareUpdateProgressFlow.emit(percent)
                }
            }

            override fun onFirmwareValidating(deviceAddress: String) {
                log(TAG, "onFirmwareValidating $deviceAddress")
            }

            override fun onDeviceDisconnecting(deviceAddress: String?) {
                log(TAG, "onDeviceDisconnecting $deviceAddress")
            }

            override fun onDeviceDisconnected(deviceAddress: String) {
                log(TAG, "onDeviceDisconnected $deviceAddress")
            }

            override fun onDfuCompleted(deviceAddress: String) {
                log(TAG, "[FIRMWARE] onDfuCompleted $deviceAddress")
                stateData.state = FirmwareState.IDLE
                scope.launch {
                    _firmwareUpdateCompletedFlow.emit(stateData)
                }
                unregisterDfuListener()
            }

            override fun onDfuAborted(deviceAddress: String) {
                log(TAG, "[FIRMWARE] onDfuAborted $deviceAddress")
                val originalUuid = stateData.uuid
                stateData.state = FirmwareState.IDLE
                scope.launch {
                    _firmwareUpdateErrorFlow.emit("Firmware update aborted")
                    if (originalUuid.isNotEmpty()) {
                        _firmwareUpdateCompletedFlow.emit(FirmwareStateData(originalUuid, "", FirmwareState.IDLE))
                    }
                }
                unregisterDfuListener()
            }

            override fun onError(
                deviceAddress: String,
                error: Int,
                errorType: Int,
                message: String?
            ) {
                log(TAG, "[FIRMWARE] onError $deviceAddress $error $errorType $message")
                val originalUuid = stateData.uuid
                stateData.state = FirmwareState.IDLE
                scope.launch {
                    _firmwareUpdateErrorFlow.emit(message ?: "Unknown error")
                    if (originalUuid.isNotEmpty()) {
                        _firmwareUpdateCompletedFlow.emit(FirmwareStateData(originalUuid, "", FirmwareState.IDLE))
                    }
                }
                unregisterDfuListener()
            }
        }

        dfuProgressListener?.let { listener ->
            DfuServiceListenerHelper.registerProgressListener(context, listener)
            log(TAG, "[FIRMWARE] Registered DFU listener")
        }

        dfuServiceController = starter.start(context, serviceClass)
    }

    private fun unregisterDfuListener() {
        dfuProgressListener?.let {
            DfuServiceListenerHelper.unregisterProgressListener(context, it)
            dfuProgressListener = null
            log(TAG, "[FIRMWARE] Unregistered DFU listener")
        }
    }

    /**
     * Anchors are the ones latched with the sample snapshots along the sync chain — never
     * read from live command state here, where a frame parsed after the snapshot could
     * have advanced them past samples that are not in [heartRates].
     */
    fun emitHeartRate(
        uuid: String,
        heartRates: ArrayList<HeartRate>,
        passiveLastBlockTimestamp: Long,
        activityLastBlockTimestamp: Long,
        activityLastEntryTimestamp: Long
    ) {
        heartRates.sortBy { heartRate -> heartRate.timestamp }
        scope.launch {
            _totalHeartRateFlow.emit(TotalHeartRateData(
                uuid = uuid,
                heartRates = heartRates,
                activityLastBlockTimestamp = activityLastBlockTimestamp,
                activityLastEntryTimestamp = activityLastEntryTimestamp,
                passiveLastBlockTimestamp = passiveLastBlockTimestamp
            ))
        }
    }

    // Wall-clock time of the last heart-rate history frame (data or error) per device —
    // per device so one band's stream cannot mask another band's stalled sync.
    private val lastHeartRateFrameAt = ConcurrentHashMap<String, Long>()

    fun lastHeartRateFrameAt(uuid: String): Long = lastHeartRateFrameAt[uuid] ?: 0L

    private fun markHeartRateFrame(device: BleDevice?) {
        device?.getMacAddress()?.let { lastHeartRateFrameAt[it] = System.currentTimeMillis() }
    }

    /**
     * Ends the passive heart-rate phase with whatever was received so far — after a band
     * error frame or a transfer gone silent — so the sync chain proceeds to the activity
     * phase instead of waiting forever for a frame that will never come.
     */
    fun forcePassiveHeartRateEnd(uuid: String) {
        val heartRateData = getPassiveHeartRate.snapshotEnd()
        heartRateData.uuid = uuid
        scope.launch { _passiveHeartRateFlow.emit(heartRateData) }
    }

    /** Same as [forcePassiveHeartRateEnd], for the activity heart-rate phase. */
    fun forceActivityHeartRateEnd(uuid: String) {
        val heartRateData = getActivityHeartRate.snapshotEnd()
        heartRateData.uuid = uuid
        scope.launch { _activityHeartRateFlow.emit(heartRateData) }
    }

    fun onWrite(byteArray: ByteArray?, device: BleDevice) {
        if (byteArray != null && byteArray.isNotEmpty() && byteArray[0] == otaUpdate.getId()) {
            log(TAG, "OTA update command written")
            stateData.state = FirmwareState.STARTED
            stateData.uuid = device.getMacAddress()
            scope.launch {
                _firmwareUpdateFlow.emit(stateData)
            }
        }
    }

    fun onDeviceConnected() {
        stopped = false
        stateData = FirmwareStateData("", "", FirmwareState.IDLE)
    }

    /**
     * Syncs native activity state to "in activity" after the user chooses to resume
     * a crash-interrupted activity. Does NOT send any BLE command to the band -- the
     * band is already running.
     */
    fun markActivityAsActive() {
        activityStatus = ActivityStatus.STARTED
        activityMode = ActivityMode.START
        activityRestorePending = false
        stopped = false
    }

    fun onError(deviceAddress: String, error: Error, commandId: Byte) {
        when (commandId) {
            batteryLevel.errorId() -> {
                log(TAG, "Get battery level error")
                scope.launch {
                    _batteryLevelDataFlow.emit(BatteryLevelData(deviceAddress, -1, GetBatteryLevelError()))
                }
            }
            factoryReset.errorId() -> {
                log(TAG, "Factory reset error")
                scope.launch {
                    _factoryResetFlow.emit(FactoryResetData(deviceAddress, false, FactoryResetError()))
                }
            }
            getUserData.errorId() -> {
                log(TAG, "Get user data error")
                scope.launch {
                    _userDataResponseFlow.emit(UserData(deviceAddress, UserInfo(0, 0, 0, 0f, 0, ""),
                        GetUserDataError()
                    ))
                }
            }
            setUserData.errorId() -> {
                log(TAG, "Set user data error")
                scope.launch {
                    _setUserDataResponseFlow.emit(UserData(deviceAddress, UserInfo(0, 0, 0, 0f, 0, ""),
                        SetUserDataError()))
                }
            }
            otaUpdate.errorId() -> {
                log(TAG, "[FIRMWARE] ❌ OTA command write failed: ${error.message}")
                val originalUuid = stateData.uuid
                stateData.state = FirmwareState.IDLE
                stateData.error = error
                scope.launch {
                    _firmwareUpdateErrorFlow.emit("Failed to start OTA update: ${error.message}")

                    if (originalUuid.isNotEmpty()) {
                        _firmwareUpdateCompletedFlow.emit(FirmwareStateData(originalUuid, "", FirmwareState.IDLE))
                    }
                }
            }
        }

    }

    fun getPostSubscriptionCommands(): List<Command<*>> {
        setMotionSavingInterval.setInterval(1)

        val commands = mutableListOf<Command<*>>(
            handshake,
            getCurrentTime,
            setCurrentTime,
            getAutomaticDetectionHeartRate,
            setAutomaticDetectionHeartRate,
            getAutomaticDetectionHrv,
            setAutomaticDetectionHrv,
            getWristBandParams
        )

        // Skip outside-activity wristband params when a restore is pending so the
        // band stays in activity mode until the user decides what to do.
        val addOutsideParams = activityStatus == ActivityStatus.FINISHED && !activityRestorePending
        if (addOutsideParams) {
            commands.add(setWristbandParamsOutsideActivity)
        }
        commands.add(setMotionSavingInterval)

        return commands
    }
}
