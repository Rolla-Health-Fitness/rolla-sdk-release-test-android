package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.characteristics.data.HeartRateData
import app.rolla.bluetoothSdk.commands.data.HeartRate
import app.rolla.bluetoothSdk.commands.data.PassiveHeartRateRecord
import app.rolla.bluetoothSdk.commands.data.SyncTimestamp
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.toBcdTimeOrNull
import app.rolla.bluetoothSdk.utils.toEpochMilliSecondsOrNull
import app.rolla.bluetoothSdk.utils.toIntLE
import app.rolla.bluetoothSdk.utils.toPositionedInt
import app.rolla.bluetoothSdk.utils.writeBcdTimeToArray
import java.util.Calendar
import java.util.TimeZone

class GetPassiveHeartRate : Command<HeartRateData> {

    // Mutated on the GATT callback thread via read(), snapshotted from coroutine threads
    // via snapshotEnd() — every access to this state is @Synchronized.
    private var heartRateList: MutableList<HeartRate> = mutableListOf()
    private var passiveHeartRateTimestamp: SyncTimestamp = SyncTimestamp()
    private var nextPage = false
    private var maxDeliveredTimestamp = 0L

    companion object {
        const val TAG = "GetPassiveHeartRate"
        private const val NEXT_PAGE_FLAG = 0x02.toByte()
        private const val FIRST_PAGE_FLAG = 0x00.toByte()
        private const val TIMESTAMP_START_INDEX = 4
        private const val RECORD_SIZE = 10
        private const val DATA_NUMBER_OFFSET = 1
        private const val BCD_TIME_OFFSET = 3
        private const val HEART_RATE_OFFSET = 9
        private const val PAGE_SIZE = 50 * 24
        private const val END_OF_DATA_MARKER = 0xff.toByte()
        // Band clock skew tolerance: samples stamped further in the future than this are
        // dropped for now (they are re-fetched once the wall clock passes them), so a
        // persisted anchor can never end up ahead of the data the band actually has.
        internal const val MAX_ANCHOR_SKEW_MS = 5 * 60 * 1000L
    }

    @Synchronized
    fun setHeartRateTimestamp(lastBlockTimestamp: Long) {
        // A persisted anchor far ahead of the wall clock (from a corrupt record parsed by an
        // older SDK) would make every fetch return empty until real time catches up — pulling
        // it back to now re-opens the window immediately. Anchors within the skew allowance
        // are honored: they come from legitimate small band-clock skew, and lowering them
        // would make the band re-deliver the overlap on every sync.
        passiveHeartRateTimestamp = SyncTimestamp(lastBlockTimestamp = recoverAnchor(lastBlockTimestamp))
        heartRateList.clear()
        maxDeliveredTimestamp = 0L
    }

    private fun recoverAnchor(anchor: Long): Long {
        return if (anchor > System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS) System.currentTimeMillis() else anchor
    }

    fun setIsNextPage(nextPage: Boolean) {
        this.nextPage = nextPage
    }

    override fun getId(): Byte = 0x55.toByte()

    override fun errorId(): Byte = 0xD5.toByte()

    override fun bytesToWrite(): ByteArray {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        calendar.timeInMillis = passiveHeartRateTimestamp.lastBlockTimestamp

        return createCommandBytes {
            this[1] = if (nextPage) NEXT_PAGE_FLAG else FIRST_PAGE_FLAG
            calendar.writeBcdTimeToArray(this, TIMESTAMP_START_INDEX)
        }
    }

    @Synchronized
    override fun read(data: ByteArray): HeartRateData {
        log(TAG, "Passive heart rate data ${data.contentToString()}")

        val recordCount = data.size / RECORD_SIZE
        if (recordCount == 0) {
            return createHeartRateData(isEndOfData = true, hasMoreData = false)
        }

        for (i in 0 until recordCount) {
            // A corrupted record (invalid BCD or impossible date) is skipped, not fatal —
            // aborting here would lose the rest of the page and stall the transfer.
            val heartRateRecord = parseHeartRateRecord(data, i)
            if (heartRateRecord == null) {
                log(TAG, "Skipping unparseable passive heart rate record at offset ${i * RECORD_SIZE}")
                continue
            }
            processHeartRateRecord(heartRateRecord)

            if (shouldReturnPage(heartRateRecord.dataNumber)) {
                return createHeartRateData(isEndOfData = true, hasMoreData = heartRateRecord.timeInMilliseconds > passiveHeartRateTimestamp.lastBlockTimestamp)
            }
        }

        val endOfData = isEndOfData(data)
        return createHeartRateData(isEndOfData = endOfData, hasMoreData = !endOfData)
    }

    private fun parseHeartRateRecord(data: ByteArray, recordIndex: Int): PassiveHeartRateRecord? {
        val offset = recordIndex * RECORD_SIZE
        val dataNumber = data.toIntLE(DATA_NUMBER_OFFSET + offset, 2)
        val bcdTime = data.toBcdTimeOrNull(BCD_TIME_OFFSET + offset) ?: return null
        val heartRate = data[HEART_RATE_OFFSET + offset].toPositionedInt(0)
        val timeInSeconds = bcdTime.toEpochMilliSecondsOrNull() ?: return null

        return PassiveHeartRateRecord(dataNumber, bcdTime, heartRate, timeInSeconds, offset)
    }

    private fun processHeartRateRecord(record: PassiveHeartRateRecord) {
        if (shouldAddHeartRate(record.heartRate, record.timeInMilliseconds)) {
            heartRateList.add(HeartRate(record.timeInMilliseconds, record.heartRate))
            maxDeliveredTimestamp = maxOf(maxDeliveredTimestamp, record.timeInMilliseconds)
        }
        logHeartRateRecord(record)
    }

    // 0xFF (255) is the firmware "end of activity / no data" sentinel — never a real BPM (QA-207).
    // A sample stamped beyond the skew allowance is dropped for now rather than delivered:
    // delivering it would either poison the anchor or, with a clamped anchor, be re-uploaded
    // on every sync; it is re-fetched once the wall clock passes it.
    private fun shouldAddHeartRate(heartRate: Int, timestamp: Long): Boolean {
        return heartRate > 0 &&
                heartRate != 255 &&
                timestamp > passiveHeartRateTimestamp.lastBlockTimestamp &&
                timestamp <= System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS
    }

    private fun logHeartRateRecord(record: PassiveHeartRateRecord) {
        log(TAG, "Data Number: ${record.dataNumber}, Date: ${record.bcdTime.toDateString()}, " +
                "Heart Rate: ${record.heartRate}")
    }

    private fun shouldReturnPage(dataNumber: Int): Boolean {
        return (dataNumber + 1) % PAGE_SIZE == 0
    }

    /**
     * Snapshot of the samples accumulated so far together with the matching sync anchor.
     * List and anchor are latched under the same lock, so a frame parsed after this
     * snapshot can never advance the anchor past samples missing from the list.
     */
    private fun createHeartRateData(isEndOfData: Boolean, hasMoreData: Boolean): HeartRateData {
        return HeartRateData(
            isEndOfData = isEndOfData,
            hasMoreData = hasMoreData,
            heartRates = ArrayList(heartRateList),
            lastBlockTimestamp = currentAnchor()
        )
    }

    private fun isEndOfData(data: ByteArray): Boolean {
        return data.lastOrNull() == END_OF_DATA_MARKER
    }

    /** Ends the transfer with whatever was received so far (band error, silence, disconnect). */
    @Synchronized
    fun snapshotEnd(): HeartRateData {
        return createHeartRateData(isEndOfData = true, hasMoreData = false)
    }

    /**
     * Anchor for the next sync: the newest sample delivered this sync, falling back to the
     * previous anchor when nothing was delivered. Matching iOS, a truncated transfer
     * continues from the newest delivered sample — its undelivered remainder is re-fetched
     * by the next sync. The clamp is a backstop; delivery already filters future samples.
     */
    private fun currentAnchor(): Long {
        val anchor = maxOf(passiveHeartRateTimestamp.lastBlockTimestamp, maxDeliveredTimestamp)
        return minOf(anchor, System.currentTimeMillis() + MAX_ANCHOR_SKEW_MS)
    }
}
