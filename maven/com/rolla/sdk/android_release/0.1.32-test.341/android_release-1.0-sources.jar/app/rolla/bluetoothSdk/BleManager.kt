package app.rolla.bluetoothSdk

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import androidx.annotation.RequiresPermission
import androidx.core.content.ContextCompat
import app.rolla.bluetoothSdk.connect.BleConnector
import app.rolla.bluetoothSdk.device.DeviceConnectionState
import app.rolla.bluetoothSdk.device.DeviceType
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceManager
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.ActivityAlreadyInProgressOrStarting
import app.rolla.bluetoothSdk.result.error.ActivityNotStarted
import app.rolla.bluetoothSdk.result.error.BluetoothAdapterNull
import app.rolla.bluetoothSdk.result.error.BluetoothNotEnabled
import app.rolla.bluetoothSdk.result.error.BluetoothNotSupported
import app.rolla.bluetoothSdk.result.error.DeviceNotFound
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.OtaAlreadyInProgress
import app.rolla.bluetoothSdk.scan.manager.ScanManager
import app.rolla.bluetoothSdk.scan.state.ScanState
import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.characteristics.data.ActivityControlData
import app.rolla.bluetoothSdk.characteristics.data.BatteryLevelData
import app.rolla.bluetoothSdk.characteristics.data.FactoryResetData
import app.rolla.bluetoothSdk.characteristics.data.FirmwareRevisionData
import app.rolla.bluetoothSdk.characteristics.data.FirmwareStateData
import app.rolla.bluetoothSdk.characteristics.data.HeartRateData
import app.rolla.bluetoothSdk.characteristics.data.HeartRateMeasurementData
import app.rolla.bluetoothSdk.characteristics.data.HrvData
import app.rolla.bluetoothSdk.characteristics.data.MotionData
import app.rolla.bluetoothSdk.characteristics.data.RunningSpeedCadenceData
import app.rolla.bluetoothSdk.characteristics.data.SerialNumberData
import app.rolla.bluetoothSdk.characteristics.data.SleepData
import app.rolla.bluetoothSdk.characteristics.data.StepsData
import app.rolla.bluetoothSdk.characteristics.data.TotalHeartRateData
import app.rolla.bluetoothSdk.characteristics.data.UserData
import app.rolla.bluetoothSdk.commands.Command
import app.rolla.bluetoothSdk.commands.data.ActivityMode
import app.rolla.bluetoothSdk.commands.data.ActivityType
import app.rolla.bluetoothSdk.commands.data.ChargingState
import app.rolla.bluetoothSdk.commands.data.FirmwareState
import app.rolla.bluetoothSdk.commands.data.HeartRate
import app.rolla.bluetoothSdk.commands.data.UserInfo
import app.rolla.bluetoothSdk.result.error.AutoConnectFailed
import app.rolla.bluetoothSdk.result.error.UnknownError
import app.rolla.bluetoothSdk.utils.crcValue
import app.rolla.bluetoothSdk.utils.log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import no.nordicsemi.android.dfu.DfuBaseService
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

/**
 * Main entry point for the Bluetooth SDK, providing high-level access to Bluetooth functionality.
 * Manages BLE scanning and device discovery through a unified interface.
 */
@Singleton
@SuppressLint("MissingPermission")
class BleManager @Inject constructor(
    @param:ApplicationContext private val context: Context,
    private val bluetoothAdapter: BluetoothAdapter?,
    private val scanManager: ScanManager,
    private val bleConnector: BleConnector,
    private val deviceManager: DeviceManager,
    private val bleRegistry: BleRegistry,
    @BleScopeContext bleScopeContext: CoroutineContext
) {
    companion object {
        private const val TAG = "BleManager"

        // Heart-rate history is a multi-packet notification stream with no per-packet ack;
        // 20 s of band silence (2x the iOS per-block timeout) means the transfer is dead and
        // the sync must finish with whatever arrived instead of waiting forever.
        private const val HR_SYNC_INACTIVITY_TIMEOUT_MS = 20_000L
        private const val HR_SYNC_WATCHDOG_POLL_MS = 5_000L
    }

    private val managerScope = CoroutineScope(bleScopeContext + SupervisorJob())

    private enum class HrSyncPhase { PASSIVE, ACTIVITY }

    private val hrSyncPhase = ConcurrentHashMap<String, HrSyncPhase>()
    private val hrPhaseStartedAt = ConcurrentHashMap<String, Long>()
    private val hrSyncWatchdogs = ConcurrentHashMap<String, Job>()
    // The passive anchor latched with the snapshot that ended the passive phase, held
    // until the activity phase finishes and the combined result is emitted.
    private val hrPassiveAnchor = ConcurrentHashMap<String, Long>()

    val scanStateFlow: StateFlow<ScanState>? get() = scanManager.scanState
    val connectionStateChanges: SharedFlow<Pair<String, DeviceConnectionState>> get() = deviceManager.connectionStateChanges

    private val _bleStateFlow = MutableSharedFlow<Int>(replay = 1)
    val bleStateFlow: SharedFlow<Int> = _bleStateFlow.asSharedFlow()

    fun enableRawCaptureMode() {
        bleRegistry.getRollaBandImpl().enableRawCaptureMode()
    }

    fun disableRawCaptureMode() {
        bleRegistry.getRollaBandImpl().disableRawCaptureMode()
    }

    fun getRawNotificationFlow(): SharedFlow<ByteArray> {
        return bleRegistry.getRollaBandImpl().rawNotificationFlow
    }

    fun writeCustomCommand(uuid: String, commandByte: Byte, isNextPage: Boolean): MethodResult {
        val customCommand = object : Command<ByteArray> {
            override fun getId(): Byte = commandByte
            override fun bytesToWrite(): ByteArray = createCommandBytes {
                this[1] = if (isNextPage) 0x02.toByte() else 0x00.toByte()
            }
            override fun read(data: ByteArray): ByteArray = data
        }
        return readRollaBandCommand(uuid, customCommand)
    }

    private val stateChangeReceiver = object : BroadcastReceiver() {

        override fun onReceive(context: Context?, intent: Intent?) {
            if (BluetoothAdapter.ACTION_STATE_CHANGED == intent?.action) {
                val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                managerScope.launch {
                    _bleStateFlow.emit(state)
                }
                if (state == BluetoothAdapter.STATE_ON) {

                } else if (state == BluetoothAdapter.STATE_OFF) {
                    managerScope.launch {
                        scanManager.stopScan()
                    }
                    bleConnector.disconnectAll()
                }
            }
        }
    }

    init {
        collectFirmwareRevisionFlow()
        collectHeartRatePackages()
        collectFirmwareUpdate()
        collectFirmwareCompleted()
        collectConnectionStateChanges()
        collectSteps()
        collectHrv()
        collectPassiveHeartRate()
        collectActivityHeartRate()
        collectSleep()
        collectMotionData()
        collectScanResults()
        collectScanErrors()
        collectScanStates()
        ContextCompat.registerReceiver(context, stateChangeReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    /**
     * Starts scanning for devices of the specified types.
     *
     * @param deviceTypes Set of device types to scan for
     * @return MethodResult of the scan start operation
     *
     * As error, it can return:
     *  - BleScannerNotAvailableException if BLE scanner is not available
     *  - BluetoothNotAvailableException if bluetooth is not available
     *  - BluetoothNotEnabledException if bluetooth is not enabled
     *  - BluetoothNotSupported if bluetooth is not supported
     */
    suspend fun startScan(deviceTypes: Set<DeviceType>): MethodResult {
        val result = checkBluetoothAvailable()
        if (result != null) {
            return result
        }
        log(TAG, "Starting scan for device types: ${deviceTypes.joinToString()}")

        // Set device types filter in device manager
        deviceManager.setAllowedDeviceTypes(deviceTypes)

        // Get UUIDs to scan for from device types
        val scanUuids = bleRegistry.getScanningServicesForDeviceTypes(deviceTypes)
        return scanManager.startScan(scanUuids.toList())
    }

    /**
     * Stops the current scan operation.
     *
     * @return MethodResult of the scan stop operation
     *
     * As error, it can return:
     *  - BleScannerNotAvailableException if BLE scanner is not available
     *  - BluetoothNotAvailableException if bluetooth is not available
     *  - BluetoothNotEnabledException if bluetooth is not enabled
     *  - BluetoothNotSupported if bluetooth is not supported
     */
    suspend fun stopScan(): MethodResult {
        val result = checkBluetoothAvailable()
        if (result != null) {
            return result
        }
        log(TAG, "Stopping scan")
        return scanManager.stopScan()
    }

    /**
     * Gets all discovered devices, sorted by signal strength.
     *
     * @return List of all discovered devices
     *
     */
    fun getAllScannedDevices(): List<BleDevice> {
        return deviceManager.getAllDevicesSorted()
    }

    /**
     * Gets devices of a specific type, sorted by signal strength.
     *
     * @param deviceType The device type to filter by
     * @return List of devices matching the specified type
     *
     */
    fun getDevicesByType(deviceType: DeviceType): List<BleDevice> {
        return deviceManager.getDevicesByType(deviceType)
    }

    /**
     * Sets the duration for scan operations.
     *
     * @param scanDurationMs The scan duration in milliseconds
     * @return MethodResult of the operation
     *
     * As error, it can return:
     *  - InvalidParameterException if scan duration is invalid
     */
    fun setScanDuration(scanDurationMs: Long): MethodResult {
        log(TAG, "Setting scan duration to $scanDurationMs ms")
        return scanManager.setScanDuration(scanDurationMs)
    }

    /**
     * The device-type filter currently applied to scan results. [startScan] sets
     * it from its own argument, and periodic rescans reuse it, so a caller that
     * scans for one narrow type can capture this first and restore it afterwards
     * rather than leaving every later scan narrowed to that type.
     */
    fun getAllowedDeviceTypes(): Set<DeviceType> = deviceManager.getAllowedDeviceTypes()

    /**
     * Restores a device-type filter captured from [getAllowedDeviceTypes].
     */
    fun setAllowedDeviceTypes(deviceTypes: Set<DeviceType>) {
        log(TAG, "Restoring allowed device types: ${deviceTypes.joinToString()}")
        deviceManager.setAllowedDeviceTypes(deviceTypes)
    }

    /**
     * Clears all discovered devices.
     *
     * @return MethodResult of the operation
     *
     */
    fun clearScannedDevices(): MethodResult {
        log(TAG, "Clearing all discovered devices")

        deviceManager.clearDevices()
        return MethodResult(true)
    }

    /**
     * Removes disconnected discoveries for [includeTypes], keeping connected
     * devices and any matching [excludeTypes] (e.g. Rolla Band while scanning
     * for standalone heart-rate monitors).
     */
    fun clearDisconnectedScannedDevices(
        includeTypes: Set<DeviceType>,
        excludeTypes: Set<DeviceType> = emptySet()
    ): MethodResult {
        log(
            TAG,
            "Clearing disconnected scanned devices: include=${includeTypes.joinToString()}, " +
                "exclude=${excludeTypes.joinToString()}"
        )
        deviceManager.clearDisconnectedScannedDevices(includeTypes, excludeTypes)
        return MethodResult(true)
    }

    fun connectToBleDevice(macAddress: String, deviceTypesForSubscribe: Set<DeviceType>? = null): MethodResult {
        val result = checkBluetoothAvailable()
        if (result != null) {
            return result
        }
        log(TAG, "Start connecting to device with mac address: $macAddress, subscribe for all device types")
        var bleDevice = deviceManager.getDevice(macAddress)
        if (bleDevice == null) {
            val remoteDevice = bluetoothAdapter?.getRemoteDevice(macAddress)
            log("BleManager", "Device: ${remoteDevice?.address}")
            if (remoteDevice != null) {
                val deviceTypes = deviceTypesForSubscribe ?: setOf(
                    DeviceType.ROLLA_BAND,
                    DeviceType.HEART_RATE,
                    DeviceType.RUNNING_SPEED_AND_CADENCE
                )
                bleDevice = BleDevice(
                    btDevice = remoteDevice,
                    discoveredServiceUuids = emptyList(),
                    rssi = 0,
                    scannedDeviceTypes = deviceTypes
                )
            } else {
                return MethodResult(
                    false,
                    DeviceNotFound()
                )
            }
        }
        if (bleDevice.getBluetoothDeviceType(context) == 0) {
            return MethodResult(false, AutoConnectFailed())
        }
        // A Rolla Band advertises the heart rate and running speed/cadence
        // services next to its own, so connecting for every type it advertises
        // would reserve those two generic roles as well and lock out standalone
        // sensors (a chest strap, a footpod) for as long as the band is
        // connected. The band type's own service set already covers all three
        // services, so asking for ROLLA_BAND alone subscribes to exactly the
        // same characteristics.
        val requestedDeviceTypes = deviceTypesForSubscribe
            ?: if (bleDevice.hasDeviceType(DeviceType.ROLLA_BAND)) {
                setOf(DeviceType.ROLLA_BAND)
            } else {
                bleDevice.scannedDeviceTypes
            }
        return bleConnector.connectToDevice(bleDevice, requestedDeviceTypes)
    }

    fun disconnectFromDevice(macAddress: String): MethodResult {
        val result = checkBluetoothAvailable()
        if (result != null) {
            return result
        }
        val bleDevice = deviceManager.getDevice(macAddress) ?: return MethodResult(false, DeviceNotFound())
        log(TAG, "Start disconnecting all device types from: $macAddress")

        return bleConnector.disconnectFromDevice(bleDevice, bleDevice.scannedDeviceTypes)
    }


    fun disconnectFromDevice(bleDevice: BleDevice, deviceTypesForUnsubscribe: Set<DeviceType>): MethodResult {
        val result = checkBluetoothAvailable()
        if (result != null) {
            return result
        }

        return bleConnector.disconnectFromDevice(bleDevice, deviceTypesForUnsubscribe)
    }

    fun getConnectedDevices(): List<BleDevice> = deviceManager.getConnectedDevices()

    fun isDeviceConnected(macAddress: String): Boolean = deviceManager.isConnected(macAddress)

    /**
     * Get connection state for device
     *
     * onSuccess: DeviceConnectionState
     * onError: DeviceNotFound
     */
    fun getConnectionState(macAddress: String, onSuccess: (DeviceConnectionState) -> Unit, onError: (Error) -> Unit) {
        val state = deviceManager.getConnectionState(macAddress)
        if (state == null) {
            onError(DeviceNotFound())
        } else {
            onSuccess(state)
        }
    }

    fun getConnectedDeviceForType(deviceType: DeviceType): BleDevice? = deviceManager.getConnectedDeviceForType(deviceType)

    /**
     * Disconnect all devices
     */
    fun disconnectAll() {
        bleConnector.disconnectAll()
    }

    fun writeCharacteristic(uuid: String, characteristic: Characteristic, data: ByteArray): MethodResult {
        return bleConnector.writeCharacteristic(uuid, characteristic, data) {}
    }

    fun readRollaBandCommand(uuid: String, command: Command<*>): MethodResult {
        return bleConnector.readCharacteristic(uuid, bleRegistry.getRollaBandWriteCharacteristic(), command)
    }

    fun readSerialNumber(uuid: String): MethodResult {
        return bleConnector.readCharacteristic(uuid, bleRegistry.getSerialNumberCharacteristic())
    }

    fun readFirmwareRevision(uuid: String): MethodResult {
        return bleConnector.readCharacteristic(uuid, bleRegistry.getFirmwareRevisionCharacteristic())
    }

    fun readBandBatteryLevel(uuid: String): MethodResult {
        val command = bleRegistry.getRollaBandImpl().batteryLevel
        return readRollaBandCommand(uuid, command)
    }

    fun readBandUserData(uuid: String): MethodResult {
        val command = bleRegistry.getRollaBandImpl().getUserData
        return readRollaBandCommand(uuid, command)
    }

    fun setBandUserData(uuid: String, userInfo: UserInfo): MethodResult {
        val command = bleRegistry.getRollaBandImpl().setUserData
        command.setUserInfo(userInfo)
        bleRegistry.getRunningSpeedAndCadenceCharacteristic().setUserData(
            userInfo.height, userInfo.weight, userInfo.age, userInfo.gender
        )
        return readRollaBandCommand(uuid, command)
    }

    fun factoryReset(uuid: String): MethodResult {
        bleConnector.disableAutoReconnect(uuid)
        val command = bleRegistry.getRollaBandImpl().factoryReset
        return readRollaBandCommand(uuid, command)
    }

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun removeBond(macAddress: String): MethodResult {
        val result = checkBluetoothAvailable()
        if (result != null) {
            return result
        }

        log(TAG, "Attempting to remove bond for device: $macAddress")

        val device = bluetoothAdapter?.getRemoteDevice(macAddress)
            ?: return MethodResult(false, DeviceNotFound())

        return try {
            if (device.bondState != BluetoothDevice.BOND_BONDED) {
                log(TAG, "Device $macAddress is not bonded, nothing to remove")
                return MethodResult(true)
            }

            val method = device.javaClass.getMethod("removeBond")
            val success = method.invoke(device) as? Boolean ?: false

            if (success) {
                log(TAG, "Successfully initiated bond removal for device: $macAddress")
            } else {
                log(TAG, "Failed to remove bond for device: $macAddress")
            }

            MethodResult(success)
        } catch (e: Exception) {
            log(TAG, "Exception while removing bond for device $macAddress: ${e.message}")
            MethodResult(false, UnknownError(e))
        }
    }

    fun startBandActivity(uuid: String, activityType: ActivityType): MethodResult {
        val command = bleRegistry.getRollaBandImpl().activityControl
        command.setActivityType(activityType)
        command.setActivityMode(ActivityMode.START)
        val canStart = bleRegistry.getRollaBandImpl().canStartActivity()
        if (!canStart) {
            return MethodResult(false, ActivityAlreadyInProgressOrStarting())
        }
        val readCommand = readRollaBandCommand(uuid, command)
        if (readCommand.successful) {
            bleRegistry.getRollaBandImpl().setStartingStatus()
        }
        return readCommand
    }

    fun stopBandActivity(uuid: String, activityType: ActivityType): MethodResult {
        val command = bleRegistry.getRollaBandImpl().activityControl
        command.setActivityType(activityType)
        command.setActivityMode(ActivityMode.STOP)
        val isStarted = bleRegistry.getRollaBandImpl().isActivityStarted()
        if (isStarted) {
            val readCommand = readRollaBandCommand(uuid, command)
            if (readCommand.successful) {
                bleRegistry.getRollaBandImpl().setFinishingStatus()
            }
            return readCommand
        } else {
            return MethodResult(false, ActivityNotStarted())
        }
    }

    /**
     * Sends a stop command to the band bypassing the [isActivityStarted] guard.
     * Used for the deferred stop after crash recovery when the native state does not
     * know the band is still in activity mode (because the app restarted).
     */
    fun forceStopBandActivity(uuid: String, activityType: ActivityType): MethodResult {
        val command = bleRegistry.getRollaBandImpl().activityControl
        command.setActivityType(activityType)
        command.setActivityMode(ActivityMode.STOP)
        val readCommand = readRollaBandCommand(uuid, command)
        if (readCommand.successful) {
            bleRegistry.getRollaBandImpl().setFinishingStatus()
        }
        return readCommand
    }

    /**
     * Sets the activity-restore-pending flag on the native band implementation.
     * While pending, auto-stop triggers (HR packages, post-subscription params) are suppressed.
     */
    fun setActivityRestorePending(pending: Boolean) {
        bleRegistry.getRollaBandImpl().activityRestorePending = pending
    }

    /**
     * Returns the MAC address of the currently connected Rolla Band, or null if none is connected.
     */
    fun getConnectedBandUuid(): String? {
        return getConnectedDeviceForType(DeviceType.ROLLA_BAND)?.getMacAddress()
    }

    /**
     * Syncs native state to "in activity" after the user chooses to resume a
     * crash-interrupted activity, and updates the band wristband params accordingly.
     */
    fun markBandActivityAsActive(uuid: String) {
        bleRegistry.getRollaBandImpl().markActivityAsActive()
        setBandWristbandParams(uuid, true)
    }

    fun startBandOtaUpdate(
        url: String,
        uuid: String,
        dfuServiceClass: Class<out DfuBaseService>
    ): MethodResult {
        if (bleRegistry.getRollaBandImpl().isOtaStarted()) {
            return MethodResult(false, OtaAlreadyInProgress())
        }

        bleConnector.disableAutoReconnect(uuid)
        bleRegistry.getRollaBandImpl().setFirmwareStateStarted(uuid)

        val command = bleRegistry.getRollaBandImpl().otaUpdate
        bleRegistry.getRollaBandImpl().setOtaUrl(url)
        bleRegistry.getRollaBandImpl().setDfuServiceClass(dfuServiceClass)
        log(TAG, "Starting OTA update for $uuid")
        return readRollaBandCommand(uuid, command)
    }

    fun setBandWristbandParams(uuid: String, inActivity: Boolean): MethodResult {
        val command = if (inActivity) {
            bleRegistry.getRollaBandImpl().setWristbandParamsInActivity
        } else {
            bleRegistry.getRollaBandImpl().setWristbandParamsOutsideActivity
        }
        return readRollaBandCommand(uuid, command)
    }

    fun readBandSteps(uuid: String, blockTimestamp: Long, entryTimestamp: Long): MethodResult {
        val command = bleRegistry.getRollaBandImpl().getSteps
        command.setStepTimestamp(blockTimestamp, entryTimestamp)
        command.setIsNextPage(false)
        return readRollaBandCommand(uuid, command)
    }

    private fun readBandStepsNextPage(uuid: String) {
        val command = bleRegistry.getRollaBandImpl().getSteps
        command.setIsNextPage(true)
        readRollaBandCommand(uuid, command)
    }

    fun readBandHrv(uuid: String, blockTimestamp: Long): MethodResult {
        val command = bleRegistry.getRollaBandImpl().getHrv
        command.setHrvTimestamp(blockTimestamp)
        command.setIsNextPage(false)
        return readRollaBandCommand(uuid, command)
    }

    private fun readBandHrvNextPage(uuid: String) {
        val command = bleRegistry.getRollaBandImpl().getHrv
        command.setIsNextPage(true)
        readRollaBandCommand(uuid, command)
    }

    fun readBandSleep(uuid: String, blockTimestamp: Long, entryTimestamp: Long): MethodResult {
        val command = bleRegistry.getRollaBandImpl().getSleep
        command.setSleepTimestamp(blockTimestamp, entryTimestamp)
        command.setIsNextPage(false)
        return readRollaBandCommand(uuid, command)
    }

    private fun readBandSleepNextPage(uuid: String) {
        val command = bleRegistry.getRollaBandImpl().getSleep
        command.setIsNextPage(true)
        readRollaBandCommand(uuid, command)
    }

    fun readBandMotionData(uuid: String, fromTimestamp: Long): MethodResult {
        val command = bleRegistry.getRollaBandImpl().getMotionData
        command.setFromTimestamp(fromTimestamp)
        command.setIsNextPage(false)
        return readRollaBandCommand(uuid, command)
    }

    private fun readBandMotionDataNextPage(uuid: String) {
        val command = bleRegistry.getRollaBandImpl().getMotionData
        command.setIsNextPage(true)
        readRollaBandCommand(uuid, command)
    }

    fun readBandHeartRate(uuid: String, activityBlockTimestamp: Long, activityEntryTimestamp: Long, passiveBlockTimestamp: Long): MethodResult {
        if (hrSyncPhase.containsKey(uuid)) {
            log(TAG, "New heart rate sync requested while a previous chain is still tracked — clearing stale chain state")
            clearHrSyncState(uuid)
        }
        val commandActive = bleRegistry.getRollaBandImpl().getActivityHeartRate
        val commandPassive = bleRegistry.getRollaBandImpl().getPassiveHeartRate
        commandPassive.setHeartRateTimestamp(passiveBlockTimestamp)
        commandActive.setHeartRateTimestamp(activityBlockTimestamp, activityEntryTimestamp)
        hrSyncPhase[uuid] = HrSyncPhase.PASSIVE
        hrPhaseStartedAt[uuid] = System.currentTimeMillis()
        val result = readBandPassiveHeartRate(uuid)
        if (result.successful) {
            startHrSyncWatchdog(uuid)
        } else {
            clearHrSyncState(uuid)
        }
        return result
    }

    fun readBandPassiveHeartRate(uuid: String): MethodResult {
        val commandPassive = bleRegistry.getRollaBandImpl().getPassiveHeartRate
        commandPassive.setIsNextPage(false)
        return readRollaBandCommand(uuid, commandPassive)
    }

    private fun readBandPassiveHeartRateNextPage(uuid: String) {
        val command = bleRegistry.getRollaBandImpl().getPassiveHeartRate
        command.setIsNextPage(true)
        val result = readRollaBandCommand(uuid, command)
        if (!result.successful) {
            log(TAG, "Passive heart rate next-page request failed — continuing with data received so far")
            advanceToActivityHeartRate(uuid, command.snapshotEnd())
        }
    }

    private fun readBandActivityHeartRate(uuid: String, heartRates: ArrayList<HeartRate>): MethodResult {
        val command = bleRegistry.getRollaBandImpl().getActivityHeartRate
        command.setIsNextPage(false)
        command.setHeartRateList(heartRates)
        return readRollaBandCommand(uuid, command)
    }

    private fun readBandActivityHeartRateNextPage(uuid: String) {
        val command = bleRegistry.getRollaBandImpl().getActivityHeartRate
        command.setIsNextPage(true)
        val result = readRollaBandCommand(uuid, command)
        if (!result.successful) {
            log(TAG, "Activity heart rate next-page request failed — finishing with data received so far")
            finishHeartRateSync(uuid, command.snapshotEnd())
        }
    }

    /**
     * Moves the heart-rate sync from the passive to the activity phase exactly once —
     * the atomic replace makes a racing watchdog and a late passive emission harmless.
     * The passive snapshot's anchor is held until the combined result is emitted.
     */
    private fun advanceToActivityHeartRate(uuid: String, passiveData: HeartRateData) {
        if (!hrSyncPhase.replace(uuid, HrSyncPhase.PASSIVE, HrSyncPhase.ACTIVITY)) return
        hrPassiveAnchor[uuid] = passiveData.lastBlockTimestamp
        hrPhaseStartedAt[uuid] = System.currentTimeMillis()
        val result = readBandActivityHeartRate(uuid, passiveData.heartRates)
        if (!result.successful) {
            log(TAG, "Activity heart rate request failed — finishing with data received so far")
            finishHeartRateSync(uuid, bleRegistry.getRollaBandImpl().getActivityHeartRate.snapshotEnd())
        }
    }

    /**
     * Completes the heart-rate sync exactly once — the atomic remove makes duplicate
     * completion paths (normal end, watchdog, error frame, failed write) emit one result.
     */
    private fun finishHeartRateSync(uuid: String, activityData: HeartRateData) {
        if (hrSyncPhase.remove(uuid) == null) return
        hrPhaseStartedAt.remove(uuid)
        hrSyncWatchdogs.remove(uuid)?.cancel()
        // The anchor is always latched by advanceToActivityHeartRate; the fallback snapshot
        // only guards an unreachable path — the emission must never be skipped, or the
        // sync's callback would sit unresolved until the command timeout.
        val passiveAnchor = hrPassiveAnchor.remove(uuid)
            ?: bleRegistry.getRollaBandImpl().getPassiveHeartRate.snapshotEnd().lastBlockTimestamp
        bleRegistry.getRollaBandImpl().emitHeartRate(
            uuid = uuid,
            heartRates = activityData.heartRates,
            passiveLastBlockTimestamp = passiveAnchor,
            activityLastBlockTimestamp = activityData.lastBlockTimestamp,
            activityLastEntryTimestamp = activityData.lastEntryTimestamp
        )
    }

    private fun clearHrSyncState(uuid: String) {
        hrSyncPhase.remove(uuid)
        hrPhaseStartedAt.remove(uuid)
        hrPassiveAnchor.remove(uuid)
        hrSyncWatchdogs.remove(uuid)?.cancel()
    }

    /**
     * Fallback for a heart-rate transfer that stops emitting notifications (lost packet,
     * band-side stall, disconnect): after [HR_SYNC_INACTIVITY_TIMEOUT_MS] of silence the
     * current phase is force-ended with the data received so far, mirroring the iOS
     * per-block timeout, so the sync always completes and later syncs are never blocked.
     */
    private fun startHrSyncWatchdog(uuid: String) {
        hrSyncWatchdogs.remove(uuid)?.cancel()
        hrSyncWatchdogs[uuid] = managerScope.launch {
            while (isActive && hrSyncPhase.containsKey(uuid)) {
                delay(HR_SYNC_WATCHDOG_POLL_MS)
                val phase = hrSyncPhase[uuid] ?: break
                val phaseStartedAt = hrPhaseStartedAt[uuid] ?: break
                val lastFrameAt = bleRegistry.getRollaBandImpl().lastHeartRateFrameAt(uuid)
                val lastActivityAt = maxOf(phaseStartedAt, lastFrameAt)
                if (System.currentTimeMillis() - lastActivityAt < HR_SYNC_INACTIVITY_TIMEOUT_MS) continue
                log(TAG, "Heart rate sync silent in $phase phase — force-ending with data received so far")
                when (phase) {
                    HrSyncPhase.PASSIVE -> bleRegistry.getRollaBandImpl().forcePassiveHeartRateEnd(uuid)
                    HrSyncPhase.ACTIVITY -> bleRegistry.getRollaBandImpl().forceActivityHeartRateEnd(uuid)
                }
                // The forced emission travels the normal chain; give it a fresh window
                // before judging the next phase silent.
                hrPhaseStartedAt[uuid] = System.currentTimeMillis()
            }
        }
    }

    /**
     * Checks if bluetooth is enabled
     *
     * @return MethodResult with success if bluetooth is enabled or error if not
     */
    fun isBluetoothEnabled(): MethodResult {
        if (!isBluetoothLESupported()) {
            return MethodResult(false, BluetoothNotSupported())
        }
        if (bluetoothAdapter == null) {
            return MethodResult(false, BluetoothAdapterNull())
        }
        return MethodResult(bluetoothAdapter.isEnabled)
    }

    /**
     * Get bluetooth state
     *
     * @return Int representing the state
     */
    fun getBluetoothState(onSuccess: (Int) -> Unit, onError: (Error) -> Unit) {
        if (!isBluetoothLESupported()) {
            onError(BluetoothNotSupported())
            return
        }
        if (bluetoothAdapter == null) {
            onError(BluetoothAdapterNull())
            return
        }
        onSuccess(bluetoothAdapter.state)
    }

    /**
     * Checks if bluetooth is supported on device
     *
     * @return true if it is supported or false if not
     */
    fun isBluetoothLESupported(): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)
    }

    /**
     * Checks if bluetooth is available (enabled and adapter is not null)
     *
     * @return MethodResult with success if bluetooth is available or error if not
     */
    private fun checkBluetoothAvailable(): MethodResult? {
        if (!isBluetoothLESupported()) {
            return MethodResult(false, BluetoothNotSupported())
        }
        if (bluetoothAdapter == null) {
            return MethodResult(false, BluetoothAdapterNull())
        }
        if (!bluetoothAdapter.isEnabled) {
            return MethodResult(false, BluetoothNotEnabled())
        }
        return null
    }

    /**
     * Cleans up resources when the manager is no longer needed.
     * Should be called when the application is shutting down or the manager is no longer needed.
     */
    fun destroy() {
        log(TAG, "Destroying BleManager")

        runCatching {
            managerScope.cancel()
            scanManager.destroy()
            deviceManager.destroy()
            bleConnector.destroy()

            // Unregister receiver
            runCatching { context.unregisterReceiver(stateChangeReceiver) }
                .onFailure { log(TAG, "Error unregistering receiver: ${it.message}") }

        }.onFailure {
            log(TAG, "Error during BleManager destruction: ${it.message}")
        }

        log(TAG, "BleManager destroyed successfully")
    }

    // Collect flows
    private fun collectFirmwareRevisionFlow() {
        managerScope.launch {
            bleRegistry.getFirmwareRevisionCharacteristic().dataFlow.collect { firmwareRevisionData ->
                bleRegistry.getRollaBandImpl().setFirmwareVersion(firmwareRevisionData.firmwareVersion)
            }
        }
    }

    private fun collectHeartRatePackages() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().heartRatePackagesFlow.collect { stopData ->
                stopBandActivity(stopData.uuid, ActivityType.RUN)
            }
        }
    }
    private fun collectFirmwareUpdate() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().firmwareUpdateFlow.collect { otaState ->
                log(TAG, "OTA state: $otaState")
                if (otaState.state == FirmwareState.STARTED) {
                    startScan(setOf(DeviceType.ROLLA_BAND))
                } else if (otaState.state == FirmwareState.INTERNAL_STARTED) {
                    stopScan()
                }
            }
        }
    }

    private fun collectFirmwareCompleted() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().firmwareUpdateCompletedFlow.collect { firmwareStateData ->
                log(TAG, "[FIRMWARE] Firmware update completed: $firmwareStateData")

                val originalUuid = firmwareStateData.uuid
                if (originalUuid.isNotEmpty()) {
                    bleConnector.enableAutoReconnect(originalUuid)
                    log(TAG, "[FIRMWARE] Re-enabled auto-reconnect for $originalUuid")
                }

                setScanDuration(60000L)
                startScan(deviceManager.getAllowedDeviceTypes())
            }
        }
    }

    private fun collectConnectionStateChanges() {
        managerScope.launch {
            connectionStateChanges.collect { event ->
                if (event.second == DeviceConnectionState.CONNECTED) {
                    val bleDevice = deviceManager.getDevice(event.first)
                    bleRegistry.onDeviceConnected(bleDevice?.gatt, bleDevice?.getSubscribedTypes() ?: emptySet())
                }
            }
        }
    }
    private fun collectSteps() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().stepsFlow.collect { stepsData ->
                log(TAG, "Steps data: $stepsData")
                if (stepsData.hasMoreData && stepsData.isEndOfData) {
                    log(TAG, "Reading next page of steps data")
                    readBandStepsNextPage(stepsData.uuid)
                }
            }
        }
    }
    private fun collectHrv() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().hrvFlow.collect { hrvData ->
                log(TAG, "HRV data: $hrvData")
                if (hrvData.hasMoreData && hrvData.isEndOfData) {
                    log(TAG, "Reading next page of hrv data")
                    readBandHrvNextPage(hrvData.uuid)
                }
            }
        }
    }
    private fun collectPassiveHeartRate() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().passiveHeartRateFlow.collect { heartRateData ->
                // The collector must outlive any single bad emission — an uncaught throw
                // here would kill heart rate syncing for the rest of the process.
                runCatching {
                    log(TAG, "Passive heart rate data: $heartRateData")
                    // A late emission from an already-ended phase (stale page, replayed flow
                    // value) must not restart the chain and desync the protocol.
                    if (hrSyncPhase[heartRateData.uuid] != HrSyncPhase.PASSIVE) {
                        log(TAG, "Ignoring passive heart rate emission outside the passive phase")
                        return@runCatching
                    }
                    if (heartRateData.hasMoreData && heartRateData.isEndOfData) {
                        log(TAG, "Reading next page of passive heart rate data")
                        readBandPassiveHeartRateNextPage(heartRateData.uuid)
                    } else {
                        advanceToActivityHeartRate(heartRateData.uuid, heartRateData)
                    }
                }.onFailure { log(TAG, "Passive heart rate handling failed: ${it.message}") }
            }
        }
    }
    private fun collectActivityHeartRate() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().activityHeartRateFlow.collect { heartRateData ->
                runCatching {
                    log(TAG, "Activity heart rate data: $heartRateData")
                    if (hrSyncPhase[heartRateData.uuid] != HrSyncPhase.ACTIVITY) {
                        log(TAG, "Ignoring activity heart rate emission outside the activity phase")
                        return@runCatching
                    }
                    if (heartRateData.hasMoreData && heartRateData.isEndOfData) {
                        log(TAG, "Reading next page of activity heart rate data")
                        readBandActivityHeartRateNextPage(heartRateData.uuid)
                    } else {
                        finishHeartRateSync(heartRateData.uuid, heartRateData)
                    }
                }.onFailure { log(TAG, "Activity heart rate handling failed: ${it.message}") }
            }
        }
    }
    private fun collectSleep() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().sleepFlow.collect { sleepData ->
                log(TAG, "Sleep data: $sleepData")
                if (sleepData.hasMoreData && sleepData.isEndOfData) {
                    log(TAG, "Reading next page of sleep data")
                    readBandSleepNextPage(sleepData.uuid)
                }
            }
        }
    }

    private fun collectMotionData() {
        managerScope.launch {
            bleRegistry.getRollaBandImpl().motionDataFlow.collect { motionData ->
                log(TAG, "Motion data: $motionData")
                if (motionData.hasMoreData && motionData.isEndOfData) {
                    log(TAG, "Reading next page of motion data")
                    readBandMotionDataNextPage(motionData.uuid)
                }
            }
        }
    }

    private fun collectScanResults() {
        scanManager.scanResults
            .onEach { device ->
                val serviceUuids = device.getDiscoveredServiceUuidsAsStringList()
                if (serviceUuids.find { uuid -> uuid == bleRegistry.deviceFirmwareUpdateService.uuid} != null) {
                    bleRegistry.getRollaBandImpl().startInternalUpdate(device)
                } else {
                    val detectedTypes = bleRegistry.determineDeviceTypes(serviceUuids)
                    deviceManager.processScannedDevice(device, detectedTypes)
                }
            }.launchIn(managerScope)
    }

    private fun collectScanErrors() {
        scanManager.scanErrors
            .onEach { error ->
                log(TAG, "Scan error: ${error.message}")
            }.launchIn(managerScope)
    }

    private fun collectScanStates() {
        scanManager.scanState
            .onEach { state ->
                when (state) {
                    is ScanState.Scanning -> log(TAG, "Scan started")
                    is ScanState.Idle -> log(TAG, "Scan stopped")
                    is ScanState.Stopped -> log(TAG, "Scan stopped")
                    is ScanState.Failed -> log(TAG, "Scan failed with error code: ${state.errorCode}")
                }
            }.launchIn(managerScope)
    }

    // getFlows
    fun getSerialNumberFlow(): SharedFlow<SerialNumberData> = bleRegistry.getSerialNumberCharacteristic().dataFlow
    fun getFirmwareVersionFlow(): SharedFlow<FirmwareRevisionData> = bleRegistry.getFirmwareRevisionCharacteristic().dataFlow
    fun getHeartRateFlow(): SharedFlow<HeartRateMeasurementData> = bleRegistry.getHeartRateCharacteristic().dataFlow
    fun getRunningSpeedCadenceFlow(): SharedFlow<RunningSpeedCadenceData> = bleRegistry.getRunningSpeedAndCadenceCharacteristic().dataFlow
    fun getRollaBandBatteryLevelFlow(): SharedFlow<BatteryLevelData> = bleRegistry.getRollaBandImpl().batteryLevelDataFlow
    fun getRollaBandFactoryResetFlow(): SharedFlow<FactoryResetData> = bleRegistry.getRollaBandImpl().factoryResetFlow
    fun getRollaBandUserDataFlow(): SharedFlow<UserData> = bleRegistry.getRollaBandImpl().userDataFlow
    fun getRollaBandSetUserDataFlow(): SharedFlow<UserData> = bleRegistry.getRollaBandImpl().setUserDataFlow
    fun getRollaBandStartActivityFlow(): SharedFlow<ActivityControlData> = bleRegistry.getRollaBandImpl().startActivityFlow
    fun getRollaBandStopActivityFlow(): SharedFlow<ActivityControlData> = bleRegistry.getRollaBandImpl().stopActivityFlow
    fun getRollaBandFirmwareUpdateProgressFlow(): SharedFlow<Int> = bleRegistry.getRollaBandImpl().firmwareUpdateProgressFlow
    fun getRollaBandFirmwareUpdateErrorFlow(): SharedFlow<String> = bleRegistry.getRollaBandImpl().firmwareUpdateErrorFlow
    fun getRollaBandFirmwareUpdateCompletedFlow(): SharedFlow<FirmwareStateData> = bleRegistry.getRollaBandImpl().firmwareUpdateCompletedFlow
    fun getRollaBandFirmwareUpdateStartedFlow(): SharedFlow<FirmwareStateData> = bleRegistry.getRollaBandImpl().firmwareUpdateStartedFlow
    fun getRollaBandChargingStateFlow(): SharedFlow<ChargingState> = bleRegistry.getRollaBandImpl().chargingStateFlow
    fun getRollaBandStepsFlow(): SharedFlow<StepsData> = bleRegistry.getRollaBandImpl().stepsFlow
    fun getRollaBandHrvFlow(): SharedFlow<HrvData> = bleRegistry.getRollaBandImpl().hrvFlow
    fun getRollaBandHeartRateFlow(): SharedFlow<TotalHeartRateData> = bleRegistry.getRollaBandImpl().totalHeartRateFlow
    fun getRollaBandSleepFlow(): SharedFlow<SleepData> = bleRegistry.getRollaBandImpl().sleepFlow
    fun getRollaBandMotionDataFlow(): SharedFlow<MotionData> = bleRegistry.getRollaBandImpl().motionDataFlow
    fun getAllDevicesFlow(): Flow<List<BleDevice>> = deviceManager.devicesFlow
}

