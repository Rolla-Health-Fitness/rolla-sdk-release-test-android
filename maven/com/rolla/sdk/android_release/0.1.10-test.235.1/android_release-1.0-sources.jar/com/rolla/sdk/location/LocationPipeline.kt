package com.rolla.sdk.location

import android.location.Location
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.generated.BandActivityType
import kotlin.math.*

/**
 * GPS processing pipeline — direct port of iOS DefaultLocationDataProcessor
 * from the location-improvements branch.
 *
 * Pipeline flow:
 *   Raw GPS → timestamp validation → GPS gap detection → accuracy/coordinate validation →
 *   calibration → post-calibration warm-up → Gate A (speed) → Gate B (lateral deviation) →
 *   Gate C (course spike) → consecutive rejection handling → stationary detection →
 *   minimum emit distance → EMA smoothing → emit
 */
class LocationPipeline(
    private val activityType: BandActivityType,
    private val config: LocationActivityConfig,
    private val trackingStartTimeMs: Long,
    private val logger: LocationDebugCapture = LocationDebugCapture
) {
    companion object {
        private const val TAG = "LocationPipeline"
    }

    private val calibrationManager = GPSCalibrationManager(config.calibrationConfig)
    private val courseValidator = CourseValidator()
    private val stationaryDetector = StationaryDetector(
        enterSpeedThreshold = config.stationarySpeedEntry,
        requiredSlowReadings = config.stationaryConsecutiveRequired,
        exitSpeedThreshold = config.stationarySpeedExit,
        exitDisplacementThreshold = config.stationaryDisplacementExit
    )

    private var lastAcceptedLocation: Location? = null
    private var lastEmittedLocation: Location? = null
    private var secondLastEmittedLocation: Location? = null
    private var isPostCalibrationWarmUp = false
    private var lastAcceptedTimestampMs: Long = 0L
    private var lastValidGpsWallTimeMs: Long? = null
    private var consecutiveGateRejections = 0

    private var smoothedLat: Double? = null
    private var smoothedLon: Double? = null

    // Debug-capture bookkeeping — all per-session. Populated regardless of
    // whether the capture is enabled, so values are always ready to emit.
    private val sessionStartWallMs: Long = System.currentTimeMillis()
    private var sessionInputCount: Int = 0
    private var sessionEmitCount: Int = 0
    private var sessionWarmupReanchors: Int = 0
    private var sessionRebootstraps: Int = 0
    private var sessionRebootstrapSuppressed: Int = 0
    private val sessionGateRejections: MutableMap<String, Int> =
        linkedMapOf("A" to 0, "B" to 0, "C" to 0, "warmup" to 0)
    private val sessionSuppressCounts: MutableMap<String, Int> = linkedMapOf()
    private var lastInputFixMs: Long? = null
    private var lastEmitMs: Long? = null
    private var lastStationaryState: Boolean = false

    init {
        // Land the config-snapshot event before any fix can arrive so log
        // readers can reconstruct which tunings were active this run.
        emitConfigSnapshot()
    }

    /**
     * Process a raw location through the full pipeline.
     * Returns a smoothed, filtered location or null if rejected at any gate.
     */
    fun processLocation(location: Location): Location? {
        sessionInputCount += 1
        logger.logInput(location)

        val fixMs = location.time
        val dtSec = lastInputFixMs?.let { (fixMs - it) / 1000.0 }
        val dtSinceLastEmit = lastEmitMs?.let { (fixMs - it) / 1000.0 }
        logger.logTimer(
            fixTsMs = fixMs,
            dtSec = dtSec,
            dtSinceLastEmit = dtSinceLastEmit,
            dtSincePendingArm = null,
            dtSinceLastStationary = null
        )
        lastInputFixMs = fixMs

        val timestampMs = location.time

        val nowMs = System.currentTimeMillis()
        if (timestampMs > nowMs + 60_000) {
            log(TAG, "[PIPELINE] Rejected: timestamp >60s in future")
            return suppress(location, "timestamp_future")
        }

        if (timestampMs < trackingStartTimeMs) {
            log(TAG, "[PIPELINE] Rejected: before tracking start")
            return suppress(location, "timestamp_before_start")
        }

        if (lastAcceptedTimestampMs > 0 && timestampMs <= lastAcceptedTimestampMs) {
            log(TAG, "[PIPELINE] Rejected: timestamp regression or duplicate")
            return suppress(location, "timestamp_regression")
        }

        if (lastAcceptedLocation != null) {
            val lastWall = lastValidGpsWallTimeMs
            if (lastWall != null && (nowMs - lastWall) > (config.gapResetThresholdSeconds * 1000).toLong()) {
                val gapSec = (nowMs - lastWall) / 1000
                log(TAG, "[PIPELINE] GPS gap of ${gapSec}s detected — resetting pipeline")
                logger.logState(
                    transition = "gap-reset",
                    details = mapOf("gapSec" to gapSec.toDouble())
                )
                triggerGapReset()
            }
        }

        if (!isValidLocation(location)) {
            return null
        }

        lastValidGpsWallTimeMs = nowMs

        val calibrationResult = calibrationManager.processLocation(location)
        when (calibrationResult) {
            is GPSCalibrationManager.Result.Calibrating -> return suppress(location, "calibrating")

            is GPSCalibrationManager.Result.Calibrated -> {
                if (lastAcceptedLocation == null) {
                    setLastAccepted(calibrationResult.location, "calibration-complete")
                    isPostCalibrationWarmUp = true
                    lastAcceptedTimestampMs = calibrationResult.location.time
                    lastValidGpsWallTimeMs = nowMs
                    log(TAG, "[PIPELINE] Calibration complete — initial anchor, warm-up active")
                    logger.logState(
                        transition = "calibration-complete",
                        details = mapOf(
                            "lat" to calibrationResult.location.latitude,
                            "lon" to calibrationResult.location.longitude,
                            "acc" to if (calibrationResult.location.hasAccuracy())
                                calibrationResult.location.accuracy.toDouble() else null
                        )
                    )
                    return suppress(location, "calibration_bootstrap")
                }
                return applyPipeline(calibrationResult.location)
            }

            is GPSCalibrationManager.Result.Failed -> {
                if (lastAcceptedLocation == null) {
                    setLastAccepted(location, "calibration-failed-bootstrap")
                    isPostCalibrationWarmUp = true
                    lastAcceptedTimestampMs = location.time
                    lastValidGpsWallTimeMs = nowMs
                    log(TAG, "[PIPELINE] Calibration failed — bootstrapping from raw fix, warm-up active")
                    logger.logState(
                        transition = "calibration-failed-bootstrap",
                        details = mapOf("reason" to calibrationResult.reason)
                    )
                    return suppress(location, "calibration_bootstrap")
                }
                return applyPipeline(location)
            }
        }
    }

    fun reset() {
        calibrationManager.reset()
        courseValidator.reset()
        stationaryDetector.reset()
        setLastAccepted(null, "pipeline-reset")
        setLastEmittedPair(null, null, "pipeline-reset")
        setSmoothed(null, null, "pipeline-reset")
        lastAcceptedTimestampMs = 0L
        lastValidGpsWallTimeMs = null
        setConsecutiveRejections(0, "reset")
        isPostCalibrationWarmUp = false
        lastStationaryState = false
    }

    /**
     * Emit the per-session summary line. Callers must invoke this before
     * the underlying log file is closed, so the summary lands as the last
     * line of the JSONL for easy post-hoc triage.
     */
    fun finalizeSession() {
        val durationSec = (System.currentTimeMillis() - sessionStartWallMs) / 1000.0
        logger.logPipelineSummary(
            mapOf(
                "durationSec" to durationSec,
                "inputCount" to sessionInputCount,
                "emitCount" to sessionEmitCount,
                "suppressCountByReason" to sessionSuppressCounts.toMap(),
                "gateRejectionCounts" to sessionGateRejections.toMap(),
                "warmupReanchors" to sessionWarmupReanchors,
                "rebootstraps" to sessionRebootstraps,
                "rebootstrapSuppressed" to sessionRebootstrapSuppressed,
                // Counters for mechanisms not yet ported to Android. Kept
                // in the payload so iOS and Android pipeline-summary lines
                // have the same keys and `jq` scripts work unchanged.
                "warmupTeleportRejections" to 0,
                "pendingArms" to 0,
                "pendingConfirms" to mapOf("speed" to 0, "distance" to 0, "timeout" to 0),
                "stationaryEntryFrozen" to 0,
                "stationaryExitConfirmed" to 0
            )
        )
    }

    private fun triggerGapReset() {
        setLastAccepted(null, "gap-reset")
        setLastEmittedPair(null, null, "gap-reset")
        lastValidGpsWallTimeMs = null
        setConsecutiveRejections(0, "reset")
        isPostCalibrationWarmUp = false
        stationaryDetector.reset()
        courseValidator.reset()
        setSmoothed(null, null, "gap-reset")
        if (config.resetCalibrationOnGap) {
            calibrationManager.reset()
        }
        lastStationaryState = false
    }

    private fun applyPipeline(location: Location): Location? {
        val last = lastAcceptedLocation ?: return null

        if (isPostCalibrationWarmUp) {
            if (location.hasAccuracy() && location.accuracy <= 15f) {
                setLastAccepted(location, "warmup-reanchor")
                lastAcceptedTimestampMs = location.time
                isPostCalibrationWarmUp = false
                sessionWarmupReanchors += 1
                log(TAG, "[PIPELINE] Warm-up re-anchor: replaced centroid with ${String.format("%.1f", location.accuracy)}m-accuracy fix")
                logger.logState(
                    transition = "warm-up-reanchor",
                    details = mapOf("acc" to location.accuracy.toDouble())
                )
                logger.logGate(
                    gate = "warmup",
                    passed = true,
                    reason = "pass",
                    inputs = mapOf("acc" to location.accuracy.toDouble()),
                    fixTsMs = location.time
                )
                return suppress(location, "warmup_reanchor")
            } else {
                logger.logGate(
                    gate = "warmup",
                    passed = false,
                    reason = "warmup_awaiting_accuracy",
                    inputs = mapOf(
                        "acc" to if (location.hasAccuracy()) location.accuracy.toDouble() else null
                    ),
                    fixTsMs = location.time
                )
            }
        }

        val dtMs = location.time - last.time
        if (dtMs <= 0) {
            log(TAG, "[PIPELINE] Rejected: non-positive dt in pipeline")
            return suppress(location, "dt_non_positive")
        }

        val dtSeconds = dtMs / 1000.0
        val distance = distanceMeters(last.latitude, last.longitude, location.latitude, location.longitude)
        val impliedSpeed = distance / dtSeconds

        // Gate A: Speed validation
        val gateAInputs = mapOf(
            "impliedSpeedMps" to impliedSpeed,
            "maxSpeedMps" to config.maxSpeedMps,
            "distanceM" to distance,
            "dtSec" to dtSeconds
        )
        if (impliedSpeed > config.maxSpeedMps) {
            bumpGateRejection("A")
            logger.logGate(
                gate = "A",
                passed = false,
                reason = "gate_a_speed",
                inputs = gateAInputs,
                fixTsMs = location.time
            )
            log(TAG, "[GATE A] Rejected: implied ${String.format("%.1f", impliedSpeed)}m/s " +
                    "> max ${String.format("%.1f", config.maxSpeedMps)}m/s " +
                    "[rejection #$consecutiveGateRejections]")
            checkConsecutiveRejectionsForRebootstrap()
            return suppress(location, "gate_a_speed")
        }
        logger.logGate(
            gate = "A",
            passed = true,
            reason = "pass",
            inputs = gateAInputs,
            fixTsMs = location.time
        )

        // Gate B: Lateral deviation
        val prevEmit = lastEmittedLocation
        val prev2Emit = secondLastEmittedLocation
        if (prevEmit != null && prev2Emit != null) {
            val emitDtMs = location.time - prevEmit.time
            val emitDtSeconds = emitDtMs / 1000.0
            if (emitDtSeconds > 0 && emitDtSeconds < 5.0) {
                val lateralDev = perpendicularDistance(
                    pointLat = location.latitude, pointLon = location.longitude,
                    lineStartLat = prev2Emit.latitude, lineStartLon = prev2Emit.longitude,
                    lineEndLat = prevEmit.latitude, lineEndLon = prevEmit.longitude
                )
                val lateralThreshold = maxOf(5.0, location.accuracy * 0.7)
                val gateBInputs = mapOf(
                    "lateralDevM" to lateralDev,
                    "thresholdM" to lateralThreshold,
                    "emitDtSec" to emitDtSeconds,
                    "acc" to location.accuracy.toDouble()
                )
                if (lateralDev > lateralThreshold) {
                    bumpGateRejection("B")
                    logger.logGate(
                        gate = "B",
                        passed = false,
                        reason = "gate_b_lateral",
                        inputs = gateBInputs,
                        fixTsMs = location.time
                    )
                    log(TAG, "[GATE B] Rejected: lateral deviation ${String.format("%.1f", lateralDev)}m " +
                            "> threshold ${String.format("%.1f", lateralThreshold)}m " +
                            "[rejection #$consecutiveGateRejections]")
                    checkConsecutiveRejectionsForRebootstrap()
                    return suppress(location, "gate_b_lateral")
                }
                logger.logGate(
                    gate = "B",
                    passed = true,
                    reason = "pass",
                    inputs = gateBInputs,
                    fixTsMs = location.time
                )
            }
        }

        // Gate C: Course spike detection
        if (!courseValidator.validate(location)) {
            bumpGateRejection("C")
            logger.logGate(
                gate = "C",
                passed = false,
                reason = "gate_c_course",
                inputs = mapOf(
                    "course" to if (location.hasBearing()) location.bearing.toDouble() else null,
                    "spd" to if (location.hasSpeed()) location.speed.toDouble() else null
                ),
                fixTsMs = location.time
            )
            log(TAG, "[GATE C] Rejected: course spike [rejection #$consecutiveGateRejections]")
            checkConsecutiveRejectionsForRebootstrap()
            return suppress(location, "gate_c_course")
        }
        logger.logGate(
            gate = "C",
            passed = true,
            reason = "pass",
            inputs = mapOf(
                "course" to if (location.hasBearing()) location.bearing.toDouble() else null,
                "spd" to if (location.hasSpeed()) location.speed.toDouble() else null
            ),
            fixTsMs = location.time
        )

        setConsecutiveRejections(0, "reset")

        // Stationary detection
        val hasDoppler = location.hasSpeed() && location.speed >= 0
        stationaryDetector.addPosition(location.latitude, location.longitude, location.time)

        val wasStationary = stationaryDetector.isStationary
        val update = if (hasDoppler) {
            stationaryDetector.update(location.speed.toDouble())
        } else {
            stationaryDetector.checkDisplacementStationary()
        }
        val isStationary = update.isStationary

        logger.logStationaryDetail(
            speed = if (hasDoppler) location.speed.toDouble() else Double.NaN,
            displacement = update.displacement,
            consecutiveSlowReadings = stationaryDetector.consecutiveSlowReadings,
            isStationary = isStationary,
            isPendingStationary = stationaryDetector.isPendingStationary,
            ruleFired = update.ruleFired,
            fixTsMs = location.time
        )

        if (wasStationary != isStationary) {
            val transition = if (isStationary) "stationary-entered" else "stationary-exited"
            logger.logState(
                transition = transition,
                details = mapOf("ruleFired" to update.ruleFired)
            )
            lastStationaryState = isStationary
        }

        if (wasStationary && !isStationary) {
            courseValidator.reset()
            log(TAG, "[PIPELINE] Stationary ended — CourseValidator reset")
        }

        if (isStationary || stationaryDetector.isPendingStationary) {
            setLastAccepted(location, if (isStationary) "stationary-confirmed" else "stationary-pending")
            lastAcceptedTimestampMs = location.time
            val speedStr = if (hasDoppler) String.format("%.2f", location.speed) else "n/a"
            val state = if (isStationary) "confirmed" else "pending"
            log(TAG, "[PIPELINE] Stationary ($state) — suppressed (doppler: ${speedStr}m/s)")
            return suppress(
                location,
                if (isStationary) "stationary_confirmed" else "stationary_pending"
            )
        }

        // Minimum emit distance (accuracy-adaptive)
        val minimumEmitDistance = maxOf(config.minEmitDistanceFloor, minOf(location.accuracy * 0.5, 8.0))
        val distanceFromLastEmit = lastEmittedLocation?.let {
            distanceMeters(it.latitude, it.longitude, location.latitude, location.longitude)
        } ?: Double.MAX_VALUE

        setLastAccepted(location, "post-gate-accept")
        lastAcceptedTimestampMs = location.time

        val emitInputs = mapOf(
            "distanceFromLastEmitM" to (if (distanceFromLastEmit.isFinite()) distanceFromLastEmit else null),
            "minimumEmitDistanceM" to minimumEmitDistance,
            "acc" to location.accuracy.toDouble()
        )
        if (distanceFromLastEmit < minimumEmitDistance) {
            logger.logGate(
                gate = "emit-threshold",
                passed = false,
                reason = "sub_threshold",
                inputs = emitInputs,
                fixTsMs = location.time
            )
            log(TAG, "[PIPELINE] Sub-threshold: ${String.format("%.2f", distanceFromLastEmit)}m " +
                    "< min ${String.format("%.2f", minimumEmitDistance)}m " +
                    "(acc=${String.format("%.1f", location.accuracy)}m)")
            return suppress(location, "sub_threshold")
        }
        logger.logGate(
            gate = "emit-threshold",
            passed = true,
            reason = "pass",
            inputs = emitInputs,
            fixTsMs = location.time
        )

        // EMA smoothing (adaptive alpha based on accuracy)
        val alpha = minOf(config.emaAlphaCap, maxOf(0.2, 5.0 / maxOf(location.accuracy.toDouble(), 1.0)))

        val emitLat: Double
        val emitLon: Double
        val sLat = smoothedLat
        val sLon = smoothedLon
        if (sLat != null && sLon != null) {
            emitLat = alpha * location.latitude + (1.0 - alpha) * sLat
            emitLon = alpha * location.longitude + (1.0 - alpha) * sLon
        } else {
            emitLat = location.latitude
            emitLon = location.longitude
        }
        setSmoothed(emitLat, emitLon, "emit")

        val emitted = Location(location.provider ?: "fused").apply {
            latitude = emitLat
            longitude = emitLon
            altitude = location.altitude
            accuracy = location.accuracy
            time = location.time
            elapsedRealtimeNanos = location.elapsedRealtimeNanos
            if (location.hasSpeed()) speed = location.speed
            if (location.hasBearing()) bearing = location.bearing
        }

        setLastEmittedPair(emitted, lastEmittedLocation, "emit")

        log(TAG, "[PIPELINE] Emitted | ${String.format("%.1f", distanceFromLastEmit)}m, " +
                "alpha=${String.format("%.2f", alpha)}, " +
                "acc=${String.format("%.1f", location.accuracy)}m")
        sessionEmitCount += 1
        lastEmitMs = location.time
        logger.logEmit(emitted)

        return emitted
    }

    private fun checkConsecutiveRejectionsForRebootstrap() {
        if (consecutiveGateRejections >= config.maxConsecutiveRejections) {
            log(TAG, "[PIPELINE] $consecutiveGateRejections consecutive rejections — " +
                    "force-clearing prior for re-bootstrap")
            sessionRebootstraps += 1
            logger.logState(
                transition = "rebootstrap-triggered",
                details = mapOf("consecutiveRejections" to consecutiveGateRejections)
            )
            setLastAccepted(null, "rebootstrap")
            setLastEmittedPair(null, null, "rebootstrap")
            setConsecutiveRejections(0, "rebootstrap")
            stationaryDetector.reset()
            courseValidator.reset()
            setSmoothed(null, null, "rebootstrap")
        }
    }

    private fun isValidLocation(location: Location): Boolean {
        if (!location.hasAccuracy()) {
            log(TAG, "[PIPELINE] Rejected: no accuracy")
            suppress(location, "validation_no_accuracy")
            return false
        }
        val acc = location.accuracy.toDouble()
        if (!acc.isFinite() || acc <= 0) {
            log(TAG, "[PIPELINE] Rejected: accuracy $acc <= 0 or non-finite")
            suppress(location, "validation_accuracy_invalid")
            return false
        }
        if (acc > config.maxAccuracy) {
            log(TAG, "[PIPELINE] Rejected: accuracy ${String.format("%.1f", acc)}m > max ${String.format("%.1f", config.maxAccuracy)}m")
            suppress(location, "validation_accuracy")
            return false
        }
        val lat = location.latitude
        val lon = location.longitude
        if (!lat.isFinite() || !lon.isFinite() || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
            log(TAG, "[PIPELINE] Rejected: coordinate out of valid range")
            suppress(location, "validation_coordinate")
            return false
        }
        if (abs(lat) < 0.001 && abs(lon) < 0.001) {
            log(TAG, "[PIPELINE] Rejected: Null Island (0,0) — GPS chip error state")
            suppress(location, "validation_null_island")
            return false
        }
        return true
    }

    /**
     * Perpendicular distance from a point to the line defined by two previous emissions.
     * Used for Gate B (lateral deviation check).
     * Port of iOS perpendicularDistance() — uses flat-Earth approximation at mid-latitude.
     */
    private fun perpendicularDistance(
        pointLat: Double, pointLon: Double,
        lineStartLat: Double, lineStartLon: Double,
        lineEndLat: Double, lineEndLon: Double
    ): Double {
        val midLat = (lineStartLat + lineEndLat) / 2.0
        val cosLat = cos(Math.toRadians(midLat))
        val metersPerDegreeLat = 111_320.0
        val metersPerDegreeLon = 111_320.0 * cosLat

        val bx = (lineEndLon - lineStartLon) * metersPerDegreeLon
        val by = (lineEndLat - lineStartLat) * metersPerDegreeLat
        val cx = (pointLon - lineStartLon) * metersPerDegreeLon
        val cy = (pointLat - lineStartLat) * metersPerDegreeLat

        val lenSq = bx * bx + by * by
        if (lenSq <= 0.01) {
            return sqrt(cx * cx + cy * cy)
        }

        val t = (cx * bx + cy * by) / lenSq
        val projX = t * bx
        val projY = t * by
        val dx = cx - projX
        val dy = cy - projY

        return sqrt(dx * dx + dy * dy)
    }

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, results)
        return results[0].toDouble()
    }

    // --------------------------------------------------------------
    // Typed anchor setters — route every anchor mutation through here
    // so a single `anchor-change` event is emitted per mutation.
    // --------------------------------------------------------------

    private fun setLastAccepted(new: Location?, reason: String) {
        val old = lastAcceptedLocation
        lastAcceptedLocation = new
        logger.logAnchorChange(
            variable = "lastAccepted",
            reason = reason,
            old = locationAnchorMap(old),
            new = locationAnchorMap(new)
        )
    }

    private fun setLastEmittedPair(
        newLast: Location?,
        newSecondLast: Location?,
        reason: String
    ) {
        val oldLast = lastEmittedLocation
        val oldSecondLast = secondLastEmittedLocation
        lastEmittedLocation = newLast
        secondLastEmittedLocation = newSecondLast
        logger.logAnchorChange(
            variable = "lastEmitted",
            reason = reason,
            old = locationAnchorMap(oldLast),
            new = locationAnchorMap(newLast)
        )
        logger.logAnchorChange(
            variable = "secondLastEmitted",
            reason = reason,
            old = locationAnchorMap(oldSecondLast),
            new = locationAnchorMap(newSecondLast)
        )
    }

    private fun setSmoothed(lat: Double?, lon: Double?, reason: String) {
        val oldLat = smoothedLat
        val oldLon = smoothedLon
        smoothedLat = lat
        smoothedLon = lon
        val oldMap = if (oldLat != null && oldLon != null) {
            mapOf("lat" to oldLat, "lon" to oldLon)
        } else null
        val newMap = if (lat != null && lon != null) {
            mapOf("lat" to lat, "lon" to lon)
        } else null
        logger.logAnchorChange(
            variable = "smoothed",
            reason = reason,
            old = oldMap,
            new = newMap
        )
    }

    private fun setConsecutiveRejections(new: Int, gate: String) {
        val old = consecutiveGateRejections
        if (old == new) return
        consecutiveGateRejections = new
        logger.logRejectionCounter(old = old, new = new, gate = gate)
    }

    private fun bumpGateRejection(gate: String) {
        sessionGateRejections[gate] = (sessionGateRejections[gate] ?: 0) + 1
        setConsecutiveRejections(consecutiveGateRejections + 1, gate)
    }

    // --------------------------------------------------------------
    // Suppress helper — single path for every `return null` that isn't
    // gate-based, so session counts and the JSONL stay in lock-step.
    // --------------------------------------------------------------

    private fun suppress(location: Location, reason: String): Location? {
        sessionSuppressCounts[reason] = (sessionSuppressCounts[reason] ?: 0) + 1
        logger.logSuppress(location, reason)
        return null
    }

    private fun locationAnchorMap(loc: Location?): Map<String, Any?>? {
        if (loc == null) return null
        return mapOf(
            "lat" to loc.latitude,
            "lon" to loc.longitude,
            "acc" to if (loc.hasAccuracy()) loc.accuracy.toDouble() else null,
            "tsMs" to loc.time
        )
    }

    private fun emitConfigSnapshot() {
        logger.logConfigSnapshot(
            mapOf(
                "activity" to activityType.name,
                "maxAccuracy" to config.maxAccuracy,
                "maxSpeedMps" to config.maxSpeedMps,
                "gapResetThresholdSeconds" to config.gapResetThresholdSeconds,
                "maxConsecutiveRejections" to config.maxConsecutiveRejections,
                "resetCalibrationOnGap" to config.resetCalibrationOnGap,
                "minEmitDistanceFloor" to config.minEmitDistanceFloor,
                "emaAlphaCap" to config.emaAlphaCap,
                "stationarySpeedEntry" to config.stationarySpeedEntry,
                "stationaryConsecutiveRequired" to config.stationaryConsecutiveRequired,
                "stationarySpeedExit" to config.stationarySpeedExit,
                "stationaryDisplacementExit" to config.stationaryDisplacementExit,
                "calibrationDurationMs" to config.calibrationConfig.calibrationDurationMs,
                "minPointsForCalibration" to config.calibrationConfig.minPointsForCalibration,
                "maxCalibrationAccuracy" to config.calibrationConfig.maxCalibrationAccuracy,
                "trackingStartTimeMs" to trackingStartTimeMs
            )
        )
    }
}
