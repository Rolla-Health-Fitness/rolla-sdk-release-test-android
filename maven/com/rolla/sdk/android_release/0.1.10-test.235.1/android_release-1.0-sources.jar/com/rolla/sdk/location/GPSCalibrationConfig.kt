package com.rolla.sdk.location

/**
 * Configuration for GPS calibration phase.
 * Direct port of iOS GPSCalibrationConfig from the location-improvements branch.
 */
data class GPSCalibrationConfig(
    /** How long to collect calibration points (ms). */
    val calibrationDurationMs: Long = 6000L,
    /** Minimum points required for successful calibration. */
    val minPointsForCalibration: Int = 3,
    /** Maximum points to keep in the calibration buffer (ring buffer). */
    val maxPointsForCalibration: Int = 15,
    /** Max accuracy (meters) for a point to be accepted during calibration. */
    val maxCalibrationAccuracy: Double = 30.0,
    /** Max distance (meters) any recent point can be from centroid for stable result. */
    val stabilityThreshold: Double = 35.0,
    /** Number of recent points to check for centroid stability. */
    val recentPointsForStability: Int = 3,
    /** If median accuracy of calibration points exceeds this, calibration fails. */
    val medianAccuracyThreshold: Double = 80.0,
    /** Time-to-live for calibration (ms) — after this the baseline is passively refreshed. */
    val calibrationTTLMs: Long = 14_400_000L, // 4 hours
    /** Cooldown (ms) after calibration failure before retrying. */
    val retryAfterFailureCooldownMs: Long = 5000L
) {
    init {
        require(calibrationDurationMs > 0)
        require(minPointsForCalibration > 0)
        require(maxPointsForCalibration >= minPointsForCalibration)
        require(maxCalibrationAccuracy > 0)
        require(stabilityThreshold > 0)
        require(recentPointsForStability in 1..minPointsForCalibration)
        require(medianAccuracyThreshold > 0)
        require(calibrationTTLMs > 0)
        require(retryAfterFailureCooldownMs >= 0)
    }
}
