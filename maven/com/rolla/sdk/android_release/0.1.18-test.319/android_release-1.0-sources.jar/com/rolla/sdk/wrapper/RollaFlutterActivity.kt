package com.rolla.sdk.wrapper

import android.os.Build
import android.os.Bundle
import com.rolla.sdk.R
import io.flutter.embedding.android.FlutterFragmentActivity

class RollaFlutterActivity : FlutterFragmentActivity() {

    companion object {
        /** Intent extra carrying the [RollaTransition] name chosen at [Rolla.show]. */
        internal const val EXTRA_TRANSITION = "com.rolla.sdk.wrapper.EXTRA_TRANSITION"

        @Volatile
        internal var onDismiss: ((RollaCloseReason) -> Unit)? = null

        @Volatile
        private var pendingCloseReason: RollaCloseReason? = null

        @Volatile
        private var currentInstance: RollaFlutterActivity? = null

        internal fun setPendingCloseReason(reason: RollaCloseReason) {
            pendingCloseReason = reason
        }

        internal fun clearCallbacks() {
            onDismiss = null
            pendingCloseReason = null
        }

        internal fun finishCurrent() {
            currentInstance?.finish()
        }
    }

    private var didNotifyDismiss = false
    private var backPressedDuringSession = false
    private var isFadeTransition = false

    override fun getCachedEngineId(): String = RollaEngineManager.ENGINE_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentInstance = this
        didNotifyDismiss = false
        backPressedDuringSession = false
        isFadeTransition = intent?.getStringExtra(EXTRA_TRANSITION) == RollaTransition.FADE.name
        if (isFadeTransition && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // The API < 34 path runs overridePendingTransition in finish()
            // instead — every close funnels through that one override.
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        backPressedDuringSession = true
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        currentInstance = null
        notifyDismissOnce()
    }

    override fun finish() {
        if (pendingCloseReason == null && backPressedDuringSession) {
            pendingCloseReason = RollaCloseReason.HostNavigationBack
        }
        super.finish()
        if (isFadeTransition && Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    private fun notifyDismissOnce() {
        if (didNotifyDismiss) return
        didNotifyDismiss = true

        val reason = pendingCloseReason ?: RollaCloseReason.HostModalDismiss
        pendingCloseReason = null

        onDismiss?.invoke(reason)
        onDismiss = null
    }
}
