package app.rolla.bluetoothSdk.services

import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.utils.getFullUUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
    class DeviceFirmwareUpdateService @Inject constructor(
) : Service {
    override val uuid: String = "FE59".getFullUUID()
    override val characteristics: List<Characteristic> = listOf()
}