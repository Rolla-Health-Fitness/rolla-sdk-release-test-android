package app.rolla.bluetoothSdk.di

import android.bluetooth.BluetoothAdapter
import android.content.Context
import app.rolla.bluetoothSdk.scan.manager.ScanConfigurationManager
import app.rolla.bluetoothSdk.scan.manager.ScanManager
import app.rolla.bluetoothSdk.scan.manager.ScanOperationManager
import app.rolla.bluetoothSdk.scan.manager.ScanStateManager
import app.rolla.bluetoothSdk.scan.manager.ScanThrottleManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext


@Module
@InstallIn(SingletonComponent::class)
object ScanModule {

    // Scan-related managers
    @Provides
    @Singleton
    fun provideScanStateManager(): ScanStateManager = ScanStateManager()

    @Provides
    @Singleton
    fun provideScanThrottleManager(): ScanThrottleManager = ScanThrottleManager()

    @Provides
    @Singleton
    fun provideScanConfigurationManager(): ScanConfigurationManager = ScanConfigurationManager()

    @Provides
    @Singleton
    fun provideScanOperationManager(
        @ApplicationContext context: Context,
        bluetoothAdapter: BluetoothAdapter?,
        stateManager: ScanStateManager,
        throttleManager: ScanThrottleManager,
        configManager: ScanConfigurationManager,
        @BleScopeContext coroutineContext: CoroutineContext
    ): ScanOperationManager = ScanOperationManager(
        context, bluetoothAdapter, stateManager, throttleManager, configManager, coroutineContext
    )

    @Provides
    @Singleton
    fun provideScanManager(
        @ApplicationContext context: Context,
        @BleScopeContext coroutineContext: CoroutineContext,
        stateManager: ScanStateManager,
        configManager: ScanConfigurationManager,
        operationManager: ScanOperationManager
    ): ScanManager = ScanManager(context, coroutineContext, stateManager, configManager, operationManager)

}