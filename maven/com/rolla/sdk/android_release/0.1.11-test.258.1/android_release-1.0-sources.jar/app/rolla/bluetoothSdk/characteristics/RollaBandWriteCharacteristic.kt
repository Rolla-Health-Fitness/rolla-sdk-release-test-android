package app.rolla.bluetoothSdk.characteristics

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.commands.Command
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
import app.rolla.bluetoothSdk.utils.getFullUUID
import kotlinx.coroutines.CoroutineScope
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class RollaBandWriteCharacteristic @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext,
    val rollaBandImpl: RollaBandImpl
) : Characteristic {

    companion object {
        const val TAG = "RollaBandWriteCharacteristic"
    }

    override val uuid: String = "FFF6".getFullUUID()
    override val scope = CoroutineScope(bleScopeContext)


    override fun onDeviceConnected() {
        rollaBandImpl.onDeviceConnected()
    }

    override fun getPostSubscriptionCommands(): List<Command<*>> {
        return rollaBandImpl.getPostSubscriptionCommands()
    }

    override fun onWrite(byteArray: ByteArray?, device: BleDevice) {
        super.onWrite(byteArray, device)
        rollaBandImpl.onWrite(byteArray, device)
    }

    override fun onError(deviceAddress: String, error: Error, value: ByteArray?) {
        super.onError(deviceAddress, error, value)
        if (value != null && value.isNotEmpty()) {
            rollaBandImpl.onError(deviceAddress, error, value[0])
        }
    }
}