package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideConnectTimeoutManagerFactory implements Factory<ConnectTimeoutManager> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideConnectTimeoutManagerFactory(
      Provider<CoroutineContext> coroutineContextProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public ConnectTimeoutManager get() {
    return provideConnectTimeoutManager(coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideConnectTimeoutManagerFactory create(
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideConnectTimeoutManagerFactory(coroutineContextProvider);
  }

  public static ConnectTimeoutManager provideConnectTimeoutManager(
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideConnectTimeoutManager(coroutineContext));
  }
}
