package app.rolla.bluetoothSdk.result

import app.rolla.bluetoothSdk.result.error.Error

/**
 * Result class for method calls.
 *
 * @property successful Whether the method call is successful
 * @property error Optional error if the method call failed
 */
data class MethodResult(
    val successful: Boolean,
    val error: Error? = null
)