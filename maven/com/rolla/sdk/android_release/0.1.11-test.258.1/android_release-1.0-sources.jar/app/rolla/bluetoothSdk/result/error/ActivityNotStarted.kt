package app.rolla.bluetoothSdk.result.error

class ActivityNotStarted : Error (
    code = ErrorCodes.ACTIVITY_NOT_STARTED,
    message = "Activity not started"
)