package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDeviceStateManagerFactory implements Factory<DeviceStateManager> {
  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideDeviceStateManagerFactory(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DeviceStateManager get() {
    return provideDeviceStateManager(deviceStorageManagerProvider.get(), coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideDeviceStateManagerFactory create(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideDeviceStateManagerFactory(deviceStorageManagerProvider, coroutineContextProvider);
  }

  public static DeviceStateManager provideDeviceStateManager(
      DeviceStorageManager deviceStorageManager, CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDeviceStateManager(deviceStorageManager, coroutineContext));
  }
}
