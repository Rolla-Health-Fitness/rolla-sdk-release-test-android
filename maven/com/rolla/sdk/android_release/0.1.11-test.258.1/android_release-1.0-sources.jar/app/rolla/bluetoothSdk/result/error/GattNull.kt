package app.rolla.bluetoothSdk.result.error

class GattNull : Error (
    code = ErrorCodes.GATT_IS_NULL,
    message = "GATT is null"
)