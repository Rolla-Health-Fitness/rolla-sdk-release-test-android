package app.rolla.bluetoothSdk.result.error

class DeviceNotConnected : Error (
    code = ErrorCodes.DEVICE_NOT_CONNECTED,
    message = "Device not connected"
)