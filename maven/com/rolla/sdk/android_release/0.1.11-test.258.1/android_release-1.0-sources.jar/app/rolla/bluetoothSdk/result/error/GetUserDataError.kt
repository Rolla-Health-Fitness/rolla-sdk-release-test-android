package app.rolla.bluetoothSdk.result.error

class GetUserDataError : Error (
    code = ErrorCodes.GET_USER_DATA_ERROR,
    message = "Get user data error"
)
