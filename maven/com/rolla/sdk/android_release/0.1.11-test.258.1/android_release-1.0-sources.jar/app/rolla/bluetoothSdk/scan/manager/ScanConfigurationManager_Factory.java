package app.rolla.bluetoothSdk.scan.manager;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanConfigurationManager_Factory implements Factory<ScanConfigurationManager> {
  @Override
  public ScanConfigurationManager get() {
    return newInstance();
  }

  public static ScanConfigurationManager_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScanConfigurationManager newInstance() {
    return new ScanConfigurationManager();
  }

  private static final class InstanceHolder {
    static final ScanConfigurationManager_Factory INSTANCE = new ScanConfigurationManager_Factory();
  }
}
