package app.rolla.bluetoothSdk.result.error

class DeviceTypeEmpty : Error (
    code = ErrorCodes.DEVICE_TYPE_EMPTY,
    message = "Device types cannot be empty"
)