package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRealTimeStepCalculatorFactory implements Factory<RealTimeStepCalculator> {
  @Override
  public RealTimeStepCalculator get() {
    return provideRealTimeStepCalculator();
  }

  public static FlutterSdkModule_ProvideRealTimeStepCalculatorFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static RealTimeStepCalculator provideRealTimeStepCalculator() {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRealTimeStepCalculator());
  }

  private static final class InstanceHolder {
    static final FlutterSdkModule_ProvideRealTimeStepCalculatorFactory INSTANCE = new FlutterSdkModule_ProvideRealTimeStepCalculatorFactory();
  }
}
