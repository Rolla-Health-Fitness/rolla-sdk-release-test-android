package app.rolla.bluetoothSdk.result.error

class ReadFailed(status: Int?) : Error (
    code = ErrorCodes.READ_FAILED,
    message = "Read failed - status: $status"
)