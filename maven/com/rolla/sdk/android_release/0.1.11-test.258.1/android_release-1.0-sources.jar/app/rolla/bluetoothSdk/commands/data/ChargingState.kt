package app.rolla.bluetoothSdk.commands.data

enum class ChargingState {
    CHARGING,
    NOT_CHARGING
}