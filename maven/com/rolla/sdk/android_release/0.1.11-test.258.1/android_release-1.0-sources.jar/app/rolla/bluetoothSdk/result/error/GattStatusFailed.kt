package app.rolla.bluetoothSdk.result.error

class GattStatusFailed(throwable: Throwable? = null) : Error (
    code = ErrorCodes.GATT_STATUS_FAILED,
    message = "GATT status failed",
    exception = throwable
)