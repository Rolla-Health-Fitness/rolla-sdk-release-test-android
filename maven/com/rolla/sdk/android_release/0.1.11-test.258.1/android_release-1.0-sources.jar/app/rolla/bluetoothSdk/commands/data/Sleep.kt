package app.rolla.bluetoothSdk.commands.data

data class Sleep (
    val timestamp: Long,
    val phase: SleepPhase
)