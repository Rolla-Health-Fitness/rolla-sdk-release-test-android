package app.rolla.bluetoothSdk.commands.data

enum class WristDetectionStatus {
    WEAR,
    NOT_WEAR
}