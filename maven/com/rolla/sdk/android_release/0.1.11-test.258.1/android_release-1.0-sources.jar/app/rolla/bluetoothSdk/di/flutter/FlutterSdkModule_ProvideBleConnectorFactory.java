package app.rolla.bluetoothSdk.di.flutter;

import android.content.Context;
import app.rolla.bluetoothSdk.connect.BleConnector;
import app.rolla.bluetoothSdk.connect.ConnectionManager;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import app.rolla.bluetoothSdk.device.DeviceManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideBleConnectorFactory implements Factory<BleConnector> {
  private final Provider<Context> contextProvider;

  private final Provider<DeviceManager> deviceManagerProvider;

  private final Provider<OperationQueue> operationQueueProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<ConnectionManager> connectionManagerProvider;

  private FlutterSdkModule_ProvideBleConnectorFactory(Provider<Context> contextProvider,
      Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<ConnectionManager> connectionManagerProvider) {
    this.contextProvider = contextProvider;
    this.deviceManagerProvider = deviceManagerProvider;
    this.operationQueueProvider = operationQueueProvider;
    this.coroutineContextProvider = coroutineContextProvider;
    this.connectionManagerProvider = connectionManagerProvider;
  }

  @Override
  public BleConnector get() {
    return provideBleConnector(contextProvider.get(), deviceManagerProvider.get(), operationQueueProvider.get(), coroutineContextProvider.get(), connectionManagerProvider.get());
  }

  public static FlutterSdkModule_ProvideBleConnectorFactory create(
      Provider<Context> contextProvider, Provider<DeviceManager> deviceManagerProvider,
      Provider<OperationQueue> operationQueueProvider,
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<ConnectionManager> connectionManagerProvider) {
    return new FlutterSdkModule_ProvideBleConnectorFactory(contextProvider, deviceManagerProvider, operationQueueProvider, coroutineContextProvider, connectionManagerProvider);
  }

  public static BleConnector provideBleConnector(Context context, DeviceManager deviceManager,
      OperationQueue operationQueue, CoroutineContext coroutineContext,
      ConnectionManager connectionManager) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideBleConnector(context, deviceManager, operationQueue, coroutineContext, connectionManager));
  }
}
