package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.UserInfo
import app.rolla.bluetoothSdk.result.error.Error

class UserData (
    val uuid: String,
    val userInfo: UserInfo,
    val error: Error? = null
) {
    override fun toString(): String {
        return "UserData(uuid=$uuid, userInfo=$userInfo, error=$error)"
    }
}