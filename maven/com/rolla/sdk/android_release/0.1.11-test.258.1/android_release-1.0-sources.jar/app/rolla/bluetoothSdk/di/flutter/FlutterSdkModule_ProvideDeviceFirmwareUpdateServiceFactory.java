package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDeviceFirmwareUpdateServiceFactory implements Factory<DeviceFirmwareUpdateService> {
  @Override
  public DeviceFirmwareUpdateService get() {
    return provideDeviceFirmwareUpdateService();
  }

  public static FlutterSdkModule_ProvideDeviceFirmwareUpdateServiceFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DeviceFirmwareUpdateService provideDeviceFirmwareUpdateService() {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDeviceFirmwareUpdateService());
  }

  private static final class InstanceHolder {
    static final FlutterSdkModule_ProvideDeviceFirmwareUpdateServiceFactory INSTANCE = new FlutterSdkModule_ProvideDeviceFirmwareUpdateServiceFactory();
  }
}
