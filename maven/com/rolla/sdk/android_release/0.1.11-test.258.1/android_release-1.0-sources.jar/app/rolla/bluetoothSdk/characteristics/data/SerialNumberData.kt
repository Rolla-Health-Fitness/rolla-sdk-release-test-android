package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.result.error.Error

data class SerialNumberData(
    val uuid: String,
    val serialNumber: String,
    val error: Error? = null
) {
    override fun toString(): String {
        return "SerialNumber(uuid=$uuid, serialNumber=$serialNumber, error=$error)"
    }
}