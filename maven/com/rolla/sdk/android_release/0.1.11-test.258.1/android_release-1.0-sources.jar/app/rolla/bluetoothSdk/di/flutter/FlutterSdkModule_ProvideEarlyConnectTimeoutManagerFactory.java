package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideEarlyConnectTimeoutManagerFactory implements Factory<EarlyConnectTimeoutManager> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideEarlyConnectTimeoutManagerFactory(
      Provider<CoroutineContext> coroutineContextProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public EarlyConnectTimeoutManager get() {
    return provideEarlyConnectTimeoutManager(coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideEarlyConnectTimeoutManagerFactory create(
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideEarlyConnectTimeoutManagerFactory(coroutineContextProvider);
  }

  public static EarlyConnectTimeoutManager provideEarlyConnectTimeoutManager(
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideEarlyConnectTimeoutManager(coroutineContext));
  }
}
