package app.rolla.bluetoothSdk.di;

import android.content.Context;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BleSdkModule_ProvideBleOperationQueueFactory implements Factory<OperationQueue> {
  private final Provider<Context> contextProvider;

  private BleSdkModule_ProvideBleOperationQueueFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public OperationQueue get() {
    return provideBleOperationQueue(contextProvider.get());
  }

  public static BleSdkModule_ProvideBleOperationQueueFactory create(
      Provider<Context> contextProvider) {
    return new BleSdkModule_ProvideBleOperationQueueFactory(contextProvider);
  }

  public static OperationQueue provideBleOperationQueue(Context context) {
    return Preconditions.checkNotNullFromProvides(BleSdkModule.INSTANCE.provideBleOperationQueue(context));
  }
}
