package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.result.error.Error

class FactoryResetData (
    val uuid: String,
    val success: Boolean,
    val error: Error? = null
) {
    override fun toString(): String {
        return "FactoryResetData(uuid=$uuid, success=$success, error=$error)"
    }
}