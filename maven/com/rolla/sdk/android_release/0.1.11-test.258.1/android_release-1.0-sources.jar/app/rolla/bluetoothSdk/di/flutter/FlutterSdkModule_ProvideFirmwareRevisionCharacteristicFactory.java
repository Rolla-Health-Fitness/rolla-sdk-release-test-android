package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideFirmwareRevisionCharacteristicFactory implements Factory<FirmwareRevisionCharacteristic> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideFirmwareRevisionCharacteristicFactory(
      Provider<CoroutineContext> coroutineContextProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public FirmwareRevisionCharacteristic get() {
    return provideFirmwareRevisionCharacteristic(coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideFirmwareRevisionCharacteristicFactory create(
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideFirmwareRevisionCharacteristicFactory(coroutineContextProvider);
  }

  public static FirmwareRevisionCharacteristic provideFirmwareRevisionCharacteristic(
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideFirmwareRevisionCharacteristic(coroutineContext));
  }
}
