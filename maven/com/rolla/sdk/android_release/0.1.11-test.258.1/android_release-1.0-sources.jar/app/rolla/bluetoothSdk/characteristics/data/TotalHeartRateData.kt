package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.HeartRate

data class TotalHeartRateData (
    var uuid: String = "",
    val heartRates: ArrayList<HeartRate> = arrayListOf(),
    val activityLastBlockTimestamp: Long = 0L,
    val activityLastEntryTimestamp: Long = 0L,
    val passiveLastBlockTimestamp: Long = 0L
)