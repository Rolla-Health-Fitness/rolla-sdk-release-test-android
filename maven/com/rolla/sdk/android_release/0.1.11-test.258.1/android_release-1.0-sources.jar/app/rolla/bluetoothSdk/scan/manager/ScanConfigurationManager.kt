package app.rolla.bluetoothSdk.scan.manager

import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanSettings
import android.os.Build
import android.os.ParcelUuid
import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.InvalidParameter
import app.rolla.bluetoothSdk.utils.log
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScanConfigurationManager @Inject constructor() {
    companion object {
        const val DEFAULT_SCAN_DURATION_MS = 30_000L
        const val MAX_ALLOWED_SCAN_DURATION_MS = 5 * 60_000L
        private const val TAG = "ScanConfigurationManager"
    }

    private var scanDuration = DEFAULT_SCAN_DURATION_MS


    /**
     * Sets the duration for scan operations.
     *
     * @param durationMs The scan duration in milliseconds
     * @return Result of the operation
     *
     * @error InvalidParameter if scan duration is invalid
     */
    fun setScanDuration(durationMs: Long): MethodResult {
        if (durationMs < 0 || durationMs > MAX_ALLOWED_SCAN_DURATION_MS) {
            return MethodResult(
                false,
                InvalidParameter(
                    Throwable("Scan duration must be between 0 and ${MAX_ALLOWED_SCAN_DURATION_MS}ms")
                )
            )
        }
        scanDuration = durationMs
        return MethodResult(true)
    }

    /**
     * Get the current scan duration
     */
    fun getScanDuration(): Long = scanDuration

    /**
     * Create scan filters from UUIDs
     *
     * @param uuids List of UUIDs to scan for
     * @return List of ScanFilters
     * @throws IllegalArgumentException if any UUID is invalid
     */
    fun createScanFilters(uuids: List<String>): List<ScanFilter> {
        if (uuids.isEmpty()) return emptyList()

        return uuids.mapNotNull { uuidString ->
            try {
                val uuid = UUID.fromString(uuidString)
                ScanFilter.Builder().setServiceUuid(ParcelUuid(uuid)).build()
            } catch (e: IllegalArgumentException) {
                log(TAG, "Invalid UUID format: $uuidString")
                null
            }
        }
    }

    /**
     * Create scan settings
     *
     * @return ScanSettings
     */
    fun createScanSettings(): ScanSettings {
        return ScanSettings.Builder().apply {
            setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
            setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
            setNumOfMatches(ScanSettings.MATCH_NUM_MAX_ADVERTISEMENT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setLegacy(false)
                setPhy(ScanSettings.PHY_LE_ALL_SUPPORTED)
            }
            setReportDelay(0)
        }.build()
    }

    /**
     * Clear all configuration
     */
    fun clear() {
        scanDuration = DEFAULT_SCAN_DURATION_MS
    }
}