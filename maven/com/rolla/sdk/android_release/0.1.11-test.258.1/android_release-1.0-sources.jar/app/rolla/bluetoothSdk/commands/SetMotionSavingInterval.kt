package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.utils.log
class SetMotionSavingInterval : Command<ByteArray> {

    companion object {
        const val TAG = "SetMotionSavingInterval"
        private const val SETTING_MODE = 0x01.toByte()
        private const val FAILURE_RESPONSE = 0xFF.toByte()
    }

    private var intervalSeconds: Int = 1

    fun setInterval(seconds: Int) {
        require(seconds in 0..255) { "Interval must be between 0 and 255 seconds" }
        intervalSeconds = seconds
    }

    override fun getId(): Byte = 0x78.toByte()

    override fun errorId(): Byte = 0x78.toByte()

    override fun bytesToWrite(): ByteArray = createCommandBytes {
        this[1] = SETTING_MODE
        this[2] = intervalSeconds.toByte()
    }

    override fun read(data: ByteArray): ByteArray {
        if (data.size >= 2 && data[1] == FAILURE_RESPONSE) {
            log(TAG, "⚠️ Band rejected motion saving interval command - ignoring failure")
            return data
        }

        log(TAG, "✅ Successfully set motion saving interval to ${intervalSeconds}s")
        return data
    }
}

