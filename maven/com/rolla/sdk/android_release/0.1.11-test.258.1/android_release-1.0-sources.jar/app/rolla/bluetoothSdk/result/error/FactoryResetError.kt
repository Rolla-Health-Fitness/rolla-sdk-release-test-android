package app.rolla.bluetoothSdk.result.error

class FactoryResetError : Error (
    code = ErrorCodes.FACTORY_RESET_ERROR,
    message = "Factory reset error"
)