package app.rolla.bluetoothSdk.di.flutter

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.BleRegistry
import app.rolla.bluetoothSdk.characteristics.*
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
import app.rolla.bluetoothSdk.connect.*
import app.rolla.bluetoothSdk.connect.reconnect.*
import app.rolla.bluetoothSdk.connect.timeout.*
import app.rolla.bluetoothSdk.device.*
import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager
import app.rolla.bluetoothSdk.device.state.DeviceStateManager
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager
import app.rolla.bluetoothSdk.scan.manager.*
import app.rolla.bluetoothSdk.services.*
import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

/**
 * Pure Dagger module (no Hilt annotations) that provides all SDK dependencies.
 * 
 * This module mirrors the functionality of the Hilt modules (BleSdkModule,
 * BluetoothModule, ScanModule, etc.) but uses pure Dagger @Provides methods
 * instead of Hilt's @InstallIn(SingletonComponent::class).
 * 
 * Key differences from Hilt modules:
 * - No @InstallIn annotation (pure Dagger)
 * - No @HiltAndroidApp required in host app
 * - Works with FlutterSdkComponent instead of Hilt's generated components
 * - Manually included in FlutterSdkComponent.modules
 * 
 * Maintenance note: When updating Hilt modules, keep this module in sync.
 * This ensures Flutter and native Android apps get the same behavior.
 */
@Module
object FlutterSdkModule {

    // ==================== Dispatchers Module ====================
    // Mirrors: DispatchersModule.kt
    
    /**
     * Provides the main coroutine context for BLE operations.
     * Uses IO dispatcher with SupervisorJob and exception handler.
     */
    @Provides
    @Singleton
    fun provideBleScopeContext(): CoroutineContext {
        val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
            println("BLE Coroutine Exception: ${throwable.message}")
        }
        return SupervisorJob() + Dispatchers.IO + exceptionHandler
    }

    // ==================== Bluetooth Module ====================
    // Mirrors: BluetoothModule.kt

    @Provides
    @Singleton
    fun provideBluetoothManager(context: Context): BluetoothManager? {
        return context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    }

    @Provides
    @Singleton
    fun provideBluetoothAdapter(bluetoothManager: BluetoothManager?): BluetoothAdapter? {
        return bluetoothManager?.adapter
    }

    @Provides
    @Singleton
    fun provideFirstConnectionRetryStrategy(
        context: CoroutineContext
    ): FirstConnectionRetryStrategy = FirstConnectionRetryStrategy(context)

    @Provides
    @Singleton
    fun provideAutoReconnectStrategy(
        context: CoroutineContext
    ): AutoReconnectStrategy = AutoReconnectStrategy(context)

    @Provides
    @Singleton
    fun provideReconnectionManager(
        bluetoothAdapter: BluetoothAdapter?,
        firstConnectionRetryStrategy: FirstConnectionRetryStrategy,
        autoReconnectStrategy: AutoReconnectStrategy
    ): ReconnectionManager = ReconnectionManager(
        bluetoothAdapter,
        firstConnectionRetryStrategy,
        autoReconnectStrategy
    )

    // ==================== Scan Module ====================
    // Mirrors: ScanModule.kt

    @Provides
    @Singleton
    fun provideScanStateManager(): ScanStateManager = ScanStateManager()

    @Provides
    @Singleton
    fun provideScanThrottleManager(): ScanThrottleManager = ScanThrottleManager()

    @Provides
    @Singleton
    fun provideScanConfigurationManager(): ScanConfigurationManager = ScanConfigurationManager()

    @Provides
    @Singleton
    fun provideScanOperationManager(
        context: Context,
        bluetoothAdapter: BluetoothAdapter?,
        stateManager: ScanStateManager,
        throttleManager: ScanThrottleManager,
        configManager: ScanConfigurationManager,
        coroutineContext: CoroutineContext
    ): ScanOperationManager = ScanOperationManager(
        context, bluetoothAdapter, stateManager, throttleManager, configManager, coroutineContext
    )

    @Provides
    @Singleton
    fun provideScanManager(
        context: Context,
        coroutineContext: CoroutineContext,
        stateManager: ScanStateManager,
        configManager: ScanConfigurationManager,
        operationManager: ScanOperationManager
    ): ScanManager = ScanManager(
        context, coroutineContext, stateManager, configManager, operationManager
    )

    // ==================== Device Module ====================
    // Mirrors: DeviceModule.kt

    @Provides
    @Singleton
    fun provideDeviceStorageManager(): DeviceStorageManager = DeviceStorageManager()

    @Provides
    @Singleton
    fun provideDeviceStateManager(
        deviceStorageManager: DeviceStorageManager,
        coroutineContext: CoroutineContext
    ): DeviceStateManager = DeviceStateManager(deviceStorageManager, coroutineContext)

    @Provides
    @Singleton
    fun provideDeviceTypeManager(
        deviceStorageManager: DeviceStorageManager
    ): DeviceTypeManager = DeviceTypeManager(deviceStorageManager)

    @Provides
    @Singleton
    fun provideDeviceMonitoringManager(
        deviceStorageManager: DeviceStorageManager,
        deviceStateManager: DeviceStateManager,
        coroutineContext: CoroutineContext
    ): DeviceMonitoringManager = DeviceMonitoringManager(
        deviceStorageManager, deviceStateManager, coroutineContext
    )

    @Provides
    @Singleton
    fun provideDeviceManager(
        coroutineContext: CoroutineContext,
        deviceTypeManager: DeviceTypeManager,
        deviceMonitoringManager: DeviceMonitoringManager,
        deviceStateManager: DeviceStateManager,
        deviceStorageManager: DeviceStorageManager
    ): DeviceManager = DeviceManager(
        coroutineContext, deviceTypeManager, deviceMonitoringManager,
        deviceStateManager, deviceStorageManager
    )

    // ==================== Characteristic Module ====================
    // Mirrors: CharacteristicModule.kt

    @Provides
    @Singleton
    fun provideRealTimeStepCalculator(): RealTimeStepCalculator = RealTimeStepCalculator()

    @Provides
    @Singleton
    fun provideRollaBandImpl(
        context: Context,
        coroutineContext: CoroutineContext
    ): RollaBandImpl = RollaBandImpl(context, coroutineContext)

    @Provides
    @Singleton
    fun provideFirmwareRevisionCharacteristic(
        coroutineContext: CoroutineContext
    ): FirmwareRevisionCharacteristic = FirmwareRevisionCharacteristic(coroutineContext)

    @Provides
    @Singleton
    fun provideSerialNumberCharacteristic(
        coroutineContext: CoroutineContext
    ): SerialNumberCharacteristic = SerialNumberCharacteristic(coroutineContext)

    @Provides
    @Singleton
    fun provideHeartRateCharacteristic(
        coroutineContext: CoroutineContext
    ): HeartRateCharacteristic = HeartRateCharacteristic(coroutineContext)

    @Provides
    @Singleton
    fun provideRunningSpeedCadenceCharacteristic(
        coroutineContext: CoroutineContext,
        realTimeStepCalculator: RealTimeStepCalculator
    ): RunningSpeedCadenceCharacteristic = RunningSpeedCadenceCharacteristic(
        coroutineContext, realTimeStepCalculator
    )

    @Provides
    @Singleton
    fun provideRollaBandWriteCharacteristic(
        coroutineContext: CoroutineContext,
        rollaBandImpl: RollaBandImpl
    ): RollaBandWriteCharacteristic = RollaBandWriteCharacteristic(coroutineContext, rollaBandImpl)

    @Provides
    @Singleton
    fun provideRollaBandReadCharacteristic(
        coroutineContext: CoroutineContext,
        rollaBandImpl: RollaBandImpl
    ): RollaBandReadCharacteristic = RollaBandReadCharacteristic(coroutineContext, rollaBandImpl)

    // ==================== Service Module ====================
    // Mirrors: ServiceModule.kt

    @Provides
    @Singleton
    fun provideDeviceInformationService(
        serialNumberCharacteristic: SerialNumberCharacteristic,
        firmwareRevisionCharacteristic: FirmwareRevisionCharacteristic
    ): DeviceInformationService = DeviceInformationService(
        serialNumberCharacteristic, firmwareRevisionCharacteristic
    )

    @Provides
    @Singleton
    fun provideDeviceFirmwareUpdateService(): DeviceFirmwareUpdateService = DeviceFirmwareUpdateService()

    @Provides
    @Singleton
    fun provideRollaBandService(
        rollaBandReadCharacteristic: RollaBandReadCharacteristic,
        rollaBandWriteCharacteristic: RollaBandWriteCharacteristic
    ): RollaBandService = RollaBandService(rollaBandReadCharacteristic, rollaBandWriteCharacteristic)

    @Provides
    @Singleton
    fun provideHeartRateService(
        heartRateCharacteristic: HeartRateCharacteristic
    ): HeartRateService = HeartRateService(heartRateCharacteristic)

    @Provides
    @Singleton
    fun provideRunningSpeedAndCadenceService(
        runningSpeedCadenceCharacteristic: RunningSpeedCadenceCharacteristic
    ): RunningSpeedAndCadenceService = RunningSpeedAndCadenceService(runningSpeedCadenceCharacteristic)

    @Provides
    @Singleton
    fun provideBleRegistry(
        heartRateService: HeartRateService,
        runningSpeedAndCadenceService: RunningSpeedAndCadenceService,
        rollaBandService: RollaBandService,
        deviceInformationService: DeviceInformationService,
        deviceFirmwareUpdateService: DeviceFirmwareUpdateService
    ): BleRegistry = BleRegistry(
        heartRateService, runningSpeedAndCadenceService, rollaBandService,
        deviceInformationService, deviceFirmwareUpdateService
    )

    // ==================== Connect Module ====================
    // Mirrors: ConnectModule.kt

    @Provides
    @Singleton
    fun provideOperationQueue(context: Context): OperationQueue = OperationQueue(context)

    @Provides
    @Singleton
    fun provideConnectTimeoutManager(
        coroutineContext: CoroutineContext
    ): ConnectTimeoutManager = ConnectTimeoutManager(coroutineContext)

    @Provides
    @Singleton
    fun provideEarlyConnectTimeoutManager(
        coroutineContext: CoroutineContext
    ): EarlyConnectTimeoutManager = EarlyConnectTimeoutManager(coroutineContext)

    @Provides
    @Singleton
    fun provideDisconnectTimeoutManager(
        coroutineContext: CoroutineContext
    ): DisconnectTimeoutManager = DisconnectTimeoutManager(coroutineContext)

    @Provides
    @Singleton
    fun provideSubscriptionManager(
        coroutineContext: CoroutineContext,
        context: Context,
        operationQueue: OperationQueue,
        bleRegistry: BleRegistry
    ): SubscriptionManager = SubscriptionManager(
        coroutineContext, context, operationQueue, bleRegistry
    )

    @Provides
    @Singleton
    fun provideConnectionManager(
        context: Context,
        coroutineContext: CoroutineContext,
        bluetoothAdapter: BluetoothAdapter?,
        deviceManager: DeviceManager,
        operationQueue: OperationQueue,
        subscriptionManager: SubscriptionManager,
        bleRegistry: BleRegistry,
        earlyConnectTimeoutManager: EarlyConnectTimeoutManager,
        connectTimeoutManager: ConnectTimeoutManager,
        disconnectTimeoutManager: DisconnectTimeoutManager,
        reconnectionManager: ReconnectionManager
    ): ConnectionManager = ConnectionManager(
        context, coroutineContext, bluetoothAdapter, deviceManager, operationQueue,
        subscriptionManager, bleRegistry, earlyConnectTimeoutManager,
        connectTimeoutManager, disconnectTimeoutManager, reconnectionManager
    )

    @Provides
    @Singleton
    fun provideBleConnector(
        context: Context,
        deviceManager: DeviceManager,
        operationQueue: OperationQueue,
        coroutineContext: CoroutineContext,
        connectionManager: ConnectionManager
    ): BleConnector = BleConnector(
        context, deviceManager, operationQueue, coroutineContext, connectionManager
    )

    // ==================== BleSdk Module ====================
    // Mirrors: BleSdkModule.kt
    
    /**
     * Main entry point - provides BleManager with all dependencies.
     * This is what the Flutter plugin will access via component.bleManager()
     */
    @Provides
    @Singleton
    fun provideBleManager(
        context: Context,
        bluetoothAdapter: BluetoothAdapter?,
        scanManager: ScanManager,
        bleConnector: BleConnector,
        deviceManager: DeviceManager,
        bleRegistry: BleRegistry,
        coroutineContext: CoroutineContext
    ): BleManager = BleManager(
        context, bluetoothAdapter, scanManager, bleConnector,
        deviceManager, bleRegistry, coroutineContext
    )
}

