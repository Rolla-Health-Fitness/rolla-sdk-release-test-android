package app.rolla.bluetoothSdk.scan.manager;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanStateManager_Factory implements Factory<ScanStateManager> {
  @Override
  public ScanStateManager get() {
    return newInstance();
  }

  public static ScanStateManager_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScanStateManager newInstance() {
    return new ScanStateManager();
  }

  private static final class InstanceHolder {
    static final ScanStateManager_Factory INSTANCE = new ScanStateManager_Factory();
  }
}
