package app.rolla.bluetoothSdk.connect.timeout;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class EarlyConnectTimeoutManager_Factory implements Factory<EarlyConnectTimeoutManager> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private EarlyConnectTimeoutManager_Factory(Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public EarlyConnectTimeoutManager get() {
    return newInstance(bleScopeContextProvider.get());
  }

  public static EarlyConnectTimeoutManager_Factory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new EarlyConnectTimeoutManager_Factory(bleScopeContextProvider);
  }

  public static EarlyConnectTimeoutManager newInstance(CoroutineContext bleScopeContext) {
    return new EarlyConnectTimeoutManager(bleScopeContext);
  }
}
