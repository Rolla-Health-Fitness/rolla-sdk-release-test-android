package app.rolla.bluetoothSdk.characteristics;

import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RollaBandWriteCharacteristic_Factory implements Factory<RollaBandWriteCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<RollaBandImpl> rollaBandImplProvider;

  private RollaBandWriteCharacteristic_Factory(Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.rollaBandImplProvider = rollaBandImplProvider;
  }

  @Override
  public RollaBandWriteCharacteristic get() {
    return newInstance(bleScopeContextProvider.get(), rollaBandImplProvider.get());
  }

  public static RollaBandWriteCharacteristic_Factory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    return new RollaBandWriteCharacteristic_Factory(bleScopeContextProvider, rollaBandImplProvider);
  }

  public static RollaBandWriteCharacteristic newInstance(CoroutineContext bleScopeContext,
      RollaBandImpl rollaBandImpl) {
    return new RollaBandWriteCharacteristic(bleScopeContext, rollaBandImpl);
  }
}
