package app.rolla.bluetoothSdk.services;

import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic;
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceInformationService_Factory implements Factory<DeviceInformationService> {
  private final Provider<SerialNumberCharacteristic> serialNumberCharacteristicProvider;

  private final Provider<FirmwareRevisionCharacteristic> firmwareRevisionCharacteristicProvider;

  private DeviceInformationService_Factory(
      Provider<SerialNumberCharacteristic> serialNumberCharacteristicProvider,
      Provider<FirmwareRevisionCharacteristic> firmwareRevisionCharacteristicProvider) {
    this.serialNumberCharacteristicProvider = serialNumberCharacteristicProvider;
    this.firmwareRevisionCharacteristicProvider = firmwareRevisionCharacteristicProvider;
  }

  @Override
  public DeviceInformationService get() {
    return newInstance(serialNumberCharacteristicProvider.get(), firmwareRevisionCharacteristicProvider.get());
  }

  public static DeviceInformationService_Factory create(
      Provider<SerialNumberCharacteristic> serialNumberCharacteristicProvider,
      Provider<FirmwareRevisionCharacteristic> firmwareRevisionCharacteristicProvider) {
    return new DeviceInformationService_Factory(serialNumberCharacteristicProvider, firmwareRevisionCharacteristicProvider);
  }

  public static DeviceInformationService newInstance(
      SerialNumberCharacteristic serialNumberCharacteristic,
      FirmwareRevisionCharacteristic firmwareRevisionCharacteristic) {
    return new DeviceInformationService(serialNumberCharacteristic, firmwareRevisionCharacteristic);
  }
}
