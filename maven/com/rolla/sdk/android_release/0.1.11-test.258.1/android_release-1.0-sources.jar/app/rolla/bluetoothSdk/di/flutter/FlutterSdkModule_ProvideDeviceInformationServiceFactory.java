package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic;
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic;
import app.rolla.bluetoothSdk.services.DeviceInformationService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDeviceInformationServiceFactory implements Factory<DeviceInformationService> {
  private final Provider<SerialNumberCharacteristic> serialNumberCharacteristicProvider;

  private final Provider<FirmwareRevisionCharacteristic> firmwareRevisionCharacteristicProvider;

  private FlutterSdkModule_ProvideDeviceInformationServiceFactory(
      Provider<SerialNumberCharacteristic> serialNumberCharacteristicProvider,
      Provider<FirmwareRevisionCharacteristic> firmwareRevisionCharacteristicProvider) {
    this.serialNumberCharacteristicProvider = serialNumberCharacteristicProvider;
    this.firmwareRevisionCharacteristicProvider = firmwareRevisionCharacteristicProvider;
  }

  @Override
  public DeviceInformationService get() {
    return provideDeviceInformationService(serialNumberCharacteristicProvider.get(), firmwareRevisionCharacteristicProvider.get());
  }

  public static FlutterSdkModule_ProvideDeviceInformationServiceFactory create(
      Provider<SerialNumberCharacteristic> serialNumberCharacteristicProvider,
      Provider<FirmwareRevisionCharacteristic> firmwareRevisionCharacteristicProvider) {
    return new FlutterSdkModule_ProvideDeviceInformationServiceFactory(serialNumberCharacteristicProvider, firmwareRevisionCharacteristicProvider);
  }

  public static DeviceInformationService provideDeviceInformationService(
      SerialNumberCharacteristic serialNumberCharacteristic,
      FirmwareRevisionCharacteristic firmwareRevisionCharacteristic) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDeviceInformationService(serialNumberCharacteristic, firmwareRevisionCharacteristic));
  }
}
