package app.rolla.bluetoothSdk.di.flutter;

import android.content.Context;
import app.rolla.bluetoothSdk.connect.OperationQueue;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideOperationQueueFactory implements Factory<OperationQueue> {
  private final Provider<Context> contextProvider;

  private FlutterSdkModule_ProvideOperationQueueFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public OperationQueue get() {
    return provideOperationQueue(contextProvider.get());
  }

  public static FlutterSdkModule_ProvideOperationQueueFactory create(
      Provider<Context> contextProvider) {
    return new FlutterSdkModule_ProvideOperationQueueFactory(contextProvider);
  }

  public static OperationQueue provideOperationQueue(Context context) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideOperationQueue(context));
  }
}
