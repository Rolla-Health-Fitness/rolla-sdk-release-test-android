package app.rolla.bluetoothSdk.result.error

class UnsupportedDeviceTypes(throwable: Throwable? = null) : Error (
    code = ErrorCodes.UNSUPPORTED_DEVICE_TYPES,
    message = "Some device types are not supported",
    exception = throwable
)