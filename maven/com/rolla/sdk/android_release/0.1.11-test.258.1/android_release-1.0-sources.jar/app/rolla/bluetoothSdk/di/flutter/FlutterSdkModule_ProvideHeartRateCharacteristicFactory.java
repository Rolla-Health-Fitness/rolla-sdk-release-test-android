package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideHeartRateCharacteristicFactory implements Factory<HeartRateCharacteristic> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideHeartRateCharacteristicFactory(
      Provider<CoroutineContext> coroutineContextProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public HeartRateCharacteristic get() {
    return provideHeartRateCharacteristic(coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideHeartRateCharacteristicFactory create(
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideHeartRateCharacteristicFactory(coroutineContextProvider);
  }

  public static HeartRateCharacteristic provideHeartRateCharacteristic(
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideHeartRateCharacteristic(coroutineContext));
  }
}
