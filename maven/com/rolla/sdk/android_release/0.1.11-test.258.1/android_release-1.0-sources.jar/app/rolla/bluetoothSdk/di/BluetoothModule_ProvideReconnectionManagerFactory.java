package app.rolla.bluetoothSdk.di;

import android.bluetooth.BluetoothAdapter;
import app.rolla.bluetoothSdk.connect.reconnect.AutoReconnectStrategy;
import app.rolla.bluetoothSdk.connect.reconnect.FirstConnectionRetryStrategy;
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BluetoothModule_ProvideReconnectionManagerFactory implements Factory<ReconnectionManager> {
  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<FirstConnectionRetryStrategy> firstConnectionRetryStrategyProvider;

  private final Provider<AutoReconnectStrategy> autoReconnectStrategyProvider;

  private BluetoothModule_ProvideReconnectionManagerFactory(
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<FirstConnectionRetryStrategy> firstConnectionRetryStrategyProvider,
      Provider<AutoReconnectStrategy> autoReconnectStrategyProvider) {
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.firstConnectionRetryStrategyProvider = firstConnectionRetryStrategyProvider;
    this.autoReconnectStrategyProvider = autoReconnectStrategyProvider;
  }

  @Override
  public ReconnectionManager get() {
    return provideReconnectionManager(bluetoothAdapterProvider.get(), firstConnectionRetryStrategyProvider.get(), autoReconnectStrategyProvider.get());
  }

  public static BluetoothModule_ProvideReconnectionManagerFactory create(
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<FirstConnectionRetryStrategy> firstConnectionRetryStrategyProvider,
      Provider<AutoReconnectStrategy> autoReconnectStrategyProvider) {
    return new BluetoothModule_ProvideReconnectionManagerFactory(bluetoothAdapterProvider, firstConnectionRetryStrategyProvider, autoReconnectStrategyProvider);
  }

  public static ReconnectionManager provideReconnectionManager(
      @Nullable BluetoothAdapter bluetoothAdapter,
      FirstConnectionRetryStrategy firstConnectionRetryStrategy,
      AutoReconnectStrategy autoReconnectStrategy) {
    return Preconditions.checkNotNullFromProvides(BluetoothModule.INSTANCE.provideReconnectionManager(bluetoothAdapter, firstConnectionRetryStrategy, autoReconnectStrategy));
  }
}
