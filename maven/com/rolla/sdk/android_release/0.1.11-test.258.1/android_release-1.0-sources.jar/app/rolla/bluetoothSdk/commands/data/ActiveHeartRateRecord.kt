package app.rolla.bluetoothSdk.commands.data

import app.rolla.bluetoothSdk.utils.BcdTime

data class ActiveHeartRateRecord(
    val dataNumber: Int,
    val bcdTime: BcdTime,
    val timeInMilliseconds: Long,
    val offset: Int
)