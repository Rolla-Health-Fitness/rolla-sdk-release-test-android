package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic;
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ServiceModule_ProvideRunningSpeedAndCadenceServiceFactory implements Factory<RunningSpeedAndCadenceService> {
  private final Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider;

  private ServiceModule_ProvideRunningSpeedAndCadenceServiceFactory(
      Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider) {
    this.runningSpeedCadenceCharacteristicProvider = runningSpeedCadenceCharacteristicProvider;
  }

  @Override
  public RunningSpeedAndCadenceService get() {
    return provideRunningSpeedAndCadenceService(runningSpeedCadenceCharacteristicProvider.get());
  }

  public static ServiceModule_ProvideRunningSpeedAndCadenceServiceFactory create(
      Provider<RunningSpeedCadenceCharacteristic> runningSpeedCadenceCharacteristicProvider) {
    return new ServiceModule_ProvideRunningSpeedAndCadenceServiceFactory(runningSpeedCadenceCharacteristicProvider);
  }

  public static RunningSpeedAndCadenceService provideRunningSpeedAndCadenceService(
      RunningSpeedCadenceCharacteristic runningSpeedCadenceCharacteristic) {
    return Preconditions.checkNotNullFromProvides(ServiceModule.INSTANCE.provideRunningSpeedAndCadenceService(runningSpeedCadenceCharacteristic));
  }
}
