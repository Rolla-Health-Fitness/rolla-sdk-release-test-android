package app.rolla.bluetoothSdk.services;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceFirmwareUpdateService_Factory implements Factory<DeviceFirmwareUpdateService> {
  @Override
  public DeviceFirmwareUpdateService get() {
    return newInstance();
  }

  public static DeviceFirmwareUpdateService_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DeviceFirmwareUpdateService newInstance() {
    return new DeviceFirmwareUpdateService();
  }

  private static final class InstanceHolder {
    static final DeviceFirmwareUpdateService_Factory INSTANCE = new DeviceFirmwareUpdateService_Factory();
  }
}
