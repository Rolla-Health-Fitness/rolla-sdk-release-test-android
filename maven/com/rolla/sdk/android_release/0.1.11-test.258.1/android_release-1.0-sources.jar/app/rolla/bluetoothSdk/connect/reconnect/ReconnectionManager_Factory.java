package app.rolla.bluetoothSdk.connect.reconnect;

import android.bluetooth.BluetoothAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ReconnectionManager_Factory implements Factory<ReconnectionManager> {
  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<FirstConnectionRetryStrategy> firstConnectionRetryStrategyProvider;

  private final Provider<AutoReconnectStrategy> autoReconnectStrategyProvider;

  private ReconnectionManager_Factory(Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<FirstConnectionRetryStrategy> firstConnectionRetryStrategyProvider,
      Provider<AutoReconnectStrategy> autoReconnectStrategyProvider) {
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.firstConnectionRetryStrategyProvider = firstConnectionRetryStrategyProvider;
    this.autoReconnectStrategyProvider = autoReconnectStrategyProvider;
  }

  @Override
  public ReconnectionManager get() {
    return newInstance(bluetoothAdapterProvider.get(), firstConnectionRetryStrategyProvider.get(), autoReconnectStrategyProvider.get());
  }

  public static ReconnectionManager_Factory create(
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<FirstConnectionRetryStrategy> firstConnectionRetryStrategyProvider,
      Provider<AutoReconnectStrategy> autoReconnectStrategyProvider) {
    return new ReconnectionManager_Factory(bluetoothAdapterProvider, firstConnectionRetryStrategyProvider, autoReconnectStrategyProvider);
  }

  public static ReconnectionManager newInstance(@Nullable BluetoothAdapter bluetoothAdapter,
      FirstConnectionRetryStrategy firstConnectionRetryStrategy,
      AutoReconnectStrategy autoReconnectStrategy) {
    return new ReconnectionManager(bluetoothAdapter, firstConnectionRetryStrategy, autoReconnectStrategy);
  }
}
