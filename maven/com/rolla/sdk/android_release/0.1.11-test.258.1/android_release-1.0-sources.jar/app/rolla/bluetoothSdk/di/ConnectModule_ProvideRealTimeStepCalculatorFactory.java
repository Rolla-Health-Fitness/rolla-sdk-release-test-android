package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ConnectModule_ProvideRealTimeStepCalculatorFactory implements Factory<RealTimeStepCalculator> {
  @Override
  public RealTimeStepCalculator get() {
    return provideRealTimeStepCalculator();
  }

  public static ConnectModule_ProvideRealTimeStepCalculatorFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static RealTimeStepCalculator provideRealTimeStepCalculator() {
    return Preconditions.checkNotNullFromProvides(ConnectModule.INSTANCE.provideRealTimeStepCalculator());
  }

  private static final class InstanceHolder {
    static final ConnectModule_ProvideRealTimeStepCalculatorFactory INSTANCE = new ConnectModule_ProvideRealTimeStepCalculatorFactory();
  }
}
