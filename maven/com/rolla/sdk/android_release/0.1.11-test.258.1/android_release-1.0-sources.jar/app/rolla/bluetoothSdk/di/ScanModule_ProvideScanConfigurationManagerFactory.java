package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.scan.manager.ScanConfigurationManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanModule_ProvideScanConfigurationManagerFactory implements Factory<ScanConfigurationManager> {
  @Override
  public ScanConfigurationManager get() {
    return provideScanConfigurationManager();
  }

  public static ScanModule_ProvideScanConfigurationManagerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScanConfigurationManager provideScanConfigurationManager() {
    return Preconditions.checkNotNullFromProvides(ScanModule.INSTANCE.provideScanConfigurationManager());
  }

  private static final class InstanceHolder {
    static final ScanModule_ProvideScanConfigurationManagerFactory INSTANCE = new ScanModule_ProvideScanConfigurationManagerFactory();
  }
}
