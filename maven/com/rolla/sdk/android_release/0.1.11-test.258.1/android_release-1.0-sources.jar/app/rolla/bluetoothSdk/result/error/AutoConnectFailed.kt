package app.rolla.bluetoothSdk.result.error

class AutoConnectFailed : Error (
    code = ErrorCodes.AUTO_CONNECT_FAILED,
    message = "Auto connect failed"
)