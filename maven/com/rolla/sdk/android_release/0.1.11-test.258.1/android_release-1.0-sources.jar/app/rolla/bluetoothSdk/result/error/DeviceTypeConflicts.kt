package app.rolla.bluetoothSdk.result.error

class DeviceTypeConflicts(throwable: Throwable? = null) : Error (
    code = ErrorCodes.DEVICE_TYPE_CONFLICTS,
    message = "Device type conflicts",
    exception = throwable
)