package app.rolla.bluetoothSdk.connect.timeout

import app.rolla.bluetoothSdk.di.BleScopeContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class ConnectTimeoutManager @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext
) : TimeoutManager(bleScopeContext) {
    companion object {
        const val TAG = "ConnectTimeoutManager"

        private const val CONNECTION_TIMEOUT_MS = 30_000L // 30 seconds
    }

    override fun getTag(): String = TAG

    override fun getTimeoutMs(): Long = CONNECTION_TIMEOUT_MS
}