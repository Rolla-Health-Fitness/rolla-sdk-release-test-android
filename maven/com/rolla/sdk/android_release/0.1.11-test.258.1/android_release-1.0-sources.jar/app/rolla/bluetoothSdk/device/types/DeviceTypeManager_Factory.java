package app.rolla.bluetoothSdk.device.types;

import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceTypeManager_Factory implements Factory<DeviceTypeManager> {
  private final Provider<DeviceStorageManager> storageManagerProvider;

  private DeviceTypeManager_Factory(Provider<DeviceStorageManager> storageManagerProvider) {
    this.storageManagerProvider = storageManagerProvider;
  }

  @Override
  public DeviceTypeManager get() {
    return newInstance(storageManagerProvider.get());
  }

  public static DeviceTypeManager_Factory create(
      Provider<DeviceStorageManager> storageManagerProvider) {
    return new DeviceTypeManager_Factory(storageManagerProvider);
  }

  public static DeviceTypeManager newInstance(DeviceStorageManager storageManager) {
    return new DeviceTypeManager(storageManager);
  }
}
