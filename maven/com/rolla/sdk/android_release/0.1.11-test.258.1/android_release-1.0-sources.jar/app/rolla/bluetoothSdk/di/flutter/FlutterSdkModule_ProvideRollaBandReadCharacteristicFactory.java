package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRollaBandReadCharacteristicFactory implements Factory<RollaBandReadCharacteristic> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<RollaBandImpl> rollaBandImplProvider;

  private FlutterSdkModule_ProvideRollaBandReadCharacteristicFactory(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
    this.rollaBandImplProvider = rollaBandImplProvider;
  }

  @Override
  public RollaBandReadCharacteristic get() {
    return provideRollaBandReadCharacteristic(coroutineContextProvider.get(), rollaBandImplProvider.get());
  }

  public static FlutterSdkModule_ProvideRollaBandReadCharacteristicFactory create(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    return new FlutterSdkModule_ProvideRollaBandReadCharacteristicFactory(coroutineContextProvider, rollaBandImplProvider);
  }

  public static RollaBandReadCharacteristic provideRollaBandReadCharacteristic(
      CoroutineContext coroutineContext, RollaBandImpl rollaBandImpl) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRollaBandReadCharacteristic(coroutineContext, rollaBandImpl));
  }
}
