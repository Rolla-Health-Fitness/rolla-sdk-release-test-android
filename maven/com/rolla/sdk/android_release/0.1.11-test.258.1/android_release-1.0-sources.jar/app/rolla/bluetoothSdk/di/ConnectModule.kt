package app.rolla.bluetoothSdk.di

import android.bluetooth.BluetoothAdapter
import android.content.Context
import app.rolla.bluetoothSdk.BleRegistry
import app.rolla.bluetoothSdk.connect.OperationQueue
import app.rolla.bluetoothSdk.connect.SubscriptionManager
import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager
import app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager
import app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager
import app.rolla.bluetoothSdk.connect.ConnectionManager
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager
import app.rolla.bluetoothSdk.device.DeviceManager
import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineScope

@Module
@InstallIn(SingletonComponent::class)
object ConnectModule {

    @Provides
    @Singleton
    fun provideGattCallbackHandler(
        @ApplicationContext context: Context,
        @BleScopeContext bleScopeContext: CoroutineContext,
        bluetoothAdapter: BluetoothAdapter?,
        deviceManager: DeviceManager,
        operationQueue: OperationQueue,
        subscriptionManager: SubscriptionManager,
        bleRegistry: BleRegistry,
        earlyConnectTimeoutManager: EarlyConnectTimeoutManager,
        connectTimeoutManager: ConnectTimeoutManager,
        disconnectTimeoutManager: DisconnectTimeoutManager,
        reconnectionManager: ReconnectionManager
    ): ConnectionManager = ConnectionManager(context, bleScopeContext, bluetoothAdapter, deviceManager, operationQueue, subscriptionManager, bleRegistry, earlyConnectTimeoutManager, connectTimeoutManager, disconnectTimeoutManager, reconnectionManager)

    @Provides
    @Singleton
    fun provideConnectTimeoutManager(
        @BleScopeContext bleScopeContext: CoroutineContext
    ): ConnectTimeoutManager = ConnectTimeoutManager(bleScopeContext)

    @Provides
    @Singleton
    fun provideEarlyConnectTimeoutManager(
        @BleScopeContext bleScopeContext: CoroutineContext
    ): EarlyConnectTimeoutManager = EarlyConnectTimeoutManager(bleScopeContext)

    @Provides
    @Singleton
    fun provideDisconnectTimeoutManager(
        @BleScopeContext bleScopeContext: CoroutineContext
    ): DisconnectTimeoutManager = DisconnectTimeoutManager(bleScopeContext)

    @Provides
    @Singleton
    fun provideSubscriptionManager(
        @BleScopeContext bleScopeContext: CoroutineContext,
        @ApplicationContext context: Context,
        operationQueue: OperationQueue,
        bleRegistry: BleRegistry
    ): SubscriptionManager = SubscriptionManager(bleScopeContext, context, operationQueue, bleRegistry)

    @Provides
    @Singleton
    fun provideRealTimeStepCalculator(): RealTimeStepCalculator = RealTimeStepCalculator()

}