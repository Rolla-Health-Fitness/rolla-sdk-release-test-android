package app.rolla.bluetoothSdk.services

import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic
import app.rolla.bluetoothSdk.utils.getFullUUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeviceInformationService @Inject constructor(
    private val serialNumberCharacteristic: SerialNumberCharacteristic,
    private val firmwareRevisionCharacteristic: FirmwareRevisionCharacteristic
) : Service {
    override val uuid: String = "180A".getFullUUID()
    override val characteristics: List<Characteristic> = listOf(serialNumberCharacteristic, firmwareRevisionCharacteristic)

    fun getSerialNumberCharacteristic(): SerialNumberCharacteristic {
        return serialNumberCharacteristic
    }

    fun getFirmwareRevisionCharacteristic(): FirmwareRevisionCharacteristic {
        return firmwareRevisionCharacteristic
    }
}