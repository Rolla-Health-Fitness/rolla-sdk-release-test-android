package app.rolla.bluetoothSdk.result.error

class OtaAlreadyInProgress : Error (
    code = ErrorCodes.OTA_ALREADY_IN_PROGRESS,
    message = "OTA already in progress"
)

