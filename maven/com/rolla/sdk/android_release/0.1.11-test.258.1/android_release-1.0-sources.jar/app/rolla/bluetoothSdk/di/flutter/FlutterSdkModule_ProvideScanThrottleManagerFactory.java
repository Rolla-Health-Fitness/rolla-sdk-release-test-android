package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.scan.manager.ScanThrottleManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideScanThrottleManagerFactory implements Factory<ScanThrottleManager> {
  @Override
  public ScanThrottleManager get() {
    return provideScanThrottleManager();
  }

  public static FlutterSdkModule_ProvideScanThrottleManagerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScanThrottleManager provideScanThrottleManager() {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideScanThrottleManager());
  }

  private static final class InstanceHolder {
    static final FlutterSdkModule_ProvideScanThrottleManagerFactory INSTANCE = new FlutterSdkModule_ProvideScanThrottleManagerFactory();
  }
}
