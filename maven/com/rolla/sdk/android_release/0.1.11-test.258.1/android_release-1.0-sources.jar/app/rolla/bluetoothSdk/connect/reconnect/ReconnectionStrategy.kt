package app.rolla.bluetoothSdk.connect.reconnect

import app.rolla.bluetoothSdk.device.BleDevice

interface ReconnectionStrategy {
    fun shouldReconnect(device: BleDevice, status: Int): Boolean
    fun startReconnection(device: BleDevice, status: Int, onReconnect: (BleDevice) -> Unit, onFinalFailure: (BleDevice) -> Unit)
    fun cancelReconnection(deviceAddress: String)
    fun cleanup()
}