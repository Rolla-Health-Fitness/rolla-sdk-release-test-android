package app.rolla.bluetoothSdk.characteristics

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.InvalidEncoding
import app.rolla.bluetoothSdk.characteristics.data.SerialNumberData
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class SerialNumberCharacteristic @Inject constructor(
    @BleScopeContext bleScopeContext: CoroutineContext
) : Characteristic {

    companion object {
        private const val TAG = "SerialNumberCharacteristic"
    }

    override val uuid: String = "2A25".getFullUUID()
    override val scope = CoroutineScope(bleScopeContext)


    private val _dataFlow = MutableSharedFlow<SerialNumberData>(replay = 1)
    val dataFlow: SharedFlow<SerialNumberData> = _dataFlow.asSharedFlow()

    override fun onRead(byteArray: ByteArray, device: BleDevice) {
        processSerialNumberData(byteArray, device)
    }

    private fun processSerialNumberData(byteArray: ByteArray, device: BleDevice) {
        if (byteArray.isEmpty()) {
            onError(device.getMacAddress(), InvalidEncoding(Throwable("Serial number data is empty")))
            return
        }

        try {
            val serialNumber = String(byteArray, Charsets.UTF_8).trim()
            log(TAG, "Serial Number: $serialNumber")
            onSuccess(SerialNumberData(device.getMacAddress(), serialNumber))
        } catch (e: Exception) {
            onError(device.getMacAddress(), InvalidEncoding(e))
        }
    }

    fun onSuccess(data: SerialNumberData) {
        scope.launch {
            _dataFlow.emit(data)
        }
    }

    override fun onError(deviceAddress: String, error: Error, value: ByteArray?) {
        scope.launch {
            _dataFlow.emit(SerialNumberData(deviceAddress, "", error))
        }
    }
}