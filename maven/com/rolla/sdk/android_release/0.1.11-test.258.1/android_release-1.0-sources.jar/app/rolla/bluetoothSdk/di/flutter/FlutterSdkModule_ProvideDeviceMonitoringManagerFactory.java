package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager;
import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDeviceMonitoringManagerFactory implements Factory<DeviceMonitoringManager> {
  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private final Provider<DeviceStateManager> deviceStateManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideDeviceMonitoringManagerFactory(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
    this.deviceStateManagerProvider = deviceStateManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DeviceMonitoringManager get() {
    return provideDeviceMonitoringManager(deviceStorageManagerProvider.get(), deviceStateManagerProvider.get(), coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideDeviceMonitoringManagerFactory create(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideDeviceMonitoringManagerFactory(deviceStorageManagerProvider, deviceStateManagerProvider, coroutineContextProvider);
  }

  public static DeviceMonitoringManager provideDeviceMonitoringManager(
      DeviceStorageManager deviceStorageManager, DeviceStateManager deviceStateManager,
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDeviceMonitoringManager(deviceStorageManager, deviceStateManager, coroutineContext));
  }
}
