package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceModule_ProvideDeviceStateManagerFactory implements Factory<DeviceStateManager> {
  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private DeviceModule_ProvideDeviceStateManagerFactory(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DeviceStateManager get() {
    return provideDeviceStateManager(deviceStorageManagerProvider.get(), coroutineContextProvider.get());
  }

  public static DeviceModule_ProvideDeviceStateManagerFactory create(
      Provider<DeviceStorageManager> deviceStorageManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new DeviceModule_ProvideDeviceStateManagerFactory(deviceStorageManagerProvider, coroutineContextProvider);
  }

  public static DeviceStateManager provideDeviceStateManager(
      DeviceStorageManager deviceStorageManager, CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(DeviceModule.INSTANCE.provideDeviceStateManager(deviceStorageManager, coroutineContext));
  }
}
