package app.rolla.bluetoothSdk.result.error

class OperationAlreadyInProgress(operationName: String) : Error (
    code = ErrorCodes.OPERATION_ALREADY_IN_PROGRESS,
    message = "$operationName already in progress"
)