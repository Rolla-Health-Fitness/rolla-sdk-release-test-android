package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic;
import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRunningSpeedCadenceCharacteristicFactory implements Factory<RunningSpeedCadenceCharacteristic> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<RealTimeStepCalculator> realTimeStepCalculatorProvider;

  private FlutterSdkModule_ProvideRunningSpeedCadenceCharacteristicFactory(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<RealTimeStepCalculator> realTimeStepCalculatorProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
    this.realTimeStepCalculatorProvider = realTimeStepCalculatorProvider;
  }

  @Override
  public RunningSpeedCadenceCharacteristic get() {
    return provideRunningSpeedCadenceCharacteristic(coroutineContextProvider.get(), realTimeStepCalculatorProvider.get());
  }

  public static FlutterSdkModule_ProvideRunningSpeedCadenceCharacteristicFactory create(
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<RealTimeStepCalculator> realTimeStepCalculatorProvider) {
    return new FlutterSdkModule_ProvideRunningSpeedCadenceCharacteristicFactory(coroutineContextProvider, realTimeStepCalculatorProvider);
  }

  public static RunningSpeedCadenceCharacteristic provideRunningSpeedCadenceCharacteristic(
      CoroutineContext coroutineContext, RealTimeStepCalculator realTimeStepCalculator) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRunningSpeedCadenceCharacteristic(coroutineContext, realTimeStepCalculator));
  }
}
