package app.rolla.bluetoothSdk.commands

/**
 * When true, legacy 14-byte motion records are **skipped** (not surfaced to the app) but still consumed
 * so BLE paging does not stall after OTA.
 *
 * Recognises:
 * - `14.01.2026` (DD.MM.YYYY)
 * - `V_30353938-260114` (suffix **YYMMDD** after the last `-`, same style as [GetUserData])
 */
internal object MotionSecondLevelFirmware {
    private val dayMonthYear = Regex("""(?:^|[^\d])(\d{2})\.(\d{2})\.(\d{4})(?:[^\d]|$)""")
    private val yyMMddSuffix = Regex("""-(\d{6})$""")

    fun isSupported(version: String?): Boolean {
        if (version.isNullOrBlank()) return false
        val v = version.trim()
        val ymd = parseYearMonthDay(v) ?: return false
        val (year, month, day) = ymd
        return when {
            year > 2026 -> true
            year == 2026 && month > 1 -> true
            year == 2026 && month == 1 && day >= 14 -> true
            else -> false
        }
    }

    private fun parseYearMonthDay(version: String): Triple<Int, Int, Int>? {
        dayMonthYear.find(version)?.let { m ->
            val day = m.groupValues[1].toIntOrNull() ?: return null
            val month = m.groupValues[2].toIntOrNull() ?: return null
            val year = m.groupValues[3].toIntOrNull() ?: return null
            return Triple(year, month, day)
        }
        yyMMddSuffix.find(version)?.let { m ->
            val s = m.groupValues[1]
            if (s.length != 6) return null
            val yy = s.substring(0, 2).toIntOrNull() ?: return null
            val mm = s.substring(2, 4).toIntOrNull() ?: return null
            val dd = s.substring(4, 6).toIntOrNull() ?: return null
            return Triple(2000 + yy, mm, dd)
        }
        return null
    }
}
