package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDisconnectTimeoutManagerFactory implements Factory<DisconnectTimeoutManager> {
  private final Provider<CoroutineContext> coroutineContextProvider;

  private FlutterSdkModule_ProvideDisconnectTimeoutManagerFactory(
      Provider<CoroutineContext> coroutineContextProvider) {
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DisconnectTimeoutManager get() {
    return provideDisconnectTimeoutManager(coroutineContextProvider.get());
  }

  public static FlutterSdkModule_ProvideDisconnectTimeoutManagerFactory create(
      Provider<CoroutineContext> coroutineContextProvider) {
    return new FlutterSdkModule_ProvideDisconnectTimeoutManagerFactory(coroutineContextProvider);
  }

  public static DisconnectTimeoutManager provideDisconnectTimeoutManager(
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDisconnectTimeoutManager(coroutineContext));
  }
}
