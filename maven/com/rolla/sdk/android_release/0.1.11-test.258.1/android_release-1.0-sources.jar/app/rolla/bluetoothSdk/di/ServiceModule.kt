package app.rolla.bluetoothSdk.di

import app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService
import app.rolla.bluetoothSdk.services.DeviceInformationService
import app.rolla.bluetoothSdk.services.HeartRateService
import app.rolla.bluetoothSdk.services.RollaBandService
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService
import app.rolla.bluetoothSdk.BleRegistry
import app.rolla.bluetoothSdk.characteristics.FirmwareRevisionCharacteristic
import app.rolla.bluetoothSdk.characteristics.HeartRateCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic
import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic
import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ServiceModule {

    @Provides
    @Singleton
    fun provideDeviceInformationService(
        serialNumberCharacteristic: SerialNumberCharacteristic,
        firmwareRevisionCharacteristic: FirmwareRevisionCharacteristic
    ): DeviceInformationService = DeviceInformationService(serialNumberCharacteristic, firmwareRevisionCharacteristic)

    @Provides
    @Singleton
    fun provideDeviceFirmwareUpdateService(): DeviceFirmwareUpdateService = DeviceFirmwareUpdateService()

    @Provides
    @Singleton
    fun provideRollaBandService(
        rollaBandReadCharacteristic: RollaBandReadCharacteristic,
        rollaBandWriteCharacteristic: RollaBandWriteCharacteristic
    ): RollaBandService = RollaBandService(rollaBandReadCharacteristic, rollaBandWriteCharacteristic)

    @Provides
    @Singleton
    fun provideHeartRateService(
        heartRateCharacteristic: HeartRateCharacteristic
    ): HeartRateService = HeartRateService(heartRateCharacteristic)

    @Provides
    @Singleton
    fun provideRunningSpeedAndCadenceService(
        runningSpeedCadenceCharacteristic: RunningSpeedCadenceCharacteristic
    ): RunningSpeedAndCadenceService = RunningSpeedAndCadenceService(runningSpeedCadenceCharacteristic)

    @Provides
    @Singleton
    fun provideServiceRegistry(
        heartRateService: HeartRateService,
        runningSpeedAndCadenceService: RunningSpeedAndCadenceService,
        rollaBandService: RollaBandService,
        deviceInformationService: DeviceInformationService,
        deviceFirmwareUpdateService: DeviceFirmwareUpdateService
    ): BleRegistry = BleRegistry(heartRateService, runningSpeedAndCadenceService, rollaBandService, deviceInformationService, deviceFirmwareUpdateService)
}