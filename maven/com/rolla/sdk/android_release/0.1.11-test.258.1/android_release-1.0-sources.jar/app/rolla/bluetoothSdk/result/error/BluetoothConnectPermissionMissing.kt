package app.rolla.bluetoothSdk.result.error

class BluetoothConnectPermissionMissing(throwable: Throwable? = null) : Error (
    code = ErrorCodes.BLUETOOTH_CONNECT_PERMISSION_MISSING,
    message = "Bluetooth connect permission is missing",
    exception = throwable
)