package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.result.error.Error

data class FirmwareRevisionData(
    val uuid: String,
    val firmwareVersion: String,
    val error: Error? = null
) {
    override fun toString(): String {
        return "FirmwareRevision(uuid=$uuid, firmwareVersion=$firmwareVersion, error=$error)"
    }
}