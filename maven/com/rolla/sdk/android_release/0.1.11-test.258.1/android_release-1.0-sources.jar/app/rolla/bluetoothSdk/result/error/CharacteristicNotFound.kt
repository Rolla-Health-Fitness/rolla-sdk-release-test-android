package app.rolla.bluetoothSdk.result.error

class CharacteristicNotFound : Error (
    code = ErrorCodes.CHARACTERISTIC_NOT_FOUND,
    message = "Characteristic not found"
)