package app.rolla.bluetoothSdk.connect.timeout

import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.collections.set
import kotlin.coroutines.CoroutineContext

abstract class TimeoutManager(
    @BleScopeContext bleScopeContext: CoroutineContext
) {

    abstract fun getTag(): String
    abstract fun getTimeoutMs(): Long

    private val timeoutScope = CoroutineScope(bleScopeContext)

    private val timeoutJobs = ConcurrentHashMap<String, Job>()

    /**
     * Start timeout monitoring
     */
    fun startTimeout(deviceAddress: String, onTimeout: (String) -> Unit) {
        // Cancel existing timeout if any
        timeoutJobs[deviceAddress]?.cancel()

        val timeoutJob = timeoutScope.launch {
            try {
                delay(getTimeoutMs())
                log(getTag(), "Timeout for device: $deviceAddress")
                onTimeout(deviceAddress)
            } catch (e: Exception) {
                log(getTag(), "Timeout job error for $deviceAddress: ${e.message}")
            } finally {
                timeoutJobs.remove(deviceAddress)
            }
        }

        timeoutJobs[deviceAddress] = timeoutJob
        log(getTag(), "Started timeout for device: $deviceAddress")
    }

    fun cancelTimeout(deviceAddress: String) {
        timeoutJobs[deviceAddress]?.cancel()
        timeoutJobs.remove(deviceAddress)
        log(getTag(), "Cancelled timeout for device: $deviceAddress")
    }

    fun clear() {
        timeoutJobs.values.forEach { it.cancel() }
        timeoutJobs.clear()
    }
}