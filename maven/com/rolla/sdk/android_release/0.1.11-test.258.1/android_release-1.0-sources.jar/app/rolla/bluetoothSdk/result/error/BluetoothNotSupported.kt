package app.rolla.bluetoothSdk.result.error

/**
 * Error class for when Bluetooth is not supported
 */
class BluetoothNotSupported : Error (
    code = ErrorCodes.BLUETOOTH_NOT_SUPPORTED,
    message = "Bluetooth is not supported"
)