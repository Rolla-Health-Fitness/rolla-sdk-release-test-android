package app.rolla.bluetoothSdk.di;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import app.rolla.bluetoothSdk.scan.manager.ScanConfigurationManager;
import app.rolla.bluetoothSdk.scan.manager.ScanOperationManager;
import app.rolla.bluetoothSdk.scan.manager.ScanStateManager;
import app.rolla.bluetoothSdk.scan.manager.ScanThrottleManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanModule_ProvideScanOperationManagerFactory implements Factory<ScanOperationManager> {
  private final Provider<Context> contextProvider;

  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<ScanStateManager> stateManagerProvider;

  private final Provider<ScanThrottleManager> throttleManagerProvider;

  private final Provider<ScanConfigurationManager> configManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private ScanModule_ProvideScanOperationManagerFactory(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanStateManager> stateManagerProvider,
      Provider<ScanThrottleManager> throttleManagerProvider,
      Provider<ScanConfigurationManager> configManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.contextProvider = contextProvider;
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.stateManagerProvider = stateManagerProvider;
    this.throttleManagerProvider = throttleManagerProvider;
    this.configManagerProvider = configManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public ScanOperationManager get() {
    return provideScanOperationManager(contextProvider.get(), bluetoothAdapterProvider.get(), stateManagerProvider.get(), throttleManagerProvider.get(), configManagerProvider.get(), coroutineContextProvider.get());
  }

  public static ScanModule_ProvideScanOperationManagerFactory create(
      Provider<Context> contextProvider, Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanStateManager> stateManagerProvider,
      Provider<ScanThrottleManager> throttleManagerProvider,
      Provider<ScanConfigurationManager> configManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new ScanModule_ProvideScanOperationManagerFactory(contextProvider, bluetoothAdapterProvider, stateManagerProvider, throttleManagerProvider, configManagerProvider, coroutineContextProvider);
  }

  public static ScanOperationManager provideScanOperationManager(Context context,
      @Nullable BluetoothAdapter bluetoothAdapter, ScanStateManager stateManager,
      ScanThrottleManager throttleManager, ScanConfigurationManager configManager,
      CoroutineContext coroutineContext) {
    return Preconditions.checkNotNullFromProvides(ScanModule.INSTANCE.provideScanOperationManager(context, bluetoothAdapter, stateManager, throttleManager, configManager, coroutineContext));
  }
}
