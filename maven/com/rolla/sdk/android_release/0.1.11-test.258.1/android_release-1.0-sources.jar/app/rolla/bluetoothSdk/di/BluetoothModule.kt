package app.rolla.bluetoothSdk.di

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import app.rolla.bluetoothSdk.connect.reconnect.AutoReconnectStrategy
import app.rolla.bluetoothSdk.connect.reconnect.FirstConnectionRetryStrategy
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Module
@InstallIn(SingletonComponent::class)
object BluetoothModule {

    @Provides
    @Singleton
    fun provideBluetoothManager(@ApplicationContext context: Context): BluetoothManager? {
        return context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    }

    @Provides
    @Singleton
    fun provideBluetoothAdapter(bluetoothManager: BluetoothManager?): BluetoothAdapter? {
        return bluetoothManager?.adapter
    }

    @Provides
    @Singleton
    fun provideFirstConnectionRetryStrategy(
        @BleScopeContext context: CoroutineContext
    ): FirstConnectionRetryStrategy = FirstConnectionRetryStrategy(context)

    @Provides
    @Singleton
    fun provideAutoReconnectStrategy(
        @BleScopeContext context: CoroutineContext
    ): AutoReconnectStrategy = AutoReconnectStrategy(context)

    @Provides
    @Singleton
    fun provideReconnectionManager(
        bluetoothAdapter: BluetoothAdapter?,
        firstConnectionRetryStrategy: FirstConnectionRetryStrategy,
        autoReconnectStrategy: AutoReconnectStrategy
    ): ReconnectionManager = ReconnectionManager(bluetoothAdapter, firstConnectionRetryStrategy, autoReconnectStrategy)
}
