package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.device.DeviceManager;
import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager;
import app.rolla.bluetoothSdk.device.state.DeviceStateManager;
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceModule_ProvideDeviceManagerFactory implements Factory<DeviceManager> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<DeviceTypeManager> deviceTypeManagerProvider;

  private final Provider<DeviceMonitoringManager> deviceMonitoringManagerProvider;

  private final Provider<DeviceStateManager> deviceStateManagerProvider;

  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private DeviceModule_ProvideDeviceManagerFactory(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<DeviceTypeManager> deviceTypeManagerProvider,
      Provider<DeviceMonitoringManager> deviceMonitoringManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.deviceTypeManagerProvider = deviceTypeManagerProvider;
    this.deviceMonitoringManagerProvider = deviceMonitoringManagerProvider;
    this.deviceStateManagerProvider = deviceStateManagerProvider;
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
  }

  @Override
  public DeviceManager get() {
    return provideDeviceManager(bleScopeContextProvider.get(), deviceTypeManagerProvider.get(), deviceMonitoringManagerProvider.get(), deviceStateManagerProvider.get(), deviceStorageManagerProvider.get());
  }

  public static DeviceModule_ProvideDeviceManagerFactory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<DeviceTypeManager> deviceTypeManagerProvider,
      Provider<DeviceMonitoringManager> deviceMonitoringManagerProvider,
      Provider<DeviceStateManager> deviceStateManagerProvider,
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    return new DeviceModule_ProvideDeviceManagerFactory(bleScopeContextProvider, deviceTypeManagerProvider, deviceMonitoringManagerProvider, deviceStateManagerProvider, deviceStorageManagerProvider);
  }

  public static DeviceManager provideDeviceManager(CoroutineContext bleScopeContext,
      DeviceTypeManager deviceTypeManager, DeviceMonitoringManager deviceMonitoringManager,
      DeviceStateManager deviceStateManager, DeviceStorageManager deviceStorageManager) {
    return Preconditions.checkNotNullFromProvides(DeviceModule.INSTANCE.provideDeviceManager(bleScopeContext, deviceTypeManager, deviceMonitoringManager, deviceStateManager, deviceStorageManager));
  }
}
