package app.rolla.bluetoothSdk.services

import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic
import app.rolla.bluetoothSdk.utils.getFullUUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RunningSpeedAndCadenceService @Inject constructor(
    private val runningSpeedCadenceCharacteristic: RunningSpeedCadenceCharacteristic
) : Service {
    override val uuid: String = "1814".getFullUUID()
    override val characteristics: List<Characteristic> = listOf(runningSpeedCadenceCharacteristic)

    fun getRunningSpeedCadenceCharacteristic(): RunningSpeedCadenceCharacteristic = runningSpeedCadenceCharacteristic
}