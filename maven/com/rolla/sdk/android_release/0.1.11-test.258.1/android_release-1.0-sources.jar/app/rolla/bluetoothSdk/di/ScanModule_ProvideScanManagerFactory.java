package app.rolla.bluetoothSdk.di;

import android.content.Context;
import app.rolla.bluetoothSdk.scan.manager.ScanConfigurationManager;
import app.rolla.bluetoothSdk.scan.manager.ScanManager;
import app.rolla.bluetoothSdk.scan.manager.ScanOperationManager;
import app.rolla.bluetoothSdk.scan.manager.ScanStateManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanModule_ProvideScanManagerFactory implements Factory<ScanManager> {
  private final Provider<Context> contextProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private final Provider<ScanStateManager> stateManagerProvider;

  private final Provider<ScanConfigurationManager> configManagerProvider;

  private final Provider<ScanOperationManager> operationManagerProvider;

  private ScanModule_ProvideScanManagerFactory(Provider<Context> contextProvider,
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<ScanStateManager> stateManagerProvider,
      Provider<ScanConfigurationManager> configManagerProvider,
      Provider<ScanOperationManager> operationManagerProvider) {
    this.contextProvider = contextProvider;
    this.coroutineContextProvider = coroutineContextProvider;
    this.stateManagerProvider = stateManagerProvider;
    this.configManagerProvider = configManagerProvider;
    this.operationManagerProvider = operationManagerProvider;
  }

  @Override
  public ScanManager get() {
    return provideScanManager(contextProvider.get(), coroutineContextProvider.get(), stateManagerProvider.get(), configManagerProvider.get(), operationManagerProvider.get());
  }

  public static ScanModule_ProvideScanManagerFactory create(Provider<Context> contextProvider,
      Provider<CoroutineContext> coroutineContextProvider,
      Provider<ScanStateManager> stateManagerProvider,
      Provider<ScanConfigurationManager> configManagerProvider,
      Provider<ScanOperationManager> operationManagerProvider) {
    return new ScanModule_ProvideScanManagerFactory(contextProvider, coroutineContextProvider, stateManagerProvider, configManagerProvider, operationManagerProvider);
  }

  public static ScanManager provideScanManager(Context context, CoroutineContext coroutineContext,
      ScanStateManager stateManager, ScanConfigurationManager configManager,
      ScanOperationManager operationManager) {
    return Preconditions.checkNotNullFromProvides(ScanModule.INSTANCE.provideScanManager(context, coroutineContext, stateManager, configManager, operationManager));
  }
}
