package app.rolla.bluetoothSdk.services

import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl
import app.rolla.bluetoothSdk.utils.getFullUUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RollaBandService @Inject constructor(
    private val rollaBandReadCharacteristic: RollaBandReadCharacteristic,
    private val rollaBandWriteCharacteristic: RollaBandWriteCharacteristic
) : Service {
    override val uuid: String = "FFF0".getFullUUID()
    override val characteristics: List<Characteristic> = listOf(
        rollaBandReadCharacteristic,
        rollaBandWriteCharacteristic
    )

    fun getRollaBandWriteCharacteristic(): RollaBandWriteCharacteristic {
        return rollaBandWriteCharacteristic
    }

    fun getRollaBandReadCharacteristic(): RollaBandReadCharacteristic {
        return rollaBandReadCharacteristic
    }

    fun getRollaBandImpl(): RollaBandImpl {
        return rollaBandWriteCharacteristic.rollaBandImpl
    }
}