package app.rolla.bluetoothSdk.result.error

class AlreadyScanning : Error (
    code = ErrorCodes.ALREADY_SCANNING,
    message = "Already scanning"
)