package app.rolla.bluetoothSdk.result.error

class DeviceNotFound : Error (
    code = ErrorCodes.DEVICE_NOT_FOUND,
    message = "Device not found"
)