package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic;
import app.rolla.bluetoothSdk.characteristics.impl.RollaBandImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideRollaBandReadCharacteristicFactory implements Factory<RollaBandReadCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<RollaBandImpl> rollaBandImplProvider;

  private CharacteristicModule_ProvideRollaBandReadCharacteristicFactory(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.rollaBandImplProvider = rollaBandImplProvider;
  }

  @Override
  public RollaBandReadCharacteristic get() {
    return provideRollaBandReadCharacteristic(bleScopeContextProvider.get(), rollaBandImplProvider.get());
  }

  public static CharacteristicModule_ProvideRollaBandReadCharacteristicFactory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RollaBandImpl> rollaBandImplProvider) {
    return new CharacteristicModule_ProvideRollaBandReadCharacteristicFactory(bleScopeContextProvider, rollaBandImplProvider);
  }

  public static RollaBandReadCharacteristic provideRollaBandReadCharacteristic(
      CoroutineContext bleScopeContext, RollaBandImpl rollaBandImpl) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideRollaBandReadCharacteristic(bleScopeContext, rollaBandImpl));
  }
}
