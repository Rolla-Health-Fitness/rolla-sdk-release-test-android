package app.rolla.bluetoothSdk.scan.manager;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dagger.hilt.android.qualifiers.ApplicationContext",
    "app.rolla.bluetoothSdk.di.BleScopeContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScanOperationManager_Factory implements Factory<ScanOperationManager> {
  private final Provider<Context> contextProvider;

  private final Provider<BluetoothAdapter> bluetoothAdapterProvider;

  private final Provider<ScanStateManager> stateManagerProvider;

  private final Provider<ScanThrottleManager> throttleManagerProvider;

  private final Provider<ScanConfigurationManager> configManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private ScanOperationManager_Factory(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanStateManager> stateManagerProvider,
      Provider<ScanThrottleManager> throttleManagerProvider,
      Provider<ScanConfigurationManager> configManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.contextProvider = contextProvider;
    this.bluetoothAdapterProvider = bluetoothAdapterProvider;
    this.stateManagerProvider = stateManagerProvider;
    this.throttleManagerProvider = throttleManagerProvider;
    this.configManagerProvider = configManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public ScanOperationManager get() {
    return newInstance(contextProvider.get(), bluetoothAdapterProvider.get(), stateManagerProvider.get(), throttleManagerProvider.get(), configManagerProvider.get(), coroutineContextProvider.get());
  }

  public static ScanOperationManager_Factory create(Provider<Context> contextProvider,
      Provider<BluetoothAdapter> bluetoothAdapterProvider,
      Provider<ScanStateManager> stateManagerProvider,
      Provider<ScanThrottleManager> throttleManagerProvider,
      Provider<ScanConfigurationManager> configManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new ScanOperationManager_Factory(contextProvider, bluetoothAdapterProvider, stateManagerProvider, throttleManagerProvider, configManagerProvider, coroutineContextProvider);
  }

  public static ScanOperationManager newInstance(Context context,
      @Nullable BluetoothAdapter bluetoothAdapter, ScanStateManager stateManager,
      ScanThrottleManager throttleManager, ScanConfigurationManager configManager,
      CoroutineContext coroutineContext) {
    return new ScanOperationManager(context, bluetoothAdapter, stateManager, throttleManager, configManager, coroutineContext);
  }
}
