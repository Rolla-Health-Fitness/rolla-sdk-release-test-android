package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideDeviceTypeManagerFactory implements Factory<DeviceTypeManager> {
  private final Provider<DeviceStorageManager> deviceStorageManagerProvider;

  private FlutterSdkModule_ProvideDeviceTypeManagerFactory(
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    this.deviceStorageManagerProvider = deviceStorageManagerProvider;
  }

  @Override
  public DeviceTypeManager get() {
    return provideDeviceTypeManager(deviceStorageManagerProvider.get());
  }

  public static FlutterSdkModule_ProvideDeviceTypeManagerFactory create(
      Provider<DeviceStorageManager> deviceStorageManagerProvider) {
    return new FlutterSdkModule_ProvideDeviceTypeManagerFactory(deviceStorageManagerProvider);
  }

  public static DeviceTypeManager provideDeviceTypeManager(
      DeviceStorageManager deviceStorageManager) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideDeviceTypeManager(deviceStorageManager));
  }
}
