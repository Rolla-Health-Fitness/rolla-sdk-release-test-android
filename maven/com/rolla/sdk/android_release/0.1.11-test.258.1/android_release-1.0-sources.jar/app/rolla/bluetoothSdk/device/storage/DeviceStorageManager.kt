package app.rolla.bluetoothSdk.device.storage

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceType
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeviceStorageManager @Inject constructor() {
    
    private val devices = ConcurrentHashMap<String, BleDevice>()
    
    @Synchronized
    fun addDevice(address: String, device: BleDevice) {
        devices[address] = device
    }
    
    @Synchronized
    fun removeDevice(address: String): BleDevice? = devices.remove(address)
    
    fun getDevice(address: String): BleDevice? = devices[address]

    fun getAllDevices(): List<BleDevice> = devices.values.toList()
    
    @Synchronized
    fun getConnectedDevices(): List<BleDevice> = 
        devices.values.filter { it.isConnected() }
    
    @Synchronized
    fun getDevicesByType(deviceType: DeviceType): List<BleDevice> =
        devices.values.filter { it.hasDeviceType(deviceType) }.sortedByDescending { it.rssi }
    
    @Synchronized
    fun updateDevice(address: String, updater: (BleDevice) -> BleDevice): BleDevice? {
        return devices[address]?.let { device ->
            val updatedDevice = updater(device).copy(timestamp = System.currentTimeMillis())
            devices[address] = updatedDevice
            updatedDevice
        }
    }
    
    @Synchronized
    fun clear() {
        devices.clear()
    }
    
    @Synchronized
    fun getActiveConnectionCount(): Int =
        devices.values.count { it.isConnected() || it.isConnecting() }
}