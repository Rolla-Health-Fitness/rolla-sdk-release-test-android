package app.rolla.bluetoothSdk.result.error

class DeviceTypeAlreadySubscribed : Error (
    code = ErrorCodes.DEVICE_TYPE_ALREADY_SUBSCRIBED,
    message = "Device types already subscribed"
)