package app.rolla.bluetoothSdk.utils

import android.util.Log

fun log(tag: String, message: String){
    if (GlobalConfig.ENABLE_LOGS) {
        Log.e(tag, message)
    }
}