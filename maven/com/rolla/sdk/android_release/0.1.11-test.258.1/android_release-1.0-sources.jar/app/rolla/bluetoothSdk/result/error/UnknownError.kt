package app.rolla.bluetoothSdk.result.error

class UnknownError(throwable: Throwable? = null) : Error (
    code = ErrorCodes.UNKNOWN_ERROR,
    message = "Unknown error",
    exception = throwable
)