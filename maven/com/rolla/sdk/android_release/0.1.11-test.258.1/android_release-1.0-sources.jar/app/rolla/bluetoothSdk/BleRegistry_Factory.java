package app.rolla.bluetoothSdk;

import app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService;
import app.rolla.bluetoothSdk.services.DeviceInformationService;
import app.rolla.bluetoothSdk.services.HeartRateService;
import app.rolla.bluetoothSdk.services.RollaBandService;
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BleRegistry_Factory implements Factory<BleRegistry> {
  private final Provider<HeartRateService> heartRateServiceProvider;

  private final Provider<RunningSpeedAndCadenceService> runningSpeedCadenceServiceProvider;

  private final Provider<RollaBandService> rollaBandServiceProvider;

  private final Provider<DeviceInformationService> deviceInformationServiceProvider;

  private final Provider<DeviceFirmwareUpdateService> deviceFirmwareUpdateServiceProvider;

  private BleRegistry_Factory(Provider<HeartRateService> heartRateServiceProvider,
      Provider<RunningSpeedAndCadenceService> runningSpeedCadenceServiceProvider,
      Provider<RollaBandService> rollaBandServiceProvider,
      Provider<DeviceInformationService> deviceInformationServiceProvider,
      Provider<DeviceFirmwareUpdateService> deviceFirmwareUpdateServiceProvider) {
    this.heartRateServiceProvider = heartRateServiceProvider;
    this.runningSpeedCadenceServiceProvider = runningSpeedCadenceServiceProvider;
    this.rollaBandServiceProvider = rollaBandServiceProvider;
    this.deviceInformationServiceProvider = deviceInformationServiceProvider;
    this.deviceFirmwareUpdateServiceProvider = deviceFirmwareUpdateServiceProvider;
  }

  @Override
  public BleRegistry get() {
    return newInstance(heartRateServiceProvider.get(), runningSpeedCadenceServiceProvider.get(), rollaBandServiceProvider.get(), deviceInformationServiceProvider.get(), deviceFirmwareUpdateServiceProvider.get());
  }

  public static BleRegistry_Factory create(Provider<HeartRateService> heartRateServiceProvider,
      Provider<RunningSpeedAndCadenceService> runningSpeedCadenceServiceProvider,
      Provider<RollaBandService> rollaBandServiceProvider,
      Provider<DeviceInformationService> deviceInformationServiceProvider,
      Provider<DeviceFirmwareUpdateService> deviceFirmwareUpdateServiceProvider) {
    return new BleRegistry_Factory(heartRateServiceProvider, runningSpeedCadenceServiceProvider, rollaBandServiceProvider, deviceInformationServiceProvider, deviceFirmwareUpdateServiceProvider);
  }

  public static BleRegistry newInstance(HeartRateService heartRateService,
      RunningSpeedAndCadenceService runningSpeedCadenceService, RollaBandService rollaBandService,
      DeviceInformationService deviceInformationService,
      DeviceFirmwareUpdateService deviceFirmwareUpdateService) {
    return new BleRegistry(heartRateService, runningSpeedCadenceService, rollaBandService, deviceInformationService, deviceFirmwareUpdateService);
  }
}
