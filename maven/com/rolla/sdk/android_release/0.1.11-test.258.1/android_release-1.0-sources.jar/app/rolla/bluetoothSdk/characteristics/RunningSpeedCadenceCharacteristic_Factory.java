package app.rolla.bluetoothSdk.characteristics;

import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RunningSpeedCadenceCharacteristic_Factory implements Factory<RunningSpeedCadenceCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<RealTimeStepCalculator> stepCalculatorProvider;

  private RunningSpeedCadenceCharacteristic_Factory(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RealTimeStepCalculator> stepCalculatorProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.stepCalculatorProvider = stepCalculatorProvider;
  }

  @Override
  public RunningSpeedCadenceCharacteristic get() {
    return newInstance(bleScopeContextProvider.get(), stepCalculatorProvider.get());
  }

  public static RunningSpeedCadenceCharacteristic_Factory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RealTimeStepCalculator> stepCalculatorProvider) {
    return new RunningSpeedCadenceCharacteristic_Factory(bleScopeContextProvider, stepCalculatorProvider);
  }

  public static RunningSpeedCadenceCharacteristic newInstance(CoroutineContext bleScopeContext,
      RealTimeStepCalculator stepCalculator) {
    return new RunningSpeedCadenceCharacteristic(bleScopeContext, stepCalculator);
  }
}
