package app.rolla.bluetoothSdk.commands.data

enum class ActivityMode {
    START,
    STOP
}