package app.rolla.bluetoothSdk.di

import app.rolla.bluetoothSdk.device.DeviceManager
import app.rolla.bluetoothSdk.device.monitoring.DeviceMonitoringManager
import app.rolla.bluetoothSdk.device.state.DeviceStateManager
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
import app.rolla.bluetoothSdk.device.types.DeviceTypeManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Module
@InstallIn(SingletonComponent::class)
object DeviceModule {

    @Provides
    @Singleton
    fun provideDeviceStorageManager(): DeviceStorageManager = DeviceStorageManager()

    @Provides
    @Singleton
    fun provideDeviceStateManager(
        deviceStorageManager: DeviceStorageManager,
        @BleScopeContext coroutineContext: CoroutineContext
    ): DeviceStateManager = DeviceStateManager(deviceStorageManager, coroutineContext)

    @Provides
    @Singleton
    fun provideDeviceTypeManager(
        deviceStorageManager: DeviceStorageManager
    ): DeviceTypeManager = DeviceTypeManager(deviceStorageManager)

    @Provides
    @Singleton
    fun provideDeviceMonitoringManager(
        deviceStorageManager: DeviceStorageManager,
        deviceStateManager: DeviceStateManager,
        @BleScopeContext coroutineContext: CoroutineContext
    ): DeviceMonitoringManager = DeviceMonitoringManager(deviceStorageManager, deviceStateManager, coroutineContext)

    @Provides
    @Singleton
    fun provideDeviceManager(
        @BleScopeContext bleScopeContext: CoroutineContext,
        deviceTypeManager: DeviceTypeManager,
        deviceMonitoringManager: DeviceMonitoringManager,
        deviceStateManager: DeviceStateManager,
        deviceStorageManager: DeviceStorageManager
    ): DeviceManager = DeviceManager(bleScopeContext, deviceTypeManager, deviceMonitoringManager, deviceStateManager, deviceStorageManager)

}