package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.SerialNumberCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideSerialNumberCharacteristicFactory implements Factory<SerialNumberCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private CharacteristicModule_ProvideSerialNumberCharacteristicFactory(
      Provider<CoroutineContext> bleScopeContextProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
  }

  @Override
  public SerialNumberCharacteristic get() {
    return provideSerialNumberCharacteristic(bleScopeContextProvider.get());
  }

  public static CharacteristicModule_ProvideSerialNumberCharacteristicFactory create(
      Provider<CoroutineContext> bleScopeContextProvider) {
    return new CharacteristicModule_ProvideSerialNumberCharacteristicFactory(bleScopeContextProvider);
  }

  public static SerialNumberCharacteristic provideSerialNumberCharacteristic(
      CoroutineContext bleScopeContext) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideSerialNumberCharacteristic(bleScopeContext));
  }
}
