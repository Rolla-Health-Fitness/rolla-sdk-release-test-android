package app.rolla.bluetoothSdk.device.monitoring

import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceEvent
import app.rolla.bluetoothSdk.device.state.DeviceStateManager
import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class DeviceMonitoringManager @Inject constructor(
    private val storageManager: DeviceStorageManager,
    private val stateManager: DeviceStateManager,
    coroutineContext: CoroutineContext
) {
    companion object {
        private const val TAG = "DeviceMonitoringManager"
        private const val DEVICE_TIMEOUT_MS = 20000L
        private const val CONNECTED_DEVICE_TIMEOUT_MS = 30000L
        private const val MONITORING_INTERVAL_MS = 1000L
    }

    private val monitoringScope = CoroutineScope(coroutineContext)
    private var monitoringJob: Job? = null

    private val _deviceEventFlow = MutableSharedFlow<DeviceEvent>(replay = 1)
    val deviceEventFlow: SharedFlow<DeviceEvent> = _deviceEventFlow.asSharedFlow()

    init {
        startMonitoring()
    }

    private fun startMonitoring() {
        stopMonitoring()
        log(TAG, "Starting device monitoring")
        
        monitoringJob = monitoringScope.launch {
            while (true) {
                pruneOldDevices()
                delay(MONITORING_INTERVAL_MS)
            }
        }
    }

    fun stopMonitoring() {
        monitoringJob?.cancel()
        monitoringJob = null
        log(TAG, "Device monitoring stopped")
    }

    /**
     * Removes devices that haven't been seen recently and triggers RSSI reads for connected devices.
     */
    private fun pruneOldDevices() {
        val currentTime = System.currentTimeMillis()
        val devicesToRemove = mutableListOf<String>()

        storageManager.getAllDevices().forEach { device ->
            val timeSinceLastUpdate = currentTime - device.timestamp
            val address = device.getMacAddress()

            if (device.isConnected()) {
                when {
                    timeSinceLastUpdate >= 10000L && timeSinceLastUpdate < 11000L -> {
                        emitRssiReadRequest(device)
                    }
                    timeSinceLastUpdate >= 20000L && timeSinceLastUpdate < 21000L -> {
                        emitRssiReadRequest(device)
                    }
                    timeSinceLastUpdate > CONNECTED_DEVICE_TIMEOUT_MS -> {
                        log(TAG, "Connected device became unresponsive: $address")
                        emitDeviceUnresponsive(device)
                    }
                }
            } else {
                if (timeSinceLastUpdate > DEVICE_TIMEOUT_MS) {
                    log(TAG, "Scanned device timed out: $address")
                    devicesToRemove.add(address)
                }
            }
        }

        devicesToRemove.forEach { address ->
            storageManager.removeDevice(address)
        }
        stateManager.refreshDevicesList()
    }

    private fun emitRssiReadRequest(device: BleDevice) {
        monitoringScope.launch {
            _deviceEventFlow.emit(DeviceEvent.RssiReadRequested(device))
        }
    }

    private fun emitDeviceUnresponsive(device: BleDevice) {
        monitoringScope.launch {
            _deviceEventFlow.emit(DeviceEvent.DeviceUnresponsive(device))
        }
    }

    fun destroy() {
        stopMonitoring()
    }
}