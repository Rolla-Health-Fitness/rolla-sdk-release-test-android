package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.utils.log

class SetWristBandParams(val inActivity: Boolean) : Command<ByteArray> {

    companion object {
        const val TAG = "SetWristBandParams"
        // JStyle 2251 API spec line 165: byte[5] (EE) = "Auto Exercise Heart Rate
        // Enable Flag, 0x81: enable. 0x80: off". This is NOT wrist detection
        // (the previous constant name was misleading) — it lets the band's firmware
        // autonomously end activities after low motion, which then emits 0x18 0xFF
        // and stalls the HR stream. Keep this disabled. See QA-207.
        private const val AUTO_EXERCISE_HR_DISABLED = 0x80.toByte()
        private const val IN_ACTIVITY_MODE = 0x8A.toByte()
        private const val OUTSIDE_ACTIVITY_MODE = 0x8F.toByte()
    }

    override fun getId(): Byte = 0x03.toByte()

    override fun errorId(): Byte = 0x83.toByte()

    override fun bytesToWrite(): ByteArray = createCommandBytes {
        this[5] = AUTO_EXERCISE_HR_DISABLED
        this[6] = if (inActivity) IN_ACTIVITY_MODE else OUTSIDE_ACTIVITY_MODE
    }

    override fun read(data: ByteArray): ByteArray {
        log(TAG, "Successful - Set wristband basic params response: ${data.contentToString()}")
        return data
    }
}