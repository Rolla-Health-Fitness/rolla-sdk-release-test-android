package app.rolla.bluetoothSdk.result.error

class BluetoothLeScannerNotAvailable : Error (
    code = ErrorCodes.BLUETOOTH_LE_SCANNER_NOT_AVAILABLE,
    message = "Bluetooth LE scanner is not available"
) {
}