package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceModule_ProvideDeviceStorageManagerFactory implements Factory<DeviceStorageManager> {
  @Override
  public DeviceStorageManager get() {
    return provideDeviceStorageManager();
  }

  public static DeviceModule_ProvideDeviceStorageManagerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DeviceStorageManager provideDeviceStorageManager() {
    return Preconditions.checkNotNullFromProvides(DeviceModule.INSTANCE.provideDeviceStorageManager());
  }

  private static final class InstanceHolder {
    static final DeviceModule_ProvideDeviceStorageManagerFactory INSTANCE = new DeviceModule_ProvideDeviceStorageManagerFactory();
  }
}
