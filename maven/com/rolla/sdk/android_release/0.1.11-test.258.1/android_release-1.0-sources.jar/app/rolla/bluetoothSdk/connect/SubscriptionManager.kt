package app.rolla.bluetoothSdk.connect

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.content.Context
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.characteristics.Characteristic
import app.rolla.bluetoothSdk.BleRegistry
import app.rolla.bluetoothSdk.commands.Command
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.utils.executeWithBluetoothConnect
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.CoroutineContext

class SubscriptionManager(
    @BleScopeContext coroutineContext: CoroutineContext,
    private val context: Context,
    private val operationQueue: OperationQueue,
    private val bleRegistry: BleRegistry
) {

    companion object {
        const val TAG = "SubscriptionManager"

        private const val CLIENT_CHARACTERISTIC_CONFIG_UUID = "00002902-0000-1000-8000-00805f9b34fb"
    }

    private val subscriptionScope = CoroutineScope(coroutineContext)

    private val _characteristicEvents = MutableSharedFlow<CharacteristicEvent>(replay = 1)
    val characteristicEvents: SharedFlow<CharacteristicEvent> = _characteristicEvents.asSharedFlow()

    private val pendingSubscriptions = ConcurrentHashMap<String, MutableSet<String>>()
    private val pendingUnsubscriptions = ConcurrentHashMap<String, MutableSet<String>>()
    private val pendingCommands = ConcurrentHashMap<String, MutableSet<Byte>>()

    fun subscribeToCharacteristics(device: BleDevice, allCharacteristics: Set<Pair<Characteristic, BluetoothGattCharacteristic>>) {
        val deviceAddress = device.getMacAddress()
        allCharacteristics.forEach { characteristic ->
            val characteristicUuid = characteristic.first.uuid
            addToPendingSubscriptions(deviceAddress, characteristicUuid)
        }
        allCharacteristics.forEach { characteristic ->
            subscribeToCharacteristicInternal(
                deviceAddress,
                device.gatt,
                characteristic.second,
            )
        }
        allCharacteristics.forEach { characteristic ->
            val commands = if ( characteristic.first.uuid == bleRegistry.getRollaBandWriteCharacteristic().uuid) {
                characteristic.first.getPostSubscriptionCommands()
            } else {
                emptyList()
            }
            if (commands.isNotEmpty()) {
                addCommands(device, characteristic.second, characteristic.first, commands)
            }
        }
    }


    @SuppressLint("MissingPermission")
    private fun subscribeToCharacteristicInternal(
        deviceAddress: String,
        gatt: BluetoothGatt?,
        bleCharacteristic: BluetoothGattCharacteristic
    ) {
        val characteristicUuid = bleCharacteristic.uuid.getFullUUID()

        log(TAG, "Subscribe to $characteristicUuid for $deviceAddress")

        if (gatt == null) {
            log(TAG, "GATT is null for $deviceAddress")
            completeSubscription(deviceAddress, characteristicUuid)
            return
        }

        if (!canSubscribeToCharacteristic(bleCharacteristic)) {
            log(TAG, "Characteristic $characteristicUuid does not support notifications/indications")
            completeSubscription(deviceAddress, characteristicUuid)
            return
        }

        context.executeWithBluetoothConnect(
            operation = {
                val success = gatt.setCharacteristicNotification(bleCharacteristic, true)
                if (success) {
                    val descriptor = bleCharacteristic.getDescriptor(UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG_UUID))
                    if (descriptor != null) {
                        val operation = BleOperation.WriteDescriptor(
                            deviceAddress = deviceAddress,
                            name = "WriteDescriptor - $characteristicUuid",
                            gatt = gatt,
                            descriptor = descriptor,
                            onComplete = { success, status ->
                                if (success) {
                                    log(TAG, "Descriptor write queued successfully for $characteristicUuid")
                                } else {
                                    log(TAG, "Failed to queue descriptor write for $characteristicUuid")
                                    completeSubscription(deviceAddress, characteristicUuid)
                                }
                            }
                        )

                        operationQueue.queueOperation(operation)
                    } else {
                        log(TAG, "Notification descriptor not found for $characteristicUuid on $deviceAddress")
                        completeSubscription(deviceAddress, characteristicUuid)
                    }
                } else {
                    log(TAG, "Failed to enable notifications for $characteristicUuid on $deviceAddress")
                    completeSubscription(deviceAddress, characteristicUuid)
                }
            },
            onPermissionDenied = { exception ->
                log(TAG, "Missing BLUETOOTH_CONNECT permission for characteristic subscription")
                completeSubscription(deviceAddress, characteristicUuid)
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun unsubscribeFromCharacteristics(device: BleDevice) {
        val allCharacteristics = bleRegistry.getAllowedCharacteristicsForDeviceTypes(device.gatt, device.requestedTypes)
        val deviceAddress = device.getMacAddress()
        allCharacteristics.forEach { characteristic ->
            val characteristicUuid = characteristic.first.uuid
            addToPendingUnsubscriptions(deviceAddress, characteristicUuid)
        }
        allCharacteristics.forEach { characteristic ->
            unSubscribeFromCharacteristicInternal(
                device.getMacAddress(),
                device.gatt,
                characteristic.second,
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun unSubscribeFromCharacteristicInternal(
        deviceAddress: String,
        gatt: BluetoothGatt?,
        characteristic: BluetoothGattCharacteristic
    ) {
        val characteristicUuid = characteristic.uuid.getFullUUID()

        log(TAG, "Unsubscribe from $characteristicUuid for $deviceAddress")

        if (gatt == null) {
            log(TAG, "GATT is null for $deviceAddress")
            completeUnsubscription(deviceAddress, characteristicUuid)
            return
        }

        if (!canSubscribeToCharacteristic(characteristic)) {
            log(TAG, "Characteristic $characteristicUuid does not support notifications/indications")
            completeUnsubscription(deviceAddress, characteristicUuid)
            return
        }

        context.executeWithBluetoothConnect(
            operation = {
                val success = gatt.setCharacteristicNotification(characteristic, false)
                if (success) {
                    val descriptor =
                        characteristic.getDescriptor(UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG_UUID))
                    if (descriptor != null) {
                        log(TAG, "Queueing descriptor write for $characteristicUuid on $deviceAddress")
                        val operation = BleOperation.WriteDescriptor(
                            deviceAddress = deviceAddress,
                            name = "WriteDescriptor - $characteristicUuid",
                            gatt = gatt,
                            descriptor = descriptor,
                            value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE,
                            onComplete = { success, status ->
                                if (success) {
                                    log(TAG, "Successfully disabled notifications for $characteristicUuid")
                                } else {
                                    log(TAG, "Failed to disable notifications for $characteristicUuid")
                                    completeUnsubscription(deviceAddress, characteristicUuid)
                                }
                            }
                        )
                        operationQueue.queueOperation(operation)
                    } else {
                        log(TAG, "Notification descriptor not found for $characteristicUuid on $deviceAddress")
                        completeUnsubscription(deviceAddress, characteristicUuid)
                    }
                } else {
                    log(TAG, "Failed to disable notifications for $characteristicUuid on $deviceAddress")
                    completeUnsubscription(deviceAddress, characteristicUuid)
                }
            },
            onPermissionDenied = { exception ->
                log(TAG, "Missing BLUETOOTH_CONNECT permission for characteristic unsubscription")
                completeUnsubscription(deviceAddress, characteristicUuid)
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun disableNotification(device: BleDevice) {
        val allCharacteristics = bleRegistry.getAllowedCharacteristicsForDeviceTypes(device.gatt, device.requestedTypes)
        val fullName = device.getFullName(context)
        if (device.gatt == null) {
            log(TAG, "No GATT connection for $fullName")
            return
        }
        context.executeWithBluetoothConnect(
            operation = {
                for (characteristic in allCharacteristics) {
                    // Disable notifications
                    device.gatt.setCharacteristicNotification(
                        characteristic.second,
                        false
                    )
                    log(
                        TAG,
                        "Disabled notifications for ${characteristic.first.uuid} on ${device.getMacAddress()}"
                    )
                }
            },
            onPermissionDenied = {
                log(TAG, "Missing BLUETOOTH_CONNECT permission for disableNotification")
            }
        )
    }

    private fun canSubscribeToCharacteristic(characteristic: BluetoothGattCharacteristic): Boolean {
        val properties = characteristic.properties
        return (properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                (properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
    }

    /**
     * Add characteristic to pending subscriptions (thread-safe)
     */
    private fun addToPendingSubscriptions(deviceAddress: String, characteristicUuid: String) {
        pendingSubscriptions.computeIfAbsent(deviceAddress) {
            Collections.synchronizedSet(mutableSetOf())
        }.add(characteristicUuid)
    }

    /**
     * Add characteristic to pending unsubscriptions (thread-safe)
     */
    private fun addToPendingUnsubscriptions(deviceAddress: String, characteristicUuid: String) {
        pendingUnsubscriptions.computeIfAbsent(deviceAddress) {
            Collections.synchronizedSet(mutableSetOf())
        }.add(characteristicUuid)
    }

    /**
     * Mark characteristic subscription as complete (thread-safe)
     */
    fun completeSubscription(deviceAddress: String, characteristicUuid: String) {
        log(TAG, "Complete subscription - All pending subscriptions: ${pendingSubscriptions[deviceAddress]}")
        val pending = pendingSubscriptions[deviceAddress]
        if (pending != null) {
            synchronized(pending) {
                pending.remove(characteristicUuid)
                log(TAG, "After remove - All pending subscriptions: ${pendingSubscriptions[deviceAddress]}")
                // If all subscriptions complete, emit completion event
                if (pending.isEmpty()) {
                    pendingSubscriptions.remove(deviceAddress)
                    log(TAG, "All subscriptions completed for device: $deviceAddress")
                    subscriptionScope.launch {
                        _characteristicEvents.emit(CharacteristicEvent.AllSubscriptionsComplete(deviceAddress))
                        
                        // Check if there are no pending commands - if so, immediately complete post commands
                        val hasPendingCommands = pendingCommands[deviceAddress]?.isNotEmpty() ?: false
                        if (!hasPendingCommands) {
                            log(TAG, "No pending commands for $deviceAddress, immediately completing post-subscription commands")
                            _characteristicEvents.emit(CharacteristicEvent.AllPostSubscriptionCommandsComplete(deviceAddress))
                        }
                    }
                }
            }
        }
    }

    /**
     * Mark characteristic unsubscription as complete (thread-safe)
     */
    fun completeUnsubscription(deviceAddress: String, characteristicUuid: String) {
        log(TAG, "All pending unsubscriptions: ${pendingUnsubscriptions[deviceAddress]}")
        val pending = pendingUnsubscriptions[deviceAddress]
        if (pending != null) {
            synchronized(pending) {
                pending.remove(characteristicUuid)
                // If all unsubscriptions complete, emit completion event
                if (pending.isEmpty()) {
                    pendingUnsubscriptions.remove(deviceAddress)
                    log(TAG, "All unsubscriptions completed for device: $deviceAddress")
                    subscriptionScope.launch {
                        _characteristicEvents.emit(CharacteristicEvent.AllUnsubscriptionsComplete(deviceAddress))
                    }
                }
            }
        }
    }

    fun handleConnectionTimeout(deviceAddress: String) {
        val pending = pendingSubscriptions.remove(deviceAddress)
        if (pending != null) {
            val pendingList = synchronized(pending) { pending.toList() }
            if (pendingList.isNotEmpty()) {
                log(
                    TAG,
                    "Connection timeout - cleaning up pending subscriptions for ${deviceAddress}: $pendingList"
                )
            }
        }
    }

    fun handleDisconnectionTimeout(deviceAddress: String) {
        val pending = pendingUnsubscriptions.remove(deviceAddress)
        if (pending != null) {
            val pendingList = synchronized(pending) { pending.toList() }
            if (pendingList.isNotEmpty()) {
                log(
                    TAG,
                    "Disconnection timeout - cleaning up pending unsubscriptions for ${deviceAddress}: $pendingList"
                )
            }
        }
    }

    fun cleanup() {
        pendingSubscriptions.clear()
        pendingUnsubscriptions.clear()
        pendingCommands.clear()
    }

    fun cleanForDevice(deviceAddress: String) {
        pendingSubscriptions.remove(deviceAddress)
        pendingUnsubscriptions.remove(deviceAddress)
        pendingCommands.remove(deviceAddress)
    }

    fun completeDescriptorWrite(deviceAddress: String, characteristicUuid: String) {
        // Check pending operations
        val isPendingSubscription = pendingSubscriptions[deviceAddress]?.contains(characteristicUuid) ?: false
        val isPendingUnsubscription = pendingUnsubscriptions[deviceAddress]?.contains(characteristicUuid) ?: false
        if (isPendingSubscription) {
            completeSubscription(deviceAddress, characteristicUuid)
        } else if (isPendingUnsubscription) {
            completeUnsubscription(deviceAddress, characteristicUuid)
        } else {
            log(TAG, "No pending operation found")
        }
    }

    fun addCommands(
        device: BleDevice,
        gattCharacteristic: BluetoothGattCharacteristic,
        characteristic: Characteristic,
        commands: List<Command<*>>
    ) {
        for (command in commands) {
            val deviceAddress = device.getMacAddress()
            pendingCommands.computeIfAbsent(deviceAddress) {
                Collections.synchronizedSet(mutableSetOf())
            }.add(command.getId())
            log(TAG, "Queueing post-subscription command for ${characteristic.uuid} - ${command.getId()}")

            val operation = BleOperation.WriteCharacteristic(
                deviceAddress = deviceAddress,
                name = "PostSubscriptionCommand - ${command.getId()}",
                gatt = device.gatt!!,
                characteristic = gattCharacteristic,
                data = command.bytesToWrite(),
                onComplete = { success, status ->
                    handlePostCommandComplete(deviceAddress, command, success, status)
                }
            )
            operationQueue.queueOperation(operation)
        }
        log(TAG, "Pending commands count for ${device.getMacAddress()}: ${getPendingCommandSize(device.getMacAddress())}")
    }

    private fun handlePostCommandComplete(
        deviceAddress: String,
        command: Command<*>,
        success: Boolean,
        status: Int?
    ) {
        val commandName = command::class.simpleName

        if (success) {
            log(TAG, "✅ Post-subscription command completed: $commandName")
        } else {
            log(TAG, "❌ Post-subscription command failed: $commandName (status: $status)")
        }

        val pending = pendingCommands[deviceAddress]
        if (pending != null) {
            synchronized(pending) {
                pending.remove(command.getId())

                // If all subscriptions complete, emit completion event
                if (pending.isEmpty()) {
                    pendingCommands.remove(deviceAddress)
                    log(TAG, "All post command completed for device: $deviceAddress")
                    subscriptionScope.launch {
                        _characteristicEvents.emit(CharacteristicEvent.AllPostSubscriptionCommandsComplete(deviceAddress))
                    }
                }
            }
        }
    }

    fun getPendingCommandSize(deviceAddress: String): Int {
        return pendingCommands.filter { it.key == deviceAddress }.size
    }

}