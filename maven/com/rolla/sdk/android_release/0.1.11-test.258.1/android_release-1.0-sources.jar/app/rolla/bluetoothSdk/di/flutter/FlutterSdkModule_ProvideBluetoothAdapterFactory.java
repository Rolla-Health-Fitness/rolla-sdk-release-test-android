package app.rolla.bluetoothSdk.di.flutter;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideBluetoothAdapterFactory implements Factory<BluetoothAdapter> {
  private final Provider<BluetoothManager> bluetoothManagerProvider;

  private FlutterSdkModule_ProvideBluetoothAdapterFactory(
      Provider<BluetoothManager> bluetoothManagerProvider) {
    this.bluetoothManagerProvider = bluetoothManagerProvider;
  }

  @Override
  @Nullable
  public BluetoothAdapter get() {
    return provideBluetoothAdapter(bluetoothManagerProvider.get());
  }

  public static FlutterSdkModule_ProvideBluetoothAdapterFactory create(
      Provider<BluetoothManager> bluetoothManagerProvider) {
    return new FlutterSdkModule_ProvideBluetoothAdapterFactory(bluetoothManagerProvider);
  }

  @Nullable
  public static BluetoothAdapter provideBluetoothAdapter(
      @Nullable BluetoothManager bluetoothManager) {
    return FlutterSdkModule.INSTANCE.provideBluetoothAdapter(bluetoothManager);
  }
}
