package app.rolla.bluetoothSdk.connect.reconnect;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FirstConnectionRetryStrategy_Factory implements Factory<FirstConnectionRetryStrategy> {
  private final Provider<CoroutineContext> contextProvider;

  private FirstConnectionRetryStrategy_Factory(Provider<CoroutineContext> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public FirstConnectionRetryStrategy get() {
    return newInstance(contextProvider.get());
  }

  public static FirstConnectionRetryStrategy_Factory create(
      Provider<CoroutineContext> contextProvider) {
    return new FirstConnectionRetryStrategy_Factory(contextProvider);
  }

  public static FirstConnectionRetryStrategy newInstance(CoroutineContext context) {
    return new FirstConnectionRetryStrategy(context);
  }
}
