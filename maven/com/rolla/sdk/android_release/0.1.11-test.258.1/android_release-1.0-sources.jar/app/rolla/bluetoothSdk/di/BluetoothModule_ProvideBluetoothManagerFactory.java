package app.rolla.bluetoothSdk.di;

import android.bluetooth.BluetoothManager;
import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BluetoothModule_ProvideBluetoothManagerFactory implements Factory<BluetoothManager> {
  private final Provider<Context> contextProvider;

  private BluetoothModule_ProvideBluetoothManagerFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  @Nullable
  public BluetoothManager get() {
    return provideBluetoothManager(contextProvider.get());
  }

  public static BluetoothModule_ProvideBluetoothManagerFactory create(
      Provider<Context> contextProvider) {
    return new BluetoothModule_ProvideBluetoothManagerFactory(contextProvider);
  }

  @Nullable
  public static BluetoothManager provideBluetoothManager(Context context) {
    return BluetoothModule.INSTANCE.provideBluetoothManager(context);
  }
}
