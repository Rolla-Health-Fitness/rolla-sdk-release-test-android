package app.rolla.bluetoothSdk.device.state;

import app.rolla.bluetoothSdk.device.storage.DeviceStorageManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceStateManager_Factory implements Factory<DeviceStateManager> {
  private final Provider<DeviceStorageManager> storageManagerProvider;

  private final Provider<CoroutineContext> coroutineContextProvider;

  private DeviceStateManager_Factory(Provider<DeviceStorageManager> storageManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    this.storageManagerProvider = storageManagerProvider;
    this.coroutineContextProvider = coroutineContextProvider;
  }

  @Override
  public DeviceStateManager get() {
    return newInstance(storageManagerProvider.get(), coroutineContextProvider.get());
  }

  public static DeviceStateManager_Factory create(
      Provider<DeviceStorageManager> storageManagerProvider,
      Provider<CoroutineContext> coroutineContextProvider) {
    return new DeviceStateManager_Factory(storageManagerProvider, coroutineContextProvider);
  }

  public static DeviceStateManager newInstance(DeviceStorageManager storageManager,
      CoroutineContext coroutineContext) {
    return new DeviceStateManager(storageManager, coroutineContext);
  }
}
