package app.rolla.bluetoothSdk.commands.data

enum class SleepPhase {
    DEEP,
    LIGHT,
    REM,
    AWAKE
}