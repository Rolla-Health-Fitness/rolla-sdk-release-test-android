package app.rolla.bluetoothSdk.di;

import app.rolla.bluetoothSdk.characteristics.RunningSpeedCadenceCharacteristic;
import app.rolla.bluetoothSdk.steps.RealTimeStepCalculator;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlin.coroutines.CoroutineContext;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("app.rolla.bluetoothSdk.di.BleScopeContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CharacteristicModule_ProvideRunningSpeedCadenceCharacteristicFactory implements Factory<RunningSpeedCadenceCharacteristic> {
  private final Provider<CoroutineContext> bleScopeContextProvider;

  private final Provider<RealTimeStepCalculator> realTimeStepCalculatorProvider;

  private CharacteristicModule_ProvideRunningSpeedCadenceCharacteristicFactory(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RealTimeStepCalculator> realTimeStepCalculatorProvider) {
    this.bleScopeContextProvider = bleScopeContextProvider;
    this.realTimeStepCalculatorProvider = realTimeStepCalculatorProvider;
  }

  @Override
  public RunningSpeedCadenceCharacteristic get() {
    return provideRunningSpeedCadenceCharacteristic(bleScopeContextProvider.get(), realTimeStepCalculatorProvider.get());
  }

  public static CharacteristicModule_ProvideRunningSpeedCadenceCharacteristicFactory create(
      Provider<CoroutineContext> bleScopeContextProvider,
      Provider<RealTimeStepCalculator> realTimeStepCalculatorProvider) {
    return new CharacteristicModule_ProvideRunningSpeedCadenceCharacteristicFactory(bleScopeContextProvider, realTimeStepCalculatorProvider);
  }

  public static RunningSpeedCadenceCharacteristic provideRunningSpeedCadenceCharacteristic(
      CoroutineContext bleScopeContext, RealTimeStepCalculator realTimeStepCalculator) {
    return Preconditions.checkNotNullFromProvides(CharacteristicModule.INSTANCE.provideRunningSpeedCadenceCharacteristic(bleScopeContext, realTimeStepCalculator));
  }
}
