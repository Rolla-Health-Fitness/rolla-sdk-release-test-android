package app.rolla.bluetoothSdk.services;

import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic;
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RollaBandService_Factory implements Factory<RollaBandService> {
  private final Provider<RollaBandReadCharacteristic> rollaBandReadCharacteristicProvider;

  private final Provider<RollaBandWriteCharacteristic> rollaBandWriteCharacteristicProvider;

  private RollaBandService_Factory(
      Provider<RollaBandReadCharacteristic> rollaBandReadCharacteristicProvider,
      Provider<RollaBandWriteCharacteristic> rollaBandWriteCharacteristicProvider) {
    this.rollaBandReadCharacteristicProvider = rollaBandReadCharacteristicProvider;
    this.rollaBandWriteCharacteristicProvider = rollaBandWriteCharacteristicProvider;
  }

  @Override
  public RollaBandService get() {
    return newInstance(rollaBandReadCharacteristicProvider.get(), rollaBandWriteCharacteristicProvider.get());
  }

  public static RollaBandService_Factory create(
      Provider<RollaBandReadCharacteristic> rollaBandReadCharacteristicProvider,
      Provider<RollaBandWriteCharacteristic> rollaBandWriteCharacteristicProvider) {
    return new RollaBandService_Factory(rollaBandReadCharacteristicProvider, rollaBandWriteCharacteristicProvider);
  }

  public static RollaBandService newInstance(
      RollaBandReadCharacteristic rollaBandReadCharacteristic,
      RollaBandWriteCharacteristic rollaBandWriteCharacteristic) {
    return new RollaBandService(rollaBandReadCharacteristic, rollaBandWriteCharacteristic);
  }
}
