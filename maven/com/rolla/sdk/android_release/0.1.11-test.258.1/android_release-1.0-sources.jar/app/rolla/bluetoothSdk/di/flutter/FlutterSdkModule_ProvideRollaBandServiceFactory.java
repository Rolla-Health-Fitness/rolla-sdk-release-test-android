package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.characteristics.RollaBandReadCharacteristic;
import app.rolla.bluetoothSdk.characteristics.RollaBandWriteCharacteristic;
import app.rolla.bluetoothSdk.services.RollaBandService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideRollaBandServiceFactory implements Factory<RollaBandService> {
  private final Provider<RollaBandReadCharacteristic> rollaBandReadCharacteristicProvider;

  private final Provider<RollaBandWriteCharacteristic> rollaBandWriteCharacteristicProvider;

  private FlutterSdkModule_ProvideRollaBandServiceFactory(
      Provider<RollaBandReadCharacteristic> rollaBandReadCharacteristicProvider,
      Provider<RollaBandWriteCharacteristic> rollaBandWriteCharacteristicProvider) {
    this.rollaBandReadCharacteristicProvider = rollaBandReadCharacteristicProvider;
    this.rollaBandWriteCharacteristicProvider = rollaBandWriteCharacteristicProvider;
  }

  @Override
  public RollaBandService get() {
    return provideRollaBandService(rollaBandReadCharacteristicProvider.get(), rollaBandWriteCharacteristicProvider.get());
  }

  public static FlutterSdkModule_ProvideRollaBandServiceFactory create(
      Provider<RollaBandReadCharacteristic> rollaBandReadCharacteristicProvider,
      Provider<RollaBandWriteCharacteristic> rollaBandWriteCharacteristicProvider) {
    return new FlutterSdkModule_ProvideRollaBandServiceFactory(rollaBandReadCharacteristicProvider, rollaBandWriteCharacteristicProvider);
  }

  public static RollaBandService provideRollaBandService(
      RollaBandReadCharacteristic rollaBandReadCharacteristic,
      RollaBandWriteCharacteristic rollaBandWriteCharacteristic) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideRollaBandService(rollaBandReadCharacteristic, rollaBandWriteCharacteristic));
  }
}
