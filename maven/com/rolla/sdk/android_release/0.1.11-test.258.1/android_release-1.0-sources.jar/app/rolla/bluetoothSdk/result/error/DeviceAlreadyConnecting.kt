package app.rolla.bluetoothSdk.result.error

class DeviceAlreadyConnecting : Error (
    code = ErrorCodes.DEVICE_ALREADY_CONNECTING,
    message = "Device already connecting"
)