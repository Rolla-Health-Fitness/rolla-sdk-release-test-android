package app.rolla.bluetoothSdk.di.flutter;

import app.rolla.bluetoothSdk.BleRegistry;
import app.rolla.bluetoothSdk.services.DeviceFirmwareUpdateService;
import app.rolla.bluetoothSdk.services.DeviceInformationService;
import app.rolla.bluetoothSdk.services.HeartRateService;
import app.rolla.bluetoothSdk.services.RollaBandService;
import app.rolla.bluetoothSdk.services.RunningSpeedAndCadenceService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlutterSdkModule_ProvideBleRegistryFactory implements Factory<BleRegistry> {
  private final Provider<HeartRateService> heartRateServiceProvider;

  private final Provider<RunningSpeedAndCadenceService> runningSpeedAndCadenceServiceProvider;

  private final Provider<RollaBandService> rollaBandServiceProvider;

  private final Provider<DeviceInformationService> deviceInformationServiceProvider;

  private final Provider<DeviceFirmwareUpdateService> deviceFirmwareUpdateServiceProvider;

  private FlutterSdkModule_ProvideBleRegistryFactory(
      Provider<HeartRateService> heartRateServiceProvider,
      Provider<RunningSpeedAndCadenceService> runningSpeedAndCadenceServiceProvider,
      Provider<RollaBandService> rollaBandServiceProvider,
      Provider<DeviceInformationService> deviceInformationServiceProvider,
      Provider<DeviceFirmwareUpdateService> deviceFirmwareUpdateServiceProvider) {
    this.heartRateServiceProvider = heartRateServiceProvider;
    this.runningSpeedAndCadenceServiceProvider = runningSpeedAndCadenceServiceProvider;
    this.rollaBandServiceProvider = rollaBandServiceProvider;
    this.deviceInformationServiceProvider = deviceInformationServiceProvider;
    this.deviceFirmwareUpdateServiceProvider = deviceFirmwareUpdateServiceProvider;
  }

  @Override
  public BleRegistry get() {
    return provideBleRegistry(heartRateServiceProvider.get(), runningSpeedAndCadenceServiceProvider.get(), rollaBandServiceProvider.get(), deviceInformationServiceProvider.get(), deviceFirmwareUpdateServiceProvider.get());
  }

  public static FlutterSdkModule_ProvideBleRegistryFactory create(
      Provider<HeartRateService> heartRateServiceProvider,
      Provider<RunningSpeedAndCadenceService> runningSpeedAndCadenceServiceProvider,
      Provider<RollaBandService> rollaBandServiceProvider,
      Provider<DeviceInformationService> deviceInformationServiceProvider,
      Provider<DeviceFirmwareUpdateService> deviceFirmwareUpdateServiceProvider) {
    return new FlutterSdkModule_ProvideBleRegistryFactory(heartRateServiceProvider, runningSpeedAndCadenceServiceProvider, rollaBandServiceProvider, deviceInformationServiceProvider, deviceFirmwareUpdateServiceProvider);
  }

  public static BleRegistry provideBleRegistry(HeartRateService heartRateService,
      RunningSpeedAndCadenceService runningSpeedAndCadenceService,
      RollaBandService rollaBandService, DeviceInformationService deviceInformationService,
      DeviceFirmwareUpdateService deviceFirmwareUpdateService) {
    return Preconditions.checkNotNullFromProvides(FlutterSdkModule.INSTANCE.provideBleRegistry(heartRateService, runningSpeedAndCadenceService, rollaBandService, deviceInformationService, deviceFirmwareUpdateService));
  }
}
