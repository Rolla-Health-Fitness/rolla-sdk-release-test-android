package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.characteristics.data.HrvData
import app.rolla.bluetoothSdk.characteristics.data.SleepData
import app.rolla.bluetoothSdk.characteristics.data.StepsData
import app.rolla.bluetoothSdk.characteristics.data.TotalHeartRateData
import app.rolla.bluetoothSdk.commands.data.SleepPhase
import com.rolla.sdk.extensions.collectNextPageFlowWithCallback
import com.rolla.sdk.extensions.executeCommandOperation
import com.rolla.sdk.generated.RollaBandHRV
import com.rolla.sdk.generated.RollaBandHRVSyncResponse
import com.rolla.sdk.generated.RollaBandHealthDataHostApi
import com.rolla.sdk.generated.RollaBandHeartRate
import com.rolla.sdk.generated.RollaBandHeartRateSyncResponse
import com.rolla.sdk.generated.RollaBandSleepStage
import com.rolla.sdk.generated.RollaBandSleepStageValue
import com.rolla.sdk.generated.RollaBandSleepSyncResponse
import com.rolla.sdk.generated.RollaBandStep
import com.rolla.sdk.generated.RollaBandStepsSyncResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

@SuppressLint("MissingPermission")
class RollaBandHealthDataHostApiImpl(
    private val bleManager: BleManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : RollaBandHealthDataHostApi {

    companion object {
        private const val TAG = "RollaBandHealthDataHostApiImpl"
        private const val END_MARKER: Byte = 0xFF.toByte()
        private const val BLOCK_TIMEOUT_MS = 3000L
        private const val MAX_CONSECUTIVE_TIMEOUTS = 2

        private val ENTRY_SIZES = mapOf(
            0x52.toByte() to 25,   // Steps
            0x53.toByte() to 130,  // Sleep
            0x54.toByte() to 24,   // Activity HR
            0x55.toByte() to 10,   // Passive HR
            0x56.toByte() to 15,   // HRV
        )
    }

    private data class CustomCommandSpec(
        val header: String,
        val commandByte: Byte,
        val entrySize: Int,
        val maxEntriesPerPage: Int
    )

    private val customPagingCommands = listOf(
        CustomCommandSpec("CUSTOM 0x76", 0x76.toByte(), 10, 24 * 50),
        CustomCommandSpec("CUSTOM 0x77", 0x77.toByte(), 14, 17 * 50),
        CustomCommandSpec("CUSTOM 0x58", 0x58.toByte(), 33, 7 * 50),
        CustomCommandSpec("CUSTOM 0x59", 0x59.toByte(), 75, 3 * 50),
        CustomCommandSpec("CUSTOM 0x5C", 0x5C.toByte(), 25, 9 * 50),
    )

    private val stepsCallbacks: MutableMap<String, (Result<RollaBandStepsSyncResponse>) -> Unit> = ConcurrentHashMap()
    private val hrvCallbacks: MutableMap<String, (Result<RollaBandHRVSyncResponse>) -> Unit> = ConcurrentHashMap()
    private val heartRateCallbacks: MutableMap<String, (Result<RollaBandHeartRateSyncResponse>) -> Unit> = ConcurrentHashMap()
    private val sleepCallbacks: MutableMap<String, (Result<RollaBandSleepSyncResponse>) -> Unit> = ConcurrentHashMap()

    init {
        collectStepsFlow()
        collectHrvFlow()
        collectHeartRateFlow()
        collectSleepFlow()
    }

    override fun getStepsData(
        uuid: String,
        lastSyncedBlockTimestamp: Long,
        lastSyncedEntryTimestamp: Long,
        callback: (Result<RollaBandStepsSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = stepsCallbacks,
            callback = callback,
            operationName = "getStepsData",
            operation = {
                bleManager.readBandSteps(uuid, lastSyncedBlockTimestamp, lastSyncedEntryTimestamp)
            },
            tag = TAG
        )
    }

    override fun getHeartRateData(
        uuid: String,
        activityLastSyncedBlockTimestamp: Long,
        activityLastSyncedEntryTimestamp: Long,
        passiveLastSyncedTimestamp: Long,
        callback: (Result<RollaBandHeartRateSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = heartRateCallbacks,
            callback = callback,
            operationName = "getHeartRateData",
            operation = {
                bleManager.readBandHeartRate(
                    uuid,
                    activityLastSyncedBlockTimestamp,
                    activityLastSyncedEntryTimestamp,
                    passiveLastSyncedTimestamp
                )
            },
            tag = TAG
        )
    }

    override fun getHRVData(
        uuid: String,
        lastSyncedBlockTimestamp: Long,
        callback: (Result<RollaBandHRVSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = hrvCallbacks,
            callback = callback,
            operationName = "getHRVData",
            operation = {
                bleManager.readBandHrv(uuid, lastSyncedBlockTimestamp)
            },
            tag = TAG
        )
    }

    override fun getSleepData(
        uuid: String,
        lastSyncedBlockTimestamp: Long,
        lastSyncedEntryTimestamp: Long,
        callback: (Result<RollaBandSleepSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = sleepCallbacks,
            callback = callback,
            operationName = "getSleepData",
            operation = {
                bleManager.readBandSleep(uuid, lastSyncedBlockTimestamp, lastSyncedEntryTimestamp)
            },
            tag = TAG
        )
    }

    override fun getRawDataLogs(uuid: String, callback: (Result<String>) -> Unit) {
        scope.launch {
            try {
                val sections = mutableListOf<String>()

                sections.add(fetchUserProfileForRawLogs(uuid))

                bleManager.enableRawCaptureMode()
                try {
                    val standardRawBytes: MutableList<ByteArray> = Collections.synchronizedList(mutableListOf())
                    val collectorJob: Job = launch {
                        bleManager.getRawNotificationFlow().collect { bytes ->
                            standardRawBytes.add(bytes.copyOf())
                        }
                    }

                    try {
                        awaitStepsSync(uuid)
                        awaitSleepSync(uuid)
                        awaitHeartRateSync(uuid)
                        awaitHrvSync(uuid)
                    } finally {
                        collectorJob.cancelAndJoin()
                    }

                    val grouped = standardRawBytes.groupBy { if (it.isNotEmpty()) it[0] else 0.toByte() }
                    sections.add(formatSection("STEPS", grouped[0x52.toByte()], ENTRY_SIZES.getValue(0x52.toByte())))
                    sections.add(formatSection("SLEEP", grouped[0x53.toByte()], ENTRY_SIZES.getValue(0x53.toByte())))
                    sections.add(formatSection("HEART RATE", grouped[0x55.toByte()], ENTRY_SIZES.getValue(0x55.toByte())))
                    sections.add(formatSection("ACTIVITY HEART RATE", grouped[0x54.toByte()], ENTRY_SIZES.getValue(0x54.toByte())))
                    sections.add(formatSection("HRV", grouped[0x56.toByte()], ENTRY_SIZES.getValue(0x56.toByte())))

                   for (spec in customPagingCommands) {
                        val sectionResult = try {
                            val bytes = readCustomCommandData(uuid, spec.commandByte, spec.entrySize, spec.maxEntriesPerPage)
                            formatSection(spec.header, bytes, spec.entrySize)
                        } catch (e: Exception) {
                            "=== ${spec.header} ===\n(error: ${e.message})\n\n"
                        }
                        sections.add(sectionResult)
                    }

                    val singleReadResult = try {
                        val bytes = readSingleCommand(uuid, 0x66.toByte())
                        formatSingleReadSection("CUSTOM READ 0x66", bytes)
                    } catch (e: Exception) {
                        "=== CUSTOM READ 0x66 ===\n(error: ${e.message})\n\n"
                    }
                    sections.add(singleReadResult)

                } finally {
                    bleManager.disableRawCaptureMode()
                }

                val rawData = sections.joinToString("")
                withContext(Dispatchers.Main) {
                    callback(Result.success(rawData))
                }
            } catch (e: Exception) {
                bleManager.disableRawCaptureMode()
                withContext(Dispatchers.Main) {
                    callback(Result.failure(e))
                }
            }
        }
    }

    private suspend fun awaitStepsSync(uuid: String): Unit = suspendCancellableCoroutine { cont ->
        getStepsData(uuid, 0, 0) { if (cont.isActive) cont.resume(Unit) }
    }

    private suspend fun awaitSleepSync(uuid: String): Unit = suspendCancellableCoroutine { cont ->
        getSleepData(uuid, 0, 0) { if (cont.isActive) cont.resume(Unit) }
    }

    private suspend fun awaitHeartRateSync(uuid: String): Unit = suspendCancellableCoroutine { cont ->
        getHeartRateData(uuid, 0, 0, 0) { if (cont.isActive) cont.resume(Unit) }
    }

    private suspend fun awaitHrvSync(uuid: String): Unit = suspendCancellableCoroutine { cont ->
        getHRVData(uuid, 0) { if (cont.isActive) cont.resume(Unit) }
    }

    private suspend fun readCustomCommandData(
        uuid: String,
        commandByte: Byte,
        entrySize: Int,
        maxEntriesPerPage: Int
    ): List<ByteArray> {
        val allRawBytes = mutableListOf<ByteArray>()
        val channel = Channel<ByteArray>(Channel.UNLIMITED)

        val collectorJob = scope.launch {
            bleManager.getRawNotificationFlow().collect { bytes ->
                if (bytes.isNotEmpty() && bytes[0] == commandByte) {
                    channel.send(bytes.copyOf())
                }
            }
        }

        try {
            var keepPaging = true
            var isFirstPage = true

            while (keepPaging) {
                val writeResult = bleManager.writeCustomCommand(uuid, commandByte, !isFirstPage)
                if (!writeResult.successful) break
                isFirstPage = false

                var totalEntries = 0
                var consecutiveTimeouts = 0

                pageLoop@ while (true) {
                    val notification = withTimeoutOrNull(BLOCK_TIMEOUT_MS) {
                        channel.receive()
                    }

                    if (notification == null) {
                        consecutiveTimeouts++
                        if (consecutiveTimeouts >= MAX_CONSECUTIVE_TIMEOUTS) {
                            keepPaging = if (allRawBytes.isEmpty()) false
                            else totalEntries >= maxEntriesPerPage
                            break@pageLoop
                        }
                        continue@pageLoop
                    }

                    consecutiveTimeouts = 0
                    allRawBytes.add(notification)

                    if (notification.last() == END_MARKER) {
                        keepPaging = false
                        break@pageLoop
                    }

                    totalEntries += countEntriesInBlock(notification, commandByte, entrySize)

                    if (totalEntries >= maxEntriesPerPage) {
                        keepPaging = true
                        break@pageLoop
                    }
                }
            }
        } finally {
            collectorJob.cancelAndJoin()
            channel.close()
        }

        return allRawBytes
    }

    private suspend fun readSingleCommand(uuid: String, commandByte: Byte): List<ByteArray> {
        val channel = Channel<ByteArray>(Channel.UNLIMITED)

        val collectorJob = scope.launch {
            bleManager.getRawNotificationFlow().collect { bytes ->
                if (bytes.isNotEmpty() && bytes[0] == commandByte) {
                    channel.send(bytes.copyOf())
                }
            }
        }

        try {
            val writeResult = bleManager.writeCustomCommand(uuid, commandByte, false)
            if (!writeResult.successful) return emptyList()

            val notification = withTimeoutOrNull(BLOCK_TIMEOUT_MS) {
                channel.receive()
            }

            return if (notification != null) listOf(notification) else emptyList()
        } finally {
            collectorJob.cancelAndJoin()
            channel.close()
        }
    }

    private fun formatSection(header: String, rawBytes: List<ByteArray>?, entrySize: Int): String {
        val sb = StringBuilder()
        sb.append("=== $header ===\n")

        if (rawBytes.isNullOrEmpty()) {
            sb.append("(no data)")
        } else {
            val lines = mutableListOf<String>()
            for (notification in rawBytes) {
                if (notification.isEmpty()) continue
                val entries = divideIntoEntries(notification, notification[0], entrySize)
                for (entry in entries) {
                    lines.add(formatEntry(entry))
                }
                if (notification.last() == END_MARKER) {
                    lines.add(String.format("%02X FF", notification[0].toInt() and 0xFF))
                }
            }
            if (lines.isEmpty()) {
                sb.append("(no data)")
            } else {
                sb.append(lines.joinToString("\n"))
            }
        }

        sb.append("\n\n")
        return sb.toString()
    }

    private fun formatSingleReadSection(header: String, rawBytes: List<ByteArray>): String {
        val sb = StringBuilder()
        sb.append("=== $header ===\n")

        if (rawBytes.isEmpty()) {
            sb.append("(no data)")
        } else {
            sb.append(rawBytes.joinToString("\n") { bytes ->
                bytes.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }
            })
        }

        sb.append("\n\n")
        return sb.toString()
    }

    private fun divideIntoEntries(data: ByteArray, header: Byte, entrySize: Int): List<ByteArray> {
        val entries = mutableListOf<ByteArray>()
        var index = 0
        while (index < data.size) {
            if (data[index] == header) {
                val end = minOf(index + entrySize, data.size)
                val entry = data.copyOfRange(index, end)
                if (entry.size == entrySize) {
                    entries.add(entry)
                }
                index += entrySize
            } else {
                index++
            }
        }
        return entries
    }

    private fun formatEntry(entry: ByteArray): String {
        return entry.mapIndexed { index, byte ->
            if (index in 3..8) {
                val decoded = ((byte.toInt() shr 4) and 0x0F) * 10 + (byte.toInt() and 0x0F)
                String.format("%02d", decoded)
            } else {
                String.format("%02X", byte.toInt() and 0xFF)
            }
        }.joinToString(" ")
    }

    private fun countEntriesInBlock(data: ByteArray, header: Byte, entrySize: Int): Int {
        var count = 0
        var index = 0
        while (index < data.size) {
            if (data[index] == header && index + entrySize <= data.size) {
                count++
                index += entrySize
            } else {
                index++
            }
        }
        return count
    }

    private suspend fun fetchUserProfileForRawLogs(uuid: String): String {
        val defaultValue = "=== USER PROFILE ===\nFailed to fetch user profile\n\n"

        return try {
            withTimeoutOrNull(3500L) {
                val deferred = scope.async {
                    bleManager.getRollaBandUserDataFlow().first { it.uuid == uuid }
                }
                bleManager.readBandUserData(uuid)
                val userData = deferred.await()
                val userInfo = userData.userInfo
                buildString {
                    append("=== USER PROFILE ===\n")
                    append("Gender: ${if (userInfo.gender == 1) "Male" else "Female"}\n")
                    append("Age: ${userInfo.age}\n")
                    append("Height: ${userInfo.height} cm\n")
                    append("Weight: ${userInfo.weight} kg\n")
                    append("Stride: ${userInfo.stride} cm\n")
                    append("\n")
                }
            } ?: defaultValue
        } catch (e: Exception) {
            "=== USER PROFILE ===\nFailed to fetch user profile: ${e.message}\n\n"
        }
    }

    private fun collectStepsFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandStepsFlow(),
            callbacks = stepsCallbacks,
            tag = TAG,
            dataName = "Steps data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonStepsData(it) }
        )
    }

    private fun collectHrvFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandHrvFlow(),
            callbacks = hrvCallbacks,
            tag = TAG,
            dataName = "HRV data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonHrvData(it) }
        )
    }

    private fun collectHeartRateFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandHeartRateFlow(),
            callbacks = heartRateCallbacks,
            tag = TAG,
            dataName = "Heart rate data",
            getUuid = { it.uuid },
            isDataEnd = { true },
            getSuccessValue = { convertToPigeonHeartRateData(it) }
        )
    }

    private fun collectSleepFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandSleepFlow(),
            callbacks = sleepCallbacks,
            tag = TAG,
            dataName = "Sleep data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonSleepData(it) }
        )
    }

    private fun convertToPigeonStepsData(stepsData: StepsData): RollaBandStepsSyncResponse {
        return RollaBandStepsSyncResponse(
            steps = stepsData.steps.map {
                RollaBandStep(it.timestamp, it.steps.toLong(), it.calories)
            },
            lastSyncedBlockTimestamp = stepsData.lastBlockTimestamp,
            lastSyncedEntryTimestamp = stepsData.lastEntryTimestamp
        )
    }

    private fun convertToPigeonHrvData(hrvData: HrvData): RollaBandHRVSyncResponse {
        return RollaBandHRVSyncResponse(
            hrvs = hrvData.hrvList.map {
                RollaBandHRV(it.timestamp, it.hrv.toLong())
            },
            lastSyncedBlockTimestamp = hrvData.lastBlockTimestamp
        )
    }

    private fun convertToPigeonHeartRateData(heartRateData: TotalHeartRateData): RollaBandHeartRateSyncResponse {
        return RollaBandHeartRateSyncResponse(
            heartRates = heartRateData.heartRates.map {
                RollaBandHeartRate(it.timestamp, it.heartRate.toLong())
            },
            activityLastSyncedBlockTimestamp = heartRateData.activityLastBlockTimestamp,
            activityLastSyncedEntryTimestamp = heartRateData.activityLastEntryTimestamp,
            passiveLastSyncedTimestamp = heartRateData.passiveLastBlockTimestamp
        )
    }

    private fun convertToPigeonSleepData(sleepData: SleepData): RollaBandSleepSyncResponse {
        return RollaBandSleepSyncResponse(
            sleepStages = sleepData.sleeps.map {
                RollaBandSleepStage(it.startTime, it.endTime, it.phase.toPigeonValue())
            },
            lastSyncedBlockTimestamp = sleepData.lastBlockTimestamp,
            lastSyncedEntryTimestamp = sleepData.lastEntryTimestamp
        )
    }

    private fun SleepPhase.toPigeonValue(): RollaBandSleepStageValue {
        return when (this) {
            SleepPhase.DEEP -> RollaBandSleepStageValue.DEEP
            SleepPhase.LIGHT -> RollaBandSleepStageValue.LIGHT
            SleepPhase.REM -> RollaBandSleepStageValue.REM
            SleepPhase.AWAKE -> RollaBandSleepStageValue.AWAKE
        }
    }

    fun cleanup() {
        stepsCallbacks.clear()
        hrvCallbacks.clear()
        heartRateCallbacks.clear()
        sleepCallbacks.clear()
        scope.cancel()
    }

}