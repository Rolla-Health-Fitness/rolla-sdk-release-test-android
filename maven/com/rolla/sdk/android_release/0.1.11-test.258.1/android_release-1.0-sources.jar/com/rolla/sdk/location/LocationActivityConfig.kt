package com.rolla.sdk.location

import com.rolla.sdk.generated.BandActivityType

/**
 * Per-activity configuration for the location pipeline.
 * Direct port of iOS LocationTrackingConfig from the location-improvements branch.
 */
data class LocationActivityConfig(
    /** Maximum horizontal accuracy (meters) — locations worse than this are rejected. */
    val maxAccuracy: Double,
    /** Maximum plausible speed (m/s) — implied speeds above this are rejected (Gate A). */
    val maxSpeedMps: Double,
    /** Seconds of GPS silence before resetting the pipeline. */
    val gapResetThresholdSeconds: Double,
    /** Number of consecutive gate rejections before force re-bootstrapping the pipeline. */
    val maxConsecutiveRejections: Int,
    /** Whether to reset calibration on GPS gap (vs just pipeline state). */
    val resetCalibrationOnGap: Boolean,
    /** Calibration sub-config. */
    val calibrationConfig: GPSCalibrationConfig,
    /** Floor value for minimum emit distance: max(floor, min(accuracy * 0.5, 8.0)). */
    val minEmitDistanceFloor: Double = 3.0,
    /** Upper bound on EMA alpha: min(cap, max(0.2, 5.0 / accuracy)). */
    val emaAlphaCap: Double = 1.0,
    /** Doppler speed threshold for consecutive-slow counting in StationaryDetector. */
    val stationarySpeedEntry: Double = 0.40,
    /** Number of consecutive readings below entry threshold to declare stationary. */
    val stationaryConsecutiveRequired: Int = 3,
    /** Doppler speed above which stationary state is exited. */
    val stationarySpeedExit: Double = 0.45,
    /** Displacement (meters) above which stationary state is exited. */
    val stationaryDisplacementExit: Double = 3.0
) {
    companion object {
        fun forActivity(type: BandActivityType): LocationActivityConfig {
            return when (type) {
                BandActivityType.RUN -> LocationActivityConfig(
                    // 20 m: urban runners pass tall buildings regularly; tighter would drop valid fixes
                    maxAccuracy = 20.0,
                    // 12.5 m/s = 45 km/h — just above Usain Bolt's peak (12.4 m/s)
                    maxSpeedMps = 12.5,
                    // Runners move continuously; a 30 s GPS outage is a real signal problem
                    gapResetThresholdSeconds = 30.0,
                    // 6 consecutive rejections ≈ 6 s of GPS teleporting — clearly a bad fix burst
                    maxConsecutiveRejections = 6,
                    resetCalibrationOnGap = false,
                    calibrationConfig = GPSCalibrationConfig(
                        calibrationDurationMs = 6000L,
                        minPointsForCalibration = 4,
                        maxCalibrationAccuracy = 25.0
                    )
                )

                BandActivityType.CYCLING -> LocationActivityConfig(
                    // 20 m: cyclists move fast so accuracy is generally good; 20 m is generous enough
                    maxAccuracy = 20.0,
                    // 25 m/s = 90 km/h — covers downhill racing, well above typical 30–40 km/h riding
                    maxSpeedMps = 25.0,
                    // Cycling red lights can be 60–90 s; tunnels can be 30–60 s.
                    gapResetThresholdSeconds = 90.0,
                    // Cyclists can have GPS shadow from buildings for several seconds
                    maxConsecutiveRejections = 8,
                    resetCalibrationOnGap = false,
                    calibrationConfig = GPSCalibrationConfig(
                        calibrationDurationMs = 6000L,
                        minPointsForCalibration = 4,
                        maxCalibrationAccuracy = 30.0
                    )
                )

                BandActivityType.WALK -> LocationActivityConfig(
                    // 25 m: walkers are slower so fix rate matters more than peak accuracy
                    maxAccuracy = 25.0,
                    // 3.5 m/s = 12.6 km/h — competitive race walkers reach ~4 m/s
                    maxSpeedMps = 3.5,
                    // Pedestrians stop at crossings (30–90 s). Gap reset is for GPS hardware outages only.
                    gapResetThresholdSeconds = 90.0,
                    // Walkers cross building facades regularly; be tolerant of short rejection runs
                    maxConsecutiveRejections = 10,
                    resetCalibrationOnGap = false,
                    calibrationConfig = GPSCalibrationConfig(
                        calibrationDurationMs = 6000L,
                        minPointsForCalibration = 3,
                        maxCalibrationAccuracy = 30.0
                    ),
                    // LocationManager requests FusedLocation at ~970 ms (effective ~1 Hz
                    // in field logs); at that cadence a 5 m floor stretches emits to
                    // ~3.5 s at walking pace and feels laggy on the map. 3 m emits
                    // every ~2 s while the EMA alpha cap of 0.6 keeps GPS scatter
                    // from reintroducing zig-zag.
                    minEmitDistanceFloor = 3.0,
                    // Cap smoothing so GPS scatter doesn't pass through at good accuracy
                    emaAlphaCap = 0.6,
                    // Lower entry threshold avoids false stationary during slow walking
                    stationarySpeedEntry = 0.30,
                    // Extra reading required to confirm stationary — reduces micro-stop false triggers
                    stationaryConsecutiveRequired = 4,
                    // Tighter exit for faster recovery from genuine stops at walking pace
                    stationarySpeedExit = 0.40,
                    stationaryDisplacementExit = 2.5
                )

                BandActivityType.HIKING -> LocationActivityConfig(
                    // 40 m: dense forest canopy regularly degrades GPS accuracy to 25–45 m.
                    maxAccuracy = 40.0,
                    // 3.0 m/s = 10.8 km/h — covers fast trail running segments on hikes
                    maxSpeedMps = 3.0,
                    // Hikers rest under tree cover; GPS can drop for 60–120 s in dense forest.
                    gapResetThresholdSeconds = 120.0,
                    // Dense forest can cause many consecutive multipath rejections
                    maxConsecutiveRejections = 12,
                    resetCalibrationOnGap = false,
                    calibrationConfig = GPSCalibrationConfig(
                        calibrationDurationMs = 6000L,
                        minPointsForCalibration = 5,
                        maxCalibrationAccuracy = 50.0
                    ),
                    // Wider floor absorbs the scatter typical under dense forest
                    // canopy where accuracy routinely degrades to 25–45 m.
                    minEmitDistanceFloor = 5.0,
                    // Cap smoothing for forest GPS scatter
                    emaAlphaCap = 0.6,
                    // Higher entry threshold — hikers pause more deliberately
                    stationarySpeedEntry = 0.35,
                    // Extra reading required to confirm stationary — reduces micro-stop false triggers
                    stationaryConsecutiveRequired = 4,
                    // Tighter exit for faster recovery from genuine stops at hiking pace
                    stationarySpeedExit = 0.42,
                    stationaryDisplacementExit = 2.5
                )

                // Non-GPS activities and fallback
                else -> LocationActivityConfig(
                    // 30 m: conservative — unknown activity may be indoors or mixed environment
                    maxAccuracy = 30.0,
                    // 10 m/s = 36 km/h — reasonable cap for unknown activity type
                    maxSpeedMps = 10.0,
                    // 60 s: moderate tolerance for unknown environment
                    gapResetThresholdSeconds = 60.0,
                    maxConsecutiveRejections = 8,
                    resetCalibrationOnGap = false,
                    calibrationConfig = GPSCalibrationConfig(
                        calibrationDurationMs = 6000L,
                        minPointsForCalibration = 4,
                        maxCalibrationAccuracy = 40.0
                    ),
                    // Slight EMA cap for unknown activities
                    emaAlphaCap = 0.8
                )
            }
        }
    }
}
