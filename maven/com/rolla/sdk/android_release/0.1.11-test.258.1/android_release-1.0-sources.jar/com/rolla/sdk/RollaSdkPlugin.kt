package com.rolla.sdk

import androidx.annotation.NonNull
import io.flutter.embedding.engine.plugins.FlutterPlugin
import android.util.Log

/**
 * RollaSdkPlugin - Zero-config Flutter plugin for Rolla SDK
 *
 * Automatically initializes all native components when attached to Flutter engine.
 * NO Hilt configuration required in host app!
 *
 * The plugin uses RollaAndroidSdk.init() which internally manages Hilt/Dagger DI
 * without requiring the host app to configure @HiltAndroidApp or @AndroidEntryPoint.
 *
 * Partner apps just need:
 * ```yaml
 * dependencies:
 *   rolla_sdk: ^0.1.0
 * ```
 */
class RollaSdkPlugin : FlutterPlugin {

    companion object {
        private const val TAG = "RollaSdkPlugin"
    }

    private var bridge: RollaBluetoothBridge? = null

    override fun onAttachedToEngine(@NonNull flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        try {
            // Initialize SDK with application context (internally handles Hilt/Dagger)
            val sdk = RollaAndroidSdk.init(flutterPluginBinding.applicationContext)

            // Create the bridge which registers all Pigeon handlers
            bridge = sdk.createBridge(
                context = flutterPluginBinding.applicationContext,
                binaryMessenger = flutterPluginBinding.binaryMessenger
            )

            HealthConnectWorkoutDetailsBridge.register(
                context = flutterPluginBinding.applicationContext,
                messenger = flutterPluginBinding.binaryMessenger,
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize RollaSdk", e)
        }
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        bridge?.cleanUp()
        bridge = null
    }
}
