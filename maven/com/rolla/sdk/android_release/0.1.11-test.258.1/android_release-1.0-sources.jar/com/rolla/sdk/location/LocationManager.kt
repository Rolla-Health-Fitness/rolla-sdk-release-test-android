package com.rolla.sdk.location

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.Looper
import app.rolla.bluetoothSdk.result.MethodResult
import android.location.LocationManager as AndroidLocationManager
import app.rolla.bluetoothSdk.utils.log
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.rolla.sdk.generated.BandActivityType
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LocationManager(private val context: Context) {

    private val locationScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        private const val MIN_TIME_INTERVAL = 970L
        private const val MIN_DISTANCE = 0f
        private const val USE_FUSED_LOCATION = true
        private const val TAG = "LocationManager"
    }

    private val androidLocationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as AndroidLocationManager
    private val fusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    init {
        // Register the app context with the debug capture so it can resolve
        // the external files dir when a session is started. No file I/O
        // happens here; the capture stays inert until isEnabled is flipped.
        LocationDebugCapture.initialize(context)
    }

    // Pipeline — created per activity with the appropriate config.
    // @Volatile: accessed from the main-looper location callback AND from callers
    // of reset()/startLocationUpdates() which may run on other threads.
    @Volatile
    private var pipeline: LocationPipeline? = null
    private var currentActivityType: BandActivityType? = null

    private val _locationFlow = MutableSharedFlow<Location>(replay = 0)
    val locationFlow: SharedFlow<Location> = _locationFlow.asSharedFlow()

    private var isLocationTrackingStarted = false

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            // Process every fix in the batch — FusedLocationProvider can deliver
            // multiple locations after doze wake-ups or CPU sleep.
            for (location in result.locations) {
                processLocation(location)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates(activityType: BandActivityType = BandActivityType.WALK): MethodResult {

        val hasFineLocation = context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val hasCoarseLocation = context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!hasFineLocation && !hasCoarseLocation) {
            return MethodResult(false, app.rolla.bluetoothSdk.result.error.UnknownError(Exception("Location permissions not granted")))
        }

        // iOS-parity idempotency guard. If tracking is already live, silently
        // no-op the second call instead of tearing the pipeline down and
        // rebuilding it. Mirrors DefaultLocationTrackingUseCase.startLocationTracking
        // on iOS, which early-returns via
        //   guard !(await locationManager.isLocationTracking()) else { return }
        //
        // Rationale: the Dart layer (ActivitySetupOverlay pre-warm +
        // ActivityCubit.start) fires startLocationTracking twice for a single
        // user-initiated workout. On iOS the second call is swallowed, so
        // calibration / EMA / accepted-history / the JSONL capture accumulate
        // continuously from the first fix. Previously Android would reset all
        // of that state on the second call and open a second log file ~1.4 s
        // into the session, discarding the warm-up fixes.
        //
        // A dedicated stopLocationUpdates() / reset() is still required to
        // begin a new workout; this guard only covers the "already-live"
        // repeat-start path.
        if (isLocationTrackingStarted) {
            log(TAG, "[LOCATION] startLocationUpdates called while tracking already active — keeping existing pipeline (requestedActivity=$activityType, currentActivity=$currentActivityType)")
            // Re-assert the foreground service/notification in case the host
            // process was backgrounded between the two calls.
            startLocationService()
            return MethodResult(true)
        }

        resetForNewActivity(activityType)

        return try {
            val result = if (USE_FUSED_LOCATION) {
                startFusedLocationUpdates()
            } else {
                startGpsLocationUpdates()
            }

            if (result.successful) {
                startLocationService()
                isLocationTrackingStarted = true
            }
            result
        } catch (e: Exception) {
            e.printStackTrace()
            MethodResult(false, LocationTrackingStartFailed(e))
        }
    }

    fun stopLocationUpdates(): MethodResult {
        if (!isLocationTrackingStarted) {
            return MethodResult(false, LocationTrackingNotStarted())
        }
        return try {
            if (USE_FUSED_LOCATION) {
                fusedLocationProviderClient.removeLocationUpdates(locationCallback)
            } else {
                androidLocationManager.removeUpdates(this::onLocationChanged)
            }

            finalizeDebugCapture()
            stopLocationService()
            isLocationTrackingStarted = false
            MethodResult(true)
        } catch (e: Exception) {
            e.printStackTrace()
            MethodResult(false, LocationTrackingStopFailed(e))
        }
    }

    fun reset() {
        finalizeDebugCapture()
        pipeline?.reset()
        pipeline = null
        currentActivityType = null
        stopLocationUpdates()
        isLocationTrackingStarted = false
        // Do NOT cancel the singleton scope here; this LocationManager instance is a singleton.
        // Cancelling would permanently prevent future emissions via locationFlow.
    }

    private fun resetForNewActivity(activityType: BandActivityType) {
        // Close any previous capture cleanly before opening a new one. Each
        // new activity starts its own JSONL file and counter sequence.
        finalizeDebugCapture()

        currentActivityType = activityType
        val config = LocationActivityConfig.forActivity(activityType)
        val trackingStartTimeMs = System.currentTimeMillis()

        // Open the capture file BEFORE constructing the pipeline so the
        // config-snapshot emitted by the pipeline constructor lands in the
        // JSONL rather than being silently dropped while the file handle
        // is still nil. No-op if debug capture is disabled.
        LocationDebugCapture.startSession()
        pipeline = LocationPipeline(activityType, config, trackingStartTimeMs)
        log(TAG, "[LOCATION] Reset for new activity - type: $activityType, " +
                "maxAccuracy: ${config.maxAccuracy}m, maxSpeed: ${config.maxSpeedMps}m/s, " +
                "trackingStartTimeMs: $trackingStartTimeMs")
    }

    private fun finalizeDebugCapture() {
        // Emit pipeline-summary (if any pipeline is live) before closing
        // the file so the summary lands as the final line of the JSONL.
        pipeline?.finalizeSession()
        LocationDebugCapture.stopSession()
    }

    @SuppressLint("MissingPermission")
    private fun startFusedLocationUpdates(): MethodResult {
        val locationRequest = LocationRequest.Builder(MIN_TIME_INTERVAL)
            .setMaxUpdates(Integer.MAX_VALUE)
            .setMinUpdateIntervalMillis(MIN_TIME_INTERVAL)
            .setWaitForAccurateLocation(false)
            .setIntervalMillis(MIN_TIME_INTERVAL)
            .setMinUpdateDistanceMeters(MIN_DISTANCE)
            .setDurationMillis(Long.MAX_VALUE)
            .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
            .build()

        val task = fusedLocationProviderClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )

        task.addOnSuccessListener {
            log(TAG, "[LOCATION] Location updates request succeeded!")
        }
        task.addOnFailureListener { e ->
            log(TAG, "[LOCATION] ❌ Location updates request FAILED: ${e.message}")
            e.printStackTrace()
        }

        return MethodResult(true)
    }

    @SuppressLint("MissingPermission")
    private fun startGpsLocationUpdates(): MethodResult {
        androidLocationManager.requestLocationUpdates(
            AndroidLocationManager.GPS_PROVIDER,
            MIN_TIME_INTERVAL,
            MIN_DISTANCE,
            this::onLocationChanged,
            Looper.getMainLooper()
        )
        return MethodResult(true)
    }

    private fun onLocationChanged(location: Location) {
        processLocation(location)
    }

    private fun processLocation(location: Location) {
        log(TAG, "[LOCATION] Raw: ${location.latitude}, ${location.longitude}, accuracy: ${location.accuracy}")

        // Snapshot the volatile reference so we work against a single pipeline instance
        // even if another thread nulls the field mid-call.
        val currentPipeline = pipeline ?: return
        val filtered = currentPipeline.processLocation(location) ?: return

        log(TAG, "[LOCATION] Emitting filtered location to flow")
        locationScope.launch {
            _locationFlow.emit(filtered)
            log(TAG, "[LOCATION] Location emitted successfully via coroutine")
        }
    }

    private fun startLocationService() {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_START_TRACKING
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    private fun stopLocationService() {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_STOP_TRACKING
        }
        context.startService(intent)
    }
}
