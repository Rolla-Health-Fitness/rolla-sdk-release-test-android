package com.rolla.sdk.wrapper

/**
 * SDK modules that can be disabled.
 *
 * Pass values to [RollaConfiguration.disabledModules] 
 * to disable that module everywhere in the SDK UI.
 */
enum class RollaDisabledModule(val rawValue: String) {
    WEIGHT("weight"),
    BLOOD_PRESSURE("bloodPressure"),
}
