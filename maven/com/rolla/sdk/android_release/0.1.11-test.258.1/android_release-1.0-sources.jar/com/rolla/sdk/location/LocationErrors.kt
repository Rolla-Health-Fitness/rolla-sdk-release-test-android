package com.rolla.sdk.location

object LocationErrors {

    const val LOCATION_TRACKING_NOT_STARTED = "location_tracking_not_started"
    const val LOCATION_TRACKING_ALREADY_STARTED = "location_tracking_already_started"
    const val LOCATION_TRACKING_START_FAILED = "location_tracking_start_failed"
    const val LOCATION_TRACKING_STOP_FAILED = "location_tracking_stop_failed"
}