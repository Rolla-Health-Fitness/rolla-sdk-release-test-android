package com.rolla.sdk.wrapper

import android.content.Context
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.embedding.engine.plugins.util.GeneratedPluginRegister
import io.flutter.plugin.common.MethodChannel

internal class RollaEngineManager private constructor() {

    companion object {
        private const val TAG = "RollaEngineManager"
        internal const val ENGINE_ID = "rolla_wrapper_engine"
        private const val CHANNEL_NAME = "rolla_sdk/init"

        @Volatile
        private var instance: RollaEngineManager? = null

        fun getInstance(): RollaEngineManager {
            return instance ?: synchronized(this) {
                instance ?: RollaEngineManager().also { instance = it }
            }
        }
    }

    private var engine: FlutterEngine? = null
    private var methodChannel: MethodChannel? = null

    @Volatile
    var isPresenting: Boolean = false
        private set

    @Volatile
    var isReady: Boolean = false
        private set

    var onClose: ((String?) -> Unit)? = null
    var onError: ((String, String) -> Unit)? = null
    var onTokenRefreshed: ((String, String?, Int?) -> Unit)? = null
    var onTokenExpired: (() -> Unit)? = null

    private val initLock = Any()

    fun initialize(context: Context) {
        if (engine != null) {
            Log.d(TAG, "Engine already initialized")
            return
        }

        synchronized(initLock) {
            if (engine != null) {
                Log.d(TAG, "Engine already initialized (after lock)")
                return
            }

            Log.d(TAG, "Initializing Flutter engine...")

            val appContext = context.applicationContext
            val flutterEngine = FlutterEngine(appContext)

            GeneratedPluginRegister.registerGeneratedPlugins(flutterEngine)
            
            try {
                val sdk = com.rolla.sdk.RollaAndroidSdk.init(appContext)
                sdk.createBridge(appContext, flutterEngine.dartExecutor.binaryMessenger)
                Log.d(TAG, "Rolla SDK bridge created - Pigeon handlers registered")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create Rolla SDK bridge", e)
            }

            flutterEngine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint.createDefault()
            )

            FlutterEngineCache.getInstance().put(ENGINE_ID, flutterEngine)

            setupMethodChannel(flutterEngine)

            engine = flutterEngine
            isReady = true

            Log.d(TAG, "Flutter engine initialized and cached with ID: $ENGINE_ID")
        }
    }

    private fun setupMethodChannel(engine: FlutterEngine) {
        val channel = MethodChannel(
            engine.dartExecutor.binaryMessenger,
            CHANNEL_NAME
        )

        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "close" -> {
                    val args = call.arguments as? Map<*, *>
                    val reason = args?.get("reason") as? String
                    onClose?.invoke(reason)
                    result.success(null)
                }
                "error" -> {
                    val args = call.arguments as? Map<*, *>
                    val code = args?.get("code") as? String ?: "UNKNOWN"
                    val message = args?.get("message") as? String ?: "Unknown error"
                    onError?.invoke(code, message)
                    result.success(null)
                }
                "onTokenRefreshed" -> {
                    val args = call.arguments as? Map<*, *>
                    val token = args?.get("token") as? String ?: ""
                    val refreshToken = args?.get("refreshToken") as? String
                    val expiresIn = (args?.get("expiresIn") as? Number)?.toInt()
                    onTokenRefreshed?.invoke(token, refreshToken, expiresIn)
                    result.success(null)
                }
                "onTokenExpired" -> {
                    onTokenExpired?.invoke()
                    result.success(null)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        methodChannel = channel
    }

    fun configure(
        config: RollaConfiguration,
        showBackButton: Boolean,
        callback: (Result<Unit>) -> Unit
    ) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        val args = mutableMapOf<String, Any>(
            "token" to config.token,
            "partnerId" to config.partnerId,
            "environment" to config.environment,
            "isModal" to true,
            "showBackButton" to showBackButton,
            "hideBottomNavigation" to true,
            "showSettingsButton" to config.showSettingsButton,
            "removeRollaBandReferences" to config.removeRollaBandReferences
        )

        config.userId?.let { args["userId"] = it }
        config.refreshToken?.let { args["refreshToken"] = it }
        config.tokenExpiresIn?.let { args["tokenExpiresIn"] = it }
        if (config.disabledModules.isNotEmpty()) {
            args["disabledModules"] = config.disabledModules.map { it.rawValue }
        }
        config.branding?.let { args["branding"] = it.toMap() }

        channel.invokeMethod("initialize", args, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "SDK configured successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "SDK configuration failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "Initialize method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("Initialize method not implemented")
                ))
            }
        })
    }

    fun updateToken(
        token: String,
        refreshToken: String?,
        expiresIn: Int?,
        callback: (Result<Unit>) -> Unit
    ) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        val args = mutableMapOf<String, Any>("token" to token)
        refreshToken?.let { args["refreshToken"] = it }
        expiresIn?.let { args["expiresIn"] = it }

        channel.invokeMethod("updateToken", args, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "Token updated successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Token update failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "updateToken method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("updateToken method not implemented")
                ))
            }
        })
    }

    fun clearSession(callback: (Result<Unit>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("clearSession", null, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "Session cleared successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Clear session failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "clearSession method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("clearSession method not implemented")
                ))
            }
        })
    }

    fun setPresenting(value: Boolean) {
        isPresenting = value
    }

    fun getEngine(): FlutterEngine? = engine

    fun destroy() {
        methodChannel?.setMethodCallHandler(null)
        methodChannel = null
        onClose = null
        onError = null
        onTokenRefreshed = null
        onTokenExpired = null

        engine?.let {
            FlutterEngineCache.getInstance().remove(ENGINE_ID)
            it.destroy()
        }
        engine = null
        isReady = false
        isPresenting = false

        Log.d(TAG, "Flutter engine destroyed")
    }
}
