package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import app.rolla.bluetoothSdk.BleManager
import com.rolla.sdk.dfu.DfuService
import com.rolla.sdk.extensions.collectFlowWithCallback
import com.rolla.sdk.extensions.executeCommandOperation
import com.rolla.sdk.generated.FirmwareHostAPI
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.util.concurrent.ConcurrentHashMap


@SuppressLint("MissingPermission")
class FirmwareHostApiImpl(
    private val bleManager: BleManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : FirmwareHostAPI {

    private val otaUpdateCallbacks: MutableMap<String, (Result<Unit>) -> Unit> = ConcurrentHashMap()

    init {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandFirmwareUpdateStartedFlow(),
            callbacks = otaUpdateCallbacks,
            tag = "FirmwareHostApiImpl",
            dataName = "Firmware update",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { }
        )
    }

    override fun startFirmwareUpdate(
        url: String,
        uuid: String,
        callback: (Result<Unit>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = otaUpdateCallbacks,
            callback = callback,
            operationName = "startFirmwareUpdate",
            operation = {
                bleManager.startBandOtaUpdate(url, uuid, DfuService::class.java)
            },
            tag = "FirmwareHostApiImpl"
        )
    }

    fun cleanup() {
        otaUpdateCallbacks.clear()
        scope.cancel()
    }
}
