package com.rolla.sdk.location

import android.location.Location
import android.os.SystemClock
import app.rolla.bluetoothSdk.utils.log
import kotlin.math.*

/**
 * GPS calibration state machine — port of iOS GPSCalibrationManager.
 *
 * Collects early GPS fixes, computes a centroid when they stabilise, and produces
 * a calibrated anchor point. After calibration, monitors for TTL expiry and
 * passively refreshes the baseline.
 *
 * State machine: NotStarted → Calibrating → Calibrated / Failed
 * Failed state auto-retries after a cooldown.
 */
class GPSCalibrationManager(
    private var config: GPSCalibrationConfig = GPSCalibrationConfig()
) {
    companion object {
        private const val TAG = "GPSCalibrationManager"
        private const val GOOD_FIX_ACCURACY_FOR_RETRY = 15.0
        private const val TTL_POOR_ACCURACY_THRESHOLD = 30.0
        private const val TTL_FAR_FROM_BASE_METERS = 2000.0
    }

    sealed class State {
        data object NotStarted : State()
        data class Calibrating(val startUptimeMs: Long, val pointsCollected: Int) : State()
        data class Calibrated(val baseLat: Double, val baseLon: Double, val accuracy: Double, val calibratedUptimeMs: Long) : State()
        data class Failed(val reason: String) : State()
    }

    sealed class Result {
        data object Calibrating : Result()
        data class Calibrated(val location: Location) : Result()
        data class Failed(val reason: String) : Result()
    }

    var state: State = State.NotStarted
        private set

    private val calibrationPoints = mutableListOf<Location>()

    private var lastFailureReason: String? = null
    private var lastFailureUptimeMs: Long? = null

    fun processLocation(location: Location): Result {
        return when (val s = state) {
            is State.NotStarted -> startCalibration(location)
            is State.Calibrating -> continueCalibration(location, s.startUptimeMs)
            is State.Calibrated -> validateAndPassThrough(location, s)
            is State.Failed -> handleFailedState(location)
        }
    }

    fun reset() {
        state = State.NotStarted
        calibrationPoints.clear()
        lastFailureReason = null
        lastFailureUptimeMs = null
    }

    fun updateConfiguration(newConfig: GPSCalibrationConfig) {
        config = newConfig
    }

    // --- Calibrating ---

    private fun startCalibration(location: Location): Result {
        val startUptime = uptimeMs()
        calibrationPoints.clear()
        state = State.Calibrating(startUptimeMs = startUptime, pointsCollected = 0)
        return continueCalibration(location, startUptime)
    }

    private fun continueCalibration(location: Location, startUptimeMs: Long): Result {
        val elapsed = uptimeMs() - startUptimeMs
        if (elapsed > config.calibrationDurationMs) {
            return finishCalibration()
        }

        if (location.hasAccuracy() && location.accuracy > 0 && location.accuracy <= config.maxCalibrationAccuracy) {
            calibrationPoints.add(location)
            if (calibrationPoints.size > config.maxPointsForCalibration) {
                calibrationPoints.removeAt(0)
            }
            state = State.Calibrating(startUptimeMs = startUptimeMs, pointsCollected = calibrationPoints.size)

            val (stable, _) = isStableCentroid()
            if (calibrationPoints.size >= config.minPointsForCalibration && stable) {
                return finishCalibration()
            }
        }

        return Result.Calibrating
    }

    // --- Calibrated ---

    private fun validateAndPassThrough(location: Location, s: State.Calibrated): Result {
        val age = uptimeMs() - s.calibratedUptimeMs

        if (age <= config.calibrationTTLMs) {
            return Result.Calibrated(location)
        }

        // TTL expired — passively refresh baseline
        val distanceFromBase = distanceMeters(
            location.latitude, location.longitude,
            s.baseLat, s.baseLon
        )
        val poorAccuracy = location.accuracy > TTL_POOR_ACCURACY_THRESHOLD
        val farFromBase = distanceFromBase > TTL_FAR_FROM_BASE_METERS

        if (poorAccuracy || farFromBase) {
            log(TAG, "[CALIBRATION] TTL expired (${age}ms) — refreshing baseline " +
                    "(acc=${String.format("%.0f", location.accuracy.toDouble())}m, " +
                    "dist=${String.format("%.0f", distanceFromBase)}m)")
            val now = uptimeMs()
            state = State.Calibrated(
                baseLat = location.latitude,
                baseLon = location.longitude,
                accuracy = location.accuracy.toDouble(),
                calibratedUptimeMs = now
            )
        }

        return Result.Calibrated(location)
    }

    // --- Failed ---

    private fun handleFailedState(location: Location): Result {
        val failAt = lastFailureUptimeMs
        if (failAt != null) {
            val timeSinceFailure = uptimeMs() - failAt
            val cooldown = if (location.accuracy <= GOOD_FIX_ACCURACY_FOR_RETRY) {
                config.retryAfterFailureCooldownMs
            } else {
                config.retryAfterFailureCooldownMs * 6
            }

            if (timeSinceFailure >= cooldown) {
                lastFailureUptimeMs = null
                lastFailureReason = null
                state = State.NotStarted
                return startCalibration(location)
            }
        }
        return Result.Failed(lastFailureReason ?: "poor_signal_quality")
    }

    // --- Finish calibration ---

    private fun finishCalibration(): Result {
        if (calibrationPoints.isEmpty()) {
            return failWith("poor_signal_quality", "No points collected")
        }

        if (calibrationPoints.size < config.minPointsForCalibration) {
            return failWith("timeout", "Timeout with ${calibrationPoints.size} points (need ${config.minPointsForCalibration})")
        }

        val (stable, maxDeviation) = isStableCentroid()
        if (!stable) {
            return failWith("insufficient_stability", "Points too scattered (max ${String.format("%.1f", maxDeviation)}m)")
        }

        val sorted = calibrationPoints.sortedBy { it.accuracy }
        val medianIndex = sorted.size / 2
        val medianAccuracy = if (sorted.size % 2 == 0) {
            (sorted[medianIndex - 1].accuracy + sorted[medianIndex].accuracy) / 2.0
        } else {
            sorted[medianIndex].accuracy.toDouble()
        }
        val medianPoint = sorted[medianIndex]

        if (medianAccuracy > config.medianAccuracyThreshold) {
            return failWith("poor_signal_quality", "Median accuracy ${String.format("%.1f", medianAccuracy)}m too poor")
        }

        val (centroidLat, centroidLon, fusedAccuracy) = calculateCentroid() ?: run {
            return failWith("poor_signal_quality", "Centroid calculation failed")
        }

        val now = uptimeMs()
        state = State.Calibrated(
            baseLat = centroidLat,
            baseLon = centroidLon,
            accuracy = fusedAccuracy,
            calibratedUptimeMs = now
        )

        val calibratedLocation = Location("calibrated").apply {
            latitude = centroidLat
            longitude = centroidLon
            altitude = medianPoint.altitude
            accuracy = fusedAccuracy.toFloat()
            time = medianPoint.time
            elapsedRealtimeNanos = medianPoint.elapsedRealtimeNanos
            if (medianPoint.hasSpeed()) speed = medianPoint.speed
            if (medianPoint.hasBearing()) bearing = medianPoint.bearing
        }

        log(TAG, "[CALIBRATION] OK at (${String.format("%.6f", centroidLat)}, ${String.format("%.6f", centroidLon)})")
        return Result.Calibrated(calibratedLocation)
    }

    private fun failWith(reason: String, message: String? = null): Result {
        state = State.Failed(reason)
        lastFailureReason = reason
        lastFailureUptimeMs = uptimeMs()
        if (message != null) {
            log(TAG, "[CALIBRATION] Failed: $message")
        }
        return Result.Failed(reason)
    }

    // --- Centroid math (spherical mean — matches iOS) ---

    private data class CentroidResult(val lat: Double, val lon: Double, val medianAccuracy: Double)

    private fun calculateCentroid(): CentroidResult? {
        if (calibrationPoints.isEmpty()) return null

        var sumX = 0.0; var sumY = 0.0; var sumZ = 0.0
        val accuracies = mutableListOf<Double>()

        for (p in calibrationPoints) {
            val latRad = Math.toRadians(p.latitude)
            val lonRad = Math.toRadians(p.longitude)
            sumX += cos(latRad) * cos(lonRad)
            sumY += cos(latRad) * sin(lonRad)
            sumZ += sin(latRad)
            accuracies.add(p.accuracy.toDouble())
        }

        val count = calibrationPoints.size.toDouble()
        val avgX = sumX / count
        val avgY = sumY / count
        val avgZ = sumZ / count

        val centralLon = atan2(avgY, avgX)
        val centralLat = atan2(avgZ, sqrt(avgX * avgX + avgY * avgY))

        accuracies.sort()
        val medianAccuracy = accuracies[accuracies.size / 2]

        return CentroidResult(
            lat = Math.toDegrees(centralLat),
            lon = Math.toDegrees(centralLon),
            medianAccuracy = medianAccuracy
        )
    }

    private fun isStableCentroid(): Pair<Boolean, Double> {
        val n = config.recentPointsForStability
        if (calibrationPoints.size < n) return Pair(false, Double.MAX_VALUE)

        val recent = calibrationPoints.takeLast(n)
        if (recent.size < 2) return Pair(false, Double.MAX_VALUE)

        var sumX = 0.0; var sumY = 0.0; var sumZ = 0.0
        for (p in recent) {
            val latRad = Math.toRadians(p.latitude)
            val lonRad = Math.toRadians(p.longitude)
            sumX += cos(latRad) * cos(lonRad)
            sumY += cos(latRad) * sin(lonRad)
            sumZ += sin(latRad)
        }
        val count = recent.size.toDouble()
        val avgX = sumX / count
        val avgY = sumY / count
        val avgZ = sumZ / count
        val centralLon = atan2(avgY, avgX)
        val centralLat = atan2(avgZ, sqrt(avgX * avgX + avgY * avgY))

        val centroidLat = Math.toDegrees(centralLat)
        val centroidLon = Math.toDegrees(centralLon)

        var maxDeviation = 0.0
        for (p in recent) {
            val d = distanceMeters(p.latitude, p.longitude, centroidLat, centroidLon)
            maxDeviation = maxOf(maxDeviation, d)
            if (d > config.stabilityThreshold) {
                return Pair(false, maxDeviation)
            }
        }
        return Pair(true, maxDeviation)
    }

    // --- Helpers ---

    private fun uptimeMs(): Long = SystemClock.elapsedRealtime()

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, results)
        return results[0].toDouble()
    }
}
