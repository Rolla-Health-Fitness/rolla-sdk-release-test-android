package com.rolla.sdk.wrapper

interface RollaListener {
    fun onRollaClosed(rolla: Rolla, reason: RollaCloseReason) {}
    fun onRollaError(rolla: Rolla, error: RollaError) {}

    /**
     * Called when the SDK successfully refreshes tokens internally.
     *
     * Use this to sync your app's token storage with the SDK's refreshed tokens.
     *
     * @param rolla The Rolla instance that refreshed the token.
     * @param token The new access token.
     * @param refreshToken The new refresh token, if provided.
     * @param expiresIn Time in seconds until the new access token expires, if known.
     */
    fun onTokenRefreshed(rolla: Rolla, token: String, refreshToken: String?, expiresIn: Int?) {}

    /**
     * Called when the SDK's internal token refresh fails and the host app needs to provide new tokens.
     *
     * When this is called, obtain fresh tokens from your auth backend and push them
     * to the SDK via [Rolla.updateToken].
     *
     * @param rolla The Rolla instance that needs fresh tokens.
     */
    fun onTokenExpired(rolla: Rolla) {}
}
