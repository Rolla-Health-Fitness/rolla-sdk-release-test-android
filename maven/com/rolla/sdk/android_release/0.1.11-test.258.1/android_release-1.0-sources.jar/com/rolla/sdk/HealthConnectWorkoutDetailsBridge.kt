package com.rolla.sdk

import android.content.Context
import android.content.Intent
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ExerciseRouteResult
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.SpeedRecord
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

object HealthConnectWorkoutDetailsBridge {
    private const val CHANNEL_NAME = "app.rolla/health_connect_workout_details"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun register(context: Context, messenger: BinaryMessenger) {
        val appContext = context.applicationContext
        MethodChannel(messenger, CHANNEL_NAME).setMethodCallHandler { call, result ->
            when (call.method) {
                "getWorkoutDetails" -> {
                    val startMs = call.argument<Long>("startMs")
                    val endMs = call.argument<Long>("endMs")
                    if (startMs == null || endMs == null || endMs <= startMs) {
                        result.error("invalid_args", "startMs/endMs are required and must be valid", null)
                        return@setMethodCallHandler
                    }
                    val sessionId = call.argument<String>("sessionId")
                    val sourceName = call.argument<String>("sourceName")

                    scope.launch {
                        try {
                            val payload = fetchWorkoutDetails(
                                context = appContext,
                                startMs = startMs,
                                endMs = endMs,
                                sessionId = sessionId,
                                sourceName = sourceName,
                            )
                            withContext(Dispatchers.Main) { result.success(payload) }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                result.error("health_connect_details_failed", e.message, null)
                            }
                        }
                    }
                }
                "hasExerciseRoutePermission" -> {
                    scope.launch {
                        try {
                            val client = HealthConnectClient.getOrCreate(appContext)
                            val granted = client.permissionController.getGrantedPermissions()
                            val has = granted.contains(HealthPermission.PERMISSION_READ_EXERCISE_ROUTES)
                            withContext(Dispatchers.Main) { result.success(has) }
                        } catch (_: Exception) {
                            withContext(Dispatchers.Main) { result.success(false) }
                        }
                    }
                }
                "openHealthConnectSettings" -> {
                    result.success(openHealthConnectSettings(appContext))
                }
                else -> result.notImplemented()
            }
        }
    }

    private suspend fun fetchWorkoutDetails(
        context: Context,
        startMs: Long,
        endMs: Long,
        sessionId: String?,
        sourceName: String?,
    ): Map<String, Any> {
        val client = HealthConnectClient.getOrCreate(context)
        val start = java.time.Instant.ofEpochMilli(startMs)
        val end = java.time.Instant.ofEpochMilli(endMs)
        val timeRange = TimeRangeFilter.between(start, end)

        val sessions = client.readRecords(
            ReadRecordsRequest(
                recordType = ExerciseSessionRecord::class,
                timeRangeFilter = timeRange,
            ),
        ).records

        val matchingSession = sessions
            .asSequence()
            .filter { sourceName == null || it.metadata.dataOrigin.packageName == sourceName }
            .let { sequence ->
                sequence.firstOrNull { sessionId != null && it.metadata.id == sessionId }
                    ?: sequence.minByOrNull {
                        abs(it.startTime.toEpochMilli() - startMs) + abs(it.endTime.toEpochMilli() - endMs)
                    }
            }

        val hrSeries = mutableListOf<Map<String, Any>>()
        val hrRecords = client.readRecords(
            ReadRecordsRequest(
                recordType = HeartRateRecord::class,
                timeRangeFilter = timeRange,
            ),
        ).records
        for (record in hrRecords) {
            if (sourceName != null && record.metadata.dataOrigin.packageName != sourceName) continue
            for (sample in record.samples) {
                hrSeries.add(
                    mapOf(
                        "ts" to sample.time.toEpochMilli(),
                        "hr" to sample.beatsPerMinute.toInt(),
                    ),
                )
            }
        }
        hrSeries.sortBy { (it["ts"] as Long) }

        val speedSeries = mutableListOf<Map<String, Any>>()
        val speedRecords = client.readRecords(
            ReadRecordsRequest(
                recordType = SpeedRecord::class,
                timeRangeFilter = timeRange,
            ),
        ).records
        for (record in speedRecords) {
            if (sourceName != null && record.metadata.dataOrigin.packageName != sourceName) continue
            for (sample in record.samples) {
                speedSeries.add(
                    mapOf(
                        "ts" to sample.time.toEpochMilli(),
                        "speed_mps" to sample.speed.inMetersPerSecond,
                    ),
                )
            }
        }
        speedSeries.sortBy { (it["ts"] as Long) }

        val routePolyline = mutableListOf<Map<String, Any>>()
        if (matchingSession != null) {
            try {
                when (val routeResult = matchingSession.exerciseRouteResult) {
                    is ExerciseRouteResult.Data -> {
                        val locations = routeResult.exerciseRoute.route.sortedBy { it.time }
                        locations.forEachIndexed { idx, location ->
                            routePolyline.add(
                                mapOf(
                                    "seq" to idx,
                                    "ts" to location.time.toEpochMilli(),
                                    "lat" to location.latitude,
                                    "lon" to location.longitude,
                                ),
                            )
                        }
                    }
                    else -> {
                        // No route, or user consent required for third-party route.
                    }
                }
            } catch (_: Throwable) {
                // Route is optional; keep payload valid even when unavailable.
            }
        }

        var totalDistanceM = 0.0
        val distanceRecords = client.readRecords(
            ReadRecordsRequest(
                recordType = DistanceRecord::class,
                timeRangeFilter = timeRange,
            ),
        ).records
        for (record in distanceRecords) {
            if (sourceName != null && record.metadata.dataOrigin.packageName != sourceName) continue
            totalDistanceM += record.distance.inMeters
        }

        var totalCalories = 0.0
        val calorieRecords = client.readRecords(
            ReadRecordsRequest(
                recordType = TotalCaloriesBurnedRecord::class,
                timeRangeFilter = timeRange,
            ),
        ).records
        for (record in calorieRecords) {
            if (sourceName != null && record.metadata.dataOrigin.packageName != sourceName) continue
            totalCalories += record.energy.inKilocalories
        }

        var activeCalories = 0.0
        val activeCalorieRecords = client.readRecords(
            ReadRecordsRequest(
                recordType = ActiveCaloriesBurnedRecord::class,
                timeRangeFilter = timeRange,
            ),
        ).records
        for (record in activeCalorieRecords) {
            if (sourceName != null && record.metadata.dataOrigin.packageName != sourceName) continue
            activeCalories += record.energy.inKilocalories
        }

        return mapOf(
            "hr_series" to hrSeries,
            "speed_series" to speedSeries,
            "route_polyline" to routePolyline,
            "total_distance_m" to totalDistanceM,
            "total_calories" to totalCalories,
            "active_calories" to activeCalories,
        )
    }

    private fun openHealthConnectSettings(context: Context): Boolean {
        val intentConfigs = listOf(
            "androidx.health.ACTION_MANAGE_HEALTH_PERMISSIONS" to true,
            "android.health.connect.action.MANAGE_HEALTH_PERMISSIONS" to true,
            "androidx.health.ACTION_HEALTH_CONNECT_SETTINGS" to false,
            "android.health.connect.action.HEALTH_CONNECT_SETTINGS" to false,
        )

        for ((action, includePackage) in intentConfigs) {
            try {
                val intent = Intent(action).apply {
                    if (includePackage) putExtra(Intent.EXTRA_PACKAGE_NAME, context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            } catch (_: Exception) { }
        }

        try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage("com.google.android.apps.healthdata")
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return true
            }
        } catch (_: Exception) { }

        return false
    }
}
