package com.rolla.sdk.wrapper

sealed class RollaCloseReason {
    data class FlutterRequested(val reason: String?) : RollaCloseReason()
    data object HostNavigationBack : RollaCloseReason()
    data object HostModalDismiss : RollaCloseReason()
    data object Programmatic : RollaCloseReason()
    data object HostStackReplaced : RollaCloseReason()
    data object Unknown : RollaCloseReason()
}
