package com.rolla.sdk.location

import android.location.Location
import app.rolla.bluetoothSdk.utils.log
import kotlin.math.abs

/**
 * Gate C — Course spike detection. Rejects locations with unrealistic heading changes.
 * Direct port of iOS CourseValidator from the location-improvements branch.
 *
 * Logic:
 * - Only validates when speed >= minSpeedForCourseValidation (no heading at walking pace)
 * - Ignores small changes within deadband (3°)
 * - Resets tracking after idle periods (>15s)
 * - Uses shortest angular distance to handle 0°/360° boundary
 * - Rejects if rate of heading change > 180°/s
 */
class CourseValidator(
    private val maxCourseChangePerSecond: Double = 180.0,
    private val minSpeedForCourseValidation: Double = 1.5
) {
    companion object {
        private const val TAG = "CourseValidator"
        private const val MIN_TIME_STEP_MS = 250L        // 0.25s
        private const val DEADBAND_DEGREES = 3.0
        private const val MAX_IDLE_SINCE_LAST_MS = 15_000L // 15s
    }

    private var lastValidCourse: Float? = null
    private var lastValidTimestampMs: Long? = null
    private var totalValidations = 0
    private var rejectedCount = 0

    fun validate(location: Location): Boolean {
        totalValidations++

        val speed = if (location.hasSpeed()) location.speed.toDouble() else 0.0
        if (speed < minSpeedForCourseValidation) {
            val lastTs = lastValidTimestampMs
            if (lastTs != null && (location.time - lastTs) > MAX_IDLE_SINCE_LAST_MS) {
                lastValidCourse = null
                lastValidTimestampMs = null
            }
            return true
        }

        if (!location.hasBearing() || !location.bearing.isFinite()) {
            return true
        }

        val course = location.bearing
        val prevCourse = lastValidCourse
        val prevTime = lastValidTimestampMs

        if (prevCourse == null || prevTime == null) {
            lastValidCourse = course
            lastValidTimestampMs = location.time
            return true
        }

        val dtMs = location.time - prevTime

        if (dtMs <= 0 || dtMs > MAX_IDLE_SINCE_LAST_MS) {
            lastValidCourse = course
            lastValidTimestampMs = location.time
            return true
        }

        if (dtMs < MIN_TIME_STEP_MS) {
            return true
        }

        if (!prevCourse.isFinite()) {
            lastValidCourse = course
            lastValidTimestampMs = location.time
            return true
        }

        val dTheta = shortestAngularDistance(prevCourse.toDouble(), course.toDouble())
        if (abs(dTheta) < DEADBAND_DEGREES) {
            lastValidCourse = course
            lastValidTimestampMs = location.time
            return true
        }

        val dtSeconds = dtMs / 1000.0
        val rate = abs(dTheta) / dtSeconds

        if (rate > maxCourseChangePerSecond) {
            rejectedCount++
            log(TAG, "[GATE C] Course spike rejected: ${String.format("%.0f", rate)}deg/s")
            return false
        }

        lastValidCourse = course
        lastValidTimestampMs = location.time
        return true
    }

    fun reset() {
        lastValidCourse = null
        lastValidTimestampMs = null
        totalValidations = 0
        rejectedCount = 0
    }

    private fun shortestAngularDistance(from: Double, to: Double): Double {
        var diff = to - from
        while (diff > 180) diff -= 360
        while (diff < -180) diff += 360
        return diff
    }
}
