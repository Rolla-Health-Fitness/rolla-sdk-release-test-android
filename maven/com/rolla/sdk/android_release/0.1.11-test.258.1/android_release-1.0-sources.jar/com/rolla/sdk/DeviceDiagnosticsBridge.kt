package com.rolla.sdk

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

object DeviceDiagnosticsBridge {

    private const val CHANNEL_NAME = "app.rolla/device_diagnostics"

    fun register(context: Context, messenger: BinaryMessenger) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

        MethodChannel(messenger, CHANNEL_NAME).setMethodCallHandler { call, result ->
            when (call.method) {
                "getSensors" -> {
                    try {
                        val sensors: List<Sensor> = sensorManager.getSensorList(Sensor.TYPE_ALL)
                        val sensorMaps = ArrayList<Map<String, Any>>(sensors.size)

                        for (sensor in sensors) {
                            val map = HashMap<String, Any>()
                            map["name"] = sensor.name
                            map["vendor"] = sensor.vendor
                            map["type"] = sensor.type
                            map["version"] = sensor.version
                            map["power"] = sensor.power
                            map["resolution"] = sensor.resolution
                            map["maxRange"] = sensor.maximumRange
                            sensorMaps.add(map)
                        }

                        result.success(sensorMaps)
                    } catch (e: Exception) {
                        result.error("ERR_SENSORS", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
