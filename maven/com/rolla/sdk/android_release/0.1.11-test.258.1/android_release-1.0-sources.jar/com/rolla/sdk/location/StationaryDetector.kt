package com.rolla.sdk.location

import android.location.Location

/**
 * Detects when the user is stationary using Doppler speed + displacement hysteresis.
 * Direct port of iOS StationaryDetector from the location-improvements branch.
 *
 * Two detection paths:
 * 1. Doppler path (primary): uses GPS-reported speed with consecutive slow readings.
 * 2. Displacement fallback: when Doppler is unavailable, uses position scatter over a time window.
 *
 * Entry/exit thresholds use hysteresis to avoid rapid oscillation (all configurable per-activity):
 * - Enter stationary: speed < enterSpeedThreshold for N consecutive readings, OR displacement < 5.0m
 * - Exit stationary:  speed > exitSpeedThreshold OR displacement > exitDisplacementThreshold
 */
class StationaryDetector(
    private val enterSpeedThreshold: Double = 0.40,
    private val requiredSlowReadings: Int = 3,
    private val exitSpeedThreshold: Double = 0.45,
    private val exitDisplacementThreshold: Double = 3.0
) {

    /**
     * Outcome of a single detector update.
     *
     * [ruleFired] names the transition that occurred on this call, if any:
     * `"speed-enter"`, `"disp-enter"`, `"speed-exit"`, `"disp-exit"`, or
     * `"none"`. [displacement] is the max scatter over the window at the
     * time of evaluation, in meters — exposed so debug logs can record
     * the raw signal alongside the booleans.
     */
    data class Update(
        val isStationary: Boolean,
        val ruleFired: String,
        val displacement: Double
    )

    private data class PositionEntry(val timestampMs: Long, val lat: Double, val lon: Double)

    private val buffer = mutableListOf<PositionEntry>()
    private var _isStationary = false

    private val windowMs = 8000L              // 8 seconds
    private val minimumEntries = 3
    private val maxBufferCount = 200
    private val displacementEntryThreshold = 1.0   // meters — Doppler displacement path

    private var _consecutiveSlowReadings = 0

    val isStationary: Boolean get() = _isStationary

    /** True while consecutive slow readings are accumulating but haven't yet reached the
     *  threshold — the detector suspects the user may be stopping. */
    val isPendingStationary: Boolean get() = !_isStationary && _consecutiveSlowReadings > 0

    /** Exposed for debug captures; pipeline code should not branch on this. */
    val consecutiveSlowReadings: Int get() = _consecutiveSlowReadings

    fun addPosition(lat: Double, lon: Double, timestampMs: Long) {
        buffer.add(PositionEntry(timestampMs, lat, lon))
        val cutoff = timestampMs - windowMs
        buffer.removeAll { it.timestampMs < cutoff }
        if (buffer.size > maxBufferCount) {
            val excess = buffer.size - maxBufferCount
            repeat(excess) { buffer.removeAt(0) }
        }
    }

    /**
     * Primary path — uses Doppler speed from the GPS fix.
     * Also checks displacement from the position buffer for a secondary signal.
     */
    fun update(dopplerSpeed: Double): Update {
        var ruleFired = "none"

        if (!_isStationary) {
            if (dopplerSpeed < enterSpeedThreshold) {
                _consecutiveSlowReadings++
                if (_consecutiveSlowReadings >= requiredSlowReadings) {
                    _isStationary = true
                    _consecutiveSlowReadings = 0
                    ruleFired = "speed-enter"
                }
            } else {
                _consecutiveSlowReadings = 0
            }
        }

        val maxDisplacement = computeMaxDisplacement()
        if (buffer.size >= minimumEntries) {
            if (_isStationary) {
                // Exit check still runs even when we just entered this call, to
                // preserve the original behaviour where an immediate large-scatter
                // fix could push us straight back out of stationary.
                if (dopplerSpeed > exitSpeedThreshold) {
                    _isStationary = false
                    ruleFired = "speed-exit"
                    retainOnlyLatestPosition()
                } else if (maxDisplacement > exitDisplacementThreshold) {
                    _isStationary = false
                    ruleFired = "disp-exit"
                    retainOnlyLatestPosition()
                }
            } else if (ruleFired == "none") {
                if (buffer.size >= 6 && maxDisplacement < displacementEntryThreshold) {
                    _isStationary = true
                    _consecutiveSlowReadings = 0
                    ruleFired = "disp-enter"
                }
            }
        }

        return Update(_isStationary, ruleFired, maxDisplacement)
    }

    /**
     * Fallback path — when Doppler speed is unavailable (speed == -1 on some devices).
     * Uses only displacement scatter from the position buffer.
     *
     * Uses 5.0m entry threshold (more lenient than Doppler path's 1.0m) to catch
     * stationary users at traffic lights etc. where GPS noise is 1–3m.
     */
    fun checkDisplacementStationary(): Update {
        if (buffer.size < minimumEntries) {
            return Update(_isStationary, "none", 0.0)
        }

        val maxDisplacement = computeMaxDisplacement()
        var ruleFired = "none"

        if (!_isStationary) {
            if (maxDisplacement < 5.0) {
                _isStationary = true
                ruleFired = "disp-enter"
            }
        } else {
            if (maxDisplacement > exitDisplacementThreshold) {
                _isStationary = false
                ruleFired = "disp-exit"
                retainOnlyLatestPosition()
            }
        }

        return Update(_isStationary, ruleFired, maxDisplacement)
    }

    fun reset() {
        buffer.clear()
        _isStationary = false
        _consecutiveSlowReadings = 0
    }

    /**
     * On a stationary → not-stationary edge, discard every buffered position
     * except the most recent one. This prevents the window from retaining
     * samples taken during the stop, which would otherwise keep
     * `computeMaxDisplacement()` small for up to `windowMs` after the exit and
     * re-trigger `disp-enter` while the user is genuinely walking away from
     * the stop anchor.
     *
     * Called from `update()` and `checkDisplacementStationary()` on every
     * exit rule. Safe to call with an empty or single-entry buffer.
     */
    private fun retainOnlyLatestPosition() {
        if (buffer.size <= 1) return
        val latest = buffer.last()
        buffer.clear()
        buffer.add(latest)
    }

    private fun computeMaxDisplacement(): Double {
        if (buffer.size < minimumEntries) return 0.0
        val first = buffer.first()
        var maxDisp = 0.0
        for (i in 1 until buffer.size) {
            val entry = buffer[i]
            val dist = distanceMeters(first.lat, first.lon, entry.lat, entry.lon)
            if (dist > maxDisp) maxDisp = dist
        }
        return maxDisp
    }

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, results)
        return results[0].toDouble()
    }
}
