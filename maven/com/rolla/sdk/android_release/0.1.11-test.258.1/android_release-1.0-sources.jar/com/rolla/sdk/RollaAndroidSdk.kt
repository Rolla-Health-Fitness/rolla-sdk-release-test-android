package com.rolla.sdk

import android.content.Context
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.di.flutter.DaggerFlutterSdkComponent
import app.rolla.bluetoothSdk.di.flutter.FlutterSdkComponent
import com.rolla.sdk.location.LocationManager
import io.flutter.plugin.common.BinaryMessenger

/**
 * Main entry point for the Rolla Android SDK.
 *
 * This class provides a ZERO-CONFIG initialization API for Flutter apps.
 * Uses a standalone Dagger component internally - NO @HiltAndroidApp required!
 *
 * Key Features:
 * - No Hilt configuration needed in host app
 * - No custom Application class required
 * - No build.gradle modifications needed
 * - Works out-of-the-box with Flutter pub.dev integration
 *
 * Architecture:
 * ```
 * Flutter App (pub.dev dependency)
 *      ↓
 * RollaSdkPlugin (auto-registered)
 *      ↓
 * RollaAndroidSdk.init() ← YOU ARE HERE
 *      ↓
 * FlutterSdkComponent (Dagger, not Hilt)
 *      ↓
 * BleManager + all dependencies (injected)
 * ```
 *
 * Usage:
 * ```kotlin
 * // In RollaSdkPlugin.onAttachedToEngine:
 * val sdk = RollaAndroidSdk.init(context)
 * val bridge = sdk.createBridge(context, binaryMessenger)
 * ```
 *
 * For native Android apps: Use Hilt directly with @HiltAndroidApp instead.
 * This class is specifically optimized for Flutter integration.
 */
class RollaAndroidSdk private constructor(
    private val component: FlutterSdkComponent,
    private val locationManager: LocationManager
) {

    companion object {
        @Volatile
        private var instance: RollaAndroidSdk? = null

        /**
         * Initialize the Rolla SDK with the given context.
         * 
         * This method is idempotent - calling it multiple times returns the same instance.
         * Uses Dagger for dependency injection WITHOUT requiring @HiltAndroidApp.
         *
         * @param context Application context (will be converted to application context internally)
         * @return Initialized RollaAndroidSdk instance with all dependencies ready
         */
        fun init(context: Context): RollaAndroidSdk {
            return instance ?: synchronized(this) {
                instance ?: createInstance(context.applicationContext).also { instance = it }
            }
        }

        private fun createInstance(applicationContext: Context): RollaAndroidSdk {
            // Build the Dagger component - no Hilt required!
            // DaggerFlutterSdkComponent is generated at compile time by kapt
            val component = DaggerFlutterSdkComponent.builder()
                .applicationContext(applicationContext)
                .build()

            // Location manager is not part of bluetoothSdk module, so we create it here
            val locationManager = LocationManager(applicationContext)

            return RollaAndroidSdk(component, locationManager)
        }

        /**
         * Get the current SDK instance if it has been initialized.
         * @return The SDK instance, or null if not yet initialized
         */
        fun getInstance(): RollaAndroidSdk? = instance
    }

    /**
     * Get the BleManager instance for Bluetooth operations.
     * All dependencies are automatically injected by Dagger.
     * 
     * @return BleManager instance (singleton)
     */
    fun getBleManager(): BleManager = component.bleManager()

    /**
     * Get the LocationManager instance for location tracking.
     * @return LocationManager instance
     */
    fun getLocationManager(): LocationManager = locationManager

    /**
     * Create a RollaBluetoothBridge instance for Flutter communication.
     * This wires up all Pigeon-generated platform channels.
     *
     * @param context Context (typically from Flutter plugin binding)
     * @param binaryMessenger Flutter binary messenger for platform channel communication
     * @return Configured RollaBluetoothBridge instance with all handlers registered
     */
    fun createBridge(context: Context, binaryMessenger: BinaryMessenger): RollaBluetoothBridge {
        return RollaBluetoothBridge(
            context = context,
            bleManager = component.bleManager(),
            locationManager = locationManager,
            binaryMessenger = binaryMessenger
        )
    }
}

