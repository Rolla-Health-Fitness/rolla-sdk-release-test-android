package com.rolla.sdk.location

import android.content.Context
import android.location.Location
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.TreeMap
import java.util.concurrent.Executors

/**
 * On-device JSONL capture of raw GPS samples and pipeline decisions.
 *
 * Each event is one JSON line. Every event carries three header fields:
 *   - `t`: ISO-8601 wall-clock timestamp (fractional seconds)
 *   - `seq`: monotonic per-session counter (assigned on the write queue so
 *     it matches file order exactly)
 *   - `evt`: event type discriminator (see the logXxx methods below)
 *
 * The first four events (`input`, `emit`, `suppress`, `state`) also carry
 * a `kind` field that mirrors `evt` so older offline parsers keep working;
 * newer events only carry `evt`.
 *
 * ## Opt-in by default
 *
 * [isEnabled] is `false` by default. No file is created, no directory
 * is touched, and every `logXxx` call becomes a no-op unless a developer
 * explicitly flips the flag before starting a session:
 *
 * ```kotlin
 * LocationDebugCapture.initialize(appContext)   // required once
 * LocationDebugCapture.isEnabled = true         // developer opts in
 * // ...start tracking...
 * ```
 *
 * ## Where files land on Android
 *
 * Writes go to `context.getExternalFilesDir("RollaLocationLogs")`, which
 * resolves to `/Android/data/<hostAppPackage>/files/RollaLocationLogs/` on
 * the device. No runtime permission is needed; the directory is
 * automatically cleaned up when the host app is uninstalled. Retrieve
 * files with any of:
 *   - `adb pull /sdcard/Android/data/<package>/files/RollaLocationLogs/`
 *   - Android's Files app (Android 11+)
 *   - USB MTP from a desktop
 *
 * All file I/O runs on a single-threaded executor so the GPS pipeline
 * thread is never blocked by disk. Files are capped at 10 MB with a
 * graceful truncate-and-continue (a final `{"evt":"truncated",...}`
 * line is written and subsequent writes become no-ops).
 *
 * Non-finite doubles are serialised as JSON `null` rather than dropping
 * the whole line, so NaN in a computed field never corrupts a capture.
 */
object LocationDebugCapture {

    private const val TAG = "LocationDebugCapture"
    private const val MAX_FILE_SIZE_BYTES: Long = 10L * 1024L * 1024L

    /**
     * Marker class for an epoch-millis timestamp that should be serialised
     * as an ISO-8601 string. `SimpleDateFormat` is not thread-safe, so we
     * defer every format call to the single writer thread by boxing the
     * raw millis here and converting in [appendValue].
     */
    private data class IsoTs(val epochMs: Long)

    /**
     * Master switch. `false` by default so the pipeline never touches
     * the filesystem unless a developer explicitly opts in. Works on any
     * build configuration (debug, release, internal, store).
     *
     * Set to `true` locally if you want to record a file log on your
     * Android device for activity map / location tracking logs in detail.
     */
    @Volatile
    var isEnabled: Boolean = false

    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "rolla-location-debug-capture").apply { isDaemon = true }
    }

    @Volatile
    private var appContext: Context? = null

    // All of these are mutated only on `executor`.
    private var fileStream: OutputStream? = null
    private var currentFile: File? = null
    private var bytesWritten: Long = 0L
    private var truncated: Boolean = false
    private var seqCounter: Int = 0

    // ISO-8601 with fractional seconds + offset, matching
    // iOS `[.withInternetDateTime, .withFractionalSeconds]`. `SimpleDateFormat`
    // is not thread-safe, but every use site runs on the capture's single
    // writer thread so no synchronisation is needed.
    private val iso8601Formatter: SimpleDateFormat =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

    // Filename format, matching the iOS `"yyyy-MM-dd-HH-mm-ss"` POSIX formatter.
    private val fileNameFormatter: SimpleDateFormat =
        SimpleDateFormat("yyyy-MM-dd-HH-mm-ss", Locale.US)

    // ----------------------------------------------------------------
    // Setup
    // ----------------------------------------------------------------

    /**
     * Capture the application context used to resolve the external
     * files directory. Safe to call repeatedly; only the first call
     * takes effect. A no-op cost if the capture is never enabled.
     */
    fun initialize(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
        }
    }

    // ----------------------------------------------------------------
    // Session lifecycle
    // ----------------------------------------------------------------

    fun startSession() {
        if (!isEnabled) return
        executor.execute { startSessionOnExecutor() }
    }

    fun stopSession() {
        if (!isEnabled) return
        executor.execute { stopSessionOnExecutor() }
    }

    // ----------------------------------------------------------------
    // Back-compat events (both `kind` and `evt` present)
    // ----------------------------------------------------------------

    fun logInput(location: Location) {
        if (!isEnabled) return
        write("input", buildLocationPayload(location, "input"))
    }

    fun logEmit(location: Location) {
        if (!isEnabled) return
        val extra = buildLocationPayload(location, "emit").also {
            // `emit` carries the same fields as `input` minus altitude/vAcc
            // in the iOS schema — strip to stay in parity.
            it.remove("alt")
            it.remove("vAcc")
        }
        write("emit", extra)
    }

    fun logSuppress(location: Location, reason: String) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("kind", "suppress")
            put("ts", IsoTs(location.time))
            put("lat", location.latitude)
            put("lon", location.longitude)
            put("acc", if (location.hasAccuracy()) location.accuracy.toDouble() else null)
            put("spd", if (location.hasSpeed()) location.speed.toDouble() else null)
            put("reason", reason)
        }
        write("suppress", extra)
    }

    fun logState(transition: String, details: Map<String, Any?> = emptyMap()) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("kind", "state")
            put("ts", IsoTs(System.currentTimeMillis()))
            put("transition", transition)
            for ((k, v) in details) put(k, v)
        }
        write("state", extra)
    }

    // ----------------------------------------------------------------
    // Decision-level events
    // ----------------------------------------------------------------

    /**
     * Single gate evaluation. [gate] is one of `"A"`, `"B"`, `"C"`,
     * `"warmup"`, `"pending-confirm"`, `"emit-threshold"`. [reason] is
     * `"pass"` on success or the suppression reason string on failure.
     */
    fun logGate(
        gate: String,
        passed: Boolean,
        reason: String,
        inputs: Map<String, Any?>,
        fixTsMs: Long
    ) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("gate", gate)
            put("passed", passed)
            put("reason", reason)
            put("inputs", sanitize(inputs))
            put("fixTs", IsoTs(fixTsMs))
        }
        write("gate", extra)
    }

    /**
     * Per-tier pending-exit confirmation sample. Fired for every fix
     * while pending-exit is armed — both the tier that triggered the
     * re-anchor and the tier that didn't. [tier] is `"speed"` or
     * `"distance"`. Present in the API surface for parity; will only
     * start firing once the pending-exit mechanism is ported.
     */
    fun logPendingConfirm(
        tier: String,
        fired: Boolean,
        inputs: Map<String, Any?>
    ) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("tier", tier)
            put("fired", fired)
            put("inputs", sanitize(inputs))
        }
        write("pending-confirm", extra)
    }

    /**
     * Per-fix StationaryDetector observation. [ruleFired] captures the
     * transition that happened this fix (if any):
     * `"speed-enter"`, `"disp-enter"`, `"speed-exit"`, `"disp-exit"`,
     * or `"none"`.
     */
    fun logStationaryDetail(
        speed: Double,
        displacement: Double,
        consecutiveSlowReadings: Int,
        isStationary: Boolean,
        isPendingStationary: Boolean,
        ruleFired: String,
        fixTsMs: Long
    ) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("speed", sanitizeDouble(speed))
            put("displacement", sanitizeDouble(displacement))
            put("consecutiveSlowReadings", consecutiveSlowReadings)
            put("isStationary", isStationary)
            put("isPendingStationary", isPendingStationary)
            put("ruleFired", ruleFired)
            put("fixTs", IsoTs(fixTsMs))
        }
        write("stationary-detail", extra)
    }

    /**
     * Fired whenever the processor swaps one of its tracked anchors:
     * `lastAccepted`, `lastEmitted`, `secondLastEmitted`, `smoothed`,
     * `stationaryEntry`. [reason] identifies the code path that caused
     * the change.
     */
    fun logAnchorChange(
        variable: String,
        reason: String,
        old: Map<String, Any?>?,
        new: Map<String, Any?>?
    ) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("var", variable)
            put("reason", reason)
            if (old != null) put("old", sanitize(old))
            if (new != null) put("new", sanitize(new))
        }
        write("anchor-change", extra)
    }

    /**
     * Fired whenever `consecutiveGateRejections` changes. [gate] is
     * `"A"`, `"B"`, `"C"`, `"reset"`, `"rebootstrap"`, or
     * `"rebootstrap-suppressed"`.
     */
    fun logRejectionCounter(old: Int, new: Int, gate: String) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("old", old)
            put("new", new)
            put("gate", gate)
        }
        write("rejection-counter", extra)
    }

    /**
     * Fired once at `startSession` after configuration is applied.
     * Captures the full tuning surface so post-hoc log readers can
     * reason about which thresholds were active during the run.
     */
    fun logConfigSnapshot(payload: Map<String, Any?>) {
        if (!isEnabled) return
        write("config-snapshot", TreeMap(sanitize(payload)))
    }

    /**
     * Fired once per processLocation call at the top of the pipeline.
     * Null deltas are omitted from the JSON entirely (rather than
     * encoded as `null`) — same semantics as iOS, which only sets the
     * key when the underlying marker has been seen at least once.
     */
    fun logTimer(
        fixTsMs: Long,
        dtSec: Double?,
        dtSinceLastEmit: Double?,
        dtSincePendingArm: Double?,
        dtSinceLastStationary: Double?
    ) {
        if (!isEnabled) return
        val extra = TreeMap<String, Any?>().apply {
            put("fixTs", IsoTs(fixTsMs))
            if (dtSec != null && dtSec.isFinite()) put("dtSec", dtSec)
            if (dtSinceLastEmit != null && dtSinceLastEmit.isFinite()) {
                put("dtSinceLastEmit", dtSinceLastEmit)
            }
            if (dtSincePendingArm != null && dtSincePendingArm.isFinite()) {
                put("dtSincePendingArm", dtSincePendingArm)
            }
            if (dtSinceLastStationary != null && dtSinceLastStationary.isFinite()) {
                put("dtSinceLastStationary", dtSinceLastStationary)
            }
        }
        write("timer", extra)
    }

    /**
     * Fired once at `stopSession` with the whole-session tallies.
     * Consumers can eyeball a run at a glance with `jq`.
     */
    fun logPipelineSummary(payload: Map<String, Any?>) {
        if (!isEnabled) return
        write("pipeline-summary", TreeMap(sanitize(payload)))
    }

    // ----------------------------------------------------------------
    // Internal
    // ----------------------------------------------------------------

    private fun buildLocationPayload(loc: Location, kind: String): TreeMap<String, Any?> {
        return TreeMap<String, Any?>().apply {
            put("kind", kind)
            put("ts", IsoTs(loc.time))
            put("lat", loc.latitude)
            put("lon", loc.longitude)
            put("acc", if (loc.hasAccuracy()) loc.accuracy.toDouble() else null)
            put("spd", if (loc.hasSpeed()) loc.speed.toDouble() else null)
            put("course", if (loc.hasBearing()) loc.bearing.toDouble() else null)
            put("alt", if (loc.hasAltitude()) loc.altitude else null)
            put(
                "vAcc",
                if (loc.hasVerticalAccuracy()) loc.verticalAccuracyMeters.toDouble() else null
            )
        }
    }

    private fun startSessionOnExecutor() {
        stopSessionOnExecutor()
        truncated = false
        bytesWritten = 0L
        seqCounter = 0

        val ctx = appContext
        if (ctx == null) {
            Log.w(
                TAG,
                "startSession called before initialize(context); no file will be written"
            )
            return
        }

        val dir = try {
            ctx.getExternalFilesDir("RollaLocationLogs")
        } catch (e: Exception) {
            Log.w(TAG, "getExternalFilesDir failed: ${e.message}")
            null
        }
        if (dir == null) {
            Log.w(TAG, "external files dir unavailable; no file will be written")
            return
        }
        if (!dir.exists() && !dir.mkdirs()) {
            Log.w(TAG, "failed to create ${dir.absolutePath}; no file will be written")
            return
        }

        val filename = "location-${fileNameFormatter.format(Date())}.jsonl"
        val file = File(dir, filename)
        try {
            fileStream = FileOutputStream(file, false)
            currentFile = file
            Log.i(TAG, "session opened: ${file.absolutePath}")
        } catch (e: Exception) {
            Log.w(TAG, "failed to open ${file.absolutePath}: ${e.message}")
            fileStream = null
            currentFile = null
        }
    }

    private fun stopSessionOnExecutor() {
        val fs = fileStream ?: return
        try {
            fs.flush()
            fs.close()
        } catch (e: Exception) {
            Log.w(TAG, "close failed: ${e.message}")
        }
        fileStream = null
        currentFile = null
    }

    /**
     * Enqueue a write. The `seq`, `evt`, and `t` header fields are
     * stamped inside the executor block so their order matches file
     * order exactly even if two callers race from different threads.
     */
    private fun write(evt: String, extra: Map<String, Any?>) {
        executor.execute {
            val fs = fileStream ?: return@execute
            if (truncated) return@execute

            if (bytesWritten >= MAX_FILE_SIZE_BYTES) {
                val note = TreeMap<String, Any?>().apply {
                    put("kind", "truncated")
                    put("evt", "truncated")
                    put("t", IsoTs(System.currentTimeMillis()))
                }
                val line = encodeJsonObject(note) + "\n"
                try {
                    fs.write(line.toByteArray(Charsets.UTF_8))
                } catch (_: Exception) { /* swallow: already truncating */ }
                truncated = true
                return@execute
            }

            seqCounter += 1
            val line = TreeMap<String, Any?>().apply {
                put("seq", seqCounter)
                put("evt", evt)
                put("t", IsoTs(System.currentTimeMillis()))
                for ((k, v) in extra) put(k, v)
            }

            val encoded = encodeJsonObject(line) + "\n"
            val bytes = encoded.toByteArray(Charsets.UTF_8)
            try {
                fs.write(bytes)
                bytesWritten += bytes.size.toLong()
            } catch (e: Exception) {
                Log.w(TAG, "write failed: ${e.message}")
            }
        }
    }

    // ----------------------------------------------------------------
    // JSON encoding (sorted keys, NaN → null)
    // ----------------------------------------------------------------

    private fun encodeJsonObject(map: Map<String, Any?>): String {
        val sorted = if (map is TreeMap) map else TreeMap(map)
        val sb = StringBuilder(64)
        sb.append('{')
        var first = true
        for ((k, v) in sorted) {
            if (!first) sb.append(',')
            first = false
            appendString(sb, k)
            sb.append(':')
            appendValue(sb, v)
        }
        sb.append('}')
        return sb.toString()
    }

    private fun appendValue(sb: StringBuilder, value: Any?) {
        when (value) {
            null -> sb.append("null")
            is Boolean -> sb.append(if (value) "true" else "false")
            is IsoTs -> appendString(sb, iso8601(value.epochMs))
            is Double -> {
                if (!value.isFinite()) sb.append("null") else sb.append(formatDouble(value))
            }
            is Float -> {
                val d = value.toDouble()
                if (!d.isFinite()) sb.append("null") else sb.append(formatDouble(d))
            }
            is Number -> sb.append(value.toString())
            is String -> appendString(sb, value)
            is Map<*, *> -> {
                @Suppress("UNCHECKED_CAST")
                sb.append(encodeJsonObject(value as Map<String, Any?>))
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                for (item in value) {
                    if (!first) sb.append(',')
                    first = false
                    appendValue(sb, item)
                }
                sb.append(']')
            }
            else -> appendString(sb, value.toString())
        }
    }

    private fun formatDouble(d: Double): String {
        // Match iOS JSONSerialization output: integers print as integers,
        // fractions print as decimals. Trim any trailing ".0" on whole
        // numbers so log diffs stay stable across platforms.
        return if (d == d.toLong().toDouble() && !d.toString().contains('E')) {
            d.toLong().toString()
        } else {
            d.toString()
        }
    }

    private fun appendString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (ch in s) {
            when (ch) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> {
                    if (ch.code < 0x20) {
                        sb.append(String.format("\\u%04x", ch.code))
                    } else {
                        sb.append(ch)
                    }
                }
            }
        }
        sb.append('"')
    }

    // Recursively coerce a payload so nested maps are TreeMap (stable
    // key order) and non-finite doubles become null. Pure-data only;
    // never touches the executor state.
    private fun sanitize(value: Map<String, Any?>): Map<String, Any?> {
        val out = TreeMap<String, Any?>()
        for ((k, v) in value) out[k] = sanitizeAny(v)
        return out
    }

    private fun sanitizeAny(v: Any?): Any? = when (v) {
        null -> null
        is Double -> if (v.isFinite()) v else null
        is Float -> if (v.toDouble().isFinite()) v else null
        is Map<*, *> -> {
            @Suppress("UNCHECKED_CAST")
            sanitize(v as Map<String, Any?>)
        }
        is Iterable<*> -> v.map { sanitizeAny(it) }
        else -> v
    }

    private fun sanitizeDouble(v: Double): Any? = if (v.isFinite()) v else null

    private fun iso8601(epochMs: Long): String =
        iso8601Formatter.format(Date(epochMs))
}
