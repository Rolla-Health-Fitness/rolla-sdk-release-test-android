package com.rolla.sdk.extensions

import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.Error
import app.rolla.bluetoothSdk.result.error.OperationAlreadyInProgress
import app.rolla.bluetoothSdk.result.error.UnknownError
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.generated.FlutterError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun toFlutterError(err: Error? = null, exception: Exception? = null): FlutterError {
    val error = err ?: UnknownError(exception)
    return FlutterError(error.code, error.message, error.exception?.message)
}

fun <T> executeOperation(
    scope: CoroutineScope,
    callback: (Result<T>) -> Unit,
    tag: String? = null,
    operationName: String? = null,
    operation: () -> MethodResult,
    onSuccess: (MethodResult) -> T,
    onError: (Exception) -> Unit = {}
) {
    executeAsync(scope, callback, operation = {
        operationName?.let { name ->
            tag?.let { t -> log(t, name) }
        }

        val result = operation()

        if (result.successful) {
            Result.success(onSuccess(result))
        } else {
            Result.failure(toFlutterError(result.error))
        }
    }, onError = onError)
}

private fun <T> executeAsync(
    scope: CoroutineScope,
    callback: (Result<T>) -> Unit,
    operation: suspend () -> Result<T>?,
    onError: (Exception) -> Unit = {}
) {
    scope.launch {
        try {
            val result = operation()
            withContext(Dispatchers.Main) {
                if (result != null) {
                    callback(result)
                }
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                callback(Result.failure(toFlutterError(exception = e)))
                onError(e)
            }
        }
    }
}

fun <T> executeCommandOperation(
    scope: CoroutineScope,
    uuid: String,
    callbacks: MutableMap<String, (Result<T>) -> Unit>,
    callback: (Result<T>) -> Unit,
    tag: String,
    operationName: String,
    operation: () -> MethodResult
) {
    if (callbacks.containsKey(uuid)) {
        callback.invoke(Result.failure(toFlutterError(OperationAlreadyInProgress(operationName))))
        return
    }
    callbacks[uuid] = callback

    executeAsync(scope, callback, operation = {
        log(tag, operationName)
        val result = operation()

        if (result.successful) {
            null // Wait for flow data
        } else {
            callbacks.remove(uuid)
            Result.failure(toFlutterError(result.error))
        }
    }, onError = { callbacks.remove(uuid) })
}

fun <T, R> collectFlowWithCallback(
    scope: CoroutineScope,
    flow: SharedFlow<T>,
    callbacks: MutableMap<String, (Result<R>) -> Unit>,
    tag: String,
    dataName: String,
    getUuid: (T) -> String,
    getError: (T) -> Error?,
    getSuccessValue: (T) -> R,
    onNoCallback: ((T) -> Unit)? = null,
    onSuccess: ((T) -> Unit)? = null
) {
    scope.launch {
        flow.collect { data ->
            withContext(Dispatchers.Main) {
                log(tag, "$dataName: $data")
                val uuid = getUuid(data)
                val callback = callbacks[uuid]
                if (callback != null) {
                    val error = getError(data)
                    if (error != null) {
                        callback(Result.failure(toFlutterError(error)))
                    } else {
                        callback(Result.success(getSuccessValue(data)))
                        onSuccess?.invoke(data)
                    }
                    callbacks.remove(uuid)
                } else {
                    log(tag, "No callback found for $dataName $data")
                    onNoCallback?.invoke(data)
                }
            }
        }
    }
}

fun <T, R> collectNextPageFlowWithCallback(
    scope: CoroutineScope,
    flow: SharedFlow<T>,
    callbacks: MutableMap<String, (Result<R>) -> Unit>,
    tag: String,
    dataName: String,
    getUuid: (T) -> String,
    isDataEnd: (T) -> Boolean,
    getSuccessValue: (T) -> R,
    onNoCallback: ((T) -> Unit)? = null,
) {
    scope.launch {
        flow.collect { data ->
            withContext(Dispatchers.Main) {
                log(tag, "$dataName: $data")
                val uuid = getUuid(data)
                val callback = callbacks[uuid]
                if (callback != null) {
                    val isEnd = isDataEnd(data)
                    if (isEnd) {
                        callback(Result.success(getSuccessValue(data)))
                        callbacks.remove(uuid)
                    }
                } else {
                    log(tag, "No callback found for $dataName $data")
                    onNoCallback?.invoke(data)
                }
            }
        }
    }
}

fun <T> executeOperationSuspend(
    scope: CoroutineScope,
    callback: (Result<T>) -> Unit,
    tag: String,
    operationName: String,
    operation: suspend () -> MethodResult,
    onSuccess: (MethodResult) -> T
) {
    executeAsync(scope, callback, operation = {
        log(tag, operationName)
        val result = operation()

        if (result.successful) {
            Result.success(onSuccess(result))
        } else {
            Result.failure(toFlutterError(result.error))
        }
    })
}
