package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.commands.data.UserInfo
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.extensions.collectFlowWithCallback
import com.rolla.sdk.extensions.executeCommandOperation
import com.rolla.sdk.generated.BandBatteryFlutterApi
import com.rolla.sdk.generated.BandCommandHostAPI
import com.rolla.sdk.generated.UserData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class BandCommandHostApiImpl(
    private val bleManager: BleManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob()),
    private val batteryApi: BandBatteryFlutterApi
) : BandCommandHostAPI {

    private val serialNumberCallbacks: MutableMap<String, (Result<String>) -> Unit> = ConcurrentHashMap()
    private val firmwareCallbacks: MutableMap<String, (Result<String>) -> Unit> = ConcurrentHashMap()
    private val batteryCallbacks: MutableMap<String, (Result<Long>) -> Unit> = ConcurrentHashMap()
    private val getUserDataCallbacks: MutableMap<String, (Result<UserData>) -> Unit> = ConcurrentHashMap()
    private val setUserCallbacks: MutableMap<String, (Result<Unit>) -> Unit> = ConcurrentHashMap()

    companion object {
        private const val TAG = "BandCommandHostApiImpl"
    }

    init {
        collectSerialNumberFlow()
        collectFirmwareVersionFlow()
        collectBatteryLevelFlow()
        collectGetUserDataFlow()
        collectSetUserDataFlow()
    }

    override fun updateUserData(
        uuid: String,
        userData: UserData,
        callback: (Result<Unit>) -> Unit
    ) {
        executeCommandOperation(
            scope,
            uuid,
            setUserCallbacks,
            callback,
            operation = { bleManager.setBandUserData(uuid, convertToSdkUserInfo(userData)) },
            operationName = "updateUserData",
            tag = TAG
        )
    }

    override fun getUserData(uuid: String, callback: (Result<UserData>) -> Unit) {
        executeCommandOperation(
            scope,
            uuid,
            getUserDataCallbacks,
            callback,
            operation = { bleManager.readBandUserData(uuid) },
            operationName = "getUserData",
            tag = TAG
        )
    }

    override fun getFirmwareVersion(uuid: String, callback: (Result<String>) -> Unit) {
        executeCommandOperation(
            scope,
            uuid,
            firmwareCallbacks,
            callback,
            operation = { bleManager.readFirmwareRevision(uuid) },
            operationName = "getFirmwareVersion",
            tag = TAG
        )
    }

    override fun getSerialNumber(uuid: String, callback: (Result<String>) -> Unit) {
        executeCommandOperation(
            scope,
            uuid,
            serialNumberCallbacks,
            callback,
            operation = { bleManager.readSerialNumber(uuid) },
            operationName = "getSerialNumber",
            tag = TAG
        )
    }

    override fun getBatteryLevel(uuid: String, callback: (Result<Long>) -> Unit) {
        executeCommandOperation(
            scope,
            uuid,
            batteryCallbacks,
            callback,
            operation = { bleManager.readBandBatteryLevel(uuid) },
            operationName = "getBatteryLevel",
            tag = TAG
        )
    }

    private fun collectSerialNumberFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getSerialNumberFlow(),
            callbacks = serialNumberCallbacks,
            tag = TAG,
            dataName = "Serial number",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { it.serialNumber }
        )
    }

    private fun collectFirmwareVersionFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getFirmwareVersionFlow(),
            callbacks = firmwareCallbacks,
            tag = TAG,
            dataName = "Firmware version",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { it.firmwareVersion }
        )
    }

    private fun collectBatteryLevelFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandBatteryLevelFlow(),
            callbacks = batteryCallbacks,
            tag = TAG,
            dataName = "Battery level",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { it.batteryLevel.toLong() },
            onNoCallback = { batteryApi.onBatteryLevelReceived(it.batteryLevel.toLong()) {} }
        )
    }

    private fun collectGetUserDataFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandUserDataFlow(),
            callbacks = getUserDataCallbacks,
            tag = TAG,
            dataName = "User data",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { convertToPigeonUserData(it) }
        )
    }

    private fun collectSetUserDataFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandSetUserDataFlow(),
            callbacks = setUserCallbacks,
            tag = TAG,
            dataName = "Set user data",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { }
        )
    }

    fun convertToPigeonUserData(sdkData: app.rolla.bluetoothSdk.characteristics.data.UserData): UserData {
        return UserData(
            age = sdkData.userInfo.age.toLong(),
            height = sdkData.userInfo.height.toDouble(),
            weight = sdkData.userInfo.weight.toDouble(),
            gender = sdkData.userInfo.gender.toLong()
        )
    }

    fun convertToSdkUserInfo(pigeonData: UserData): UserInfo {
        log(
            TAG,
            "Converting pigeon data to sdk data: ${pigeonData.gender} - ${pigeonData.age} - ${pigeonData.height} - ${pigeonData.weight}"
        )
        return UserInfo(
            gender = pigeonData.gender.toInt(),
            age = pigeonData.age.toInt(),
            height = pigeonData.height.toInt(),
            weight = pigeonData.weight.toFloat(),
            stride = 0,
            userDeviceId = ""
        )
    }

    fun cleanup() {
        setUserCallbacks.clear()
        getUserDataCallbacks.clear()
        serialNumberCallbacks.clear()
        firmwareCallbacks.clear()
        batteryCallbacks.clear()
        scope.cancel()
    }
}
