package com.rolla.sdk.hostImpl

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.rolla.sdk.generated.PedometerPermissionStatus
import com.rolla.sdk.generated.PhonePedometerFlutterApi
import com.rolla.sdk.generated.PhonePedometerHostApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PhonePedometerHandler(
    private val context: Context,
    private val flutterApi: PhonePedometerFlutterApi,
    private val scope: CoroutineScope
) : PhonePedometerHostApi {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var stepSensor: Sensor? = null
    private var listener: SensorEventListener? = null
    private var initialStepCount: Int? = null
    private var lastStepTimestampMs: Long = 0L
    private var lastStepCount: Int = 0

    override fun startPedometerUpdates(callback: (Result<Unit>) -> Unit) {
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (stepSensor == null) {
            callback(Result.failure(Exception("Step counter sensor not available on this device")))
            return
        }

        if (listener != null) {
            callback(Result.success(Unit))
            return
        }

        initialStepCount = null
        lastStepTimestampMs = 0L
        lastStepCount = 0

        listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val totalDeviceSteps = event.values[0].toInt()
                if (initialStepCount == null) {
                    initialStepCount = totalDeviceSteps
                }
                val sessionSteps = totalDeviceSteps - (initialStepCount ?: totalDeviceSteps)
                val nowMs = System.currentTimeMillis()

                val cadenceSpm: Long = if (lastStepTimestampMs > 0 && sessionSteps > lastStepCount) {
                    val dtSeconds = (nowMs - lastStepTimestampMs) / 1000.0
                    if (dtSeconds > 0) {
                        val stepsDelta = sessionSteps - lastStepCount
                        ((stepsDelta / dtSeconds) * 60.0).toLong().coerceIn(0, 300)
                    } else 0L
                } else 0L

                lastStepTimestampMs = nowMs
                lastStepCount = sessionSteps

                scope.launch {
                    withContext(Dispatchers.Main) {
                        flutterApi.onStepUpdate(
                            sessionSteps.toLong(),
                            cadenceSpm,
                            null
                        ) { }
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager.registerListener(
            listener,
            stepSensor,
            SensorManager.SENSOR_DELAY_UI
        )
        callback(Result.success(Unit))
    }

    override fun stopPedometerUpdates(callback: (Result<Unit>) -> Unit) {
        stop()
        callback(Result.success(Unit))
    }

    /// Releases the sensor listener without going through the Pigeon callback.
    /// Safe to call from the bridge teardown path on engine detach.
    fun stop() {
        listener?.let { sensorManager.unregisterListener(it) }
        listener = null
        initialStepCount = null
        lastStepTimestampMs = 0L
        lastStepCount = 0
    }

    override fun requestPermission(callback: (Result<PedometerPermissionStatus>) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val hasSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null
            callback(Result.success(
                if (hasSensor) PedometerPermissionStatus.GRANTED else PedometerPermissionStatus.RESTRICTED
            ))
            return
        }

        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACTIVITY_RECOGNITION
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            callback(Result.success(PedometerPermissionStatus.GRANTED))
        } else {
            callback(Result.success(PedometerPermissionStatus.DENIED))
        }
    }
}
