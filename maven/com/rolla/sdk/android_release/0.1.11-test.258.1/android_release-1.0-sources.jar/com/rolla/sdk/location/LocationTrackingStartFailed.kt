package com.rolla.sdk.location

import app.rolla.bluetoothSdk.result.error.Error

class LocationTrackingStartFailed(throwable: Throwable? = null) : Error (
    code = LocationErrors.LOCATION_TRACKING_START_FAILED,
    message = "Location tracking start failed",
    exception = throwable
)