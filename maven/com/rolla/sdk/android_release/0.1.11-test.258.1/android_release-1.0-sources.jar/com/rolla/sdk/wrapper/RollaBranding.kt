package com.rolla.sdk.wrapper

data class RollaBranding(
    val appName: String,
    val primaryColor: Int,
    val secondaryColor: Int,
    val accentColor: Int,
    val brightness: String = "light",
    val defaultThemeMode: String = "system",
    val defaultLocale: String? = null,
    val headerLogoAsset: String? = null,
    val termsUrl: String? = null,
    val privacyUrl: String? = null
) {
    internal fun toMap(): Map<String, Any?> = buildMap {
        put("appName", appName)
        put("primaryColor", primaryColor)
        put("secondaryColor", secondaryColor)
        put("accentColor", accentColor)
        put("brightness", brightness)
        put("defaultThemeMode", defaultThemeMode)
        defaultLocale?.let { put("defaultLanguage", it) }
        headerLogoAsset?.let { put("headerLogoAsset", it) }
        termsUrl?.let { put("termsUrl", it) }
        privacyUrl?.let { put("privacyUrl", it) }
    }

    companion object {
        fun create(
            appName: String,
            primaryColor: Int,
            secondaryColor: Int,
            accentColor: Int,
            brightness: String = "light",
            defaultThemeMode: String = "system",
            defaultLocale: String? = null,
            headerLogoAsset: String? = null,
            termsUrl: String? = null,
            privacyUrl: String? = null
        ): RollaBranding = RollaBranding(
            appName = appName,
            primaryColor = primaryColor,
            secondaryColor = secondaryColor,
            accentColor = accentColor,
            brightness = brightness,
            defaultThemeMode = defaultThemeMode,
            defaultLocale = defaultLocale,
            headerLogoAsset = headerLogoAsset,
            termsUrl = termsUrl,
            privacyUrl = privacyUrl
        )
    }
}
