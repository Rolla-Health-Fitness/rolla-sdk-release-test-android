package com.rolla.sdk.wrapper

import android.content.Context
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.embedding.engine.plugins.util.GeneratedPluginRegister
import io.flutter.plugin.common.MethodChannel

internal class RollaEngineManager private constructor() {

    companion object {
        private const val TAG = "RollaEngineManager"
        internal const val ENGINE_ID = "rolla_wrapper_engine"
        private const val CHANNEL_NAME = "rolla_sdk/init"

        @Volatile
        private var instance: RollaEngineManager? = null

        fun getInstance(): RollaEngineManager {
            return instance ?: synchronized(this) {
                instance ?: RollaEngineManager().also { instance = it }
            }
        }
    }

    private var engine: FlutterEngine? = null
    private var methodChannel: MethodChannel? = null

    @Volatile
    var isPresenting: Boolean = false
        private set

    @Volatile
    var isReady: Boolean = false
        private set

    var onClose: ((String?) -> Unit)? = null
    var onError: ((String, String) -> Unit)? = null
    var onTokenRefreshed: ((String, String?, Int?) -> Unit)? = null
    var onTokenExpired: (() -> Unit)? = null

    private val initLock = Any()

    fun initialize(context: Context) {
        if (engine != null) {
            Log.d(TAG, "Engine already initialized")
            return
        }

        synchronized(initLock) {
            if (engine != null) {
                Log.d(TAG, "Engine already initialized (after lock)")
                return
            }

            Log.d(TAG, "Initializing Flutter engine...")

            val appContext = context.applicationContext
            val flutterEngine = FlutterEngine(appContext)

            GeneratedPluginRegister.registerGeneratedPlugins(flutterEngine)
            
            try {
                val sdk = com.rolla.sdk.RollaAndroidSdk.init(appContext)
                sdk.createBridge(appContext, flutterEngine.dartExecutor.binaryMessenger)
                Log.d(TAG, "Rolla SDK bridge created - Pigeon handlers registered")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create Rolla SDK bridge", e)
            }

            flutterEngine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint.createDefault()
            )

            FlutterEngineCache.getInstance().put(ENGINE_ID, flutterEngine)

            setupMethodChannel(flutterEngine)

            engine = flutterEngine
            isReady = true

            Log.d(TAG, "Flutter engine initialized and cached with ID: $ENGINE_ID")
        }
    }

    private fun setupMethodChannel(engine: FlutterEngine) {
        val channel = MethodChannel(
            engine.dartExecutor.binaryMessenger,
            CHANNEL_NAME
        )

        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "close" -> {
                    val args = call.arguments as? Map<*, *>
                    val reason = args?.get("reason") as? String
                    onClose?.invoke(reason)
                    result.success(null)
                }
                "error" -> {
                    val args = call.arguments as? Map<*, *>
                    val code = args?.get("code") as? String ?: "UNKNOWN"
                    val message = args?.get("message") as? String ?: "Unknown error"
                    onError?.invoke(code, message)
                    result.success(null)
                }
                "onTokenRefreshed" -> {
                    val args = call.arguments as? Map<*, *>
                    val token = args?.get("token") as? String ?: ""
                    val refreshToken = args?.get("refreshToken") as? String
                    val expiresIn = (args?.get("expiresIn") as? Number)?.toInt()
                    onTokenRefreshed?.invoke(token, refreshToken, expiresIn)
                    result.success(null)
                }
                "onTokenExpired" -> {
                    onTokenExpired?.invoke()
                    result.success(null)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        methodChannel = channel
    }

    fun configure(
        config: RollaConfiguration,
        showBackButton: Boolean,
        callback: (Result<Unit>) -> Unit
    ) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        val args = mutableMapOf<String, Any>(
            "token" to config.token,
            "partnerId" to config.partnerId,
            "environment" to config.environment,
            "isModal" to true,
            "showBackButton" to showBackButton,
            "hideBottomNavigation" to true,
            "showSettingsButton" to config.showSettingsButton,
            "removeRollaBandReferences" to config.removeRollaBandReferences
        )

        config.userId?.let { args["userId"] = it }
        config.refreshToken?.let { args["refreshToken"] = it }
        config.tokenExpiresIn?.let { args["tokenExpiresIn"] = it }
        if (config.disabledModules.isNotEmpty()) {
            args["disabledModules"] = config.disabledModules.map { it.rawValue }
        }
        config.branding?.let { args["branding"] = it.toMap() }

        channel.invokeMethod("initialize", args, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "SDK configured successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "SDK configuration failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "Initialize method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("Initialize method not implemented")
                ))
            }
        })
    }

    /**
     * Ensure the Flutter engine is running and the SDK is configured, WITHOUT
     * presenting any UI. Backs the headless reads (e.g. battery), letting a host
     * call into the SDK before — or without ever — showing the SDK screen.
     *
     * If the engine is already running this re-issues [configure]. For the same
     * user the Dart side treats that as a seamless resume and does not reset.
     */
    fun ensureConfigured(
        context: Context,
        config: RollaConfiguration,
        callback: (Result<Unit>) -> Unit
    ) {
        try {
            initialize(context)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize engine for headless configure", e)
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }
        // Back button is forced on (matching show()) for native add-to-app
        // hosts: it is the user's only built-in way out of the SDK and back to
        // the host app. Tapping it routes through the "close" method channel to
        // finish the SDK Activity; without it the user would be stranded in the
        // SDK with no exit. It must be set here too, not just in show(): a
        // headless configure already mounts RollaSdkHome offscreen and the Dart
        // entry point won't rebuild it on a later show() (seamless-resume
        // early-returns once initialized), so the home tree is built once with
        // whatever this first configure passes — a warm-up-then-show() flow with
        // the button off here would present without it.
        configure(config = config, showBackButton = true, callback = callback)
    }

    /**
     * Read the connected Rolla band's battery level over the method channel.
     *
     * Resolves to a typed [RollaBatteryResult]. Every no-band, disconnected,
     * timed-out, or Bluetooth-off case comes back as success with a non-AVAILABLE
     * status; a failed Result is reserved for transport problems, such as the
     * engine not being started.
     */
    fun getBandBatteryLevel(callback: (Result<RollaBatteryResult>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("getBandBatteryLevel", null, object : MethodChannel.Result {
            override fun success(result: Any?) {
                callback(Result.success(RollaBatteryResult.fromResponse(result)))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Battery read failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.FlutterError(errorCode, errorMessage ?: "Battery read failed")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "getBandBatteryLevel method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("getBandBatteryLevel method not implemented")
                ))
            }
        })
    }

    /**
     * Run a headless sync over the method channel.
     *
     * Resolves to a typed [RollaSyncResult]. Success, skipped, and failure
     * outcomes are all encoded in the result; a failed Result is reserved for
     * transport problems, such as the engine not being started.
     *
     * `includeSamples` is forwarded to Dart so the result's `syncedData` also
     * carries the raw sample arrays when requested.
     */
    fun syncHealthData(includeSamples: Boolean = false, callback: (Result<RollaSyncResult>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("syncHealthData", mapOf("includeSamples" to includeSamples), object : MethodChannel.Result {
            override fun success(result: Any?) {
                callback(Result.success(RollaSyncResult.fromResponse(result)))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Sync failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.FlutterError(errorCode, errorMessage ?: "Sync failed")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "syncHealthData method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("syncHealthData method not implemented")
                ))
            }
        })
    }

    fun updateToken(
        token: String,
        refreshToken: String?,
        expiresIn: Int?,
        callback: (Result<Unit>) -> Unit
    ) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        val args = mutableMapOf<String, Any>("token" to token)
        refreshToken?.let { args["refreshToken"] = it }
        expiresIn?.let { args["expiresIn"] = it }

        channel.invokeMethod("updateToken", args, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "Token updated successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Token update failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "updateToken method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("updateToken method not implemented")
                ))
            }
        })
    }

    fun clearSession(callback: (Result<Unit>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("clearSession", null, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "Session cleared successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Clear session failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "clearSession method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("clearSession method not implemented")
                ))
            }
        })
    }

    fun setPresenting(value: Boolean) {
        isPresenting = value
    }

    fun getEngine(): FlutterEngine? = engine

    fun destroy() {
        methodChannel?.setMethodCallHandler(null)
        methodChannel = null
        onClose = null
        onError = null
        onTokenRefreshed = null
        onTokenExpired = null

        engine?.let {
            FlutterEngineCache.getInstance().remove(ENGINE_ID)
            it.destroy()
        }
        engine = null
        isReady = false
        isPresenting = false

        Log.d(TAG, "Flutter engine destroyed")
    }
}
