package com.rolla.sdk.wrapper

interface RollaListener {
    fun onRollaClosed(rolla: Rolla, reason: RollaCloseReason) {}
    fun onRollaError(rolla: Rolla, error: RollaError) {}

    /**
     * Called when the SDK successfully refreshes tokens internally.
     *
     * Use this to sync your app's token storage with the SDK's refreshed tokens.
     *
     * @param rolla The Rolla instance that refreshed the token.
     * @param token The new access token.
     * @param refreshToken The new refresh token, if provided.
     * @param expiresIn Time in seconds until the new access token expires, if known.
     */
    fun onTokenRefreshed(rolla: Rolla, token: String, refreshToken: String?, expiresIn: Int?) {}

    /**
     * Called when the SDK's internal token refresh fails and the host app needs to provide new tokens.
     *
     * When this is called, obtain fresh tokens from your auth backend and push them
     * to the SDK via [Rolla.updateToken].
     *
     * @param rolla The Rolla instance that needs fresh tokens.
     */
    fun onTokenExpired(rolla: Rolla) {}

    /**
     * Called when a headless [Rolla.syncHealthData] runs to a terminal outcome.
     *
     * Delivers the same [RollaSyncResult] passed to the `syncHealthData` callback, so a
     * host can observe sync results centrally (e.g. to refresh its own UI)
     * without threading a callback through every call site. Fired only when the
     * sync reached a terminal outcome; transport failures (e.g. the engine
     * could not start) are delivered to the `sync` callback as a failed Result
     * and do NOT fire this method.
     *
     * @param rolla The Rolla instance that ran the sync.
     * @param result The terminal sync result.
     */
    fun onSyncCompleted(rolla: Rolla, result: RollaSyncResult) {}
}
