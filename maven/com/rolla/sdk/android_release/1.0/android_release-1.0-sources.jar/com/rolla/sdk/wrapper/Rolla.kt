package com.rolla.sdk.wrapper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment


class Rolla(val configuration: RollaConfiguration) {

    companion object {
        private const val TAG = "Rolla"

        fun destroyEngine() {
            RollaEngineManager.getInstance().destroy()
        }
    }

    var listener: RollaListener? = null

    val isPresenting: Boolean
        get() = engineManager.isPresenting

    private val engineManager: RollaEngineManager
        get() = RollaEngineManager.getInstance()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingCloseReason: RollaCloseReason? = null

    fun show(activity: Activity) {
        mainHandler.post {
            if (engineManager.isPresenting) {
                listener?.onRollaError(this, RollaError.AlreadyPresenting())
                return@post
            }

            if (activity.isFinishing || activity.isDestroyed) {
                listener?.onRollaError(this, RollaError.InvalidContext())
                return@post
            }

            engineManager.setPresenting(true)
            prepareAndShow(activity)
        }
    }

    fun show(fragment: Fragment) {
        val activity = fragment.activity
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            mainHandler.post {
                listener?.onRollaError(this, RollaError.InvalidContext())
            }
            return
        }
        show(activity)
    }

    /**
     * Clear all persisted session data (tokens, auth metadata) from secure storage.
     *
     * Call this when your app logs out the user and you want the SDK to forget
     * all credentials for that user. This does **not** dismiss the SDK UI or
     * destroy the Flutter engine — it only purges stored tokens.
     *
     * The engine must be initialized (i.e. [show] must have been called at
     * least once) for the method channel to be available.
     */
    fun clearSession(callback: ((Result<Unit>) -> Unit)? = null) {
        mainHandler.post {
            engineManager.clearSession { result ->
                mainHandler.post {
                    callback?.invoke(result)
                }
            }
        }
    }

    /**
     * Push fresh tokens to the SDK.
     *
     * Call this after receiving an [RollaListener.onTokenExpired] callback,
     * once your app has obtained new tokens from its own auth backend.
     *
     * @param token The new access token.
     * @param refreshToken An optional new refresh token.
     * @param expiresIn Optional time in seconds until the new token expires.
     * @param callback Called when the SDK has accepted or rejected the token update.
     */
    fun updateToken(
        token: String,
        refreshToken: String? = null,
        expiresIn: Int? = null,
        callback: ((Result<Unit>) -> Unit)? = null
    ) {
        mainHandler.post {
            engineManager.updateToken(
                token = token,
                refreshToken = refreshToken,
                expiresIn = expiresIn
            ) { result ->
                mainHandler.post {
                    callback?.invoke(result)
                }
            }
        }
    }

    /**
     * Warm up the Flutter engine and configure the SDK ahead of time, WITHOUT
     * presenting any UI.
     *
     * Call this to remove the engine start-up cost from the first [show] (e.g.
     * warm up right after login so opening the SDK is instant), or to enable
     * headless reads such as [getBatteryLevel] before the UI has ever been
     * shown. A subsequent [show] reuses the already-running engine and goes
     * straight to presenting. Safe to call more than once — repeat calls for
     * the same user are a seamless no-op (the session is preserved).
     *
     * The warmed engine holds memory for the session; reclaim it with
     * [destroyEngine] when you no longer need the SDK.
     *
     * @param context Any context (application context is used internally).
     * @param callback Called when the engine is configured and ready, or with
     *   an error if start-up failed.
     */
    fun warmUpEngine(context: Context, callback: ((Result<Unit>) -> Unit)? = null) {
        val appContext = context.applicationContext
        mainHandler.post {
            // Headless: do not wire presentation callbacks (onClose/onError) here
            // so we never hijack the callbacks of a live presentation owned by a
            // different Rolla instance. show() wires them when it actually presents.
            engineManager.ensureConfigured(appContext, configuration) { result ->
                mainHandler.post { callback?.invoke(result) }
            }
        }
    }

    /**
     * Read the connected Rolla band's current battery level.
     *
     * This is a **live BLE read from a Rolla band** — the user must have a Rolla
     * band paired and reachable to get a value. The engine is warmed up
     * automatically if needed (no UI is shown), so this works even before [show]
     * has ever been called.
     *
     * The result is always a typed [RollaBatteryResult]: band-absence cases (no
     * band paired, disconnected, timeout, not a Rolla band, Bluetooth off)
     * resolve as success with a non-AVAILABLE status — never as a thrown error
     * and never as a stale value presented as live. Failure is reserved for
     * transport problems (e.g. the engine could not start).
     *
     * @param context Any context (application context is used internally).
     * @param callback Delivers the battery result on the main thread.
     */
    fun getBatteryLevel(context: Context, callback: (Result<RollaBatteryResult>) -> Unit) {
        val appContext = context.applicationContext
        mainHandler.post {
            // Headless read: don't wire presentation callbacks (see warmUpEngine).
            engineManager.ensureConfigured(appContext, configuration) { configureResult ->
                configureResult.onSuccess {
                    engineManager.getBatteryLevel { batteryResult ->
                        mainHandler.post { callback(batteryResult) }
                    }
                }.onFailure { error ->
                    val rollaError = (error as? RollaError)
                        ?: RollaError.InitializationFailed(error.message ?: "Unknown error")
                    mainHandler.post { callback(Result.failure(rollaError)) }
                }
            }
        }
    }

    fun dismiss() {
        mainHandler.post {
            if (!engineManager.isPresenting) return@post

            if (pendingCloseReason == null) {
                pendingCloseReason = RollaCloseReason.Programmatic
            }

            RollaFlutterActivity.setPendingCloseReason(
                pendingCloseReason ?: RollaCloseReason.Programmatic
            )
            RollaFlutterActivity.finishCurrent()
        }
    }

    private fun prepareAndShow(activity: Activity) {
        try {
            engineManager.initialize(activity)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize engine", e)
            cleanup()
            listener?.onRollaError(this, RollaError.EngineFailedToStart())
            return
        }

        setupCallbacks()

        engineManager.configure(
            config = configuration,
            showBackButton = true
        ) { result ->
            mainHandler.post {
                result.onSuccess {
                    if (activity.isFinishing || activity.isDestroyed) {
                        cleanup()
                        listener?.onRollaError(this, RollaError.InvalidContext())
                        return@post
                    }
                    launchActivity(activity)
                }.onFailure { error ->
                    cleanup()
                    val rollaError = when (error) {
                        is RollaError -> error
                        else -> RollaError.InitializationFailed(error.message ?: "Unknown error")
                    }
                    listener?.onRollaError(this, rollaError)
                }
            }
        }
    }

    private fun launchActivity(activity: Activity) {
        if (RollaFlutterActivity.onDismiss != null) {
            Log.w(TAG, "Warning: overwriting existing onDismiss callback - this should not happen")
        }

        RollaFlutterActivity.onDismiss = { reason ->
            mainHandler.post {
                val finalReason = pendingCloseReason ?: reason
                cleanup()
                listener?.onRollaClosed(this, finalReason)
            }
        }

        val intent = Intent(activity, RollaFlutterActivity::class.java)
        activity.startActivity(intent)

        Log.d(TAG, "RollaFlutterActivity launched")
    }

    private fun setupCallbacks() {
        if (engineManager.onClose != null || engineManager.onError != null) {
            Log.w(TAG, "Warning: overwriting existing engine callbacks - this should not happen")
        }

        engineManager.onClose = { reason ->
            pendingCloseReason = RollaCloseReason.FlutterRequested(reason)
            RollaFlutterActivity.finishCurrent()
        }

        engineManager.onError = { code, message ->
            mainHandler.post {
                listener?.onRollaError(this, RollaError.FlutterError(code, message))
            }
        }

        engineManager.onTokenRefreshed = { token, refreshToken, expiresIn ->
            mainHandler.post {
                listener?.onTokenRefreshed(this, token, refreshToken, expiresIn)
            }
        }

        engineManager.onTokenExpired = {
            mainHandler.post {
                listener?.onTokenExpired(this)
            }
        }
    }

    private fun cleanup() {
        pendingCloseReason = null
        engineManager.setPresenting(false)
        engineManager.onClose = null
        engineManager.onError = null
        engineManager.onTokenRefreshed = null
        engineManager.onTokenExpired = null
        RollaFlutterActivity.clearCallbacks()
    }
}
