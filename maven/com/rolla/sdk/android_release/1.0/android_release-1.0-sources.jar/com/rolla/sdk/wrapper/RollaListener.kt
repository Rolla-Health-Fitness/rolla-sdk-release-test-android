package com.rolla.sdk.wrapper

import com.rolla.sdk.wrapper.features.access.RollaAccessStatus
import com.rolla.sdk.wrapper.features.activity.RollaActivityPhase
import com.rolla.sdk.wrapper.features.activity.RollaCompletedActivity
import com.rolla.sdk.wrapper.features.activity.RollaRemovedActivity
import com.rolla.sdk.wrapper.features.activity.RollaStartedActivity
import com.rolla.sdk.wrapper.features.band.RollaBandInfo
import com.rolla.sdk.wrapper.features.goals.RollaGoalsChanged
import com.rolla.sdk.wrapper.features.profile.RollaProfileUpdated
import com.rolla.sdk.wrapper.features.session.RollaCloseReason
import com.rolla.sdk.wrapper.features.session.RollaError
import com.rolla.sdk.wrapper.features.sync.RollaPrimarySourceChanged
import com.rolla.sdk.wrapper.features.sync.RollaSyncResult

interface RollaListener {
    fun onRollaClosed(rolla: Rolla, reason: RollaCloseReason) {}
    fun onRollaError(rolla: Rolla, error: RollaError) {}

    /**
     * Called when the SDK successfully refreshes tokens internally.
     *
     * Use this to sync your app's token storage with the SDK's refreshed tokens.
     *
     * @param rolla The Rolla instance that refreshed the token.
     * @param token The new access token.
     * @param refreshToken The new refresh token, if provided.
     * @param expiresIn Time in seconds until the new access token expires, if known.
     */
    fun onTokenRefreshed(rolla: Rolla, token: String, refreshToken: String?, expiresIn: Int?) {}

    /**
     * Called when the SDK's internal token refresh fails and the host app needs to provide new tokens.
     *
     * When this is called, obtain fresh tokens from your auth backend and push them
     * to the SDK via [Rolla.updateToken].
     *
     * @param rolla The Rolla instance that needs fresh tokens.
     */
    fun onTokenExpired(rolla: Rolla) {}

    /**
     * Called when a headless [Rolla.syncHealthData] reaches a terminal outcome.
     *
     * Delivers the same [RollaSyncResult] the `syncHealthData` callback receives,
     * giving a host one central place to observe sync results — for example, to
     * refresh its own UI. It fires only for a terminal outcome: transport
     * failures (e.g. the engine could not start) come back through the
     * `syncHealthData` callback as a failed Result and do not fire this method.
     *
     * @param rolla The Rolla instance that ran the sync.
     * @param result The terminal sync result.
     */
    fun onSyncHealthDataCompleted(rolla: Rolla, result: RollaSyncResult) {}

    /**
     * Called when an activity completed inside the SDK UI reaches a lifecycle
     * phase: [RollaActivityPhase.FINISHED] (saved in-SDK — instant), then
     * [RollaActivityPhase.UPLOADED] (confirmed by the backend) or
     * [RollaActivityPhase.UPLOAD_FAILED] (the upload gave up permanently).
     *
     * [RollaCompletedActivity.source] distinguishes live-tracked activities
     * from manually logged ones. Key idempotency on `(activityId, phase)` —
     * `UPLOADED`/`UPLOAD_FAILED` can re-fire across retries. Distinct from
     * [onRollaClosed]: it fires whether or not the user then closes the SDK
     * UI, and `UPLOADED` can arrive after close (uploads finish in the
     * background while the engine is alive).
     *
     * @param rolla The Rolla instance delivering the event.
     * @param activity The activity payload, including its lifecycle phase.
     */
    fun onActivityCompleted(rolla: Rolla, activity: RollaCompletedActivity) {}

    /**
     * Called when a live tracking session starts running inside the SDK — a
     * fresh start or a crash-recovery resume ([RollaStartedActivity.origin]
     * says which; key on `activityId` to dedupe the crash-recovery re-fire).
     * Manual activities never fire this (they enter the lifecycle at
     * `FINISHED`), and pausing/resuming inside a session fires nothing.
     *
     * Every started activity terminates in [onActivityCompleted] (phase
     * `FINISHED`) or [onActivityRemoved] — possibly in a **different app
     * session** when the app dies in between. Two exceptions are cleaned up
     * silently, without an event: a session abandoned mid-tracking for over
     * a day, and an interrupted session neither resumed nor discarded before
     * the user starts their next activity.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param activity The started activity (id, type, start time, origin).
     */
    fun onActivityStarted(rolla: Rolla, activity: RollaStartedActivity) {}

    /**
     * Called when an activity's record is removed without a kept result —
     * [RollaRemovedActivity.reason] says why: `CANCELED` (a session that was
     * never saved — discarded from the dashboard on stop or from the
     * crash-recovery prompt; the commonly expected "activity canceled" case)
     * or `DELETED` (the user deleted a saved activity from the review screen,
     * backend-confirmed).
     *
     * @param rolla The Rolla instance delivering the event.
     * @param activity The removed activity (id, reason).
     */
    fun onActivityRemoved(rolla: Rolla, activity: RollaRemovedActivity) {}

    /**
     * Called when a sync completes inside the SDK UI: the auto-sync on open,
     * the sync on return from background while the SDK is showing, and the
     * in-app manual refresh.
     *
     * Distinct from [onSyncHealthDataCompleted], which fires only for host-initiated
     * headless [Rolla.syncHealthData] calls — the payload type is shared so a
     * host reads one result shape for both directions. On a successful or
     * partial band / Apple Health / Health Connect UI sync,
     * [RollaSyncResult.syncedData] carries the same per-stream summary
     * breakdown as the headless result (samples are never included on UI
     * syncs). It is null when there is
     * nothing attributable to report: failure and skipped events, Garmin/Oura
     * content-only refreshes, syncs that recorded no data, and syncs that
     * overlapped another sync (concurrent UI syncs or a concurrent headless
     * sync) — never wrong or double-reported data.
     *
     * [RollaSyncResult.streamResults] and [RollaSyncResult.outcome] follow the same rules as the
     * headless result, so a UI sync where a stream failed is reported as `PARTIAL` while new data
     * still reached the server (or `FAILURE` when none did), even while the SDK UI itself shows
     * the sync as complete.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param result The terminal result of the UI sync.
     */
    fun onUiSyncCompleted(rolla: Rolla, result: RollaSyncResult) {}

    /**
     * Called when the user pairs a band inside the SDK UI — the band is
     * persisted locally and registered with the backend at this moment.
     * Auto-reconnects and login restores do not fire this.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param band The paired band (name, MAC, device type, RSSI).
     */
    fun onBandPaired(rolla: Rolla, band: RollaBandInfo) {}

    /**
     * Called when the user unpairs the band inside the SDK UI (confirmed by
     * the backend). A band unpaired remotely — from another device — is
     * reconciled silently and does not fire this.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param band The unpaired band (MAC plus last cached battery/firmware/serial).
     */
    fun onBandUnpaired(rolla: Rolla, band: RollaBandInfo) {}

    /**
     * Called when the user's band establishes a live BLE link — the first
     * connect of an engine session and every reconnect after a reported
     * disconnect. Repeated "connected" updates fire it once, and a momentary
     * drop that recovers inside the disconnect debounce fires nothing on
     * either method.
     *
     * Delivery is engine-scoped, NOT an OS proximity push: nothing fires
     * while the engine is cold. Link events are orthogonal to
     * paired/unpaired — use [Rolla.getPairedBandInfo] for the pairing state.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param band The band (MAC plus last cached battery/firmware/serial).
     */
    fun onBandConnected(rolla: Rolla, band: RollaBandInfo) {}

    /**
     * Called when the user's band loses its live BLE link — debounced a few
     * seconds so a momentary drop with an immediate reconnect reports
     * nothing, and arriving only after the BLE supervision timeout, i.e.
     * seconds after physical range loss. Not a proximity/geofencing signal.
     *
     * An unpair or logout drops the physical link too, so this event
     * legitimately accompanies those flows. Nothing fires while the engine is
     * cold — a disconnect that happens with the app terminated is never
     * reported retroactively.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param band The band (MAC plus last cached battery/firmware/serial).
     */
    fun onBandDisconnected(rolla: Rolla, band: RollaBandInfo) {}

    /**
     * Called when the SDK observes the user's primary data source change —
     * committed inside the SDK UI, or discovered on a profile/connections
     * refresh (changes made server-side or on another device surface on the
     * next refresh, not instantly).
     *
     * @param rolla The Rolla instance delivering the event.
     * @param change The previous and current primary source.
     */
    fun onPrimarySourceChanged(rolla: Rolla, change: RollaPrimarySourceChanged) {}

    /**
     * Called when the user saves goal changes inside the SDK UI (each toggle
     * backend-confirmed). One call per save, carrying both the toggled goals
     * and the resulting enabled set.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param change The toggled goals and the enabled set after the save.
     */
    fun onGoalsChanged(rolla: Rolla, change: RollaGoalsChanged) {}

    /**
     * Called when the user updates profile data inside the SDK UI — a profile
     * details edit, a weight log, or a blood-pressure log — with only the
     * changed fields. See [RollaProfileUpdated] for the key vocabulary.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param update The sparse map of changed fields.
     */
    fun onProfileUpdated(rolla: Rolla, update: RollaProfileUpdated) {}

    /**
     * Called with the user's access status when the SDK first loads it and on
     * every change after, in order — a lock from a `403 access_required`
     * refusal, the access end date or a status refresh, and an unlock after a
     * redeemed code or a partner-side restore. The SDK never reports an
     * unlock without a backend answer.
     *
     * A lock that lands while a workout is recording in the SDK UI is
     * delivered once the workout is finished or discarded, so the user can
     * complete it (a newer lock replaces the held one); an unlock is never
     * held. Delivered for the engine's lifetime, UI shown or not, to the
     * instance that most recently called the SDK — last writer wins, like
     * the other host events, not the presenter-first rule of the token
     * callbacks — so set the listener on every instance that calls the SDK,
     * or keep one instance: a status that reaches an instance without a
     * listener is not repeated. A headless [Rolla.syncHealthData] that learns
     * of a lock answers `SKIPPED` with `ACCESS_REQUIRED` — or `PARTIAL`, with
     * the lock as its error, when data landed before the backend stated it
     * mid-sync — and reports the lock here, possibly after its callback.
     *
     * A host that gates its own screens shows or lifts its lock from
     * [RollaAccessStatus.isLocked]; a host that presents the SDK can leave the
     * lock to it — the SDK's own lock screen handles code entry, the help link
     * and logout while locked. Partners whose gate is off hear one status with
     * [RollaAccessStatus.gateEnabled] false per SDK session (each engine start
     * or user switch), and again only when it changes.
     *
     * @param rolla The Rolla instance delivering the event.
     * @param status The user's access status.
     */
    fun onAccessChanged(rolla: Rolla, status: RollaAccessStatus) {}
}
