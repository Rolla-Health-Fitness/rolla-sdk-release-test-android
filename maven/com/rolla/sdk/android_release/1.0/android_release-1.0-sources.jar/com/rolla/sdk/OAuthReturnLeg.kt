package com.rolla.sdk

import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Completes the return leg of an in-app OAuth session (flutter_web_auth_2) when the browser's redirect
 * lands in a task of its own.
 *
 * Browsers with Auth Tab return the redirect to the plugin's AuthenticationManagementActivity as an
 * activity result, which closes the tab by itself. Browsers without it (Samsung Internet, Firefox) run a
 * plain Custom Tab inside the host activity's task, above that activity, and deliver the redirect to the
 * callback scheme as a `NEW_TASK` VIEW intent for the plugin's CallbackActivity. The plugin resolves the
 * Dart future there and starts AuthenticationManagementActivity with `CLEAR_TOP`, which dismisses the tab
 * only when the callback activity sits in that same task. With `android:taskAffinity=""` on the callback
 * activity — the Flutter template default the plugin README prescribes, and a task-hijacking hardening
 * hosts keep — nothing can join a task by affinity: the callback roots a new task, the `CLEAR_TOP` acts
 * there, and the host's task keeps the tab on top. The connect succeeds while the user is left on the
 * provider's consent page until they close the browser by hand.
 *
 * This guard watches activity creation process-wide. When the callback activity is created in a task
 * other than [hostActivity]'s, it starts the host activity into the host's own task, found by id
 * ([ActivityManager.AppTask.startActivity]), with `CLEAR_TOP | SINGLE_TOP`: the tab and the plugin's
 * activity above the host finish, the host receives `onNewIntent` with no data (Flutter pushes no route),
 * and the task comes to the front. Launching into the task by id involves no affinity or root-activity
 * matching. It runs from the callback activity while that is the top of the foreground task, which
 * background-activity-launch rules allow. When no task of the app matches it does nothing: a `NEW_TASK`
 * launch could start a second SDK activity in an Add-to-App host.
 *
 * A callback created in the host's task is left alone, since the plugin's own `CLEAR_TOP` dismisses the
 * tab there.
 *
 * The callback activity is matched by class name: plugin modules do not see each other's classes at
 * compile time. The host manifest declares it, so the name survives code shrinking.
 *
 * Registered once per process and kept for its lifetime; every callback except [onActivityCreated] is a
 * no-op. All entry points run on the main thread.
 */
internal object OAuthReturnLeg : Application.ActivityLifecycleCallbacks {

    private const val TAG = "OAuthReturnLeg"

    /** flutter_web_auth_2's receiver of the redirect to the callback scheme. */
    private const val CALLBACK_ACTIVITY = "com.linusu.flutter_web_auth_2.CallbackActivity"

    private val registered = AtomicBoolean(false)

    // Weak so a host that detaches without notice is never kept alive by this process-wide object.
    private var hostRef: WeakReference<Activity>? = null

    /**
     * The activity the SDK's Flutter engine is attached to: the app's FlutterActivity for Flutter hosts,
     * the activity hosting the SDK UI for Add-to-App. The most recent attach wins when several engines run.
     */
    var hostActivity: Activity?
        get() = hostRef?.get()
        set(value) {
            hostRef = value?.let { WeakReference(it) }
        }

    /** Registers the guard on the application. Several engines attach in one process; only the first registers. */
    fun register(context: Context) {
        val application = context.applicationContext as? Application
        if (application == null) {
            Log.w(TAG, "No Application context; the OAuth return-leg guard is not registered")
            return
        }
        if (registered.compareAndSet(false, true)) {
            application.registerActivityLifecycleCallbacks(this)
        }
    }

    /** Clears [hostActivity] only while it is still [activity]: another engine may have attached since. */
    fun releaseHost(activity: Activity) {
        if (hostActivity === activity) hostActivity = null
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        if (activity.javaClass.name != CALLBACK_ACTIVITY || activity.intent?.data == null) return
        val host = hostActivity ?: return
        if (host.isFinishing || host.isDestroyed) return
        // A failure escaping a lifecycle callback would crash the host app, so every one is only logged.
        try {
            val hostTaskId = host.taskId
            if (activity.taskId == hostTaskId) return
            val hostTask = findAppTask(host, hostTaskId)
            if (hostTask == null) {
                Log.w(TAG, "OAuth redirect arrived outside the host task, and the host task $hostTaskId was not found")
                return
            }
            Log.d(TAG, "OAuth redirect arrived outside the host task; bringing ${host.javaClass.name} back on top")
            val relaunch = Intent(host, host.javaClass)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            hostTask.startActivity(activity, relaunch, null)
        } catch (t: Throwable) {
            Log.w(TAG, "Could not bring the host activity back after an OAuth redirect", t)
        }
    }

    private fun findAppTask(context: Context, taskId: Int): ActivityManager.AppTask? {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return null
        return activityManager.appTasks.firstOrNull { appTask ->
            // getTaskInfo throws for a task removed since the list was read.
            try {
                taskIdOf(appTask.taskInfo) == taskId
            } catch (e: IllegalArgumentException) {
                false
            }
        }
    }

    // TaskInfo.taskId exists from API 29; below it the id is RecentTaskInfo.persistentId. The receiver
    // stays typed RecentTaskInfo so the field resolves through its superclass on API 29+.
    @Suppress("DEPRECATION")
    private fun taskIdOf(info: ActivityManager.RecentTaskInfo): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info.taskId else info.persistentId

    override fun onActivityStarted(activity: Activity) = Unit

    override fun onActivityResumed(activity: Activity) = Unit

    override fun onActivityPaused(activity: Activity) = Unit

    override fun onActivityStopped(activity: Activity) = Unit

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit

    override fun onActivityDestroyed(activity: Activity) = Unit
}
