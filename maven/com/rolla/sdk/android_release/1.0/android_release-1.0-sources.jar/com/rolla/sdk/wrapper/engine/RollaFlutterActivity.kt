package com.rolla.sdk.wrapper.engine

import android.content.Intent
import android.os.Build
import android.os.Bundle
import com.rolla.sdk.R
import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaTransition
import com.rolla.sdk.wrapper.features.session.RollaCloseReason
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache

class RollaFlutterActivity : FlutterFragmentActivity() {

    companion object {
        /** Intent extra carrying the [RollaTransition] name chosen at [Rolla.show]. */
        internal const val EXTRA_TRANSITION = "com.rolla.sdk.wrapper.EXTRA_TRANSITION"

        @Volatile
        internal var onDismiss: ((RollaCloseReason) -> Unit)? = null

        @Volatile
        private var pendingCloseReason: RollaCloseReason? = null

        @Volatile
        private var currentInstance: RollaFlutterActivity? = null

        /** True while an SDK Activity instance exists (created and not yet destroyed). */
        internal val isAlive: Boolean
            get() = currentInstance != null

        /**
         * Brings the live SDK Activity back to the front of its task. Started from the
         * instance's own context so the target task is always the one it lives in —
         * the notification trampoline, which runs in a task of its own, would
         * otherwise start a second instance beside it.
         *
         * False when no instance exists or the one that does is finishing — stricter
         * than [isAlive] on purpose: a dismiss runs `finish()` synchronously, but the
         * instance is only cleared in the later `onDestroy` message, and reordering a
         * finishing record to the front would start a fresh instance with no dismiss
         * wiring.
         */
        internal fun bringToFront(): Boolean {
            val instance = currentInstance ?: return false
            if (instance.isFinishing || instance.isDestroyed) return false
            instance.startActivity(
                Intent(instance, RollaFlutterActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            )
            return true
        }

        internal fun setPendingCloseReason(reason: RollaCloseReason) {
            pendingCloseReason = reason
        }

        internal fun clearCallbacks() {
            onDismiss = null
            pendingCloseReason = null
        }

        internal fun finishCurrent() {
            currentInstance?.finish()
        }
    }

    private var didNotifyDismiss = false
    private var backPressedDuringSession = false
    private var isFadeTransition = false

    /**
     * True when this instance cannot be the SDK UI: the system restored it from a
     * task record after the engine that backed it died with the process, or after
     * the presentation it belonged to had already ended (the record was revisited
     * below a newer one). Decided once, in [onCreate], before anything attaches.
     * A configuration change recreates a presenting instance and is not an orphan.
     */
    private var isOrphan = false

    // Null for an orphan: the delegate throws on a cache miss, and attaching a
    // second view to the live engine would show an SDK UI nobody presented. The
    // fragment then builds its own bare engine — no plugins, no Dart isolate since
    // onStart never runs — and destroys it with itself.
    override fun getCachedEngineId(): String? = if (isOrphan) null else RollaEngineManager.ENGINE_ID

    // Neither the activity control surface nor the plugins belong on that bare engine.
    override fun shouldAttachEngineToActivity(): Boolean = !isOrphan

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        if (!isOrphan) super.configureFlutterEngine(flutterEngine)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        isOrphan = !FlutterEngineCache.getInstance().contains(RollaEngineManager.ENGINE_ID) ||
            (savedInstanceState != null && !RollaEngineManager.getInstance().isPresenting)
        if (isOrphan) {
            // Restored by the system from a task record — a relaunch from Recents
            // after the process died, or a record revisited once its presentation
            // was over. Restoring the saved fragment would throw on the missing
            // engine, or revive a UI with no presenter wired to it, so the saved
            // state is dropped and the instance finishes before it ever starts: it
            // never shows, never counts as the SDK activity, and the host hears
            // nothing about it.
            super.onCreate(null)
            finish()
            return
        }
        super.onCreate(savedInstanceState)
        currentInstance = this
        didNotifyDismiss = false
        backPressedDuringSession = false
        isFadeTransition = intent?.getStringExtra(EXTRA_TRANSITION) == RollaTransition.FADE.name
        if (isFadeTransition && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // The API < 34 path runs overridePendingTransition in finish()
            // instead — every close funnels through that one override.
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        backPressedDuringSession = true
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        // An orphan never presented: nothing below applies to it.
        if (isOrphan) return
        // Guarded so a late onDestroy from a replaced instance cannot
        // unregister a newer, live Activity.
        if (currentInstance == this) {
            currentInstance = null
        }
        notifyDismissOnce()
        // After super.onDestroy() the Flutter delegate has detached from the
        // engine, so a teardown deferred by a host task removal is safe now.
        RollaEngineManager.notifySdkActivityDestroyed()
    }

    override fun finish() {
        if (pendingCloseReason == null && backPressedDuringSession) {
            pendingCloseReason = RollaCloseReason.HostNavigationBack
        }
        super.finish()
        if (isFadeTransition && Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.rolla_fade_in, R.anim.rolla_fade_out)
        }
    }

    private fun notifyDismissOnce() {
        if (didNotifyDismiss) return
        didNotifyDismiss = true

        val reason = pendingCloseReason ?: RollaCloseReason.HostModalDismiss
        pendingCloseReason = null

        onDismiss?.invoke(reason)
        onDismiss = null
    }
}
