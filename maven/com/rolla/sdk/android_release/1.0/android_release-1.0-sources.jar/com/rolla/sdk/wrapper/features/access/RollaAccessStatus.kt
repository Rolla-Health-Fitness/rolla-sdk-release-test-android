package com.rolla.sdk.wrapper.features.access

import com.rolla.sdk.wrapper.RollaListener
import java.util.Date

/**
 * Where a user stands against the partner's access gate. Later versions may add values, so keep
 * an `else` branch when switching over it.
 */
enum class RollaAccessState(val rawValue: String) {
    /**
     * The user has never had access: they registered while the gate was off, or the gate was
     * turned on after they registered. A code starts it.
     */
    INACTIVE("inactive"),

    /**
     * Access is running, until [RollaAccessStatus.accessEndsAt] or without an end when
     * [RollaAccessStatus.unlimited].
     */
    ACTIVE("active"),

    /** The access end date has passed. A new code restores access. */
    EXPIRED("expired"),

    /** An admin removed the user's access. A code cannot restore it; only an admin can. */
    REVOKED("revoked"),

    /**
     * The SDK reported a state this version does not recognize (forward-compat).
     * [RollaAccessStatus.isLocked] still says whether the user is locked out.
     */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaAccessState =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Payload of [RollaListener.onAccessChanged]: the signed-in user's access status, as the backend
 * last reported it to the SDK.
 *
 * When the partner's gate is off ([gateEnabled] is false) the SDK behaves as if the access
 * feature did not exist: [state] is null and nothing is locked. When the gate is on, [state] is
 * always set and the user may use the app only while it is [RollaAccessState.ACTIVE].
 *
 * The constructor is public so a host can build a status by hand for its own tests or previews of
 * a [RollaListener] handler; the SDK fills every delivered status itself. [isLocked] defaults to
 * the SDK's rule — the gate on and the state not active; the SDK passes the wire value itself.
 */
data class RollaAccessStatus(
    /** Whether the partner requires active access to use the app. */
    val gateEnabled: Boolean,
    /** The partner's "How do I get a code?" page, for a host's own lock screen. May be null. */
    val helpUrl: String? = null,
    /** The user's access state; null exactly when the gate is off. */
    val state: RollaAccessState? = null,
    /**
     * When time-limited access ends (or ended). Null for unlimited access and for a user who never
     * had access. A revoked user still carries the stored date, which the SDK does not show.
     */
    val accessEndsAt: Date? = null,
    /** Whether the access never ends. */
    val unlimited: Boolean = false,
    /**
     * Whether the user is locked out: the gate is on and access is not active. Decided by the SDK
     * and carried on the wire, so it is right even for a [state] this version does not know.
     */
    val isLocked: Boolean = gateEnabled && state != null && state != RollaAccessState.ACTIVE
) {
    companion object {
        /**
         * Build from the method-channel wire map
         * `{ "gateEnabled": Boolean, "helpUrl": String?, "state": String?, "accessEndsAt": Long?
         * (epoch ms), "unlimited": Boolean, "isLocked": Boolean }`. An unknown state string maps
         * to [RollaAccessState.UNKNOWN].
         */
        fun fromResponse(response: Any?): RollaAccessStatus {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            return RollaAccessStatus(
                gateEnabled = map["gateEnabled"] as? Boolean ?: false,
                helpUrl = map["helpUrl"] as? String,
                state = (map["state"] as? String)?.let { RollaAccessState.fromRawValue(it) },
                accessEndsAt = (map["accessEndsAt"] as? Number)?.let { Date(it.toLong()) },
                unlimited = map["unlimited"] as? Boolean ?: false,
                isLocked = map["isLocked"] as? Boolean ?: false
            )
        }
    }
}
