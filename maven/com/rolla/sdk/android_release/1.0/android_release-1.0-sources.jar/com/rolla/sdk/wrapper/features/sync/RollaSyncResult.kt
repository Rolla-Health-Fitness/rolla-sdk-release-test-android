package com.rolla.sdk.wrapper.features.sync

import android.util.Log
import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.RollaListener
import com.rolla.sdk.wrapper.features.band.RollaBatteryStatus
import java.time.Instant
import java.time.OffsetDateTime
import java.util.Date

/**
 * The terminal outcome of a headless [Rolla.syncHealthData] call.
 *
 * A sync connects the user's primary data source and uploads anything new,
 * with no SDK UI. The outcome is always one of these.
 */
enum class RollaSyncOutcome(val rawValue: String) {
    /** The sync ran to completion. [RollaSyncResult.hasNewData] says whether anything new was uploaded. */
    SUCCESS("success"),

    /**
     * The sync ran, at least one stream failed, and new data still reached the server — a stream
     * uploaded, or a failed stream's accepted part is in [RollaSyncResult.syncedData]. See
     * [RollaSyncResult.streamResults]; [RollaSyncResult.error] is the first failure.
     * [RollaSyncResult.hasNewData] is always true. [RollaSyncResult.syncedData] is present
     * unless this sync overlapped another one (see the property), while
     * [RollaSyncResult.streamResults] is always complete.
     */
    PARTIAL("partial"),

    /** Nothing was synced and that's expected — see [RollaSyncResult.skipReason]. Not an error. */
    SKIPPED("skipped"),

    /**
     * The sync started but failed — see [RollaSyncResult.error]. Also the outcome when streams
     * failed and no new data reached the server; [RollaSyncResult.streamResults] then lists every
     * stream the sync attempted.
     */
    FAILURE("failure"),

    /** The SDK returned an outcome this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncOutcome =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/** Which data source a headless sync ran against. */
enum class RollaSyncSource(val rawValue: String) {
    /** The Rolla band (BLE). */
    BAND("band"),

    /** Apple HealthKit (not applicable on Android, present for parity). */
    APPLE_HEALTH("appleHealth"),

    /** Android Health Connect. */
    HEALTH_CONNECT("healthConnect"),

    /** Garmin (syncs server-side via OAuth). */
    GARMIN("garmin"),

    /** Oura (syncs server-side via OAuth). */
    OURA("oura"),

    /** The active source could not be determined. */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncSource =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Why a sync did nothing (only set when [RollaSyncResult.outcome] is
 * [RollaSyncOutcome.SKIPPED]). Carried by the headless sync result and by
 * [RollaListener.onUiSyncCompleted] (a paired band that can't be reached maps
 * to [BAND_NOT_CONNECTED] on both).
 */
enum class RollaSyncSkipReason(val rawValue: String) {
    /** The user's primary source is the band, but no band is paired for this account. */
    NO_BAND_PAIRED("noBandPaired"),

    /**
     * A band is paired, but it could not be reached right now — powered off,
     * out of range, or the connect attempt ran out of time. The band-battery
     * API reports the same fact as [RollaBatteryStatus.BAND_NOT_CONNECTED]
     * (identical raw value). Distinct from [NO_BAND_PAIRED] (no band on the
     * account at all).
     */
    BAND_NOT_CONNECTED("bandNotConnected"),

    /** A sync was already in progress, so this call was a no-op. */
    ALREADY_IN_PROGRESS("alreadyInProgress"),

    /** The user's primary source syncs server-side (Garmin/Oura). */
    SERVER_SIDE_SOURCE("serverSideSource"),

    /**
     * The user's primary source is the band, but the Bluetooth runtime
     * permission (`BLUETOOTH_SCAN`/`BLUETOOTH_CONNECT`, or legacy Bluetooth +
     * location ≤ Android 11) has not been granted. A headless sync cannot
     * prompt, so the host should request it before retrying. The band-battery
     * API reports the same missing permission as
     * [RollaBatteryStatus.BLUETOOTH_PERMISSION_REQUIRED] (identical raw value),
     * so a host can map it once across both APIs.
     */
    BLUETOOTH_PERMISSION_REQUIRED("bluetoothPermissionRequired"),

    /**
     * The user's primary source is the band, but Bluetooth is powered off (the
     * permission is granted — the radio is off). The host should prompt the
     * user to enable Bluetooth before retrying. The band-battery API reports the
     * same condition as [RollaBatteryStatus.BLUETOOTH_UNAVAILABLE] (identical raw
     * value), so a host can map "turn Bluetooth on" once across both APIs.
     */
    BLUETOOTH_UNAVAILABLE("bluetoothUnavailable"),

    /**
     * The user's primary source is Apple Health, but HealthKit read
     * authorization has never been requested/granted. (Not applicable on
     * Android; present for parity.)
     */
    APPLE_HEALTH_PERMISSION_REQUIRED("appleHealthPermissionRequired"),

    /**
     * The user's primary source is Health Connect, but read authorization has
     * not been granted. The host should request it before retrying.
     */
    HEALTH_CONNECT_PERMISSION_REQUIRED("healthConnectPermissionRequired"),

    /** The SDK is not initialized. */
    NOT_INITIALIZED("notInitialized"),

    /** The device is offline. */
    OFFLINE("offline"),

    /** The SDK returned a reason this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncSkipReason =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

// region Per-stream results

/**
 * A health-data stream a sync uploads. Raw values match the [RollaSyncedHealthData] property
 * names, so a stream's summary is `syncedData.<name>`. A band sync attempts heart rate, HRV,
 * steps and sleep; Health Connect attempts all seven. Later versions may add values, so keep an
 * `else` branch when switching over it.
 */
enum class RollaSyncStream(val rawValue: String) {
    /** Heart rate ([RollaSyncedHealthData.heartRate]). */
    HEART_RATE("heartRate"),

    /** Heart-rate variability ([RollaSyncedHealthData.hrv]). */
    HRV("hrv"),

    /** Steps and active calories ([RollaSyncedHealthData.steps]). */
    STEPS("steps"),

    /** Sleep stages ([RollaSyncedHealthData.sleep]). */
    SLEEP("sleep"),

    /** Weight ([RollaSyncedHealthData.weight]). Health Connect only. */
    WEIGHT("weight"),

    /** Blood pressure ([RollaSyncedHealthData.bloodPressure]). Health Connect only. */
    BLOOD_PRESSURE("bloodPressure"),

    /** Workouts ([RollaSyncedHealthData.workouts]). Health Connect only. */
    WORKOUTS("workouts"),

    /** The SDK returned a stream this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncStream =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * What happened to one stream during a sync. Later versions may add values, so keep an `else`
 * branch when switching over it.
 */
enum class RollaSyncStreamStatus(val rawValue: String) {
    /** New data for this stream reached the server; its summary is in [RollaSyncResult.syncedData]. */
    UPLOADED("uploaded"),

    /** The stream was read and held nothing new. */
    NO_NEW_DATA("noNewData"),

    /**
     * Reading the stream from its source, or uploading it, failed — see
     * [RollaSyncStreamResult.error]. What did not upload is retried on the next sync; a stream
     * that fails for the same reason every time stays failed until the cause is fixed. Data the
     * server accepted before the failure (Health Connect steps upload day by day) still appears
     * in [RollaSyncResult.syncedData].
     */
    FAILED("failed"),

    /**
     * The stream needs a permission the app has not granted. The SDK cannot prompt during a
     * sync, so the host requests it and the stream syncs from then on;
     * [RollaSyncStreamResult.error] says which permission. Does not change the sync's outcome
     * on its own.
     */
    PERMISSION_REQUIRED("permissionRequired"),

    /** The SDK returned a status this version does not recognize (forward-compat). */
    UNKNOWN("unknown");

    companion object {
        fun fromRawValue(raw: String?): RollaSyncStreamStatus =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/** One stream's entry in [RollaSyncResult.streamResults]. */
data class RollaSyncStreamResult(
    /** The stream this entry reports on. */
    val stream: RollaSyncStream,
    /** What happened to [stream]. */
    val status: RollaSyncStreamStatus,
    /**
     * Why the stream failed, or which permission it needs ([RollaSyncStreamStatus.FAILED] and
     * [RollaSyncStreamStatus.PERMISSION_REQUIRED] only). Diagnostic text — not user-facing, not
     * stable, do not parse.
     */
    val error: String? = null
) {
    companion object {
        fun from(map: Map<*, *>?): RollaSyncStreamResult? {
            if (map == null) return null
            return RollaSyncStreamResult(
                stream = RollaSyncStream.fromRawValue(map["stream"] as? String),
                status = RollaSyncStreamStatus.fromRawValue(map["status"] as? String),
                error = map["error"] as? String
            )
        }
    }
}

// endregion

// region Synced health data

/**
 * A per-stream summary: how many samples synced and the time window they span.
 *
 * A summary is only ever produced for a stream that had data, so in practice
 * [count] is at least 1 and [from]/[to] (epoch-millisecond UTC timestamps) are
 * set; they are nullable only to tolerate a malformed wire payload. [total] is
 * set for the steps stream; [blocks]/[minutes] for the sleep stream.
 */
data class RollaSyncedStreamSummary(
    val count: Int,
    val from: Long? = null,
    val to: Long? = null,
    val total: Int? = null,
    val blocks: Int? = null,
    val minutes: Int? = null
) {
    companion object {
        fun from(map: Map<*, *>?): RollaSyncedStreamSummary? {
            if (map == null) return null
            return RollaSyncedStreamSummary(
                count = (map["count"] as? Number)?.toInt() ?: 0,
                from = (map["from"] as? Number)?.toLong(),
                to = (map["to"] as? Number)?.toLong(),
                total = (map["total"] as? Number)?.toInt(),
                blocks = (map["blocks"] as? Number)?.toInt(),
                minutes = (map["minutes"] as? Number)?.toInt()
            )
        }
    }
}

/** A single heart-rate reading. [timestamp] is epoch ms (UTC). */
data class RollaSyncedHeartRateSample(val timestamp: Long, val hr: Int)

/** A single HRV reading. [timestamp] is epoch ms (UTC). */
data class RollaSyncedHrvSample(val timestamp: Long, val hrv: Int)

/** A single steps bucket. [timestamp] is epoch ms (UTC). */
data class RollaSyncedStepsSample(val timestamp: Long, val stepsDelta: Double, val caloriesDelta: Double)

/**
 * A single sleep-stage block. [startTime]/[endTime] are epoch ms (UTC);
 * [stage] is one of `awake` | `light` | `deep` | `rem`.
 */
data class RollaSyncedSleepSample(val startTime: Long, val endTime: Long, val stage: String)

/** A single weight reading (kg). [timestamp] is epoch ms (UTC). */
data class RollaSyncedWeightSample(val timestamp: Long, val weight: Double)

/** A single blood-pressure reading. [timestamp] is epoch ms (UTC). */
data class RollaSyncedBloodPressureSample(val timestamp: Long, val systolic: Int, val diastolic: Int)

/**
 * The raw sample arrays, present only when the host requested
 * `includeSamples = true`. Each list is empty when its stream had no data.
 */
data class RollaSyncedSamples(
    val heartRate: List<RollaSyncedHeartRateSample> = emptyList(),
    val hrv: List<RollaSyncedHrvSample> = emptyList(),
    val steps: List<RollaSyncedStepsSample> = emptyList(),
    val sleep: List<RollaSyncedSleepSample> = emptyList(),
    val weight: List<RollaSyncedWeightSample> = emptyList(),
    val bloodPressure: List<RollaSyncedBloodPressureSample> = emptyList()
) {
    companion object {
        @Suppress("UNCHECKED_CAST")
        fun from(map: Map<*, *>?): RollaSyncedSamples? {
            if (map == null) return null
            fun list(key: String): List<Map<*, *>> =
                (map[key] as? List<*>)?.filterIsInstance<Map<*, *>>() ?: emptyList()
            return RollaSyncedSamples(
                heartRate = list("heartRate").map {
                    RollaSyncedHeartRateSample(
                        timestamp = (it["timestamp"] as? Number)?.toLong() ?: 0L,
                        hr = (it["hr"] as? Number)?.toInt() ?: 0
                    )
                },
                hrv = list("hrv").map {
                    RollaSyncedHrvSample(
                        timestamp = (it["timestamp"] as? Number)?.toLong() ?: 0L,
                        hrv = (it["hrv"] as? Number)?.toInt() ?: 0
                    )
                },
                steps = list("steps").map {
                    RollaSyncedStepsSample(
                        timestamp = (it["timestamp"] as? Number)?.toLong() ?: 0L,
                        stepsDelta = (it["stepsDelta"] as? Number)?.toDouble() ?: 0.0,
                        caloriesDelta = (it["caloriesDelta"] as? Number)?.toDouble() ?: 0.0
                    )
                },
                sleep = list("sleep").map {
                    RollaSyncedSleepSample(
                        startTime = (it["startTime"] as? Number)?.toLong() ?: 0L,
                        endTime = (it["endTime"] as? Number)?.toLong() ?: 0L,
                        stage = it["stage"] as? String ?: ""
                    )
                },
                weight = list("weight").map {
                    RollaSyncedWeightSample(
                        timestamp = (it["timestamp"] as? Number)?.toLong() ?: 0L,
                        weight = (it["weight"] as? Number)?.toDouble() ?: 0.0
                    )
                },
                bloodPressure = list("bloodPressure").map {
                    RollaSyncedBloodPressureSample(
                        timestamp = (it["timestamp"] as? Number)?.toLong() ?: 0L,
                        systolic = (it["systolic"] as? Number)?.toInt() ?: 0,
                        diastolic = (it["diastolic"] as? Number)?.toInt() ?: 0
                    )
                }
            )
        }
    }
}

/**
 * The health data a single [Rolla.syncHealthData] call uploaded.
 *
 * A per-stream summary (counts, time windows, step total, sleep minutes,
 * battery, synced dates) is always present; the raw [samples] arrays are
 * present only when the host passed `includeSamples = true`. Streams the source
 * can't produce are null (e.g. [weight]/[bloodPressure]/[workouts] on a band
 * sync). Mirrors `RollaSyncedHealthData` in the Dart SDK.
 */
data class RollaSyncedHealthData(
    val source: RollaSyncSource,
    /** Device-local calendar dates (yyyy-mm-dd) touched by this sync. */
    val syncedDates: List<String> = emptyList(),
    /** Band battery level (0–100) at sync time, or null. */
    val batteryLevel: Int? = null,
    val heartRate: RollaSyncedStreamSummary? = null,
    val hrv: RollaSyncedStreamSummary? = null,
    val steps: RollaSyncedStreamSummary? = null,
    val sleep: RollaSyncedStreamSummary? = null,
    val weight: RollaSyncedStreamSummary? = null,
    val bloodPressure: RollaSyncedStreamSummary? = null,
    val workouts: RollaSyncedStreamSummary? = null,
    /** Raw samples, non-null only when `includeSamples = true` was requested. */
    val samples: RollaSyncedSamples? = null
) {
    companion object {
        /**
         * Build from the `syncedData` wire sub-map. Returns null when absent.
         */
        fun from(response: Any?): RollaSyncedHealthData? {
            val map = response as? Map<*, *> ?: return null
            @Suppress("UNCHECKED_CAST")
            val dates = (map["syncedDates"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
            return RollaSyncedHealthData(
                source = RollaSyncSource.fromRawValue(map["source"] as? String),
                syncedDates = dates,
                batteryLevel = (map["batteryLevel"] as? Number)?.toInt(),
                heartRate = RollaSyncedStreamSummary.from(map["heartRate"] as? Map<*, *>),
                hrv = RollaSyncedStreamSummary.from(map["hrv"] as? Map<*, *>),
                steps = RollaSyncedStreamSummary.from(map["steps"] as? Map<*, *>),
                sleep = RollaSyncedStreamSummary.from(map["sleep"] as? Map<*, *>),
                weight = RollaSyncedStreamSummary.from(map["weight"] as? Map<*, *>),
                bloodPressure = RollaSyncedStreamSummary.from(map["bloodPressure"] as? Map<*, *>),
                workouts = RollaSyncedStreamSummary.from(map["workouts"] as? Map<*, *>),
                samples = RollaSyncedSamples.from(map["samples"] as? Map<*, *>)
            )
        }
    }
}

// endregion

/**
 * Result of [Rolla.syncHealthData].
 *
 * [hasNewData] is meaningful only for [RollaSyncOutcome.SUCCESS] /
 * [RollaSyncOutcome.PARTIAL]; [skipReason] is set only for
 * [RollaSyncOutcome.SKIPPED]; [error] only for [RollaSyncOutcome.FAILURE] and
 * [RollaSyncOutcome.PARTIAL].
 */
data class RollaSyncResult(
    val outcome: RollaSyncOutcome,
    val hasNewData: Boolean,
    val source: RollaSyncSource,
    /**
     * The device-clock time this sync began running. Set on
     * [RollaSyncOutcome.SUCCESS], [RollaSyncOutcome.PARTIAL] and
     * [RollaSyncOutcome.FAILURE], with two null cases: [RollaSyncOutcome.SKIPPED]
     * results (nothing ran), and the results of overlapping syncs, where the SDK
     * reports no start time rather than a possibly wrong one. Subtract it from
     * [lastSyncAt] to get the sync's duration.
     */
    val startedAt: Date? = null,
    /**
     * When this sync completed on the device. Present on [RollaSyncOutcome.SUCCESS]
     * and [RollaSyncOutcome.PARTIAL] (null for [RollaSyncOutcome.SKIPPED] /
     * [RollaSyncOutcome.FAILURE]). A client-side completion time, consistent across
     * every source — suitable for a "Last synced at …" label; not a
     * backend-confirmed write time.
     */
    val lastSyncAt: Date? = null,
    val skipReason: RollaSyncSkipReason? = null,
    /**
     * The error message. Non-null only for [RollaSyncOutcome.FAILURE] and
     * [RollaSyncOutcome.PARTIAL]. When streams failed, this is the first failed
     * stream's error; each failed stream's own error is in [streamResults].
     */
    val error: String? = null,
    /**
     * The health data this sync carries — per-stream summaries always, raw
     * samples when `includeSamples = true` was requested. Non-null whenever the
     * sync has something to report, which includes a band success that only read
     * battery ([RollaSyncedHealthData.batteryLevel] set, [hasNewData] still
     * false). Null for [RollaSyncOutcome.SKIPPED] / [RollaSyncOutcome.FAILURE], and —
     * on a [RollaSyncOutcome.PARTIAL] too — when this sync overlapped another one (a
     * UI auto-sync starting during a headless sync, or two UI syncs): the shared
     * tally is reset under it, so nothing attributable is left to report, while
     * [streamResults] still says which streams uploaded.
     * A band sync where every stream failed is a [RollaSyncOutcome.FAILURE], so
     * a battery level read during it is not reported — use
     * [com.rolla.sdk.wrapper.Rolla.getBandBatteryLevel] for that.
     */
    val syncedData: RollaSyncedHealthData? = null,
    /**
     * One entry per stream this sync attempted, in upload order: heart rate, HRV, steps and
     * sleep, then weight, blood pressure and workouts for Health Connect. Empty when no stream
     * ran: [RollaSyncOutcome.SKIPPED] results, a failure before any stream started, and
     * Garmin/Oura content refreshes. When [syncedData] is present, every stream reported
     * [RollaSyncStreamStatus.UPLOADED] has its summary there.
     */
    val streamResults: List<RollaSyncStreamResult> = emptyList()
) {
    /** Whether the sync ran to completion (success or partial). */
    val didRun: Boolean
        get() = outcome == RollaSyncOutcome.SUCCESS || outcome == RollaSyncOutcome.PARTIAL

    companion object {
        private const val TAG = "RollaSync"

        /**
         * Build a result from the method-channel wire map
         * `{ "outcome": String, "hasNewData": Boolean, "source": String,
         *    "startedAt": String?, "lastSyncAt": String?, "skipReason": String?,
         *    "error": String?, "syncedData": Map?, "streamResults": List<Map>? }`.
         * Unknown enum strings map to their `UNKNOWN` case; a missing
         * `streamResults` is an empty list.
         */
        fun fromResponse(response: Any?): RollaSyncResult {
            val map = response as? Map<*, *>
                ?: return RollaSyncResult(
                    outcome = RollaSyncOutcome.UNKNOWN,
                    hasNewData = false,
                    source = RollaSyncSource.UNKNOWN
                )
            val outcome = RollaSyncOutcome.fromRawValue(map["outcome"] as? String)
            val hasNewData = map["hasNewData"] as? Boolean ?: false
            val source = RollaSyncSource.fromRawValue(map["source"] as? String)
            val skipReason = (map["skipReason"] as? String)?.let { RollaSyncSkipReason.fromRawValue(it) }
            val error = map["error"] as? String
            val startedAt = (map["startedAt"] as? String)?.let { parseIso8601(it) }
            val lastSyncAt = (map["lastSyncAt"] as? String)?.let { parseIso8601(it) }
            val syncedData = RollaSyncedHealthData.from(map["syncedData"])
            val streamResults = (map["streamResults"] as? List<*>)
                ?.filterIsInstance<Map<*, *>>()
                ?.mapNotNull { RollaSyncStreamResult.from(it) }
                ?: emptyList()
            return RollaSyncResult(
                outcome = outcome,
                hasNewData = hasNewData,
                source = source,
                startedAt = startedAt,
                lastSyncAt = lastSyncAt,
                skipReason = skipReason,
                error = error,
                syncedData = syncedData,
                streamResults = streamResults
            )
        }

        /**
         * Parse an ISO-8601 UTC timestamp; returns null on any parse failure.
         *
         * Uses java.time (available via core-library desugaring, already a
         * project prerequisite) so 0/3/6/9 fractional-second digits all parse to
         * the correct instant. A lenient SimpleDateFormat would silently misread
         * microsecond input (Dart's `toIso8601String()` emits 6 fractional
         * digits whenever the DateTime carries sub-millisecond precision), so it
         * is deliberately NOT used here.
         */
        private fun parseIso8601(raw: String): Date? {
            // Instant.parse handles the 'Z' (Zulu) form Dart emits; fall back to
            // OffsetDateTime for an explicit numeric offset (e.g. "+00:00").
            try {
                return Date.from(Instant.parse(raw))
            } catch (_: Exception) {
                // try offset form
            }
            try {
                return Date.from(OffsetDateTime.parse(raw).toInstant())
            } catch (_: Exception) {
                // unparseable
            }
            Log.w(TAG, "Could not parse ISO-8601 timestamp: $raw")
            return null
        }
    }
}
