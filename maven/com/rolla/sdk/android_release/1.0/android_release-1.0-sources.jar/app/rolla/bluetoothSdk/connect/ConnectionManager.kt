package app.rolla.bluetoothSdk.connect

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.content.Context
import android.os.Build
import app.rolla.bluetoothSdk.BleRegistry
import app.rolla.bluetoothSdk.connect.reconnect.ReconnectionManager
import app.rolla.bluetoothSdk.connect.timeout.ConnectTimeoutManager
import app.rolla.bluetoothSdk.connect.timeout.DisconnectTimeoutManager
import app.rolla.bluetoothSdk.connect.timeout.EarlyConnectTimeoutManager
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceConnectionState
import app.rolla.bluetoothSdk.device.DeviceEvent
import app.rolla.bluetoothSdk.device.DeviceManager
import app.rolla.bluetoothSdk.device.DeviceType
import app.rolla.bluetoothSdk.device.DeviceTypeState
import app.rolla.bluetoothSdk.di.BleScopeContext
import app.rolla.bluetoothSdk.result.MethodResult
import app.rolla.bluetoothSdk.result.error.DeviceNotFound
import app.rolla.bluetoothSdk.result.error.GattStatusFailed
import app.rolla.bluetoothSdk.utils.executeWithBluetoothConnect
import app.rolla.bluetoothSdk.utils.getFullUUID
import app.rolla.bluetoothSdk.utils.log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext

@Singleton
class ConnectionManager @Inject constructor(
    @param:ApplicationContext private val context: Context,
    @param:BleScopeContext private val coroutineContext: CoroutineContext,
    private val bluetoothAdapter: BluetoothAdapter?,
    private val deviceManager: DeviceManager,
    private val operationQueue: OperationQueue,
    private val subscriptionManager: SubscriptionManager,
    private val bleRegistry: BleRegistry,
    private val earlyConnectTimeoutManager: EarlyConnectTimeoutManager,
    private val connectTimeoutManager: ConnectTimeoutManager,
    private val disconnectTimeoutManager: DisconnectTimeoutManager,
    private val reconnectionManager: ReconnectionManager
) {
    companion object {
        private const val TAG = "ConnectionManager"
    }
    private val connectionScope = CoroutineScope(coroutineContext)

    init {
        connectionScope.launch {
            subscriptionManager.characteristicEvents.collect { event ->
                when (event) {
                    is CharacteristicEvent.AllSubscriptionsComplete -> onAllSubscriptionsComplete(event.deviceAddress)
                    is CharacteristicEvent.AllPostSubscriptionCommandsComplete -> onAllPostSubscriptionCommandsComplete(event.deviceAddress)
                    is CharacteristicEvent.AllUnsubscriptionsComplete -> onAllUnsubscriptionsComplete(event.deviceAddress)
                }
            }
        }
        connectionScope.launch {
            deviceManager.deviceEventFlow.collect { event ->
                when (event) {
                    is DeviceEvent.RssiReadRequested -> handleRssiReadRequest(event.device)
                    is DeviceEvent.DeviceUnresponsive -> {
                        val device = event.device
                        val address = device.getMacAddress()
                        log(TAG, "Device became unresponsive: $address, triggering reconnection")

                        reconnectionManager.handleDisconnection(device, 133, onReconnect = { reconnectDevice ->
                            connectionScope.launch {
                                performReconnection(reconnectDevice)
                            }
                        }, { failedDevice ->
                            handleDisconnectState(failedDevice.getMacAddress(), failedDevice.gatt, failedDevice)
                        })
                    }
                }
            }
        }
    }

    private val activeCallbacks = ConcurrentHashMap<String, BluetoothGattCallback>()

    fun handleDeviceConnection(device: BleDevice, requestedDeviceTypes: Set<DeviceType>): MethodResult {
        val address = device.getMacAddress()
        when {
            device.isConnected() -> {
                val result = deviceManager.updateRequestedTypesForConnected(address, device.getSubscribedTypes(), requestedDeviceTypes)
                if (result.successful) {
                    val allCharacteristics = bleRegistry.getAllowedCharacteristicsForDeviceTypes(device.gatt, device.requestedTypes)
                    connectionScope.launch {
                        subscriptionManager.subscribeToCharacteristics(device, allCharacteristics)
                    }
                    return MethodResult(true)
                } else return result
            }
            device.isConnecting() -> {
                return deviceManager.updateRequestedTypesWhileConnecting(address, device.scannedDeviceTypes.toSet(), requestedDeviceTypes)
            }
            else -> {
                log(TAG, "Starting new connection for device: $address")
                connectionScope.launch {
                    val bleDevice = device
                    deviceManager.addDevice(bleDevice, requestedDeviceTypes)
                    connectTimeoutManager.startTimeout(address, onTimeout = { deviceAddress ->
                        val device = deviceManager.getDevice(deviceAddress)
                        if (device?.isConnecting() == true) {
                            handleConnectionTimeout(deviceAddress, device)
                        }
                    })
                    earlyConnectTimeoutManager.startTimeout(address, onTimeout = { deviceAddress ->
                        val device = deviceManager.getDevice(deviceAddress)
                        if (device?.isConnecting() == true) {
                            handleConnectionTimeout(deviceAddress, device)
                        }
                    })
                    createAndPerformGattConnection(bleDevice, address)
                }
                return MethodResult(true)
            }
        }
    }

    fun handleDeviceDisconnection(address: String, requestedDeviceTypes: Set<DeviceType>) {
        // A single user action can reach this twice (the device stays CONNECTED for the
        // whole unsubscribe phase, so the caller-side guards let a duplicate through).
        // Re-entering while the same types are already being torn down queues a second
        // unsubscribe descriptor write per characteristic; the first pass then sees the
        // shared pending set drain, disconnects the GATT and clears the queue with those
        // duplicates still in flight. Let the running teardown finish instead. A request
        // for additional types still falls through.
        val typesBeingUnsubscribed = deviceManager.getDevice(address)?.requestedTypes ?: emptySet()
        if (disconnectTimeoutManager.hasTimeout(address) && typesBeingUnsubscribed.containsAll(requestedDeviceTypes)) {
            log(TAG, "Disconnection already in progress for: $address, ignoring duplicate request")
            return
        }

        // Disable auto-reconnect when user explicitly disconnects
        disableAutoReconnect(address)

        val device = deviceManager.updateDevice(address) { device ->
            device.withNewRequestedTypes(requestedDeviceTypes)
                .withUpdatedDeviceTypeStates(DeviceTypeState.UNSUBSCRIBING)
        }

        // Start disconnection timeout
        disconnectTimeoutManager.startTimeout(address, onTimeout = {
            val device = deviceManager.getDevice(address)
            if (device?.isDisconnecting() == true) {
                subscriptionManager.handleDisconnectionTimeout(address)
                log(TAG, "Disconnection timeout for: ${device.getMacAddress()}, forcing cleanup")
                handleDisconnectState(device.getMacAddress(), device.gatt, device)
            }
        })

        context.executeWithBluetoothConnect(
            operation = {
                connectionScope.launch {
                    subscriptionManager.unsubscribeFromCharacteristics(device!!)
                }
            },
            onPermissionDenied = { exception ->
                log(TAG, "Missing BLUETOOTH_CONNECT permission for disconnectFromDevice")
            }
        )
    }
    @SuppressLint("MissingPermission")
    fun createAndPerformGattConnection(device: BleDevice, address: String): BluetoothGattCallback? {
        if (bluetoothAdapter?.isEnabled != true) {
            log(TAG, "Bluetooth is disabled, cannot create GATT connection for $address")
            handleDisconnectState(address, device.gatt, device)
            return null
        }
        // Clear any existing callback for this device
        clearCallback(address)

        val callback = object : BluetoothGattCallback(), DeactivatableCallback {
            private var isActive = true
            val deviceAddress = address

            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                if (!isActive) return
                super.onConnectionStateChange(gatt, status, newState)
                log(TAG, "Device connection state changed: $deviceAddress, newState: $newState")
                onConnectionStateChanges(deviceAddress, gatt, status, newState)
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
                if (!isActive) return
                super.onServicesDiscovered(gatt, status)
                onServicesDiscovered(deviceAddress, gatt, status)
            }

            override fun onCharacteristicChanged(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                value: ByteArray
            ) {
                if (!isActive) return
                super.onCharacteristicChanged(gatt, characteristic, value)
                onCharacteristicChanged(deviceAddress, gatt, characteristic, value)
            }

            @Suppress("DEPRECATION")
            override fun onCharacteristicChanged(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic
            ) {
                if (!isActive) return
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    super.onCharacteristicChanged(gatt, characteristic)
                    val value = characteristic.value ?: ByteArray(0)
                    onCharacteristicChanged(deviceAddress, gatt, characteristic, value)
                }
            }

            @Suppress("DEPRECATION")
            override fun onCharacteristicRead(
                gatt: BluetoothGatt?,
                characteristic: BluetoothGattCharacteristic?,
                status: Int
            ) {
                if (!isActive) return
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    super.onCharacteristicRead(gatt, characteristic, status)
                    if (gatt != null && characteristic != null) {
                        val value = characteristic.value ?: ByteArray(0)
                        onCharacteristicRead(deviceAddress, gatt, characteristic, value, status)
                    } else {
                        log(TAG, "onCharacteristicRead called with null gatt or characteristic")
                    }
                }
            }

            override fun onCharacteristicRead(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                value: ByteArray,
                status: Int
            ) {
                if (!isActive) return
                super.onCharacteristicRead(gatt, characteristic, value, status)
                onCharacteristicRead(deviceAddress, gatt, characteristic, value, status)
            }

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {
                if (!isActive) return
                super.onCharacteristicWrite(gatt, characteristic, status)
                onCharacteristicWrite(deviceAddress, gatt, characteristic, status)
            }

            override fun onDescriptorWrite(
                gatt: BluetoothGatt,
                descriptor: BluetoothGattDescriptor,
                status: Int
            ) {
                if (!isActive) return
                super.onDescriptorWrite(gatt, descriptor, status)
                onDescriptorWrite(deviceAddress, gatt, descriptor, status)
            }

            override fun onServiceChanged(gatt: BluetoothGatt) {
                if (!isActive) return
                super.onServiceChanged(gatt)
                log(TAG, "Service changed for device: ${gatt.device.address}")
                // Re-discover services as GATT database is out of sync
                // TODO startServiceDiscovery(gatt)
            }

            override fun onReadRemoteRssi(gatt: BluetoothGatt?, rssi: Int, status: Int) {
                if (!isActive) return
                super.onReadRemoteRssi(gatt, rssi, status)
                log(TAG, "RSSI read: $deviceAddress - $rssi")
                deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
                operationQueue.operationComplete(deviceAddress, status == BluetoothGatt.GATT_SUCCESS, status)
            }

            override fun onMtuChanged(gatt: BluetoothGatt?, mtu: Int, status: Int) {
                if (!isActive) return
                super.onMtuChanged(gatt, mtu, status)
                log(TAG, "MTU changed for device: $deviceAddress")
                deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
            }

            override fun onPhyUpdate(gatt: BluetoothGatt?, txPhy: Int, rxPhy: Int, status: Int) {
                if (!isActive) return
                super.onPhyUpdate(gatt, txPhy, rxPhy, status)
                log(TAG, "PHY update for device: $deviceAddress")
                deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
            }

            override fun deactivate() {
                isActive = false
            }
        }

        activeCallbacks[address] = callback

        context.executeWithBluetoothConnect(
            operation = {
                log(TAG, "Device type: ${device.getBluetoothDeviceType(context)}")
                val gatt = device.btDevice.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
                log(TAG, "connectGatt returned: ${gatt != null}")
                if (gatt == null) {
                    log(TAG, "Failed to create GATT connection for $address")
                    handleDisconnectState(address, device.gatt, device)
                } else {
                    log(TAG, "GATT connection created successfully for $address")
                }
            },
            onPermissionDenied = { exception ->
                log(TAG, "Missing BLUETOOTH_CONNECT permission for GATT connection")
                handleDisconnectState(address, device.gatt, device)
            }
        )
        return callback
    }

    private fun onCharacteristicChanged(deviceAddress: String, gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
        log(TAG, "Characteristic changed: $deviceAddress - ${characteristic.uuid.getFullUUID()}} - ${value.toTypedArray()}")
        val device = deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
        if (device != null) {
            bleRegistry.notifyCharacteristic(characteristic.uuid.getFullUUID(), value, device)
        }
    }

    private fun onCharacteristicRead(deviceAddress: String, gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
        log(TAG, "Characteristic read: $deviceAddress - ${characteristic.uuid.getFullUUID()} - ${value.toTypedArray()} - status: $status")
        operationQueue.operationComplete(deviceAddress, status == BluetoothGatt.GATT_SUCCESS, status)
        val device = deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
        if (device != null) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                bleRegistry.readCharacteristic(characteristic.uuid.getFullUUID(), value, device)
            } else {
                bleRegistry.onCharacteristicError(
                    characteristic.uuid.getFullUUID(),
                    deviceAddress,
                    value,
                    GattStatusFailed(Throwable("Characteristic read failed with status: $status"))
                )
            }
        } else {
            bleRegistry.onCharacteristicError(
                characteristic.uuid.getFullUUID(),
                deviceAddress,
                value,
                DeviceNotFound()
            )
        }
    }

    private fun onCharacteristicWrite(deviceAddress: String, gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
        log(TAG, "Characteristic write: $deviceAddress - ${characteristic.uuid.getFullUUID()}")
        operationQueue.operationComplete(deviceAddress, status == BluetoothGatt.GATT_SUCCESS, status)

        @Suppress("DEPRECATION")
        val characteristicValue = characteristic.value ?: byteArrayOf()

        val device = deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
        if (device != null) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                bleRegistry.writeCharacteristic(characteristic.uuid.getFullUUID(), characteristicValue, device)
            } else {
                bleRegistry.onCharacteristicError(
                    characteristic.uuid.getFullUUID(),
                    deviceAddress,
                    characteristicValue,
                    GattStatusFailed(Throwable("Characteristic write failed with status: $status"))
                )
            }
        } else {
            bleRegistry.onCharacteristicError(
                characteristic.uuid.getFullUUID(),
                deviceAddress,
                characteristicValue,
                DeviceNotFound()
            )
        }
    }

    private fun onDescriptorWrite(deviceAddress: String, gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
        log(
            TAG,
            "Descriptor write for address: $deviceAddress - Characteristic: ${descriptor.characteristic.uuid.getFullUUID()}, Descriptor: ${descriptor.uuid}, Status: $status"
        )
        operationQueue.operationComplete(deviceAddress, status == BluetoothGatt.GATT_SUCCESS, status)
        val device = deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
        if (device != null) {
            subscriptionManager.completeDescriptorWrite(deviceAddress, descriptor.characteristic.uuid.getFullUUID())
        }
    }

    @SuppressLint("MissingPermission")
    private fun onConnectionStateChanges(deviceAddress: String, gatt: BluetoothGatt?, status: Int, newState: Int) {
        if (gatt != null) {
            val device = deviceManager.updateDeviceWithGatt(deviceAddress, gatt)
            when (newState) {
                BluetoothGatt.STATE_CONNECTED -> {
                    log(TAG, "Device connected: $deviceAddress")
                    if (device == null || !device.isConnecting() || status != BluetoothGatt.GATT_SUCCESS) {
                        log(TAG, "Connection validation failed - device: ${device != null}, isConnecting: ${device?.isConnecting()}, status: $status")
                        handleDisconnectState(deviceAddress, gatt, device)
                    } else {
                        // Cancel any active reconnection attempts
                        reconnectionManager.onConnectionSuccess(deviceAddress)

                        // Mark device as having been connected successfully
                        deviceManager.updateDevice(deviceAddress) { dev ->
                            dev.withConnectionHistory(true)
                        }

                        earlyConnectTimeoutManager.cancelTimeout(deviceAddress)
                        log(TAG, "Starting service discovery for device: $deviceAddress")
                        context.executeWithBluetoothConnect(
                            operation = {
                                if (!gatt.discoverServices()) {
                                    log(TAG, "Failed to start service discovery for device: $deviceAddress")
                                    handleDisconnectState(deviceAddress, gatt, device)
                                    return
                                }
                            },
                            onPermissionDenied = {
                                handleDisconnectState(deviceAddress, gatt, device)
                            }
                        )
                    }
                }
                BluetoothGatt.STATE_DISCONNECTED -> {
                    log(TAG, "Device disconnected: $deviceAddress, status: $status")

                    if (device != null) {
                        deviceManager.updateDevice(deviceAddress) { dev ->
                            dev.withConnectionState(DeviceConnectionState.DISCONNECTED)
                        }

                        reconnectionManager.handleDisconnection(device, status, onReconnect = { reconnectDevice ->
                            connectionScope.launch {
                                performReconnection(reconnectDevice)
                            }
                        }, { failedDevice ->
                            handleDisconnectState(failedDevice.getMacAddress(), failedDevice.gatt, failedDevice)
                        })
                    } else {
                        handleDisconnectState(deviceAddress, gatt, device)
                    }
                }
            }
        }
    }

    fun onServicesDiscovered(deviceAddress: String, gatt: BluetoothGatt?, status: Int) {
        log(TAG, "Services discovered: $deviceAddress - $status")
        val device = deviceManager.updateServiceDiscovery(deviceAddress, true, gatt)
        if (device?.isConnecting() != true || status != BluetoothGatt.GATT_SUCCESS || gatt == null) {
            log(TAG, "Failed to discover services for device: $deviceAddress")
            handleDisconnectState(deviceAddress, gatt, device)
            return
        }

        log(TAG, "Found services: ${device.gatt?.services?.map { it.uuid }} for device: ${device.getMacAddress()}")
        context.executeWithBluetoothConnect(
            operation = {
                connectionScope.launch {
                    val allCharacteristics = bleRegistry.getAllowedCharacteristicsForDeviceTypes(device.gatt, device.finalRequestedTypes)
                    subscriptionManager.subscribeToCharacteristics(device, allCharacteristics)
                }
            },
            onPermissionDenied = { exception ->
                log(TAG, "Missing BLUETOOTH_CONNECT permission for characteristic subscription: ${exception.message}")
                handleDisconnectState(deviceAddress, gatt, device)
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun handleDisconnectState(deviceAddress: String, gatt: BluetoothGatt?, device: BleDevice?) {
        if (device != null) {
            subscriptionManager.disableNotification(device)
        }

        cleanupConnection(deviceAddress, gatt)
        deviceManager.removeDevice(deviceAddress)
    }

    @SuppressLint("MissingPermission")
    fun cleanupConnection(deviceAddress: String, gatt: BluetoothGatt?) {
        subscriptionManager.cleanForDevice(deviceAddress)
        operationQueue.clearQueue(deviceAddress)
        connectTimeoutManager.cancelTimeout(deviceAddress)
        earlyConnectTimeoutManager.cancelTimeout(deviceAddress)
        disconnectTimeoutManager.cancelTimeout(deviceAddress)
        clearCallback(deviceAddress)
        context.executeWithBluetoothConnect(
            operation = {
                gatt?.close()
            },
            onPermissionDenied = {
                log(TAG, "Missing BLUETOOTH_CONNECT permission for closing GATT")
            }
        )
    }

    private fun handleConnectionTimeout(deviceAddress: String, device: BleDevice) {
        subscriptionManager.handleConnectionTimeout(device.getMacAddress())
        handleDisconnectState(deviceAddress, device.gatt, device)
    }

    private fun onAllSubscriptionsComplete(deviceAddress: String) {
        deviceManager.updateDevice(deviceAddress) { device ->
            device.withUpdatedDeviceTypeStates(DeviceTypeState.SUBSCRIBED)
        }
    }

    private fun onAllPostSubscriptionCommandsComplete(deviceAddress: String) {
        deviceManager.updateDevice(deviceAddress) { device ->
            device.withConnectionState(DeviceConnectionState.CONNECTED)
                .withNewRequestedTypes(emptySet())
        }
        connectTimeoutManager.cancelTimeout(deviceAddress)
    }

    private fun onAllUnsubscriptionsComplete(deviceAddress: String) {
        val device = deviceManager.updateDevice(deviceAddress) { device ->
            device.withUpdatedDeviceTypeStates(DeviceTypeState.UNSUBSCRIBED)
                .withNewRequestedTypes(emptySet())
        }
        // If no types left, complete disconnection
        if (device?.getSubscribedTypes()?.isEmpty() == true) {
            // Update state to disconnecting
            performCompleteDisconnection(deviceAddress)
        }
        disconnectTimeoutManager.cancelTimeout(deviceAddress)
    }

    @SuppressLint("MissingPermission")
    fun performCompleteDisconnection(address: String) {
        // Update state to disconnecting
        val device = deviceManager.updateDevice(address) { device ->
            device.withConnectionState(DeviceConnectionState.DISCONNECTING)
        }
        return context.executeWithBluetoothConnect(
            operation = {
                device?.gatt?.disconnect()
            },
            onPermissionDenied = { exception ->
                handleDisconnectState(address, device?.gatt, device)
            }
        )
    }

    fun handleRssiReadRequest(device: BleDevice) {
        val deviceAddress = device.getMacAddress()
        device.gatt?.let { gatt ->
            log(TAG, "Triggering RSSI read for device: $deviceAddress")

            val rssiOperation = BleOperation.ReadRssi(
                deviceAddress = deviceAddress,
                gatt = gatt,
                onComplete = { success, rssi ->
                    if (success && rssi != null) {
                        log(TAG, "RSSI read successful for $deviceAddress: $rssi")
                        // Update device timestamp through scanner
                        deviceManager.updateDevice(deviceAddress) { device ->
                            device.withRssi(rssi).copy(timestamp = System.currentTimeMillis())
                        }
                    } else {
                        log(TAG, "RSSI read failed for $deviceAddress")
                    }
                }
            )
            operationQueue.queueOperation(rssiOperation)
        }
    }

    fun clearCallback(deviceAddress: String) {
        activeCallbacks[deviceAddress]?.let { callback ->
            (callback as? DeactivatableCallback)?.deactivate()
            activeCallbacks.remove(deviceAddress)
            log(TAG, "Cleared callback for device: $deviceAddress")
        }
    }

    fun clearAllCallbacks() {
        activeCallbacks.values.forEach { callback ->
            (callback as? DeactivatableCallback)?.deactivate()
        }
        activeCallbacks.clear()

        // Cancel all reconnection strategies
        reconnectionManager.cleanup()

        log(TAG, "Cleared all callbacks and reconnection strategies")
        connectTimeoutManager.clear()
        earlyConnectTimeoutManager.clear()
        disconnectTimeoutManager.clear()
        subscriptionManager.cleanup()
        operationQueue.cleanup()
    }

    private interface DeactivatableCallback {
        fun deactivate()
    }

    fun disableAutoReconnect(deviceAddress: String) {
        deviceManager.updateDevice(deviceAddress) { device ->
            device.withAutoConnect(false)
        }
        reconnectionManager.disableAutoReconnect(deviceAddress)
        log(TAG, "Disabled auto-reconnect for $deviceAddress")
    }
    fun enableAutoReconnect(deviceAddress: String) {
        log(TAG, "enableAutoReconnect called for $deviceAddress but auto-reconnect is disabled - Flutter handles reconnection")
    }
    private suspend fun performReconnection(device: BleDevice) {
        try {
            cleanupConnection(device.getMacAddress(), device.gatt)
            delay(500)

            log(TAG, "Updating device state to CONNECTING to notify Flutter about reconnection: ${device.getMacAddress()}")
            deviceManager.updateDevice(device.getMacAddress()) { dev ->
                dev.withConnectionState(DeviceConnectionState.CONNECTING)
                    .withRequestedTypes(dev.finalRequestedTypes)
            }

            createAndPerformGattConnection(device, device.getMacAddress())

        } catch (e: Exception) {
            log(TAG, "Reconnection attempt failed for ${device.getMacAddress()}: ${e.message}")
            handleDisconnectState(device.getMacAddress(), device.gatt, device)
        }
    }
}

