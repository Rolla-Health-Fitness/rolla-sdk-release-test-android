package com.rolla.sdk.wrapper.engine

import android.content.Context
import android.util.Log
import com.rolla.sdk.wrapper.Rolla
import com.rolla.sdk.wrapper.config.RollaConfiguration
import com.rolla.sdk.wrapper.features.activity.RollaCompletedActivity
import com.rolla.sdk.wrapper.features.activity.RollaRemovedActivity
import com.rolla.sdk.wrapper.features.activity.RollaStartedActivity
import com.rolla.sdk.wrapper.features.band.RollaBandInfo
import com.rolla.sdk.wrapper.features.band.RollaBatteryResult
import com.rolla.sdk.wrapper.features.band.RollaPairedBandResult
import com.rolla.sdk.wrapper.features.goals.RollaGoalsChanged
import com.rolla.sdk.wrapper.features.profile.RollaProfileUpdated
import com.rolla.sdk.wrapper.features.session.RollaError
import com.rolla.sdk.wrapper.features.sync.RollaPrimarySourceChanged
import com.rolla.sdk.wrapper.features.sync.RollaSyncResult
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.embedding.engine.plugins.util.GeneratedPluginRegister
import io.flutter.plugin.common.MethodChannel

internal class RollaEngineManager private constructor() {

    companion object {
        private const val TAG = "RollaEngineManager"
        internal const val ENGINE_ID = "rolla_wrapper_engine"
        private const val CHANNEL_NAME = "rolla_sdk/init"

        @Volatile
        private var instance: RollaEngineManager? = null

        fun getInstance(): RollaEngineManager {
            return instance ?: synchronized(this) {
                instance ?: RollaEngineManager().also { instance = it }
            }
        }
    }

    /**
     * The freshest token pair this engine is known to hold, seeded by
     * successful [updateToken] pushes and by `onTokenRefreshed` deliveries
     * from the SDK's own internal rotation. Refresh tokens are single-use, so
     * once the SDK rotates, the pair frozen inside the host's
     * [RollaConfiguration] is consumed — re-sending it on every [configure]
     * would destroy the live refresh token and 401 the session. When present,
     * [configure] sends this register instead of the frozen configuration
     * values.
     */
    private data class LatestKnownTokens(
        val token: String,
        val refreshToken: String?,
        val expiresIn: Int?,
        val seededAtMs: Long
    )

    private var engine: FlutterEngine? = null
    private var methodChannel: MethodChannel? = null
    private var latestKnownTokens: LatestKnownTokens? = null

    // The configuration token the current credential lineage started from.
    // A configure() carrying a DIFFERENT token means the host obtained fresh
    // credentials (new login, new configuration) — the register descends from
    // the previous lineage and must not shadow them.
    private var sessionAnchorToken: String? = null

    // Count of in-flight configure() round-trips that CHANGED the anchor.
    // While one is running, the Dart side may still be tearing down the
    // previous session, and a late onTokenRefreshed from that session must
    // not seed the register under the new anchor — it would be replayed to
    // the new user on the next configure. Seeds are discarded while > 0.
    private var anchorChangingConfigures = 0

    @Volatile
    var isPresenting: Boolean = false
        private set

    @Volatile
    var isReady: Boolean = false
        private set

    var onClose: ((String?) -> Unit)? = null
    var onError: ((String, String) -> Unit)? = null
    var onTokenRefreshed: ((String, String?, Int?) -> Unit)? = null
    var onTokenExpired: (() -> Unit)? = null

    // Host-event closures. Unlike the presentation callbacks above (wired on
    // show, cleared on dismiss), these are wired for the engine's lifetime by
    // Rolla.wireHostEventCallbacks() and cleared only in destroy().
    var onActivityCompleted: ((RollaCompletedActivity) -> Unit)? = null
    var onActivityStarted: ((RollaStartedActivity) -> Unit)? = null
    var onActivityRemoved: ((RollaRemovedActivity) -> Unit)? = null
    var onUiSyncCompleted: ((RollaSyncResult) -> Unit)? = null
    var onBandPaired: ((RollaBandInfo) -> Unit)? = null
    var onBandUnpaired: ((RollaBandInfo) -> Unit)? = null
    var onBandConnected: ((RollaBandInfo) -> Unit)? = null
    var onBandDisconnected: ((RollaBandInfo) -> Unit)? = null
    var onPrimarySourceChanged: ((RollaPrimarySourceChanged) -> Unit)? = null
    var onGoalsChanged: ((RollaGoalsChanged) -> Unit)? = null
    var onProfileUpdated: ((RollaProfileUpdated) -> Unit)? = null

    private val initLock = Any()

    fun initialize(context: Context) {
        if (engine != null) {
            Log.d(TAG, "Engine already initialized")
            return
        }

        synchronized(initLock) {
            if (engine != null) {
                Log.d(TAG, "Engine already initialized (after lock)")
                return
            }

            Log.d(TAG, "Initializing Flutter engine...")

            val appContext = context.applicationContext
            val flutterEngine = FlutterEngine(appContext)

            GeneratedPluginRegister.registerGeneratedPlugins(flutterEngine)
            
            try {
                val sdk = com.rolla.sdk.RollaAndroidSdk.init(appContext)
                sdk.createBridge(appContext, flutterEngine.dartExecutor.binaryMessenger)
                Log.d(TAG, "Rolla SDK bridge created - Pigeon handlers registered")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create Rolla SDK bridge", e)
            }

            flutterEngine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint.createDefault()
            )

            FlutterEngineCache.getInstance().put(ENGINE_ID, flutterEngine)

            setupMethodChannel(flutterEngine)

            engine = flutterEngine
            isReady = true

            Log.d(TAG, "Flutter engine initialized and cached with ID: $ENGINE_ID")
        }
    }

    private fun setupMethodChannel(engine: FlutterEngine) {
        val channel = MethodChannel(
            engine.dartExecutor.binaryMessenger,
            CHANNEL_NAME
        )

        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "close" -> {
                    val args = call.arguments as? Map<*, *>
                    val reason = args?.get("reason") as? String
                    onClose?.invoke(reason)
                    result.success(null)
                }
                "error" -> {
                    val args = call.arguments as? Map<*, *>
                    val code = args?.get("code") as? String ?: "UNKNOWN"
                    val message = args?.get("message") as? String ?: "Unknown error"
                    onError?.invoke(code, message)
                    result.success(null)
                }
                "onTokenRefreshed" -> {
                    val args = call.arguments as? Map<*, *>
                    val token = args?.get("token") as? String ?: ""
                    val refreshToken = args?.get("refreshToken") as? String
                    val expiresIn = (args?.get("expiresIn") as? Number)?.toInt()
                    // Never seed while an anchor-changing configure is in
                    // flight: this event may belong to the session being
                    // replaced (its refresh raced the switch) and must not be
                    // replayed to the new user.
                    if (token.isNotEmpty() && anchorChangingConfigures == 0) {
                        latestKnownTokens = LatestKnownTokens(
                            token = token,
                            refreshToken = refreshToken,
                            expiresIn = expiresIn,
                            seededAtMs = System.currentTimeMillis()
                        )
                    }
                    onTokenRefreshed?.invoke(token, refreshToken, expiresIn)
                    result.success(null)
                }
                "onTokenExpired" -> {
                    onTokenExpired?.invoke()
                    result.success(null)
                }
                "onActivityCompleted" -> {
                    onActivityCompleted?.invoke(RollaCompletedActivity.fromResponse(call.arguments))
                    result.success(null)
                }
                "onActivityStarted" -> {
                    onActivityStarted?.invoke(RollaStartedActivity.fromResponse(call.arguments))
                    result.success(null)
                }
                "onActivityRemoved" -> {
                    onActivityRemoved?.invoke(RollaRemovedActivity.fromResponse(call.arguments))
                    result.success(null)
                }
                "onUiSyncCompleted" -> {
                    onUiSyncCompleted?.invoke(RollaSyncResult.fromResponse(call.arguments))
                    result.success(null)
                }
                "onBandPaired" -> {
                    onBandPaired?.invoke(RollaBandInfo.fromResponse(call.arguments))
                    result.success(null)
                }
                "onBandUnpaired" -> {
                    onBandUnpaired?.invoke(RollaBandInfo.fromResponse(call.arguments))
                    result.success(null)
                }
                "onBandConnected" -> {
                    onBandConnected?.invoke(RollaBandInfo.fromResponse(call.arguments))
                    result.success(null)
                }
                "onBandDisconnected" -> {
                    onBandDisconnected?.invoke(RollaBandInfo.fromResponse(call.arguments))
                    result.success(null)
                }
                "onPrimarySourceChanged" -> {
                    onPrimarySourceChanged?.invoke(RollaPrimarySourceChanged.fromResponse(call.arguments))
                    result.success(null)
                }
                "onGoalsChanged" -> {
                    onGoalsChanged?.invoke(RollaGoalsChanged.fromResponse(call.arguments))
                    result.success(null)
                }
                "onProfileUpdated" -> {
                    onProfileUpdated?.invoke(RollaProfileUpdated.fromResponse(call.arguments))
                    result.success(null)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        methodChannel = channel
    }

    fun configure(
        config: RollaConfiguration,
        showBackButton: Boolean,
        callback: (Result<Unit>) -> Unit
    ) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        // Prefer the latest known pair over the frozen configuration values,
        // but only while the configuration still carries the token the
        // register descends from. A different token means new host
        // credentials — send those and drop the outdated register.
        val anchorChanged = config.token != sessionAnchorToken
        val latest = if (anchorChanged) null else latestKnownTokens
        if (anchorChanged) {
            latestKnownTokens = null
            sessionAnchorToken = config.token
            anchorChangingConfigures += 1
        }

        val args = mutableMapOf<String, Any>(
            "token" to (latest?.token ?: config.token),
            "partnerId" to config.partnerId,
            "environment" to config.environment,
            "isModal" to true,
            "showBackButton" to showBackButton,
            "hideBottomNavigation" to true,
            "showOptionsButton" to config.showOptionsButton,
            "showGoalsSection" to config.showGoalsSection
        )

        config.userId?.let { args["userId"] = it }
        if (latest != null) {
            latest.refreshToken?.let { args["refreshToken"] = it }
            // The register's TTL was captured when the pair was seeded; send
            // what is left of it now so the Dart side doesn't restart the
            // full window on every presentation. Capped at the original TTL —
            // a wall clock moved backwards must not inflate it.
            latest.expiresIn?.let {
                val elapsedSeconds = ((System.currentTimeMillis() - latest.seededAtMs) / 1000L).toInt()
                val remaining = (it - elapsedSeconds).coerceAtMost(it)
                if (remaining > 0) args["tokenExpiresIn"] = remaining
            }
        } else {
            config.refreshToken?.let { args["refreshToken"] = it }
            config.tokenExpiresIn?.let { args["tokenExpiresIn"] = it }
        }
        if (config.disabledModules.isNotEmpty()) {
            args["disabledModules"] = config.disabledModules.map { it.rawValue }
        }
        if (config.disabledDataSources.isNotEmpty()) {
            args["disabledDataSources"] = config.disabledDataSources.map { it.rawValue }
        }
        config.language?.let { args["language"] = it.rawValue }
        config.branding?.toMap()?.takeIf { it.isNotEmpty() }?.let { args["branding"] = it }

        channel.invokeMethod("initialize", args, object : MethodChannel.Result {
            private fun settleAnchorChange() {
                // Floor at zero: destroy() resets the counter, and a late
                // callback from the destroyed engine must not push it negative.
                if (anchorChanged) anchorChangingConfigures = (anchorChangingConfigures - 1).coerceAtLeast(0)
            }

            override fun success(result: Any?) {
                settleAnchorChange()
                Log.d(TAG, "SDK configured successfully")
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                settleAnchorChange()
                Log.e(TAG, "SDK configuration failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                settleAnchorChange()
                Log.e(TAG, "Initialize method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("Initialize method not implemented")
                ))
            }
        })
    }

    /**
     * Ensure the Flutter engine is running and the SDK is configured, WITHOUT
     * presenting any UI. Backs the headless reads (e.g. battery), letting a host
     * call into the SDK before — or without ever — showing the SDK screen.
     *
     * If the engine is already running this re-issues [configure]. For the same
     * user the Dart side treats that as a seamless resume and does not reset.
     */
    fun ensureConfigured(
        context: Context,
        config: RollaConfiguration,
        callback: (Result<Unit>) -> Unit
    ) {
        try {
            initialize(context)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize engine for headless configure", e)
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }
        // Back button is forced on (matching show()) for native add-to-app
        // hosts: it is the user's only built-in way out of the SDK and back to
        // the host app. Tapping it routes through the "close" method channel to
        // finish the SDK Activity; without it the user would be stranded in the
        // SDK with no exit. It must be set here too, not just in show(): a
        // headless configure already mounts RollaSdkHome offscreen and the Dart
        // entry point won't rebuild it on a later show() (seamless-resume
        // early-returns once initialized), so the home tree is built once with
        // whatever this first configure passes — a warm-up-then-show() flow with
        // the button off here would present without it.
        configure(config = config, showBackButton = true, callback = callback)
    }

    /**
     * Read the connected Rolla band's battery level over the method channel.
     *
     * Resolves to a typed [RollaBatteryResult]. Every no-band, disconnected,
     * timed-out, or Bluetooth-off case comes back as success with a non-AVAILABLE
     * status; a failed Result is reserved for transport problems, such as the
     * engine not being started.
     */
    fun getBandBatteryLevel(callback: (Result<RollaBatteryResult>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("getBandBatteryLevel", null, object : MethodChannel.Result {
            override fun success(result: Any?) {
                callback(Result.success(RollaBatteryResult.fromResponse(result)))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Battery read failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.FlutterError(errorCode, errorMessage ?: "Battery read failed")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "getBandBatteryLevel method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("getBandBatteryLevel method not implemented")
                ))
            }
        })
    }

    /**
     * Query the account's paired band over the method channel.
     *
     * Resolves to a typed [RollaPairedBandResult] with zero Bluetooth
     * involvement. Paired, not-paired, and unknown outcomes are all encoded in
     * the result; a failed Result is reserved for transport problems, such as
     * the engine not being started.
     */
    fun getPairedBandInfo(callback: (Result<RollaPairedBandResult>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("getPairedBandInfo", null, object : MethodChannel.Result {
            override fun success(result: Any?) {
                callback(Result.success(RollaPairedBandResult.fromResponse(result)))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Paired-band query failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.FlutterError(errorCode, errorMessage ?: "Paired-band query failed")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "getPairedBandInfo method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("getPairedBandInfo method not implemented")
                ))
            }
        })
    }

    /**
     * Run a headless sync over the method channel.
     *
     * Resolves to a typed [RollaSyncResult]. Success, skipped, and failure
     * outcomes are all encoded in the result; a failed Result is reserved for
     * transport problems, such as the engine not being started.
     *
     * `includeSamples` is forwarded to Dart so the result's `syncedData` also
     * carries the raw sample arrays when requested.
     */
    fun syncHealthData(includeSamples: Boolean = false, callback: (Result<RollaSyncResult>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("syncHealthData", mapOf("includeSamples" to includeSamples), object : MethodChannel.Result {
            override fun success(result: Any?) {
                callback(Result.success(RollaSyncResult.fromResponse(result)))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Sync failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.FlutterError(errorCode, errorMessage ?: "Sync failed")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "syncHealthData method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("syncHealthData method not implemented")
                ))
            }
        })
    }

    fun updateToken(
        token: String,
        refreshToken: String?,
        expiresIn: Int?,
        callback: (Result<Unit>) -> Unit
    ) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        val args = mutableMapOf<String, Any>("token" to token)
        refreshToken?.let { args["refreshToken"] = it }
        expiresIn?.let { args["expiresIn"] = it }

        // If the anchor moves while this round-trip is in flight (the host
        // switched sessions), the response was evaluated by the OLD session —
        // seeding it under the new anchor would replay these tokens to the
        // wrong session on the next configure.
        val anchorAtInvoke = sessionAnchorToken

        channel.invokeMethod("updateToken", args, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "Token updated successfully")
                // Remember the pushed pair so a later configure() re-sends it
                // instead of the frozen configuration values — but only when
                // the SDK actually applied it (it ignores tokens older than
                // the pair it already holds).
                val applied = (result as? Map<*, *>)?.get("applied") as? Boolean ?: true
                if (applied && sessionAnchorToken == anchorAtInvoke) {
                    latestKnownTokens = LatestKnownTokens(
                        token = token,
                        refreshToken = refreshToken,
                        expiresIn = expiresIn,
                        seededAtMs = System.currentTimeMillis()
                    )
                }
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Token update failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "updateToken method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("updateToken method not implemented")
                ))
            }
        })
    }

    fun clearSession(callback: (Result<Unit>) -> Unit) {
        val channel = methodChannel
        if (channel == null) {
            callback(Result.failure(RollaError.EngineFailedToStart()))
            return
        }

        channel.invokeMethod("clearSession", null, object : MethodChannel.Result {
            override fun success(result: Any?) {
                Log.d(TAG, "Session cleared successfully")
                // The session's credentials are gone — forget the register so
                // the next configure() sends its configuration's own tokens.
                latestKnownTokens = null
                sessionAnchorToken = null
                callback(Result.success(Unit))
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                Log.e(TAG, "Clear session failed: $errorCode - $errorMessage")
                callback(Result.failure(
                    RollaError.InitializationFailed(errorMessage ?: "Unknown error")
                ))
            }

            override fun notImplemented() {
                Log.e(TAG, "clearSession method not implemented")
                callback(Result.failure(
                    RollaError.InitializationFailed("clearSession method not implemented")
                ))
            }
        })
    }

    fun setPresenting(value: Boolean) {
        isPresenting = value
    }

    fun getEngine(): FlutterEngine? = engine

    fun destroy() {
        methodChannel?.setMethodCallHandler(null)
        methodChannel = null
        latestKnownTokens = null
        sessionAnchorToken = null
        anchorChangingConfigures = 0
        onClose = null
        onError = null
        onTokenRefreshed = null
        onTokenExpired = null
        onActivityCompleted = null
        onActivityStarted = null
        onActivityRemoved = null
        onUiSyncCompleted = null
        onBandPaired = null
        onBandUnpaired = null
        onBandConnected = null
        onBandDisconnected = null
        onPrimarySourceChanged = null
        onGoalsChanged = null
        onProfileUpdated = null

        engine?.let {
            FlutterEngineCache.getInstance().remove(ENGINE_ID)
            it.destroy()
        }
        engine = null
        isReady = false
        isPresenting = false

        Log.d(TAG, "Flutter engine destroyed")
    }
}
