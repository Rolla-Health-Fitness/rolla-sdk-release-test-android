package app.rolla.bluetoothSdk.characteristics.data

import app.rolla.bluetoothSdk.commands.data.ActivityStatus
import app.rolla.bluetoothSdk.result.error.Error

data class ActivityControlData(
    val uuid: String,
    val success: Boolean,
    val activityStatus: ActivityStatus,
    val error: Error? = null,
    // True when this STOP originated from the band itself (spontaneous
    // 0x16 06 00 end frame), not from a host-issued stopWorkout. Defaulted
    // false so all existing call sites (start flow, error paths, commanded
    // stop) compile and behave unchanged.
    val endedByBand: Boolean = false
) {
    override fun toString(): String {
        return "ActivityControlData(uuid=$uuid, success=$success, error=$error, endedByBand=$endedByBand)"
    }
}