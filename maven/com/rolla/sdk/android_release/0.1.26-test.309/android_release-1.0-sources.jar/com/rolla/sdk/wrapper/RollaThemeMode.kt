package com.rolla.sdk.wrapper

/** Theme the SDK UI runs in: light, dark, or following the device (system). */
enum class RollaThemeMode(val rawValue: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark"),
}
