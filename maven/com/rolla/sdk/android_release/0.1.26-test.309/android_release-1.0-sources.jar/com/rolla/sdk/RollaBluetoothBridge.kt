package com.rolla.sdk

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.commands.data.ChargingState
import app.rolla.bluetoothSdk.device.BleDevice
import app.rolla.bluetoothSdk.device.DeviceConnectionState
import app.rolla.bluetoothSdk.utils.log
import com.rolla.sdk.generated.BandBatteryFlutterApi
import com.rolla.sdk.generated.BandChargingState
import com.rolla.sdk.generated.BandChargingStateFlutterApi
import com.rolla.sdk.generated.BandCommandHostAPI
import com.rolla.sdk.generated.BluetoothCapabilities
import com.rolla.sdk.generated.BluetoothDevice
import com.rolla.sdk.generated.BluetoothState
import com.rolla.sdk.generated.ConnectionState
import com.rolla.sdk.generated.DeviceType
import com.rolla.sdk.generated.FirmwareHostAPI
import com.rolla.sdk.generated.FirmwareProgressAPI
import com.rolla.sdk.generated.GpsData
import com.rolla.sdk.generated.LocationHostApi
import com.rolla.sdk.generated.RollaBandActivityApi
import com.rolla.sdk.generated.RollaBandGpsApi
import com.rolla.sdk.generated.RollaBandHealthDataHostApi
import com.rolla.sdk.generated.RollaBandWorkoutHostApi
import com.rolla.sdk.generated.RollaBluetoothFlutterApi
import com.rolla.sdk.generated.RollaBluetoothHostApi
import com.rolla.sdk.hostImpl.BandCommandHostApiImpl
import com.rolla.sdk.hostImpl.FirmwareHostApiImpl
import com.rolla.sdk.hostImpl.LocationHostApiImpl
import com.rolla.sdk.hostImpl.DevicePowerModeHandler
import com.rolla.sdk.hostImpl.RollaBandHealthDataHostApiImpl
import com.rolla.sdk.hostImpl.RollaBandWorkoutHostApiImpl
import com.rolla.sdk.hostImpl.RollaBluetoothHostApiImpl
import com.rolla.sdk.generated.DevicePowerModeFlutterApi
import com.rolla.sdk.generated.DevicePowerModeHostApi
import com.rolla.sdk.generated.PhonePedometerFlutterApi
import com.rolla.sdk.generated.PhonePedometerHostApi
import com.rolla.sdk.hostImpl.PhonePedometerHandler
import com.rolla.sdk.location.LocationManager
import io.flutter.plugin.common.BinaryMessenger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RollaBluetoothBridge(
    private val context: Context,
    private val bleManager: BleManager,
    private val locationManager: LocationManager,
    binaryMessenger: BinaryMessenger
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var flutterApi : RollaBluetoothFlutterApi = RollaBluetoothFlutterApi(binaryMessenger)
    private var activityApi: RollaBandActivityApi = RollaBandActivityApi(binaryMessenger)
    private var gpsApi: RollaBandGpsApi = RollaBandGpsApi(binaryMessenger)
    private var batteryApi: BandBatteryFlutterApi = BandBatteryFlutterApi(binaryMessenger)
    private var firmwareProgressApi: FirmwareProgressAPI = FirmwareProgressAPI(binaryMessenger)
    private var chargingStateFlutterApi: BandChargingStateFlutterApi = BandChargingStateFlutterApi(binaryMessenger)
    private var devicePowerModeFlutterApi: DevicePowerModeFlutterApi = DevicePowerModeFlutterApi(binaryMessenger)

    // Set up the host API
    private var bluetoothHostApiImpl: RollaBluetoothHostApiImpl =
        RollaBluetoothHostApiImpl(bleManager, scope)

    private var workoutHostApiImpl: RollaBandWorkoutHostApiImpl =
        RollaBandWorkoutHostApiImpl(context.applicationContext, bleManager, activityApi, scope)

    private var commandHostApiImpl: BandCommandHostApiImpl =
        BandCommandHostApiImpl(bleManager, scope, batteryApi)

    private var locationHostApiImpl: LocationHostApiImpl = LocationHostApiImpl(locationManager, scope)

    private var firmwareHostApiImpl: FirmwareHostApiImpl = FirmwareHostApiImpl(bleManager, scope)
    private var healthDataHostApiImpl: RollaBandHealthDataHostApiImpl = RollaBandHealthDataHostApiImpl(bleManager, scope)
    private var devicePowerModeHandler: DevicePowerModeHandler = DevicePowerModeHandler(context, devicePowerModeFlutterApi, scope)
    private var phonePedometerFlutterApi: PhonePedometerFlutterApi = PhonePedometerFlutterApi(binaryMessenger)
    private var phonePedometerHandler: PhonePedometerHandler = PhonePedometerHandler(context, phonePedometerFlutterApi, scope)

    init {
        RollaBluetoothHostApi.setUp(binaryMessenger, bluetoothHostApiImpl)
        RollaBandWorkoutHostApi.setUp(binaryMessenger, workoutHostApiImpl)
        BandCommandHostAPI.setUp(binaryMessenger, commandHostApiImpl)
        FirmwareHostAPI.setUp(binaryMessenger, firmwareHostApiImpl)
        LocationHostApi.setUp(binaryMessenger, locationHostApiImpl)
        RollaBandHealthDataHostApi.setUp(binaryMessenger, healthDataHostApiImpl)
        DevicePowerModeHostApi.setUp(binaryMessenger, devicePowerModeHandler)
        PhonePedometerHostApi.setUp(binaryMessenger, phonePedometerHandler)

        // Listen to device discoveries
        scope.launch {
            bleManager.getAllDevicesFlow().collect { devices ->
                val pigeonDevices = devices.map { convertToPigeonDevice(it) }
                withContext(Dispatchers.Main) {
                    flutterApi.onDevicesFound(pigeonDevices) { result ->
                        // Handle callback result if needed
                    }
                }
            }
        }

        // Listen to connection state changes
        scope.launch {
            bleManager.connectionStateChanges.collect { event ->
                withContext(Dispatchers.Main) {
                    log("RollaBluetoothBridge", "Connection state changed to ${event.second} for uuid ${event.first}")
                    when (event.second) {
                        DeviceConnectionState.CONNECTED -> {
                            flutterApi.onConnectionStateChanged(
                                event.first,
                                ConnectionState.CONNECTED
                            ) { }
                        }

                        DeviceConnectionState.DISCONNECTED -> {
                            flutterApi.onConnectionStateChanged(
                                event.first,
                                ConnectionState.DISCONNECTED
                            ) { }
                        }

                        DeviceConnectionState.CONNECTING -> {
                            flutterApi.onConnectionStateChanged(
                                event.first,
                                ConnectionState.CONNECTING
                            ) { }
                        }

                        DeviceConnectionState.DISCONNECTING -> {
                        }
                    }
                }
            }
        }

        scope.launch {
            bleManager.getHeartRateFlow().collect { heartRateData ->
                withContext(Dispatchers.Main) {
                    activityApi.onHeartRateReceived(heartRateData.heartRate.toLong()) {
                        log("RollaBluetoothBridge", "Heart rate received ${heartRateData.heartRate.toLong()}")
                    }
                }
            }
        }

        scope.launch {
            bleManager.getRunningSpeedCadenceFlow().collect { rscData ->
                withContext(Dispatchers.Main) {
                    activityApi.onRunningSpeedAndCadenceReceived(
                        rscData.instantaneousSpeed.toDouble(),
                        rscData.instantaneousCadence.toLong(),
                        rscData.calculatedSteps.toDouble() // Send calculated steps to Flutter
                    ) {
                        log("RollaBluetoothBridge",
                            "RSC: speed=${rscData.instantaneousSpeed}, " +
                                    "cadence=${rscData.instantaneousCadence}, " +
                                    "steps=${rscData.calculatedSteps}")
                    }
                }
            }
        }

        scope.launch {
            locationManager.locationFlow.collect { location ->
                withContext(Dispatchers.Main) {
                    gpsApi.onGpsDataReceived(
                        GpsData(
                            location.latitude,
                            location.longitude,
                            location.altitude,
                            location.time / 1000
                        )
                    ) {
                        log("RollaBluetoothBridge", "GPS data received ${location.latitude} ${location.longitude} ${location.altitude} ${location.time / 1000}")
                    }
                }
            }
        }

        scope.launch {
            bleManager.getRollaBandFirmwareUpdateProgressFlow().collect { firmwareState ->
                withContext(Dispatchers.Main) {
                    firmwareProgressApi.onFirmwareProgress(firmwareState.toLong()) {
                        log("RollaBluetoothBridge", "Firmware progress received $firmwareState")
                    }
                }
            }
        }

        scope.launch {
            bleManager.getRollaBandFirmwareUpdateCompletedFlow().collect {
                withContext(Dispatchers.Main) {
                    firmwareProgressApi.onFirmwareUpdateCompleted {
                        log("RollaBluetoothBridge", "Firmware update completed")
                    }
                }
            }
        }

        scope.launch {
            bleManager.getRollaBandFirmwareUpdateErrorFlow().collect { error ->
                withContext(Dispatchers.Main) {
                    firmwareProgressApi.onFirmwareUpdateError {
                        log("RollaBluetoothBridge", "Firmware update error received $error")
                    }
                }
            }
        }

        scope.launch {
            bleManager.bleStateFlow.collect { state ->
                withContext(Dispatchers.Main) {
                    flutterApi.onBluetoothStateChanged(convertToPigeonBluetoothState(state)) {
                        log("RollaBluetoothBridge", "BLE state changed to $state")
                    }
                }
            }
        }

        scope.launch {
            bleManager.getRollaBandChargingStateFlow().collect { chargingState ->
                withContext(Dispatchers.Main) {
                    chargingStateFlutterApi.onChargingStateReceived(convertToPigeonChargingState(chargingState)) { result ->
                        log("RollaBluetoothBridge", "Charging state received $chargingState")
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun convertToPigeonDevice(sdkDevice: BleDevice): BluetoothDevice {
        return BluetoothDevice(
            name = sdkDevice.getName(context),
            rssi = sdkDevice.rssi.toLong(),
            uuid = sdkDevice.getMacAddress(),
            capabilities = sdkDevice.getSubscribedTypes().map { convertToPigeonCapability(it) },
            connectionState = if (sdkDevice.isConnected()) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED,
            deviceType = convertToPigeonDeviceType(sdkDevice.getSubscribedTypes().firstOrNull())
        )
    }

    private fun convertToPigeonCapability(sdkType: app.rolla.bluetoothSdk.device.DeviceType): BluetoothCapabilities {
        return when (sdkType) {
            app.rolla.bluetoothSdk.device.DeviceType.RUNNING_SPEED_AND_CADENCE -> BluetoothCapabilities.RSC
            app.rolla.bluetoothSdk.device.DeviceType.HEART_RATE -> BluetoothCapabilities.HR
            else -> BluetoothCapabilities.HR // fallback
        }
    }

    private fun convertToPigeonDeviceType(sdkType: app.rolla.bluetoothSdk.device.DeviceType?): DeviceType {
        return when (sdkType) {
            app.rolla.bluetoothSdk.device.DeviceType.ROLLA_BAND -> DeviceType.ROLLA_BAND
            else -> DeviceType.OTHER
        }
    }

    private fun convertToPigeonBluetoothState(state: Int): BluetoothState {
        return when (state) {
            BluetoothAdapter.STATE_ON -> BluetoothState.POWERED_ON
            BluetoothAdapter.STATE_OFF -> BluetoothState.POWERED_OFF
            BluetoothAdapter.STATE_TURNING_ON -> BluetoothState.TURNING_ON
            BluetoothAdapter.STATE_TURNING_OFF -> BluetoothState.TURNING_OFF
            else -> BluetoothState.UNKNOWN
        }
    }

    private fun convertToPigeonChargingState(state: ChargingState): BandChargingState {
        val chargingState = when (state) {
            ChargingState.CHARGING -> BandChargingState.CHARGING
            ChargingState.NOT_CHARGING -> BandChargingState.NOT_CHARGING
        }
        log("RollaBluetoothBridge", "Converted charging state to $chargingState")
        return chargingState
    }

    fun cleanUp() {
        phonePedometerHandler.stop()
        scope.cancel()
        bluetoothHostApiImpl.cleanup()
        workoutHostApiImpl.cleanup()
        commandHostApiImpl.cleanup()
        firmwareHostApiImpl.cleanup()
        locationHostApiImpl.cleanup()
        healthDataHostApiImpl.cleanup()
    }
}
