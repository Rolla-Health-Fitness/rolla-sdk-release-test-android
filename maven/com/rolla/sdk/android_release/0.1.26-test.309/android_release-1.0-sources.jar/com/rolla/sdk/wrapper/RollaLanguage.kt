package com.rolla.sdk.wrapper

/**
 * SDK UI languages a host app can configure.
 *
 * Pass a value to [RollaConfiguration.language] to render the SDK in that
 * language for the Flutter engine's lifetime. The configured value replaces
 * persisted picks and the user's backend profile language.
 */
enum class RollaLanguage(val rawValue: String) {
    ENGLISH("english"),
    GERMAN("german"),
    SPANISH("spanish"),
    CROATIAN("croatian"),
    BOSNIAN("bosnian"),
    SERBIAN_LATIN("serbianLatin"),
    SERBIAN_CYRILLIC("serbianCyrillic"),
    ARABIC("arabic"),
}
