package com.rolla.sdk.wrapper

data class RollaConfiguration(
    val token: String,
    val partnerId: String,
    val refreshToken: String? = null,
    val tokenExpiresIn: Int? = null,
    val userId: String? = null,
    val environment: String = "rnd",
    val disabledModules: Set<RollaDisabledModule> = emptySet(),
    val disabledDataSources: Set<RollaDataSource> = emptySet(),
    /**
     * SDK UI language. When set, it is authoritative for the Flutter engine's
     * lifetime and replaces persisted picks and the user's backend profile
     * language. null keeps the profile-driven behavior.
     */
    val language: RollaLanguage? = null,
    val branding: RollaBranding? = null,
    val showSettingsButton: Boolean = true,
)
