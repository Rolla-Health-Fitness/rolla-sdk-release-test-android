package com.rolla.sdk.wrapper

/**
 * Whether the user's account currently has a Rolla band paired.
 *
 * This answers a **pairing-state query with zero Bluetooth** — no scan, no
 * connect, no BLE permission; it works with Bluetooth off. It says nothing
 * about the live link (see [RollaListener.onBandConnected] /
 * [RollaListener.onBandDisconnected] for that).
 */
enum class RollaPairedBandStatus(val rawValue: String) {
    /** A band is paired for this account — [RollaPairedBandResult.band] describes it. */
    BAND_PAIRED("bandPaired"),

    /** The user's profile confirms no band is paired. */
    NO_BAND_PAIRED("noBandPaired"),

    /**
     * The pairing state could not be determined — the profile was unreachable
     * (offline/timeout) and no local record exists (e.g. a fresh login while
     * offline) — or the SDK sent a status this wrapper version does not
     * recognize (forward-compat). Either way: no answer, not a guess.
     */
    UNKNOWN("unknown");

    companion object {
        /** Map a wire string ([rawValue]) to a status; unknown values map to [UNKNOWN]. */
        fun fromRawValue(raw: String?): RollaPairedBandStatus =
            entries.firstOrNull { it.rawValue == raw } ?: UNKNOWN
    }
}

/**
 * Result of [Rolla.getPairedBandInfo].
 *
 * [band] is non-null **only** when [status] is [RollaPairedBandStatus.BAND_PAIRED].
 */
data class RollaPairedBandResult(
    /** Whether a band is paired, or why that couldn't be determined. */
    val status: RollaPairedBandStatus,
    /**
     * The paired band. The MAC address is always present;
     * battery/firmware/serial are the last cached values and may be null if
     * the SDK hasn't read the band recently — use [Rolla.getBandBatteryLevel]
     * for a live battery value.
     */
    val band: RollaBandInfo? = null
) {
    /** Whether a paired [band] is present. */
    val isPaired: Boolean
        get() = status == RollaPairedBandStatus.BAND_PAIRED && band != null

    companion object {
        /**
         * Build a result from the method-channel wire map
         * `{ "status": String, "band": Map? }`. Unknown statuses map to
         * [RollaPairedBandStatus.UNKNOWN].
         */
        fun fromResponse(response: Any?): RollaPairedBandResult {
            val map = response as? Map<*, *>
                ?: return RollaPairedBandResult(RollaPairedBandStatus.UNKNOWN, null)
            val status = RollaPairedBandStatus.fromRawValue(map["status"] as? String)
            val band = (map["band"] as? Map<*, *>)?.let { RollaBandInfo.fromResponse(it) }
            return RollaPairedBandResult(
                status = status,
                band = if (status == RollaPairedBandStatus.BAND_PAIRED) band else null
            )
        }
    }
}
