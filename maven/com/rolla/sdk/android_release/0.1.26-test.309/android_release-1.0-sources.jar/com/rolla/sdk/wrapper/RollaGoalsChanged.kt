package com.rolla.sdk.wrapper

/** One goal as seen by the host event listener. */
data class RollaGoalInfo(
    val id: Int,
    val name: String,
    val enabled: Boolean
) {
    companion object {
        internal fun fromMap(map: Map<*, *>): RollaGoalInfo = RollaGoalInfo(
            id = (map["id"] as? Number)?.toInt() ?: 0,
            name = map["name"] as? String ?: "",
            enabled = map["enabled"] as? Boolean ?: false
        )
    }
}

/**
 * Payload of [RollaListener.onGoalsChanged].
 *
 * Goals are committed as a batch: the user toggles any number of goals in the
 * SDK UI and saves once. One event fires per successful save, carrying both
 * the delta ([changedGoals] — what the user toggled, with their new enabled
 * values) and the resulting state ([enabledGoals] — every goal enabled after
 * the save), so hosts need no query API to know the current set.
 */
data class RollaGoalsChanged(
    val changedGoals: List<RollaGoalInfo>,
    val enabledGoals: List<RollaGoalInfo>
) {
    companion object {
        /** Build from the method-channel wire map. */
        fun fromResponse(response: Any?): RollaGoalsChanged {
            val map = response as? Map<*, *> ?: emptyMap<Any, Any>()
            val changed = (map["changedGoals"] as? List<*>)
                ?.mapNotNull { (it as? Map<*, *>)?.let(RollaGoalInfo::fromMap) } ?: emptyList()
            val enabled = (map["enabledGoals"] as? List<*>)
                ?.mapNotNull { (it as? Map<*, *>)?.let(RollaGoalInfo::fromMap) } ?: emptyList()
            return RollaGoalsChanged(changedGoals = changed, enabledGoals = enabled)
        }
    }
}
