package com.rolla.sdk.wrapper

/** Theme the SDK UI starts in until the user picks one in SDK settings. */
enum class RollaThemeMode(val rawValue: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark"),
}
