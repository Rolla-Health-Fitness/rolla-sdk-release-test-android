package com.rolla.sdk.hostImpl

import android.annotation.SuppressLint
import android.content.Context
import app.rolla.bluetoothSdk.BleManager
import app.rolla.bluetoothSdk.commands.data.ActivityType
import com.rolla.sdk.ble.BleForegroundService
import com.rolla.sdk.extensions.collectFlowWithCallback
import com.rolla.sdk.extensions.collectNextPageFlowWithCallback
import com.rolla.sdk.extensions.executeCommandOperation
import com.rolla.sdk.generated.BandActivityType
import com.rolla.sdk.generated.RollaBandMotionPoint
import com.rolla.sdk.generated.RollaBandMotionSyncResponse
import com.rolla.sdk.generated.RollaBandWorkoutHostApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class RollaBandWorkoutHostApiImpl(
    private val context: Context,
    private val bleManager: BleManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : RollaBandWorkoutHostApi {

    companion object {
        private const val TAG = "RollaBandWorkoutHostApiImpl"
    }

    private val startActivityCallbacks: MutableMap<String, (Result<Unit>) -> Unit> = ConcurrentHashMap()
    private val stopActivityCallbacks: MutableMap<String, (Result<Unit>) -> Unit> = ConcurrentHashMap()
    private val motionDataCallbacks: MutableMap<String, (Result<RollaBandMotionSyncResponse>) -> Unit> = ConcurrentHashMap()

    init {
        collectStartActivityFlow()
        collectStopActivityFlow()
        collectMotionDataFlow()
    }

    override fun startWorkout(
        uuid: String,
        type: BandActivityType,
        callback: (Result<Unit>) -> Unit
    ) {
        // Start foreground service for BLE-only workouts (e.g., cardio)
        if (type == BandActivityType.WORKOUT) {
            BleForegroundService.start(context)
        }

        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = startActivityCallbacks,
            callback = callback,
            operationName = "startWorkout",
            operation = {
                bleManager.startBandActivity(uuid, convertToSdkActivityType(type))
            },
            tag = TAG
        )
    }

    override fun stopWorkout(
        uuid: String,
        type: BandActivityType,
        callback: (Result<Unit>) -> Unit
    ) {
        // Stop foreground service for BLE-only workouts (e.g., cardio)
        if (type == BandActivityType.WORKOUT) {
            BleForegroundService.stop(context)
        }

        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = stopActivityCallbacks,
            callback = callback,
            operationName = "stopWorkout",
            operation = {
                bleManager.stopBandActivity(uuid, convertToSdkActivityType(type))
            },
            tag = TAG
        )
    }

    override fun getMotionData(
        uuid: String,
        fromTimestamp: Long,
        callback: (Result<RollaBandMotionSyncResponse>) -> Unit
    ) {
        executeCommandOperation(
            scope = scope,
            uuid = uuid,
            callbacks = motionDataCallbacks,
            callback = callback,
            operationName = "getMotionData",
            operation = {
                bleManager.readBandMotionData(uuid, fromTimestamp)
            },
            tag = TAG
        )
    }

    override fun setActivityRestorePending(
        pending: Boolean,
        callback: (Result<Unit>) -> Unit
    ) {
        scope.launch {
            try {
                bleManager.setActivityRestorePending(pending)
                if (!pending) {
                    // User chose save/discard (or no activity was found). Execute the
                    // deferred stop so the band exits activity mode now.
                    val connectedUuid = bleManager.getConnectedBandUuid()
                    if (connectedUuid != null) {
                        bleManager.forceStopBandActivity(connectedUuid, ActivityType.RUN)
                    }
                }
                withContext(Dispatchers.Main) { callback(Result.success(Unit)) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { callback(Result.failure(e)) }
            }
        }
    }

    override fun notifyActivityResumedFromRestore(
        uuid: String,
        type: BandActivityType,
        callback: (Result<Unit>) -> Unit
    ) {
        scope.launch {
            try {
                bleManager.markBandActivityAsActive(uuid)
                withContext(Dispatchers.Main) { callback(Result.success(Unit)) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { callback(Result.failure(e)) }
            }
        }
    }

    private fun collectStartActivityFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandStartActivityFlow(),
            callbacks = startActivityCallbacks,
            tag = TAG,
            dataName = "Start activity",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { },
            onSuccess = {
                bleManager.setBandWristbandParams(it.uuid, true)
            }
        )
    }

    private fun collectStopActivityFlow() {
        collectFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandStopActivityFlow(),
            callbacks = stopActivityCallbacks,
            tag = TAG,
            dataName = "Stop activity",
            getUuid = { it.uuid },
            getError = { it.error },
            getSuccessValue = { },
            onSuccess = {
                bleManager.setBandWristbandParams(it.uuid, false)
            }
        )
    }

    private fun collectMotionDataFlow() {
        collectNextPageFlowWithCallback(
            scope = scope,
            flow = bleManager.getRollaBandMotionDataFlow(),
            callbacks = motionDataCallbacks,
            tag = TAG,
            dataName = "Motion data",
            getUuid = { it.uuid },
            isDataEnd = { !it.hasMoreData && it.isEndOfData },
            getSuccessValue = { convertToPigeonMotionData(it) }
        )
    }

    private fun convertToPigeonMotionData(motionData: app.rolla.bluetoothSdk.characteristics.data.MotionData): RollaBandMotionSyncResponse {
        val motionPoints = motionData.motionList.map { motion ->
            RollaBandMotionPoint(
                timestamp = motion.timestamp,
                heartRate = motion.heartRate.toLong(),
                spm = motion.spm.toLong()
            )
        }
        return RollaBandMotionSyncResponse(motionPoints = motionPoints)
    }

    private fun convertToSdkActivityType(pigeonType: BandActivityType): ActivityType {
        return when (pigeonType) {
            BandActivityType.RUN -> ActivityType.RUN
            BandActivityType.CYCLING -> ActivityType.CYCLING
            BandActivityType.BADMINTON -> ActivityType.BADMINTON
            BandActivityType.FOOTBALL -> ActivityType.FOOTBALL
            BandActivityType.TENNIS -> ActivityType.TENNIS
            BandActivityType.YOGA -> ActivityType.YOGA
            BandActivityType.MEDITATION -> ActivityType.MEDITATION
            BandActivityType.DANCE -> ActivityType.DANCE
            BandActivityType.BASKETBALL -> ActivityType.BASKETBALL
            BandActivityType.WALK -> ActivityType.WALK
            BandActivityType.WORKOUT -> ActivityType.WORKOUT
            BandActivityType.CRICKET -> ActivityType.CRICKET
            BandActivityType.HIKING -> ActivityType.HIKING
            BandActivityType.AEROBICS -> ActivityType.AEROBICS
            BandActivityType.PING_PONG -> ActivityType.PING_PONG
            BandActivityType.ROPE_JUMP -> ActivityType.ROPE_JUMP
            BandActivityType.SIT_UPS -> ActivityType.SIT_UPS
            BandActivityType.VOLLEYBALL -> ActivityType.VOLLEYBALL
        }
    }

    fun cleanup() {
        startActivityCallbacks.clear()
        stopActivityCallbacks.clear()
        motionDataCallbacks.clear()
        scope.cancel()
    }

}