package com.rolla.sdk.wrapper

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class RollaFlutterActivity : FlutterActivity() {

    companion object {
        @Volatile
        internal var onDismiss: ((RollaCloseReason) -> Unit)? = null

        @Volatile
        private var pendingCloseReason: RollaCloseReason? = null

        @Volatile
        private var currentInstance: RollaFlutterActivity? = null

        internal fun setPendingCloseReason(reason: RollaCloseReason) {
            pendingCloseReason = reason
        }

        internal fun clearCallbacks() {
            onDismiss = null
            pendingCloseReason = null
        }

        internal fun finishCurrent() {
            currentInstance?.finish()
        }
    }

    private var didNotifyDismiss = false
    private var backPressedDuringSession = false

    override fun getCachedEngineId(): String = RollaEngineManager.ENGINE_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentInstance = this
        didNotifyDismiss = false
        backPressedDuringSession = false
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        backPressedDuringSession = true
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        currentInstance = null
        notifyDismissOnce()
    }

    override fun finish() {
        if (pendingCloseReason == null && backPressedDuringSession) {
            pendingCloseReason = RollaCloseReason.HostNavigationBack
        }
        super.finish()
    }

    private fun notifyDismissOnce() {
        if (didNotifyDismiss) return
        didNotifyDismiss = true

        val reason = pendingCloseReason ?: RollaCloseReason.HostModalDismiss
        pendingCloseReason = null

        onDismiss?.invoke(reason)
        onDismiss = null
    }
}
