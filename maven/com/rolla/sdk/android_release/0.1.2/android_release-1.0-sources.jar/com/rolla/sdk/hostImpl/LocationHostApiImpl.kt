package com.rolla.sdk.hostImpl

import com.rolla.sdk.extensions.executeOperation
import com.rolla.sdk.generated.BandActivityType
import com.rolla.sdk.generated.LocationHostApi
import com.rolla.sdk.location.LocationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class LocationHostApiImpl(
    private val locationManager: LocationManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : LocationHostApi {

    companion object {
        private const val TAG = "LocationHostApiImpl"
    }

    override fun requestAlwaysLocationPermission(callback: (Result<Unit>) -> Unit) {
        callback(Result.success(Unit))
    }

    override fun startLocationTracking(type: BandActivityType, callback: (Result<Unit>) -> Unit) {
        executeOperation(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Starting location tracking for activity type: $type",
            operation = {
                locationManager.startLocationUpdates()
            },
            onSuccess = { }
        )
    }

    override fun stopLocationTracking(callback: (Result<Unit>) -> Unit) {
        executeOperation(
            scope = scope,
            callback = callback,
            tag = TAG,
            operationName = "Stopping location tracking",
            operation = {
                locationManager.stopLocationUpdates()
            },
            onSuccess = { }
        )
    }

    fun cleanup() {
        scope.cancel()
    }
}
