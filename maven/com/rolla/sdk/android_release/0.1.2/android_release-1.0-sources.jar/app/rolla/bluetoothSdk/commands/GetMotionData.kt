package app.rolla.bluetoothSdk.commands

import app.rolla.bluetoothSdk.characteristics.data.MotionData
import app.rolla.bluetoothSdk.commands.data.Motion
import app.rolla.bluetoothSdk.commands.data.MotionRecord
import app.rolla.bluetoothSdk.utils.log
import app.rolla.bluetoothSdk.utils.toBcdTime
import app.rolla.bluetoothSdk.utils.toEpochMilliSeconds
import app.rolla.bluetoothSdk.utils.toIntLE
import app.rolla.bluetoothSdk.utils.toPositionedInt

class GetMotionData : Command<MotionData> {

    private var motionList: MutableList<Motion> = mutableListOf()
    private var fromTimestamp: Long = 0
    private var nextPage = false

    companion object {
        const val TAG = "GetMotionData"
        private const val NEXT_PAGE_FLAG = 0x02.toByte()
        private const val FIRST_PAGE_FLAG = 0x00.toByte()
        private const val RECORD_SIZE = 14
        private const val DATA_NUMBER_OFFSET = 1
        private const val BCD_TIME_OFFSET = 3
        private const val HEART_RATE_OFFSET = 9
        private const val SPM_OFFSET = 10
        private const val PAGE_SIZE = 50 * 17
        private const val END_OF_DATA_MARKER = 0xff.toByte()
    }

    fun setFromTimestamp(timestamp: Long) {
        this.fromTimestamp = timestamp
        motionList.clear()
    }

    fun setIsNextPage(nextPage: Boolean) {
        this.nextPage = nextPage
    }

    override fun getId(): Byte = 0x77.toByte()

    override fun bytesToWrite(): ByteArray {
        return createCommandBytes {
            this[1] = if (nextPage) NEXT_PAGE_FLAG else FIRST_PAGE_FLAG
        }
    }

    override fun read(data: ByteArray): MotionData {
        log(TAG, "Motion data ${data.contentToString()}")

        val recordCount = data.size / RECORD_SIZE
        if (recordCount == 0) {
            return createMotionData(isEndOfData = true, hasMoreData = false)
        }

        for (i in 0 until recordCount) {
            val motionRecord = parseMotionRecord(data, i)
            processMotionRecord(motionRecord)

            if (shouldReturnPage(motionRecord.dataNumber)) {
                return createMotionData(isEndOfData = true, hasMoreData = motionRecord.timeInMilliseconds > fromTimestamp)
            }
        }
        val endOfData = isEndOfData(data)
        return createMotionData(isEndOfData = endOfData, hasMoreData = !endOfData)
    }

    private fun parseMotionRecord(data: ByteArray, recordIndex: Int): MotionRecord {
        val offset = recordIndex * RECORD_SIZE
        val dataNumber = data.toIntLE(DATA_NUMBER_OFFSET + offset, 2)
        val bcdTime = data.toBcdTime(BCD_TIME_OFFSET + offset)
        val heartRate = data[HEART_RATE_OFFSET + offset].toPositionedInt(0)

        val spm = data.toIntLE(SPM_OFFSET + offset, 4)
        
        val timeInMs = bcdTime.toEpochMilliSeconds()

        return MotionRecord(dataNumber, bcdTime, heartRate, spm, timeInMs, offset)
    }

    private fun processMotionRecord(record: MotionRecord) {
        if (shouldAddMotion(record.timeInMilliseconds)) {
            motionList.add(Motion(record.timeInMilliseconds, record.heartRate, record.spm))
        }
        logMotionRecord(record)
    }

    private fun shouldAddMotion(timestamp: Long): Boolean {
        return timestamp > fromTimestamp
    }

    private fun logMotionRecord(record: MotionRecord) {
        log(TAG, "Data Number: ${record.dataNumber}, Date: ${record.bcdTime.toDateString()}, " +
                "HR: ${record.heartRate}, SPM: ${record.spm}")
    }

    private fun shouldReturnPage(dataNumber: Int): Boolean {
        return (dataNumber + 1) % PAGE_SIZE == 0
    }

    private fun createMotionData(isEndOfData: Boolean, hasMoreData: Boolean): MotionData {
        return MotionData(
            isEndOfData = isEndOfData,
            hasMoreData = hasMoreData,
            motionList = ArrayList(motionList)
        )
    }

    private fun isEndOfData(data: ByteArray): Boolean {
        return data.lastOrNull() == END_OF_DATA_MARKER
    }
}

